package com.fet.estore.api.controller.helper.Impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fet.estore.api.controller.helper.FlowControlHelper;
import com.fet.estore.core.bean.FlowControlBean;
import com.fet.estore.core.bean.FlowRuleBean;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.constant.SystemConstant;
import com.fet.estore.core.dao.ICfgFlowControlDAO;
import com.fet.estore.core.dao.base.PropertiesDAO;
import com.fet.estore.core.dao.newstore.NActivityDAO;
import com.fet.estore.core.enums.CredentialTypeEnum;
import com.fet.estore.core.enums.FlowTypeEnum;
import com.fet.estore.core.enums.OrderFlowEnum;
import com.fet.estore.core.model.Activity;
import com.fet.estore.core.model.CfgFlowControl;
import com.fet.estore.core.model.Properties;
import com.fet.estore.core.service.shopping.NPromotionService;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;

@Service
@Transactional
public class FlowControlHelperImpl implements FlowControlHelper {

    @Autowired
    private ICfgFlowControlDAO cfgFlowControlDAO;
    @Autowired
	private NActivityDAO activityDAO;
    @Autowired
	private PropertiesDAO propertiesDAO;
    @Autowired
    private NPromotionService nPromotionService;

//	private Map<OrderFlowEnum, FlowRuleBean> getFlowRule(String flowType) {
//		return getFlowRule(flowType, null);
//	}

    /**
     * 用流程類型取得該流程的驗證規則<br>
     * Example: {OrderFlowEnum.PRODUCT_DETAIL: [], OrderFlowEnum.ORDER_LIST: [FlowRuleBean]}
     * @param flowType 流程類型
     * @return
     */
    private Map<OrderFlowEnum, FlowRuleBean> getFlowRule(FlowTypeEnum flow) {

        Map<OrderFlowEnum, FlowRuleBean> flowMap = new LinkedHashMap<>();
        List<CfgFlowControl> flowControlItems = cfgFlowControlDAO.findByFlowType(flow);
        
        if(flowControlItems != null ) {
        	flowControlItems.stream()
                            .filter(flowControlItem -> StringUtils.isNotBlank(flowControlItem.getStepId()))
                            .map(flowControlItem -> buildRuleBean(flowControlItem))
                            .filter(ruleBean -> ruleBean.getRuleEnum() != null)
                            .forEach(ruleBean -> flowMap.put(ruleBean.getRuleEnum(), ruleBean));
        }
        return flowMap;
    }

    // 取得上傳模式
    private CredentialTypeEnum getCredentialType(Long activityId) {
    	try {
			if (activityId == null || propertiesDAO.isNormalAct(activityId)) {
				// 一般賣場（ activity id 為 null 或 給的是一般賣場活動 id 時視為一般賣場）
				Properties properties = propertiesDAO.findByName(SystemConstant.CREDENTIAL_TYPE);
				if (properties != null) {
					return CredentialTypeEnum.getBtValue(properties.getContent());
				}
			} else {
				// 秘密賣場
				Activity activity = activityDAO.findById(activityId);
				if (activity != null) {
					return CredentialTypeEnum.getBtValue(activity.getCredentialType());
				}
			}
			LogUtil.warn("DB 取不出證件上傳模式，預設給「3.顧客2擇1」");
			return CredentialTypeEnum.PICK_ONE_OF_TWO; // 取不出來時預設給二擇一
		} catch(Exception e) {
    		LogUtil.error(e);
    		LogUtil.warn("DB 取不出證件上傳模式，預設給「3.顧客2擇1」");
    		return CredentialTypeEnum.PICK_ONE_OF_TWO; // 取不出來時預設給二擇一
		}
	}

	private FlowRuleBean buildRuleBean(CfgFlowControl flowControlItem) {
		
		FlowRuleBean flowRule = new FlowRuleBean();
		
		String stepFlow = flowControlItem.getStepFlow();
		String stepId = flowControlItem.getStepId();
		
		List<OrderFlowEnum> stepFlowList;

		if (StringUtil.isEmpty(stepFlow)) {
			stepFlowList = new ArrayList<>();
		} else {
		    stepFlowList = Arrays.stream(stepFlow.split(","))
                                 .map(flowId -> flowIdToEnum(flowId))
                                 .filter(Objects::nonNull)
                                 .collect(Collectors.toList());
		}

	    flowRule.setRuleEnum(flowIdToEnum(stepId));
	    flowRule.setCompleteFlow(flowControlItem.isCompleteFlow());
	    flowRule.setFinishPage(flowControlItem.isFinishPage());
	    flowRule.setRuleList(stepFlowList);

		return flowRule;
	}

	private OrderFlowEnum flowIdToEnum(String flowId) {
		try {
			return OrderFlowEnum.getByFlowId(flowId);
		} catch (Exception e) {
			LogUtil.warn("[FlowControlHelperImpl] 讀取到規則Id '{}', 無法轉換為 OrderFlowEnum, 忽略此值", flowId);
		}
		return null;
	}

    /**
     * 帶入由FlowControlHelper.getFlowRule產出的驗證規則、當前流程、session內流程歷程<br>
     * 驗證此次訪問是否合法
     * @param flowControlBean 驗證規則
     * @param currentStep 流程歷程
     * @return
     */
    private boolean validate(FlowControlBean flowControlBean, OrderFlowEnum currentStep) {

    	FlowRuleBean flowRuleBean = flowControlBean.getRuleMap().get(currentStep);

        if (flowControlBean.isCompleteFlow()) {
        	if (flowRuleBean.isFinishPage()) {
        	// 通過驗證，但仍需檢核 Rule list	
//        		return true;
        	} else {
        		return false;
        	}
        }
    	
        boolean isPass = true;
        
        List<OrderFlowEnum> currentFlowRule = flowRuleBean.getRuleList();
        List<OrderFlowEnum> passedFlow = flowControlBean.getPassedFlow();
        
        if (currentFlowRule == null || passedFlow == null || passedFlow.size() < currentFlowRule.size()) {
        	return false;
        }
        
        for(int i = 0 ; i < currentFlowRule.size() ; i++) {
            if(currentFlowRule.get(i) != passedFlow.get(i)) {
                isPass = false;
                break;
            }
        }
        return isPass;
    }

	/** 
	 * 初始化流程控制器並取得流程控制物件
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-28
	 * @param flowType
	 * @return
	 */
	@Override
	public FlowControlBean initFlowControl(OrderHelper orderHelper) {

		String flowType = orderHelper.getOrderType();
		Long activityId = orderHelper.getActivityId();
		
		LogUtil.info("initFlowControl - start - 初始化流程 -> OrderType : {} , activityId: {} ", flowType, activityId);
		
		final FlowTypeEnum flow;

		CredentialTypeEnum credentialType = getCredentialType(activityId);

		// DB 設定強制不上傳
		if (credentialType == CredentialTypeEnum.UPLOAD_AFTERWARDS) {
			LogUtil.info("initFlowControl - start - 初始化流程:DB 設定不需上傳證件 ");
			flow = FlowTypeEnum.NO_UPLOAD;
			
		} else {
			switch(flowType) {
			case "LC":
			case "LH":
				// 一般續約 學生專案/EBU -> 要上傳
				boolean isStudent = nPromotionService.isStudentPromo(orderHelper.getOnsalePromoListId());
				boolean isEbu = orderHelper.isEbu();
				LogUtil.info("initFlowControl - start - 初始化流程:續約案 -> isStudent : {}, isEbu : {} ", isStudent, isEbu);
				flow = isEbu || isStudent ? FlowTypeEnum.FULL : FlowTypeEnum.NO_UPLOAD;
				break;
			case "DA":
				// 單買不上傳
				flow = FlowTypeEnum.NO_UPLOAD;
				break;
			default:
				// 一般賣場GA/NP 要上傳
				flow = FlowTypeEnum.FULL;
			}
		}
		
		return initFlowControl(flow);
	}
	
	
	/** 
	 * 初始化流程控制器並取得流程控制物件
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-10-29
	 * @param flow
	 * @return
	 */
	@Override
	public FlowControlBean initFlowControl(FlowTypeEnum flow) {

		LogUtil.info(""); // 塞空行
		LogUtil.info("initFlowControl - start - 初始化流程 -> flowType : {} ", flow.getFlowType());
		FlowControlBean flowControlBean = new FlowControlBean();
		
		flowControlBean.setRuleMap(this.getFlowRule(flow));
		flowControlBean.setPassedFlow(new ArrayList<>());

		logFlowRule(flowControlBean, flow.getFlowType());
		
		LogUtil.info("initFlowControl - end => passedFlow : {}", logOrderFlowEnums(flowControlBean.getPassedFlow()));
		return flowControlBean;
	}

    /**
     * 驗證此次訪問是否合法，並更新已通過的流程清單
     * 
     * @description
     * @author Phil.lin
     * @date 2020-08-28
     * @param flowControlBean
     * @param goal
     * @return
     */
	@Override
    public boolean checkVisit(FlowControlBean flowControlBean, OrderFlowEnum goal) {
		
		if(flowControlBean == null || flowControlBean.getRuleMap() == null) {
			LogUtil.warn("check visit error : FlowControlBean or RuleMap is null !!");
			return false;
		}
		
    	FlowRuleBean flowRuleBean = flowControlBean.getRuleMap().get(goal);
    	
    	if(flowRuleBean == null) {
			LogUtil.warn("check visit error : FlowRule {} is not exist !!", goal.getFlowId());
			return false;
    	}
    	
		LogUtil.info(" ");// 塞空行
		LogUtil.info("Check Visit Step: {} {}, FlowRule {} with {} {}",
    			goal.getFlowId(), 
    			logFinishPage(flowRuleBean),
    			logFlowEnums(flowRuleBean),
    			logOrderFlowEnums(flowControlBean.getPassedFlow()),
    			logCompleteFlow(flowControlBean));

    	final boolean result ;
    	
    	if(validate(flowControlBean, goal)) {
    		
	    	List<OrderFlowEnum> resetRule = flowRuleBean.getRuleList();
	    	
	    	flowControlBean.setPassedFlow(resetRule.stream().collect(Collectors.toList()));

    		result = true;
    	} else {

    		result = false;
    	}
    	
    	LogUtil.info(" => {}. Visit step : {}, => passedFlow : {} {}",
    			result ? "OK": "Reject",
    			goal.getFlowId(),
    			logOrderFlowEnums(flowControlBean.getPassedFlow()),
				logCompleteFlow(flowControlBean));
    	LogUtil.info(" ");// 塞空行
    	return result;
    }

	/**
	 * 標註已完成流程
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-28
	 * @param flowControlBean
	 * @param goal
	 * @return
	 */
	@Override
	public boolean completeStep(FlowControlBean flowControlBean, OrderFlowEnum goal) {
		
		if(flowControlBean == null || flowControlBean.getRuleMap() == null) {
			LogUtil.warn("complete step error : FlowControlBean or RuleMap is null !!");
			return false;
		}
		
		FlowRuleBean flowRuleBean = flowControlBean.getRuleMap().get(goal);
		
		LogUtil.info(" ");// 塞空行
		LogUtil.info("Start Complete Step : {} {}, FlowRule {} with {}",
    			goal.getFlowId(), 
    			logCompleteFlow(flowRuleBean),
    			logFlowEnums(flowRuleBean),
    			logOrderFlowEnums(flowControlBean.getPassedFlow()));
    	
    	final boolean result;
    	
		if(validate(flowControlBean, goal)) {
			flowControlBean.getPassedFlow().add(goal);
			
			if (flowRuleBean.isCompleteFlow()) {
				flowControlBean.setCompleteFlow(true);
			}
			
			result = true;
		} else {

			result = false;
		}
		
		LogUtil.info(" => {}. Goal step : {}, => passedFlow : {} {}",
				result ? "OK": "Reject",
				goal.getFlowId(),
				logOrderFlowEnums(flowControlBean.getPassedFlow()),
				logCompleteFlow(flowControlBean));
		LogUtil.info(" ");// 塞空行
		return result;
	}
	
	private String logOrderFlowEnums(List<OrderFlowEnum> enumList) {
		if (enumList != null) {
			return StringUtil.join(enumList.stream().map(e->e.getFlowId()).collect(Collectors.toList()));
		}
		return "!!! FLOW DATA IS NULL !!!";
	}
	
	private String logFlowEnums(FlowRuleBean bean) {
		return logOrderFlowEnums(bean.getRuleList());
	}

	private String logFinishPage(FlowRuleBean bean) {
		return bean.isFinishPage() ? "(Finish Page)" : "";
	}

	private String logCompleteFlow(FlowRuleBean bean) {
		return bean.isCompleteFlow() ? "(Flow Complete)" : "";
	}
	
	private String logCompleteFlow(FlowControlBean bean) {
		return bean.isCompleteFlow() ? "(Flow Complete)" : "";
	}
	
    private void logFlowRule(FlowControlBean flowControlBean, String flowType) {

		LogUtil.info("RuleMap [{}]: ", flowType);
		flowControlBean.getRuleMap().entrySet().forEach(o->{
			LogUtil.info("{} -> {}  {}{}",
					     o.getKey().getFlowId(), 
					     logFlowEnums(o.getValue()),
					     logCompleteFlow(o.getValue()),
					     logFinishPage(o.getValue()));
		});

    }
}
