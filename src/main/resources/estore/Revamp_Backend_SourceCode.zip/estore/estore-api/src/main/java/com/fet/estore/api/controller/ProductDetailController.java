package com.fet.estore.api.controller;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.httpclient.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.ActivityDataHelper;
import com.fet.estore.api.controller.helper.CartDataHelper;
import com.fet.estore.api.controller.helper.CrmDataHelper;
import com.fet.estore.api.controller.helper.FlowControlHelper;
import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.api.controller.helper.SessionMsisdnHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.ActivityHelper;
import com.fet.estore.core.bean.Cart;
import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.bean.ExtraBuyOptionBean;
import com.fet.estore.core.bean.FlowControlBean;
import com.fet.estore.core.bean.GiftBean;
import com.fet.estore.core.bean.MsisdnFlow;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.ProductDetailInfo;
import com.fet.estore.core.bean.ProductDetailRenewalInfo;
import com.fet.estore.core.bean.ProductInfo;
import com.fet.estore.core.bean.ReservationOrderForm;
import com.fet.estore.core.bean.ReservationOrderReturn;
import com.fet.estore.core.bean.SelectMsisdn;
import com.fet.estore.core.bean.bo.GetProductInfoInputBO;
import com.fet.estore.core.bean.req.MsisdnReq;
import com.fet.estore.core.bean.req.ProductDetailReq;
import com.fet.estore.core.bean.req.ReservationOrderReq;
import com.fet.estore.core.bean.req.SubmitOrderReq;
import com.fet.estore.core.bean.vo.OrderValidationResultVO;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.constant.SystemConstant;
import com.fet.estore.core.enums.OrderFlowEnum;
import com.fet.estore.core.enums.OrderTypeEnum;
import com.fet.estore.core.enums.ValidationResultEnum;
import com.fet.estore.core.exception.OrderValidationException;
import com.fet.estore.core.facade.ICommonFacade;
import com.fet.estore.core.facade.IGetMsisdnFacade;
import com.fet.estore.core.facade.IProductDetailFacade;
import com.fet.estore.core.facade.IValidationFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.DataMaskerUtil;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;
import com.google.gson.Gson;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-06
 * @description
 */
@RestController
@RequestMapping("/productDetail")
@Tag(name = "Product Detail APIs")
public class ProductDetailController implements IBaseAct, OrderDataHelper, CrmDataHelper, CartDataHelper, ActivityDataHelper, SessionMsisdnHelper {

	@Autowired
	private ICommonFacade commonFacadeImpl;
	@Autowired
	private IProductDetailFacade productDetailFacadeImpl;
	@Autowired
	private IGetMsisdnFacade getMsisdnFacadeImpl;
	@Autowired
	private FlowControlHelper flowControlHelper;
	@Autowired
	@Qualifier("IValidationFacade")
	private IValidationFacade validationFacadeImpl;

	/**
	 *  商品明細頁 - 初始化資料包
	 *
	 * @description
	 * @author Ted.Hsieh
	 * @date 2020-08-11
	 * @return
	 * @throws java.sql.SQLException
	 */
	@Operation(summary = "取得商品明細頁初始化資訊", description = "取得商品明細頁所需資訊，包含")
	@RequestMapping(path = {"/init"}, method = {RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult<ProductDetailInfo> getProductDetailInitData(
			HttpServletRequest req,
			@RequestParam(name = "aliasUrl", required = false) String aliasUrl,
			@RequestParam(name = "mainPageFetNo", required = false) String fetNo,
			@RequestParam(name = "isRenewal", required = false) Boolean isRenewal,
			@RequestParam(name = "isActivity", required = false) Boolean isActivity) {

		LogUtil.info("getProductDetailInitData() - start");

		ProductDetailInfo productDetailInfo = new ProductDetailInfo();

		Long actId = null;
		String activityOrderType = null;
		//判斷是否為秘密賣場
		if(isActivity != null && isActivity){
			ActivityHelper activityHelper = getActivityHelper(req);
			if(activityHelper != null){
				actId = activityHelper.getActivityId();
				activityOrderType = activityHelper.getOrderType();
				productDetailInfo.setIsEmployeeAct(activityHelper.isEmployeeAct());
			}
		} else {
			removeActivityHelper(req);
		}

		GetProductInfoInputBO getProductInfoInputBO = new GetProductInfoInputBO();
		getProductInfoInputBO.setAliasUrl(aliasUrl);
		getProductInfoInputBO.setFetNo(fetNo);
		getProductInfoInputBO.setFromRenewal(isRenewal);
		getProductInfoInputBO.setActId(actId);
		getProductInfoInputBO.setActivityOrderType(activityOrderType);

		try{
			//取得商品詳細資訊
			ProductInfo productInfo = productDetailFacadeImpl.getProductInfo(getProductInfoInputBO);
			if(productInfo != null){
				if(productInfo.getProductDetail() != null && productInfo.getProductDetail().getColors().size() > 0){
					productDetailInfo.setProductDetail(productInfo.getProductDetail());
					productDetailInfo.setSpec(productInfo.getDescription());
				}else {
					//2020-09-17 Ted.Hsieh 續約館會篩選料號,可能會沒有任何東西可以選
					LogUtil.error("商品明細頁初始化失敗 -- 商品資料有誤或無可選料號");
					return buildResult(ReturnCode.RTN_CODE_CAN_NOT_FOUND_PAY_TYPE, ReturnCode.RTN_MSG_CAN_NOT_FOUND_PAY_TYPE, productDetailInfo);
				}
			}

			//如果來自續約館則取得門號資訊和前端用的flag
			if(isRenewal != null && isRenewal){
				CrmData crmData = getCustomerData(req);
				ProductDetailRenewalInfo renewalInfo = new ProductDetailRenewalInfo();
				renewalInfo.setFromRenewal(true); //前端null為false因此這邊有進直接給true
				renewalInfo.setMsisdn(DataMaskerUtil.doMask(crmData.getMsisdn(), DataMaskerUtil.MaskerType.Mobile));
				renewalInfo.setMobileGenerationCode(crmData.getMobileGenerationCode());
				productDetailInfo.setRenewalInfo(renewalInfo);
			}

			//取得麵包屑
			if(productDetailInfo != null && productDetailInfo.getProductDetail() != null){
				String entrenceType = "";
				if(isRenewal != null && isRenewal){
					entrenceType = "RENEWAL";
				}
				if(actId != null){
					entrenceType = "ACTIVITY";
				}
				productDetailInfo.setBreadcrumbs(this.commonFacadeImpl.getBreadCrumb(productDetailInfo, entrenceType));
			}
		}catch (Exception e){
			LogUtil.error("商品明細頁初始化失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, productDetailInfo);
		}

		LogUtil.info("getProductDetailInitData() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, productDetailInfo);
	}
	
	/**
	 * 商品明細頁 - 預約單取貨驗證
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-06
	 * @return
	 */
	@Operation(summary = "商品明細頁 - 預約單取貨驗證", description = "商品明細頁 - 預約單取貨驗證")
	@RequestMapping(path = { "/validateReservationOrder" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<ReservationOrderReturn> validateReservationOrder(HttpServletRequest req, 
			@RequestBody(required = false) ReservationOrderReq form) {

		LogUtil.info("validateReservationOrder() - start");

		String regexRocId = "[A-Z]{1}[1-2]{1}[0-9]{8}";
		String regexCono = "[A-Z0-9]{16}";

		if (!Pattern.matches(regexRocId, form.getRocId())) {
			return buildResult(new ReservationOrderReturn(SystemConstant.RETURN_CODE_FAIL, "身分證格式錯誤"));
		}
		if (!Pattern.matches(regexCono, form.getSeq())) {
			return buildResult(new ReservationOrderReturn(SystemConstant.RETURN_CODE_FAIL, "單號格式錯誤"));
		}

		ReservationOrderReturn orderReturn = productDetailFacadeImpl.validateReservationOrder(form);
		
		if (SystemConstant.RETURN_CODE_SUCCESS.equals(orderReturn.getRtnCode())) {
			boolean isNP = OrderTypeEnum.get(orderReturn.getOrderType()).isNP();
			boolean isLY = OrderTypeEnum.get(orderReturn.getOrderType()).isLY();
			String msisdn = orderReturn.getMsisdn();
			LogUtil.info("OrderType: {} , Msisdn: {}", orderReturn.getOrderType(), orderReturn.getMsisdn());
			if (isNP) {
				setRecordMsisdn(msisdn, req);
			}
			if (isLY) {
				saveCustomerData(orderReturn.getCrmData(), req);
			}
			orderReturn.setCrmData(null);
			// 將預約單號存入 Session 中
			putPreorderNo(req, form.getSeq());
//			orderReturn.setMsisdn(DataMaskerUtil.doMask(msisdn, MaskerType.Mobile));
		}

		LogUtil.info("validateReservationOrder() - end");

		return buildResult(orderReturn);
	}

	/**
	 * 商品明細頁 - 成立預約單
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-06
	 * @return
	 */
	@Operation(summary = "商品明細頁 - 成立預約單", description = "商品明細頁 - 成立預約單")
	@RequestMapping(path = { "/saveReservationOrder" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<ReservationOrderReturn> saveReservationOrder(
			@RequestBody(required = false) ReservationOrderForm form) {

		LogUtil.info("saveReservationOrder() - start");

		String regexPhone = "[09]{2}[0-9]{8}";

		if (!Pattern.matches(regexPhone, form.getPhone())) {
			return buildResult(new ReservationOrderReturn(SystemConstant.RETURN_CODE_FAIL, "手機格式錯誤"));
		}

		ReservationOrderReturn orderReturn = productDetailFacadeImpl.saveReservationOrder(form);

		LogUtil.info("saveReservationOrder() - end");

		return buildResult(orderReturn);
	}

    /**
     *  商品細項 - 初始化商品細項資訊
     *
     * @description
     * @author Klyve.chen
     * @date 2020-07-10
     * @return
     */
    @Operation(summary = "初始化可選門號", description = "初始化商品明細頁可選門號")
    @RequestMapping(path = {"/initProductMsisdn"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
    public RestResult<MsisdnFlow> initProductMsisdn(HttpServletRequest req) {
        return buildResult(getMsisdnFacadeImpl.initSelectMsisdn());
    }

    /**
     *  商品細項 - 門號關鍵字檢索
     *
     * @description
     * @author Klyve.chen
     * @date 2020-08-06
     * @return
     */
    @Operation(summary = "門號檢索", description = "對應前端頁面, 符合門號關鍵字之門號, 若門號關鍵字為空值, 則檢索免費門號, 非數字則檢索主題或黃金門號")
    @RequestMapping(path = {"/getMsisdns"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
    public RestResult<List<SelectMsisdn>> getMsisdns(@RequestBody(required = false) MsisdnReq form) {
        String keyword = form.getKeyword();
        String channel = form.getChannel();
        String groupName = form.getGroupName();
        Integer idxFrom = form.getIdxFrom();
        Integer size = form.getSize();
        String sortType = form.getSortType();
        if (idxFrom == null || size == null) {
            return buildResult(String.valueOf(HttpStatus.SC_INTERNAL_SERVER_ERROR), "idxFrom and size cannot by null!", null);
        }
        List<SelectMsisdn> selectMsisdns = getMsisdnFacadeImpl.getMsisdns(groupName, keyword, channel, idxFrom, size,sortType);
        return buildResult(selectMsisdns);
    }

	/**
	 * 商品細項 - 確認所選門號
	 *
	 * @description
	 * @author Klyve.chen
	 * @date 2020-08-10
	 * @return
	 */
	@Operation(summary = "確認所選門號", description = "對應前端頁面, 確認所選門號")
	@RequestMapping(path = { "/checkSelectedMsisdn" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<SelectMsisdn>> checkSelectedMsisdn(@RequestBody(required = false) MsisdnReq form) {
		String productId = form.getMsisdn();
		ValidationResultEnum result;
		if (StringUtil.isEmptyOrNull(productId)) {
			result = ValidationResultEnum.CHECK_NP_PARAMETER_EXCEPTION;
		} else {
			try {
				result = validationFacadeImpl.checkSelectedMsisdn(productId);
			} catch (Exception ex) {
				result = ValidationResultEnum.CHECK_FAIL_UNKNOWN;
				return buildResult(result.getCode(), result.getDescription() + ex.getMessage(), null);
			}
		}
		return buildResult(result.getCode(), result.getDescription(), null);
	}

	/**
	 * 商品細項 - 確認所選門號
	 *
	 * @description
	 * @author Klyve.chen
	 * @date 2020-08-10
	 * @return
	 */
	@Operation(summary = "取得開箱文", description = "取得對應商品編號支開箱文")
	@RequestMapping(path = { "/getDimBody" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> getDimBody(@RequestBody(required = false) ProductDetailReq form) {
		LogUtil.info("getDimBody() - start");
		String productId = form.getProductId();
		if (StringUtil.isEmpty(productId)) {
			return buildResult("400", "商品編號為空值", null);
		}
		String dimBody = productDetailFacadeImpl.getDimBody(productId);
		LogUtil.info("getDimBody() - end");
		return buildResult(dimBody);
	}

    /**
     * 商品細項 - 儲存Session內的購物車資訊
     *
     * @description
     * @author Klyve.chen
     * @date 2020-08-17
     * @return
     */
    @Operation(summary = "儲存購物車資訊", description = "儲存購物車資訊")
    @RequestMapping(path = { "/saveShoppingInfo" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
    public RestResult<String> saveShoppingInfo(HttpServletRequest req, @RequestBody(required = false) Cart cart) {

		LogUtil.info("saveShoppingInfo() - start");

		if (cart != null) {
			saveCartData(cart, req);
		}
		
		OrderHelper orderHelper = getOrderHelper(req);
		if(orderHelper != null) {
			orderHelper.setCart(cart);
			saveOrderHelper(orderHelper,req);
		}

		LogUtil.info("saveShoppingInfo() - end");
        return buildResult("SUCCESS");
    }

	/**
	 * 商品細項 - 清除Session內的購物車資訊
	 *
	 * @description 清除購物車資訊
	 * @author Klyve.chen
	 * @date 2020-08-17
	 * @return
	 */
	@Operation(summary = "清除購物車資訊", description = "清除購物車資訊")
	@RequestMapping(path = { "/cleanShoppingInfo" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> cleanShoppingInfo(HttpServletRequest req) {
		
		LogUtil.info("cleanShoppingInfo() - start");
		
		removeCartData(req);
		
		LogUtil.info("cleanShoppingInfo() - end");
		
		return buildResult("SUCCESS");
	}

    /**
     * 商品細項 - 取得Session內的購物車資訊
     *
     * @description
     * @author Klyve.chen
     * @date 2020-08-17
     * @return
     */
    @Operation(summary = "取得購物車資訊", description = "取得購物車資訊")
    @RequestMapping(path = { "/getShoppingInfo" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
    public RestResult<Cart> getShoppingInfo(HttpServletRequest req) {
    	
        LogUtil.info("getShoppingInfo() - start");
        
        Cart cart = getCartData(req);
        
        if (cart == null) {
        	cart = new Cart();
		}
        
		LogUtil.info("getShoppingInfo() - end");
        return buildResult(cart);
    }
    
    /**
     * 清除 Session 中紀錄的 門號
     * 
     * @description
     * @author Phil.lin
     * @date 2020-09-18
     * @param req
     * @return
     */
    @Operation(summary = "清除 Session 中紀錄的 門號", description = "清除 Session 中紀錄的 門號")
    @RequestMapping(path = { "/releaseSessionMsisdn" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = true, output = true)
    public RestResult<Object> releaseSessionMsisdn(HttpServletRequest req) {
    	
        LogUtil.info("releaseSessionMsisdn() - start");
        
        releaseRecordMsisdn(req);
        
		LogUtil.info("releaseSessionMsisdn() - end");
        return buildResult();
    }
	
	/**
	 * 商品明細頁 - 取得贈品
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-18
	 * @return
	 */
	@Operation(summary = "商品明細頁 - 取得贈品", description = "商品明細頁 - 取得贈品")
	@RequestMapping(path = { "/findGift" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<GiftBean> findGift(HttpServletRequest req,@RequestParam(required = false) String orderType) {
		
		LogUtil.info("findGift() - start");
		
		ActivityHelper activityHelper = this.getActivityHelper(req);
		Long activityId = null;
		if(activityHelper!=null) {
			activityId = activityHelper.getActivityId();
		}
		try {
			
			GiftBean result = productDetailFacadeImpl.findGift(orderType, activityId);
			LogUtil.info("findGift() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
			
		}catch(Exception e) {
			
			LogUtil.error("取得贈品失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR,null);
		
		}

	}
	
	/**
	 * 商品明細頁 - 取得加購
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-18
	 * @return
	 */
	@Operation(summary = "商品明細頁 - 取得加購", description = "商品明細頁 - 取得加購")
	@RequestMapping(path = { "/findExtraBuy" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<ExtraBuyOptionBean>> findExtraBuy(HttpServletRequest req,@RequestParam(required = false) String orderType) {
		
		LogUtil.info("findExtraBuy() - start");
		
		ActivityHelper activityHelper = this.getActivityHelper(req);
		Long activityId = null;
		if(activityHelper!=null) {
			activityId = activityHelper.getActivityId();
		}
		try {
			
			List<ExtraBuyOptionBean> result = productDetailFacadeImpl.findExtraBuy(orderType,activityId);
			LogUtil.info("findExtraBuy() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
			
		}catch(Exception e) {
			
			LogUtil.error("取得加購失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR,null);
		
		}
		
	}
	
	/**
	 * 商品明細頁點選「前往結帳」，手機商品頁面送出表單
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-19
	 * @return
	 */
	@Operation(summary = "商品明細頁送出", description = "商品明細頁送出")
	@RequestMapping(path = { "/productSubmit" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<Object> productSubmit(@RequestBody SubmitOrderReq form, HttpServletRequest req){

		LogUtil.info("productSubmit() - start");
		LogUtil.info("Request : {}", new Gson().toJson(form));
		// 續約客資
		CrmData customerData = getCustomerData(req);
		// 驗證結果表單
		OrderValidationResultVO result;
		// 活動賣場資訊
		ActivityHelper activityHelper = getActivityHelper(req);
		// 取出Session記錄的門號(給GA/NP用）
		String sessionMsisdn = getRecordMsisdn(req);
		//訂單UUID
		String orderUUID = "";
		
		// 1. 先清空訂單資料
		removeOrderHelper(req);
		
		// 2. 驗證表單資料
		try {
			result = validationFacadeImpl.checkOrderData(form, customerData, activityHelper, sessionMsisdn);
		} catch (OrderValidationException e) {
			result = new OrderValidationResultVO(e);
		}
		
		// 3. 成功後將資料存入訂單中
		if (result.getResultEnum() == ValidationResultEnum.SUCCESS) {
			// req ---> orderHelper
			// 取出Session紀錄的預約單號
			String sessionPreorderNo = popPreorderNo(req);
			// 取出Session紀錄的serviceChannel
			String serviceChannel = popServiceChannel(req);
			// 建立訂單資料
			OrderHelper orderHelper = productDetailFacadeImpl.createOrderHelper(form, customerData, activityHelper, sessionPreorderNo,serviceChannel);
			// 建立流程控制器
			FlowControlBean flowControlBean = flowControlHelper.initFlowControl(orderHelper);
			// 標記商品明細頁
			flowControlHelper.completeStep(flowControlBean, OrderFlowEnum.ORDER_SUBMIT);
			// 將流程控制器存入 Order 中
			orderHelper.setFlowControlBean(flowControlBean);
			//2020-11-11 Ted.Hsieh 新增 產生UUID
			orderUUID = UUID.randomUUID().toString();

			saveOrderHelper(orderHelper, req);
			// 將門號記錄到 Session 中
			setRecordMsisdn(orderHelper.getMsisdn(), req);
			// 將訂單的UUID記錄到 Session中
			saveOrderUUID(req, orderUUID);
			
			LogUtil.info("OrderHelper : {}", new Gson().toJson(orderHelper));
		}
		
		LogUtil.info("productSubmit() - end");
		
		return buildResult(result.getReturnCode(), result.getReturnMsg(), orderUUID);
	}
	
	/**
	 * 購物車按下「立即購買」，配件、Sim Card 購物車清單進入確認畫面
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-19
	 * @return
	 */
	@Operation(summary = "購物車按下「立即購買」", description = "購物車按下「立即購買」")
	@RequestMapping(path = { "/cartSubmit" }, method = { RequestMethod.POST })
	public RestResult<Object> cartSubmit(HttpServletRequest req, @RequestBody(required = false) Cart cart){

		LogUtil.info("cartSubmit() - start");
		LogUtil.info("Request : {}", new Gson().toJson(cart));

		//訂單UUID
		String orderUUID = "";
		
		// 1. 儲存購物車資訊 
		saveShoppingInfo(req, cart);
		
		// 2. 先清空訂單資料
		removeOrderHelper(req);
		
		// 活動賣場資訊
		ActivityHelper activityHelper = getActivityHelper(req);

		// 3. 驗證表單資料
		ValidationResultEnum result = validationFacadeImpl.checkCartData(cart);
		
		// 4. 驗證通過後轉成訂單
		if (result == ValidationResultEnum.SUCCESS) {
			//建立訂單
			OrderHelper orderHelper = productDetailFacadeImpl.createOrderHelper(cart, activityHelper);
			// 建立流程控制器
			FlowControlBean flowControlBean = flowControlHelper.initFlowControl(orderHelper);
			// 標記商品明細頁
			flowControlHelper.completeStep(flowControlBean, OrderFlowEnum.ORDER_SUBMIT);
			// 將流程控制器存入 Order 中
			orderHelper.setFlowControlBean(flowControlBean);
			//2020-11-11 Ted.Hsieh 新增 產生UUID
			orderUUID = UUID.randomUUID().toString();
			// 將訂單的UUID記錄到 Session中
			saveOrderUUID(req, orderUUID);
			
			saveOrderHelper(orderHelper, req);
		}
		LogUtil.info("cartSubmit() - end");
		
		return buildResult(result.getCode(), result.getDescription(), orderUUID);
	}


	/**
	 * 可續約時通知我
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-24
	 * @param req
	 * @param session
	 * @param params
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value= "/ly/notifyMe", method=RequestMethod.POST)
	@ApiInputOutput(input = true, output = true)
	public RestResult<Object> notifyMe(HttpServletRequest req, @RequestBody Map<String,String> map)throws Exception {	
		
		LogUtil.info("notifyMe() - start");
		
		LogUtil.info("lyRecordId: {}", map.get("lyRecordId"));
		
		productDetailFacadeImpl.notifyMe(map.get("lyRecordId"));

		removeOrderHelper(req);
		LogUtil.info("notifyMe() - end");
		return buildResult("SUCCESS");
	}
}
