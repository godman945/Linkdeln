package com.fet.estore.api.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@OpenAPIDefinition(
    info = @Info(
            title = "[DEV]Revamp - eStore RESTful APIs",
            version = "1.0.0",
            description = "eStore Backend RESTful API, 2020/08/05 Release")
)
public class OpenAPIConfiguration {
}
