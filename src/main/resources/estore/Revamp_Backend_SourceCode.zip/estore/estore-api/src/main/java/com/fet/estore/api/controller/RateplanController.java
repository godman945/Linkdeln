package com.fet.estore.api.controller;

import static com.fet.estore.core.constant.SystemConstant.SELECT_MSISDN_PAGE_INIT_SIZE;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.IndexInfo;
import com.fet.estore.core.bean.MsisdnGroupVO;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.RatePlanInfo;
import com.fet.estore.core.bean.SelectMsisdn;
import com.fet.estore.core.bean.ThemeNumberInfo;
import com.fet.estore.core.bean.vo.frontend.AuctionMsisdnVO;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.enums.BreadcrumsEnum;
import com.fet.estore.core.facade.ICommonFacade;
import com.fet.estore.core.facade.IGetMsisdnFacade;
import com.fet.estore.core.facade.IRateplanFacade;
import com.fet.estore.core.model.Msisdn;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.LogUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/rateplan")
@CrossOrigin
@Tag(name = "Rateplan APIs")
public class RateplanController implements IBaseAct,OrderDataHelper {

	@Autowired
	private IRateplanFacade rateplanFacade;
	
	@Autowired
	private IGetMsisdnFacade getMsisdnFacade;
	
	@Autowired
	private ICommonFacade commonFacadeImpl;
	
	@Operation(summary = "主題門號 - 取得門號分類", description = "主題門號 - 取得門號分類")
	@RequestMapping(path = { "/getMsisdnTags" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<MsisdnGroupVO>> getMsisdnTags(){
		
		LogUtil.info("getMsisdnTags() - start");
		
		try {
			List<MsisdnGroupVO> groupListVO = rateplanFacade.findAllMsisdnGroupName();
			LogUtil.info("getMsisdnTags() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, groupListVO);
		}catch(Exception e) {
			LogUtil.error("取得門號分類失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, null);
		}

	}
	
	@Operation(summary = "主題門號 - 取得所屬分類門號", description = "主題門號 - 取得所屬分類門號")
	@RequestMapping(path = { "/getMsisdns" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<SelectMsisdn>> getMsisdns(@RequestParam String category,@RequestParam String keyword,@RequestParam String sortType){
		
		List<SelectMsisdn> msisdns = getMsisdnFacade.getMsisdns(category,keyword,Msisdn.CHANNEL_ESTORE, 0, SELECT_MSISDN_PAGE_INIT_SIZE,sortType);
		
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, msisdns);
		
	}
	
	@Operation(summary = "門號競標", description = "門號競標")
	@RequestMapping(path = { "/initAuction" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> initAuction(HttpServletRequest req,@RequestParam String queryString){
		AuctionMsisdnVO auctionMsisdnVO = null;
		try {
			auctionMsisdnVO = rateplanFacade.decodingBiddingMsisdn(queryString);
		}catch(Exception ex) {
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR,ex.getMessage(), null);
		}

		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, auctionMsisdnVO.getMsisdn());
		
	}
	
	@Operation(summary = "取得找方案初始化資訊",description = "取得找方案初始化資訊")
	@RequestMapping(path = {"/initRatePlan"}, method = {RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult<RatePlanInfo> getRatePlanInitData(HttpServletRequest req){
		
		LogUtil.info("getRatePlanInitData() - start");
		RatePlanInfo ratePlanInfo = new RatePlanInfo();

		try {
			//麵包屑
			ratePlanInfo.setBreadcrumbs(commonFacadeImpl.getBreadCrumb(BreadcrumsEnum.RATEPLAN));
			LogUtil.info("getRatePlanInitData() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,ratePlanInfo);
		}catch(Exception e) {
			LogUtil.error("取得找方案初始化資訊失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, null);
		}

	}
	
	@Operation(summary = "取得主題門號初始化資訊",description = "取得主題門號初始化資訊")
	@RequestMapping(path = {"/initThemeNumber"}, method = {RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult<ThemeNumberInfo> getThemeNumberInitData(HttpServletRequest req){
		
		LogUtil.info("getThemeNumberInitData() - start");
		ThemeNumberInfo themeNumberInfo = new ThemeNumberInfo();
		
		try {
			//麵包屑
			themeNumberInfo.setBreadcrumbs(commonFacadeImpl.getBreadCrumb(BreadcrumsEnum.THEME_NUMBER));
			LogUtil.info("getThemeNumberInitData() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,themeNumberInfo);
		}catch(Exception e) {
			LogUtil.error("取得主題門號初始化資訊失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, null);
		}

	}
}
