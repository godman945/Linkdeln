package com.fet.estore.api.controller;

import java.sql.SQLException;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.FlowControlHelper;
import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.bean.FlowControlBean;
import com.fet.estore.core.bean.IndexInfo;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.enums.FlowTypeEnum;
import com.fet.estore.core.enums.OrderFlowEnum;
import com.fet.estore.core.facade.IShopeeFacade;
import com.fet.estore.core.facade.IValidationFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.service.ShopeeService;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;

import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * 測試用 Controller 
 * 
 * @description
 * @author Phil.lin
 * @date 2020-09-08
 */
//@RestController
//@RequestMapping("/test")
@Tag(name = "Index APIs")
public class TestController implements IBaseAct, OrderDataHelper {
	

	@Autowired
	private FlowControlHelper flowControlHelper;
    @Autowired
    @Qualifier("IValidationFacade")
    private IValidationFacade validationFacade;
	@Autowired
	private IShopeeFacade shopeeFacade;
	
	/**
	 *  流程測試器
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-10
	 * @return
	 * @throws SQLException
	 */
	@GetMapping("/flow/{flowType}/{flowIdSeq}")
	public RestResult<IndexInfo> getIndexInitData(@PathVariable String flowIdSeq, @PathVariable String flowType) {
		
		FlowControlBean fc = flowControlHelper.initFlowControl(FlowTypeEnum.valueOf(flowType));
		
		
		Arrays.asList(flowIdSeq.split(",")).stream().forEach(o->{
			try {
				OrderFlowEnum flow = OrderFlowEnum.getByFlowId(o.substring(1));
				switch(o.charAt(0)) {
				case 'v':
					flowControlHelper.checkVisit(fc, flow);
					break;
				case 's':
					flowControlHelper.completeStep(fc, flow) ;
					break;
				}

			} catch (Exception e) {
				LogUtil.error("error : {}", e);
			}
		});
		

		
		return buildResult();
	}
	
	/**
	 *  登入狀態測試器
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-07
	 * @return
	 * @throws Exception 
	 * @throws SQLException
	 */
	@GetMapping("/checklogin")
	public RestResult<String> checklogin(HttpServletRequest req) throws Exception {
		
		String uid = (String)req.getSession().getAttribute("uid");
		
		LogUtil.info("uid : {}", uid);
		
		return buildResult(uid);
	}
	
	/**
	 *  續約驗證 登入狀態測試器
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-07
	 * @return
	 * @throws Exception 
	 * @throws SQLException
	 */
	@GetMapping("/checkLy")
	public RestResult<IndexInfo> checkLy(HttpServletRequest req) throws Exception {
		
		String uid = (String)req.getSession().getAttribute("uid");
		String msisdn = (String)req.getSession().getAttribute("msisdn");
		String rocid = (String)req.getSession().getAttribute("rocid");
		
		LogUtil.info("uid : {}", uid);

		validationFacade.checkLyAcceptableForLogin(uid, msisdn, rocid);
		
		
		return buildResult();
	}
	
	/**
	 *  強制登出
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-07
	 * @return
	 * @throws Exception 
	 * @throws SQLException
	 */
	@GetMapping("/logout")
	public RestResult<String> logout(HttpServletRequest req) throws Exception {
		
		req.getSession().setAttribute("uid", null);
		String uid = (String)req.getSession().getAttribute("uid");
		LogUtil.info("uid : {}", uid);
		
		
		return buildResult(uid);
	}
	
	/**
	 *  測試 - 證號驗證
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-07
	 * @return
	 * @throws Exception 
	 * @throws SQLException
	 */
	@GetMapping("/checkRocId/{rocid}")
	public RestResult<Boolean> checkRocId(@PathVariable String rocid) throws Exception {
		
// 	X115073630
		
		return buildResult(StringUtil.checkRocId(rocid));
	}
	
	/**
	 *  測試 - 取得SESSION中的 OrderHelper
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-07
	 * @return
	 * @throws Exception 
	 */
	@GetMapping("/getOrderHelper")
	public RestResult<OrderHelper> getOrderHelperFunc(HttpServletRequest req) throws Exception {
		
		return buildResult(getOrderHelper(req));
	}
	
	/**
	 *  測試 - 清除 SESSION中的 OrderHelper
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-07
	 * @return
	 * @throws Exception 
	 */
	@GetMapping("/clearOrderHelper")
	public RestResult<Object> clearOrderHelperFunc(HttpServletRequest req) throws Exception {
		
		removeOrderHelper(req);
		
		return buildResult();
	}
	
	
	/**
	 *  測試 - 重設 Session
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-07
	 * @return
	 * @throws Exception 
	 */
	@GetMapping("/releaseSession")
	public RestResult<Object> releaseSession(HttpServletRequest req) throws Exception {
		
		req.getSession().invalidate();
		
		return buildResult();
	}
	
	@GetMapping("/getCrossCooperationData")
	@Transactional
	public RestResult<Object> getCrossCooperationData(HttpServletRequest req) throws Exception {
		
		
		String orderHelper = null;//StringUtil.toJson(shopeeFacade.createOrderHelper("200520KTC726FT"));
		LogUtil.info(orderHelper);
		return buildResult(orderHelper);
	}
	
}
