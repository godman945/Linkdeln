package com.fet.estore.api.controller.helper;

import com.fet.estore.core.bean.FlowControlBean;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.enums.FlowTypeEnum;
import com.fet.estore.core.enums.OrderFlowEnum;

public interface FlowControlHelper {

	/** 
	 * 初始化流程控制器並取得流程控制物件
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-28
	 * @param flowType
	 * @return
	 */
	FlowControlBean initFlowControl(OrderHelper orderHelper);

	/** 
	 * 初始化流程控制器並取得流程控制物件
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-10-29
	 * @param flow
	 * @return
	 */
	FlowControlBean initFlowControl(FlowTypeEnum flow);
	
	/**
	 * 驗證此次訪問是否合法，並更新已通過的流程清單
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-28
	 * @param flowControlBean
	 * @param goal
	 * @return
	 */
	boolean checkVisit(FlowControlBean flowControlBean, OrderFlowEnum goal);

	/**
	 * 標註已完成流程
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-28
	 * @param flowControlBean
	 * @param goal
	 * @return
	 */
	boolean completeStep(FlowControlBean flowControlBean, OrderFlowEnum goal);

}
