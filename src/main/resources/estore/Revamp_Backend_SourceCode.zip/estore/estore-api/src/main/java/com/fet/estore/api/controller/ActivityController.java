package com.fet.estore.api.controller;

import com.fet.estore.api.controller.helper.ActivityDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.AccessoryInfo;
import com.fet.estore.core.bean.ActivityBanner;
import com.fet.estore.core.bean.ActivityHelper;
import com.fet.estore.core.bean.ActivityInitRes;
import com.fet.estore.core.bean.DealsInfo;
import com.fet.estore.core.bean.FindActivityProductInfo;
import com.fet.estore.core.bean.Product;
import com.fet.estore.core.bean.SrvResult;
import com.fet.estore.core.bean.ThemeNumberInfo;
import com.fet.estore.core.bean.req.InitActivityReq;
import com.fet.estore.core.bean.vo.AccessoryVO;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.enums.BreadcrumsEnum;
import com.fet.estore.core.enums.OrderTypeEnum;
import com.fet.estore.core.enums.ValidationResultEnum;
import com.fet.estore.core.facade.IActivityFacade;
import com.fet.estore.core.facade.ICommonFacade;
import com.fet.estore.core.facade.IFindProductFacade;
import com.fet.estore.core.facade.IValidationFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

import static com.fet.estore.core.constant.ReturnCode.RTN_CODE_MANDATORY_FIELD;
import static com.fet.estore.core.constant.ReturnCode.RTN_MSG_MANDATORY_FIELD;

import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-09-03
 * @description
 */
@RestController
@RequestMapping("/activity")
@Tag(name = "Activity APIs")
public class ActivityController implements IBaseAct, ActivityDataHelper {

    private final static String SESSION_ACTIVITY = "SESSION_ACTIVITY";

    @Autowired
    private IActivityFacade activityFacade;
    @Autowired
    private IFindProductFacade findProductFacadeImpl;
    @Autowired
    private ICommonFacade commonFacadeImpl;
    @Autowired
    @Qualifier("IValidationFacade")
    private IValidationFacade validationFacade;

    @Operation(summary = "取得活動頁Banner", description = "取得活動頁Banner")
    @GetMapping("/banner")
    @ApiInputOutput(input = true, output = true)
    public RestResult<ActivityBanner> getActivityBanner(HttpServletRequest req) {
        ActivityHelper activityHelper = this.getActivityHelper(req);
        if (activityHelper == null || activityHelper.getActivityId() == null) {
            return buildResult(RTN_CODE_MANDATORY_FIELD, RTN_MSG_MANDATORY_FIELD, null);
        }
        return buildResult(activityFacade.getActivityBanner(activityHelper.getActivityId(), activityHelper.getOrderType()));
    }

    @Operation(summary = "初始化活動頁面", description = "初始化活動頁面(session存入活動Id)")
    @RequestMapping(path = { "/init", "/redirect" }, method = { RequestMethod.POST })
    @ApiInputOutput(input = true, output = true)
    public RestResult<Object> redirectActivity(@RequestBody(required = false) InitActivityReq activityReq, HttpServletRequest req) {
        LogUtil.info("initActivity() - start");
        ActivityHelper activityHelper = getActivityHelper(req);
        if (activityHelper == null) {
            activityHelper = new ActivityHelper();
        }
        //===========================================================
        //== 3. 參數驗証
        //===========================================================
        // 檢查參數 應該不用
        // checkEmptyParas(req);
        // 將共用參數放置activityHelper
        SrvResult result = activityFacade.redirectActivity(activityHelper, activityReq);
        if (!result.isSuccess()) {
            LogUtil.error("進入Activity Error {}", result.getMessage());
            return buildResult(RTN_CODE_MANDATORY_FIELD, RTN_MSG_MANDATORY_FIELD, result.getMessage());
        }

        OrderTypeEnum ordTypEnum = OrderTypeEnum.get(activityReq.getOrderType());

        //若是有captcha 當作namelist第一個參數驗證
        if (StringUtil.isNotEmptyOrNull(activityReq.getCaptcha())) {
            ValidationResultEnum checkResult = validationFacade.checkActivityNameList(activityHelper, activityReq.getCaptcha(), null, null);
            if (checkResult == ValidationResultEnum.SUCCESS) {
                activityHelper.setCheckNameListSucceed(true);
            }
        }
        // 將activity存入Session
        saveActivityHelper(activityHelper, req);

//        短網址
//        String queryString = "";
//        if (StringUtils.isNotEmpty(activityReq.getWtShortK())) {
//            queryString = "?WTshort_k=" + activityReq.getWtShortK();
//        }

        String action = "";
//        // 驗證coupon
//        if(activityHelper.isHasCoupon() && !(ordTypEnum.telcomOnly() || activityHelper.isDev() && !activityHelper.isDaAcc())) {
//                action = "coupon";
//        }
//        //驗證碼改用lightbox，不做獨立頁面 for 後面兩個選項
//        // 驗證nameList
//        else if(activityHelper.getNameList() != null && activityHelper.getNameList()
//                && !(ordTypEnum.telcomOnly() || activityHelper.isDev() && !activityHelper.isDaAcc())){
//            action = "nameList";
//        }
        // 活動首頁
        if(activityHelper.isDev() && !activityHelper.isDaAcc()) {
            action = "phone";
        }
        else if(activityHelper.isDev() && activityHelper.isDaAcc()) {
            action = "accessory" ;
        }
        else if(ordTypEnum.telcomOnly() || activityHelper.isFriday()){
            // 是否為試用 拿掉
            action = "deals";
        }
        LogUtil.info("action: {}", action);
        LogUtil.info("initActivity() - end, action: {}", action);
        return buildResult(action);
    }

    @Operation(summary = "取得本活動產品", description = "取得本活動產品")
    @GetMapping("/initActProductList")
    @ApiInputOutput(input = true, output = true)
    public RestResult<FindActivityProductInfo> initActProductList(HttpServletRequest req) {
        ActivityHelper activityHelper = getActivityHelper(req);
        if (activityHelper == null) {
            activityHelper = new ActivityHelper();
        }

        SrvResult<FindActivityProductInfo> result = activityFacade.initActProductList(activityHelper);
        if (!result.isSuccess()) {
            LogUtil.error("進入Activity Error {}", result.getMessage());
            return buildResult(RTN_CODE_MANDATORY_FIELD, RTN_MSG_MANDATORY_FIELD, null);
        }

        FindActivityProductInfo activityProductInfo = result.getObject();

        buildProductResult(activityProductInfo.getProducts(), activityHelper.getOrderType());

        saveActivityHelper(activityHelper, req);

        return buildResult(activityProductInfo);
    }

    @Operation(summary = "初始化-配件列表頁", description = "初始化-配件列表頁")
    @RequestMapping(path = { "/initAccessoryList" }, method = { RequestMethod.GET })
    @ApiInputOutput(input = true, output = true)
    public RestResult<AccessoryInfo> initAccessoryList(HttpServletRequest req) {

    	ActivityHelper activityHelper = getActivityHelper(req);

		if(activityHelper==null) {
			activityHelper = new ActivityHelper();
		}
		AccessoryInfo accessoryInfo = new AccessoryInfo();
    	List<AccessoryVO> accessoryVOList = null;
    	try {
    		accessoryVOList = activityFacade.initAccessoryList(activityHelper);
    		accessoryInfo.setAccessoryVO(accessoryVOList);
    		//麵包屑
    		accessoryInfo.setBreadcrumbs(commonFacadeImpl.getBreadCrumb(BreadcrumsEnum.ACTIVITY_ACCESSORY));
    	}catch(Exception e) {
    		return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR,e.getMessage(),null);
    	}

        return buildResult(ReturnCode.RTN_MSG_SUCCESS,ReturnCode.RTN_MSG_SUCCESS,accessoryInfo);
    }

    @Operation(summary = "取得目前Session activityId", description = "取得目前Session activityId")
    @RequestMapping(path = { "/getCurrentActivity" }, method = { RequestMethod.GET })
    @ApiInputOutput(input = true, output = true)
    public RestResult<Long> getCurrentActivity(HttpServletRequest req) {
        ActivityHelper activityHelper = getActivityHelper(req);
        if (activityHelper == null) {
            return buildResult(null);
        }
        return buildResult(ReturnCode.RTN_MSG_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, activityHelper.getActivityId());
    }

    // 整理回傳商品資訊, 參考FindProduct
    private void buildProductResult(List<Product> products, String orderType) {
        if(products == null) {
            return;
        }
        OrderTypeEnum orderTypeEnum = OrderTypeEnum.get(orderType);
        for(Product product: products) {
            // 清空月租費和商品價 只顯示 專案價
            // 如資費或專案價為空則清空資費及專案價欄位，反之則清空商品價，避免讓頁面同時出現三種價格
            // 當查詢方式為單機時，清空月付及專案價只顯示商品價
            LogUtil.info("活動賣場商品資訊: RatePlan: {},  Project Price: {}, orderType: {}", product.getRatePlan(), product.getProjectPrice(),
                    orderTypeEnum != null ? orderTypeEnum.name() : "null");
            if(StringUtils.isBlank(product.getRatePlan())
                    || StringUtils.isBlank(product.getProjectPrice())) {
                product.setRatePlan(null);
                product.setProjectPrice(null);
            } else if (orderTypeEnum != null && orderTypeEnum.isDa()) {
                product.setRatePlan(null);
                product.setProjectPrice(null);
            } else {
                product.setProductPrice(null);
            }
        }
    }
    
    
    @Operation(summary = "初始化-貼心小叮嚀", description = "初始化-貼心小叮嚀")
    @RequestMapping(path = { "/getPortalDesc" }, method = { RequestMethod.GET })
    @ApiInputOutput(input = true, output = true)
    public RestResult<String> getPortalDesc(HttpServletRequest req) {

    	LogUtil.info("getPortalDesc() - start");
    	ActivityHelper activityHelper = getActivityHelper(req);

		if(activityHelper==null) {
			activityHelper = new ActivityHelper();
		}

		try {
			String portalDesc = activityFacade.getPortalDesc(activityHelper);
			LogUtil.info("getPortalDesc() - end");
	        return buildResult(ReturnCode.RTN_MSG_SUCCESS,ReturnCode.RTN_MSG_SUCCESS,portalDesc);
		}catch(Exception e) {
			LogUtil.error("初始化-貼心小叮嚀失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, null);
		}

    }

    /**
     * @description 取得秘密賣場單辦初始化
     * @autor Eric.Lu
     * @date 2020-09-10
     */
    @PostMapping("/getActivityInit")
    @Operation(summary = "取得秘密賣場單辦初始化", description = "取得秘密賣場單辦初始化")
    @ApiInputOutput(input = true, output = true)
    public RestResult<ActivityInitRes> activityInit(HttpServletRequest req){

        ActivityHelper activityHelper = this.getActivityHelper(req);

        ActivityInitRes result = new ActivityInitRes();

        activityFacade.buildActivityInit(activityHelper, result);

        return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
    }

    /**
     * @author Klyve.Chen
     * @param req http request
     * @return 清除成功失敗
     * @since 2020-10-27
     */
    @Operation(summary = "清除Session activity", description = "清除目前Session activity")
    @RequestMapping(path = { "/cleanActivity" }, method = { RequestMethod.GET })
    @ApiInputOutput(input = true, output = true)
    public RestResult<Object> cleanActivity(HttpServletRequest req) {
        try {
            removeActivityHelper(req);
            return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, null);
        } catch (Exception e) {
            return buildResult(RTN_CODE_MANDATORY_FIELD, RTN_MSG_MANDATORY_FIELD, null);
        }
    }
    
	@Operation(summary = "取得單辦門號初始化資訊",description = "取得單辦門號初始化資訊")
	@RequestMapping(path = {"/initDeals"}, method = {RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult<DealsInfo> getDealsInitData(HttpServletRequest req){
		
		LogUtil.info("getDealsInitData() - start");
		DealsInfo dealsInfo = new DealsInfo();
		
		try {
			//麵包屑
			dealsInfo.setBreadcrumbs(commonFacadeImpl.getBreadCrumb(BreadcrumsEnum.DEALS));
			LogUtil.info("getDealsInitData() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,dealsInfo);
		}catch(Exception e) {
			LogUtil.error("\"取得單辦門號初始化資訊失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, null);
		}

	}

}