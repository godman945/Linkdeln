package com.fet.estore.api.controller.helper;

import javax.servlet.http.HttpServletRequest;

import com.fet.estore.core.bean.ActivityHelper;
import com.fet.estore.core.util.LogUtil;

public interface ActivityDataHelper {

	/** 在Session中存訂單資料的 Key 值 */
	final static String ACTIVITY_DATA_ATTR_NAME = "ESTORE_ACTIVITY_DATA";
	/** 開發模式，放入OrderHelper */
//	final static String DEV_ACTIVITY_HELPER_DATA_FILE = "D:\\PH.txt";
	
	/**
	 * 將活動資料存入 Seesion 中
	 * 
	 * @description
	 * @author Eric.Lu
	 * @date 2020-09-07
	 * @param orderHelperData
	 * @param req
	 */
	default void saveActivityHelper(ActivityHelper activityHelperData, HttpServletRequest req) {
		logActivityHelperData("在Session中存入 ActivityHelper", activityHelperData);
		req.getSession().setAttribute(ACTIVITY_DATA_ATTR_NAME, activityHelperData);
	}
	
	/**
	 * 從 Session 中取出活動資料，無資料時回傳 null
	 * 
	 * @description
	 * @author Eric.Lu
	 * @date 2020-09-07
	 * @param req
	 * @return
	 */
	default ActivityHelper getActivityHelper(HttpServletRequest req) {
		ActivityHelper orderData = (ActivityHelper)req.getSession().getAttribute(ACTIVITY_DATA_ATTR_NAME);
		logActivityHelperData("從Session取出 ActivityHelper", orderData);
//		if (orderData == null) {
//			orderData = loadDevFileToSession(DEV_ACTIVITY_HELPER_DATA_FILE, ActivityHelper.class);
//		}
		return orderData;
	}
	
//	default <T> T loadDevFileToSession(String file, Class<T> clazz) {
//		LogUtil.info("Session 中無 ActivityHelper,嘗試讀取測試環境用檔案，路徑:{}", file);
//		
//		T form  = null;
//		StringBuilder str = new StringBuilder();
//		
//		Path path = Paths.get(file);
//		try (Stream<String> lines = Files.lines(path , StandardCharsets.US_ASCII)) {
//			
//			lines.forEach(o->str.append(o));
//			form = new Gson().fromJson(str.toString() , clazz);
//			
//			LogUtil.info("測試資料讀取成功！ {}", file);
//			
//		} catch (Exception e) {
//			
//			LogUtil.info("測試資料讀取失敗！ {}, msg:{}", file, e.getMessage());
//		}
//		return form;
//	}
	
	/**
	 * 清除 Session 中的活動資料，並回傳該資料
	 * 
	 * @description
	 * @author Eric.Lu
	 * @date 2020-09-07
	 * @param req
	 * @return
	 */
	default ActivityHelper removeActivityHelper(HttpServletRequest req) {
		ActivityHelper orderData = (ActivityHelper)req.getSession().getAttribute(ACTIVITY_DATA_ATTR_NAME);
		logActivityHelperData("從Session中刪除 ActivityHelper", orderData);
		req.getSession().removeAttribute(ACTIVITY_DATA_ATTR_NAME);
		return orderData;
	}
	
	/**
	 * 紀錄當前 ActivityHelper DATA 的資料
	 * 
	 * @description
	 * @author Eric.Lu
	 * @date 2020-09-07
	 * @param msg
	 * @param orderHelper
	 */
	default void logActivityHelperData(String msg, ActivityHelper activityHelperData) {
		if (activityHelperData == null) {
			LogUtil.info(msg + ", ActivityHelper is null.");	
		} else {
			LogUtil.info(msg + ", ActivityHelper {}",activityHelperData);
		}
	}
}
