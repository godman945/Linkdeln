package com.fet.estore.api.controller;

import com.fet.estore.api.controller.helper.ActivityDataHelper;
import com.fet.estore.api.controller.helper.CrmDataHelper;
import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.ActivityHelper;
import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.req.PromotionReq;
import com.fet.estore.core.bean.vo.OnsalePromoVO;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.enums.OrderTypeEnum;
import com.fet.estore.core.facade.IPromotionFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.LogUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/promo")
@Tag(name = "Promotion APIs")
public class PromotionController implements IBaseAct, CrmDataHelper, ActivityDataHelper {

    @Autowired
    IPromotionFacade promotionFacade;

    /**
     * @description
     * 情境: 一般賣場、活動賣場，取得搭商品促案(NH、PH、LH)
     * 1. 取出Session資料
     * 2. 撈取可申辦促案
     * @autor Dennis.Chen
     * @date 2020-08-15
     */
    @PostMapping("/getProductPromo")
    @Operation(summary = "取得搭商品促案", description = "一般賣場、活動賣場 取得搭商品促案(NH、PH、LH)")
    @ApiInputOutput(input = true, output = true)
    public RestResult<List<OnsalePromoVO>> getProductPromo(HttpServletRequest httpServletReq, @RequestBody PromotionReq promoReq){

    	LogUtil.info("getProductPromo() - start");

        List<OnsalePromoVO> result = new ArrayList<>();
        String rtnCode = ReturnCode.RTN_CODE_SUCCESS;
        String rtnMsg = ReturnCode.RTN_MSG_SUCCESS;

        try {
            //1. 取出Session資料
            ActivityHelper activityHelper = this.getActivityHelper(httpServletReq);
            Long activityId = activityHelper != null ? activityHelper.getActivityId() : null;
            CrmData crmData = this.getCustomerData(httpServletReq);

            //2. 撈取可申辦促案
            result = promotionFacade.getProductPromo(promoReq, crmData, activityId);
        }catch (Exception e){
            LogUtil.error("取得促案出現異常", e);
            rtnCode = ReturnCode.RTN_MSG_UNEXPECT_ERROR;
            rtnMsg = ReturnCode.RTN_MSG_UNEXPECT_ERROR;
        }

        LogUtil.info("getProductPromo() - end");
        //TODO Return Code 機制需補上
        return buildResult(rtnCode, rtnMsg, result);
    }

    /**
     * @description 取得單門號促案(NC、PC、LC)
     * @author Roil.Li
     * @date 2020-09-10
     */
    @PostMapping("/getPromotions")
    @Operation(summary = "取得單門號促案", description = "取得搭商品促案(NC/PC/LC)")
    @ApiInputOutput(input = true, output = true)
    public RestResult<List<OnsalePromoVO>> getPromotions(HttpServletRequest httpServletReq, @RequestBody PromotionReq promoReq){

    	LogUtil.info("getPromotions() - start");

    	boolean isAct = promoReq.getAct() == Boolean.TRUE;

        List<OnsalePromoVO> result = new ArrayList<>();
        String rtnCode = ReturnCode.RTN_CODE_SUCCESS;
        String rtnMsg = ReturnCode.RTN_MSG_SUCCESS;

        try {
            CrmData crmData = this.getCustomerData(httpServletReq);
            ActivityHelper activityHelper = this.getActivityHelper(httpServletReq);
            Long activityId = isAct && activityHelper != null ? activityHelper.getActivityId() : null;
            
            result = promotionFacade.getPromotions(promoReq, crmData, activityId);
        }catch (Exception e){
            LogUtil.error("取得促案出現異常", e);
            rtnCode = ReturnCode.RTN_CODE_UNEXPECT_ERROR;
            rtnMsg = ReturnCode.RTN_MSG_UNEXPECT_ERROR;
        }

        LogUtil.info("getPromotions() - end");
        //TODO Return Code 機制需補上
        return buildResult(rtnCode, rtnMsg, result);
    }
}
