package com.fet.estore.api.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.ActivityDataHelper;
import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.ActivityHelper;
import com.fet.estore.core.bean.CheckRppRes;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.req.CheckRppReq;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.facade.IRppFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/rpp")
@Tag(name = "Rate Plan PlatForm APIs")
public class RppController implements IBaseAct, ActivityDataHelper, OrderDataHelper {

	@Autowired
	private IRppFacade rppFacadeImpl;
	
	/**
	 * 資費大平台天地
	 * 
	 * @description
	 * @author Eric.Lu
	 * @return
	 */
	@Operation(summary = "資費大平台天地", description = "判斷使用者是否套用資費大平台的header footer")
    @RequestMapping(value="/checkRppHeaderFooter",  method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
    public RestResult<CheckRppRes> checkRppHeaderFooter(HttpServletRequest req, ModelMap model) {
		ActivityHelper activityHelper = this.getActivityHelper(req);
		OrderHelper orderHelper = this.getOrderHelper(req);
//        if(activityHelper==null) {
//            activityHelper = new ActivityHelper();
//        }
		/*
		 * /event為秘密賣場的唯一入口
		 * /event會塞rid, eventid, clickid 進 activityHelper
		 * /event會轉導的以下三個祕密賣場頁面
		 * [
		 * /deals 單門號賣場
		 * /product/event_product_list/phone 商品約賣場
		 * /product/event_product_list/accessory 配件賣場
		 * ]
		 * 
		 * 只有進過/event session裡才會有rid,clickid,activityId(eventId)，
		 * 為防止顧客在其他頁面URL私串參數，前端傳入參數判斷路徑是否是秘密賣場流程中會有經過的
		 * 
		 * */
//		if(checkRppReq!=null) {
//			activityHelper.setrId(checkRppReq.getrId());
//			activityHelper.setClickId(checkRppReq.getClickId());
//			activityHelper.setActivityId(checkRppReq.getActivityId());
//		}
		CheckRppRes res = rppFacadeImpl.checkRppHeaderFooter(activityHelper, orderHelper);
		
		this.saveActivityHelper(activityHelper, req);
		return buildResult(ReturnCode.RTN_CODE_SUCCESS,ReturnCode.RTN_MSG_SUCCESS,res);
	}
}
