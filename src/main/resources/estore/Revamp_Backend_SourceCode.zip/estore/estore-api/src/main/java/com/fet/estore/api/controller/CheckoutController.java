package com.fet.estore.api.controller;


import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fet.estore.core.bean.OrderDiscountResult;
import com.fet.estore.core.bean.bo.Valid3dSecureBO;
import com.fet.estore.core.bean.req.CheckoutHappyGoReq;
import com.fet.estore.core.exception.FlowException;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.ActivityDataHelper;
import com.fet.estore.api.controller.helper.CrmDataHelper;
import com.fet.estore.api.controller.helper.FlowControlHelper;
import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.ActivityHelper;
import com.fet.estore.core.bean.CityAreaVO;
import com.fet.estore.core.bean.CombineCheckForm;
import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.bean.OrderCompleteRes;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.OrderListRes;
import com.fet.estore.core.bean.PremiumDiscountProd;
import com.fet.estore.core.bean.StoreBean;
import com.fet.estore.core.bean.StoreRes;
import com.fet.estore.core.bean.SubmitOrderRes;
import com.fet.estore.core.bean.req.CheckoutCouponReq;
import com.fet.estore.core.bean.req.CheckoutSubmitReq;
import com.fet.estore.core.bean.req.CreditPayReq;
import com.fet.estore.core.bean.req.SubmitOrderReq;
import com.fet.estore.core.bean.vo.CrmValidationResultVO;
import com.fet.estore.core.bean.vo.frontend.InstallmentVO;
import com.fet.estore.core.bean.vo.frontend.RecommendSourceVO;
import com.fet.estore.core.bean.vo.frontend.mobile.StoreVO;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.enums.CheckoutResultEnum;
import com.fet.estore.core.enums.OrderFlowEnum;
import com.fet.estore.core.enums.OrderTypeEnum;
import com.fet.estore.core.enums.ValidationResultEnum;
import com.fet.estore.core.exception.CouponException;
import com.fet.estore.core.facade.ICheckoutFacade;
import com.fet.estore.core.model.AreaCity;
import com.fet.estore.core.model.CoMaster;
import com.fet.estore.core.model.TmpCoMaster;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import oracle.jdbc.proxy.annotation.GetCreator;

@RestController
@RequestMapping("/checkout")
@Tag(name = "Checkout APIs")
public class CheckoutController implements IBaseAct, CrmDataHelper, OrderDataHelper, ActivityDataHelper {
	
	@Autowired
	private ICheckoutFacade checkoutFacade;
	@Autowired
	private FlowControlHelper flowControlHelper;

	@Value("${checkout.after3dSecureRedirect}")
    private String after3dSecureRedirect;

	/**
	 * 個資頁 - 合併帳單驗證
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-15
	 * @return
	 */
	@Operation(summary = "個資頁 - 合併帳單驗證", description = "個資頁 - 合併帳單驗證")
	@RequestMapping(path = { "/combineCheck" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<CrmValidationResultVO> combineCheck(@RequestBody(required = false) CombineCheckForm form, HttpServletRequest req) {
		
		LogUtil.info("combineCheck() - start");
		
		String regexPhone = "[09]{2}[0-9]{8}";
		
		String regexRocId = "[A-Z]{1}[1-2]{1}[0-9]{8}";

		if (!Pattern.matches(regexPhone, form.getMdn())) {
			return buildResult(new CrmValidationResultVO(ValidationResultEnum.MDN_PATTERN_ERROR));
		}
		
		if (!Pattern.matches(regexRocId, form.getRocId())) {
			return buildResult(new CrmValidationResultVO(ValidationResultEnum.ROCID_PATTERN_ERROR));
		}
		OrderHelper orderHelper = this.getOrderHelper(req);
		CrmValidationResultVO result = new CrmValidationResultVO();
		CrmValidationResultVO crmValidationResultVO = checkoutFacade.combineCheck(form, orderHelper);
		
		// 有 CRM DATA 則取出來塞入 Session 中
		CrmData crmData = result.getCrmData();
		if (crmData != null) {
			saveCustomerData(crmData, req);
		}
		result.setReturnCode(crmValidationResultVO.getReturnCode());
		result.setReturnMsg(crmValidationResultVO.getReturnMsg());
		LogUtil.info("combineCheck() - end");

		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
	}
	
	/**
	 * 個資頁 - 取得城市鄉鎮
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-17
	 * @return
	 */
	@Operation(summary = "個資頁 - 取得城市鄉鎮", description = "個資頁 - 取得城市鄉鎮")
	@RequestMapping(path = { "/findCityAndRgn" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<CityAreaVO>> findCityAndRgn() {
		
		LogUtil.info("findCityAndRgn() - start");
		
		List<CityAreaVO> result = checkoutFacade.findCityAndRgn();
		
		LogUtil.info("findCityAndRgn() - end");
		
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
	}
	
	/**
	 * 個資頁 - 取得推薦管道
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-17
	 * @return
	 */
	@Operation(summary = "個資頁 - 取得推薦管道", description = "個資頁 - 取得推薦管道")
	@RequestMapping(path = { "/findRecommendSources" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<RecommendSourceVO>> findRecommendSources() {
		
		LogUtil.info("findRecommendSources() - start");
		
		List<RecommendSourceVO> result = checkoutFacade.findRecommendSources();
		
		LogUtil.info("findRecommendSources() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,result);
	}
	
	/**
	 *結帳流程 - 取得申購清單
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-19
	 * @return
	 * @throws Exception 
	 */
	@Operation(summary = "結帳流程 - 取得申購清單", description = "結帳流程 - 取得申購清單")
	@RequestMapping(path = { "/getOrderList" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = true, output = true)
	public RestResult<OrderListRes> getOrderList(HttpServletRequest req) throws Exception {
		
		LogUtil.info("getOrderList() - start");
		OrderListRes result = null;
		OrderHelper orderHelper = getOrderHelper(req);
		CrmData crmData = getCustomerData(req);
		ActivityHelper activityHelper = getActivityHelper(req);
		
		try {
			
			if(null != orderHelper) {
				boolean isPass = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.ORDER_LIST);
				if(isPass) {
					result = checkoutFacade.getOrderList(orderHelper, crmData, OrderFlowEnum.ORDER_LIST, activityHelper);
				} else {
					return flowControlValidationFail();
				}
			}else {
				return flowControlValidationFail();
			}
			LogUtil.info("getOrderList() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
		
		}catch(Exception e) {
			
			LogUtil.error("取得申購清單失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR,null);
			
		}

	}
	
	/**
	 *結帳流程 - 取得銀行資訊
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-21
	 * @return
	 */
	@Operation(summary = "結帳流程 - 取得銀行資訊", description = "結帳流程 - 取得銀行資訊")
	@RequestMapping(path = { "/getInstallmentData" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = true, output = true)
	public RestResult<InstallmentVO> getInstallmentData(HttpServletRequest req) {
		
		LogUtil.info("getInstallmentData() - start");
		
		OrderHelper orderHelper = getOrderHelper(req);
		
		InstallmentVO result = checkoutFacade.getInstallmentData(orderHelper);
	
		LogUtil.info("getInstallmentData() - end");
		
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
		
	}
	
	/**
	 *結帳流程 -取得門市資訊
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-22
	 * @return
	 */
	@Operation(summary = "結帳流程 -取得門市資訊", description = "結帳流程 -取得門市資訊")
	@RequestMapping(path = { "/getStoreData" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<StoreBean> getStoreData(@RequestBody (required = false) StoreRes res) {
		
		LogUtil.info("getStoreData() - start");
		
		StoreBean storeBean = new StoreBean();
		
		try {
			//取得該縣市該區域門市
			if(!StringUtil.isEmptyOrNull(res.getCity()) && !StringUtil.isEmptyOrNull(res.getArea())) {
				List<StoreVO> stores = checkoutFacade.findStoreByAreas(res.getArea(), res.getCity());
				storeBean.setStores(stores);
			}
			//取得該縣市門市所在區域
			if(!StringUtil.isEmptyOrNull(res.getCity()) && StringUtil.isEmptyOrNull(res.getArea())) {
				List<StoreVO> areas = checkoutFacade.findStoreByCity(res.getCity());
				storeBean.setAreas(areas);
			}
			//取得所有門市縣市
			if(StringUtil.isEmptyOrNull(res.getCity()) && StringUtil.isEmptyOrNull(res.getArea())) {
			List<AreaCity> cities = checkoutFacade.findAllStoreCity();
			storeBean.setCities(cities);
			}
			
			LogUtil.info("getStoreData() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, storeBean);
		}catch(Exception e) {
			LogUtil.error("結帳流程 -取得門市資訊", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, null);
		}

	}

	/**
	 * coupon折抵
	 * 原/api/renewal/plans/payment/cpn, validateCoupon
	 *
	 * @param checkoutCouponReq
	 * @param req
	 */
	@RequestMapping(value= "/useCoupon", method=RequestMethod.POST)
	public RestResult<OrderDiscountResult> useCoupon(@RequestBody CheckoutCouponReq checkoutCouponReq, HttpServletRequest req) {
		OrderHelper orderHelper = getOrderHelper(req);
		CheckoutResultEnum resultEnum;
		if(orderHelper == null) {
			LogUtil.warn("coupon check timeout");
			resultEnum = CheckoutResultEnum.CHECK_TIMEOUT;
			return buildResult(resultEnum.getCode(), resultEnum.getDescription(), null);
		}
		OrderTypeEnum ordTypEnum = OrderTypeEnum.get(orderHelper.getOrderType());
		CrmData crmvo = getCustomerData(req);
		if(ordTypEnum.isLY() && crmvo == null) {
			LogUtil.error("coupon check LY error");
			resultEnum = CheckoutResultEnum.CHECK_LY_FAIL;
			return buildResult(resultEnum.getCode(), resultEnum.getDescription(), null);
		}
		String couponSn = checkoutCouponReq.getCouponSn();
		if(StringUtil.isEmptyOrNull(couponSn)) {
			LogUtil.error("coupon input error");
			resultEnum = CheckoutResultEnum.CHECK_COUPON_INPUT_ERROR;
			return buildResult(resultEnum.getCode(), resultEnum.getDescription(), null);
		}

		OrderDiscountResult discountAdd;
		try {
			discountAdd = checkoutFacade.useCoupon(orderHelper, couponSn, ordTypEnum.isLY() ? orderHelper.getMsisdn() : null);
			//2020-10-05 Ted.Hsieh 新增 前端要顯示coupon折抵金額,因此在這邊先把折抵總金額存起來
			orderHelper.setPaymentPageDiscount(discountAdd);
		} catch (CouponException cex) {
			LogUtil.warn(" coupon sn: {} 使用失敗 {}", couponSn, cex.getDescription());
			resultEnum = CheckoutResultEnum.CHECK_COUPON_ERROR;
			return buildResult(resultEnum.getCode(), cex.getDescription(), null);
		} catch(Exception ex) {
			LogUtil.error("check coupon sn: {} 未知錯誤: {}", couponSn, ExceptionUtils.getStackTrace(ex));
			resultEnum = CheckoutResultEnum.CHECK_COUPON_ERROR;
			return buildResult(resultEnum.getCode(), resultEnum.getDescription(), null);
		}
		saveOrderHelper(orderHelper, req);
		return buildResult(discountAdd);
	}

	/**
	 * happyGo折抵
	 *
	 * @param checkoutHappyGoReq
	 * @param req
	 */
	@RequestMapping(value= "/updateHappyGo", method=RequestMethod.POST)
	public RestResult<OrderDiscountResult> updateHappyGo(@RequestBody CheckoutHappyGoReq checkoutHappyGoReq, HttpServletRequest req) {
		OrderHelper orderHelper = getOrderHelper(req);
		if (orderHelper.getHgToken() == null) {
			return buildResult(ReturnCode.RTN_CODE_MANDATORY_FIELD, ReturnCode.RTN_MSG_MANDATORY_FIELD, null);
		}
		CheckoutResultEnum resultEnum;
		OrderDiscountResult discountResult;
		try {
			discountResult = checkoutFacade.updateHappygo(orderHelper, checkoutHappyGoReq.getPoint());
		} catch(Exception ex) {
			LogUtil.error("updateHappyGo: token {} 未知錯誤: {}", orderHelper.getHgToken(), ExceptionUtils.getStackTrace(ex));
			return buildResult(ReturnCode.RTN_CODE_MANDATORY_FIELD, ex.getMessage(), null);
		}
		saveOrderHelper(orderHelper, req);
		return buildResult(discountResult);
	}

	/**
	 * 確認申購清單送出
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-08-28
	 * @return
	 */
	@Operation(summary = "確認申購清單送出", description = "確認申購清單送出")
	@RequestMapping(path = { "/orderSubmit" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<Object> orderSubmit(@RequestBody SubmitOrderReq form, HttpServletRequest req) throws Exception{
		
		LogUtil.info("orderSubmit() - start");
		OrderHelper orderHelper = getOrderHelper(req);
		ActivityHelper activityHelper = getActivityHelper(req);
		CrmData crmData = this.getCustomerData(req);
		SubmitOrderRes res = null;
		try {
			res = checkoutFacade.orderSubmit(orderHelper,form, activityHelper, crmData);
			if(null != orderHelper) {
				boolean isPass = flowControlHelper.completeStep(orderHelper.getFlowControlBean(), OrderFlowEnum.ORDER_LIST);
				if(isPass) {
					saveOrderHelper(orderHelper, req);
					//2020-10-22 Ted.Hsieh 新增 儲存crmData的修改結果(續約在結帳頁查詢方案內容時使用)
					saveCustomerData(crmData, req);
				}else {
					return flowControlValidationFail();
				}
			}else {
				return flowControlValidationFail();
			}
		}catch(Exception e) {
			LogUtil.error("申購清單送出異常", e);
			return buildResult(ReturnCode.RTN_MSG_UNEXPECT_ERROR,"很抱歉，系統繁忙中，請稍後再試。",res);
		}
		LogUtil.info("orderSubmit() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,res);
	}

	/**
	 * @description 不須繳款結帳，處理1.貨到付款、2.零元結帳、3.門市取貨 等"當前"不須繳款的結帳方式
	 * 1. 建立暫存訂單
	 * 2. 建立訂單
	 * 3. 更新ession
	 * @author Dennis.Chen
	 * @date 2020-08-29
	 * @return
	 */
	@Operation(summary = "不須繳款結帳", description = "處理「1.貨到付款」、「2.零元結帳」、「3.門市取貨」等\"當前\"不須繳款的結帳方式")
	@PostMapping("/nonPay")
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> nonPay(HttpServletRequest req) {
		
		OrderHelper orderHelper = this.getOrderHelper(req);
		CrmData crmData = this.getCustomerData(req);
		String pbsId = String.valueOf(req.getSession().getAttribute("CHANNEL_ACTIVITY_PACKAGE_BROWSING_STATISTIC_ID"));  //訪前瀏覽ID
		String uid = String.valueOf(req.getSession().getAttribute("uid"));  //登入後id
		String sessionId = req.getSession().getId(); //取得Session ID
		TmpCoMaster tmpCoMaster = null;

		//異常擋件
		if(orderHelper == null){
			LogUtil.error("[Checkout]Session訂單資料不可為空");
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, "您選購時間已達設定標準，為確保購物安全，請您回首頁重新選購，謝謝!", null);
		}

		//1. 建立訂單前置作業
		try {
			tmpCoMaster = checkoutFacade.prepareCustomerOrder(orderHelper, crmData);
		}catch(Exception exception){
			//20201026 Dennis.Chen - 若出現異常仍需更新Session，避免重複呼叫addAsticker、saveItem
			this.saveOrderHelper(orderHelper, req);
			throw exception;
		}

		//2. 建立訂單
		checkoutFacade.createCustomerOrder(orderHelper, tmpCoMaster, pbsId, uid, sessionId);

		//3. 處理Session資料
		//3-1. 移除CrmData
		this.removeCustomerData(req);

		//3-2. 移除購物車
		/*if(orderHelper.isCart()) {
			this.removeCartVO(req);
		}*/

		//3-3. 移除訪前瀏覽ID
		req.getSession().removeAttribute("CHANNEL_ACTIVITY_PACKAGE_BROWSING_STATISTIC_ID");

		//3-3. header離開購物流程警示訊息清空
		orderHelper.setExitMsg(null);

		//3-4 更新流程狀態
		flowControlHelper.completeStep(orderHelper.getFlowControlBean(), OrderFlowEnum.CHECKOUT);
		
		//3-5. 更新Session
		this.saveOrderHelper(orderHelper, req);

		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, null);
	}

	/**
	 * @description 信用卡結帳，處理1.信用卡、2.零元結帳-零元預取授權1元過卡 結帳
	 * 1. 建立暫存訂單
	 * 2. NPX 結帳
	 * 3. 更新ession
	 * @author Dennis.Chen
	 * @date 2020-08-29
	 * @return
	 */
	@Operation(summary = "信用卡結帳", description = "處理「1.信用卡」、「2.零元結帳-零元預取授權1元過卡」結帳")
	@PostMapping("/pay/credit")
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> payCredit(HttpServletRequest req, @RequestBody CreditPayReq creditPayReq){

		OrderHelper orderHelper = this.getOrderHelper(req);
		CrmData crmData = this.getCustomerData(req);
		String redirectUrl = null;
		TmpCoMaster tmpCoMaster = null;

		//異常擋件
		if(orderHelper == null){
			LogUtil.error("[Checkout-Credit]Session訂單資料不可為空");
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, "您選購時間已達設定標準，為確保購物安全，請您回首頁重新選購，謝謝!", null);
		}

		if(creditPayReq == null){
			LogUtil.error("[Checkout-Credit]信用卡繳款資訊不可為空");
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, "刷卡失敗，請確認您的信用卡資訊。", null);
		}


		try {
			//1. 建立訂單前置作業
			tmpCoMaster = checkoutFacade.prepareCustomerOrder(orderHelper, crmData);

			//2. NPX 結帳(刷卡失敗即刷退Coupon)
			redirectUrl = checkoutFacade.doPayment(orderHelper, tmpCoMaster, creditPayReq);

		}catch(Exception exception){
			//20201026 Dennis.Chen - 若出現異常仍需更新Session，避免重複呼叫addAsticker、saveItem
			this.saveOrderHelper(orderHelper, req);
			throw exception;
		}

		//3. 更新Session
		this.saveOrderHelper(orderHelper, req);


		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, redirectUrl);
	}

	/**
	 * @description 處理信用卡結帳(3D驗證)後之驗證、成立訂單、報表、Session整理等項目
	 * 1. 檢查3D安全驗證內容(3D安全驗證失敗即刷退Coupon)
	 * 2. 建立訂單
	 * 3. 更新Session
	 * 4. 302 轉址
	 * @author Dennis.Chen
	 * @date 2020-08-29
	 * @return
	 */
	@Operation(summary = "信用卡結帳後處理", description = "處理信用卡結帳(3D驗證)後之驗證、成立訂單、報表、Session整理等項目")
	@PostMapping("/pay/afterCredit")
	@ApiInputOutput(input = true, output = true)
	public void afterCredit(HttpServletRequest req, HttpServletResponse res) throws IOException {

		OrderHelper orderHelper = this.getOrderHelper(req);
		String pbsId = String.valueOf(req.getSession().getAttribute("CHANNEL_ACTIVITY_PACKAGE_BROWSING_STATISTIC_ID")); //訪前瀏覽ID
		String nppMultiPayment = req.getParameter("nppMultiPayment"); //NPX 3D驗證後回傳結果
		String uid = String.valueOf(req.getSession().getAttribute("uid"));  //登入後id
		String sessionId = req.getSession().getId(); //取得Session ID
		CoMaster coMaster = null;
		String returnCode = ReturnCode.RTN_CODE_UNEXPECT_ERROR;
		String returnMsg = ReturnCode.RTN_MSG_UNEXPECT_ERROR;

		//異常擋件
		if (orderHelper == null) {
			//orderHelper為空須中斷流程
			LogUtil.error("[Checkout-afterCredit]Session訂單資料不可為空");
			orderHelper.setAfterCreditResult(returnCode);
			orderHelper.setAfterCreditErrMsg("您選購時間已達設定標準，為確保購物安全，請您回首頁重新選購，謝謝!");
			this.saveOrderHelper(orderHelper, req);
			//302 Redirect To Frontend : /estore/order/payment
			res.sendRedirect(after3dSecureRedirect);
		}

		if (StringUtil.isEmptyOrNull(nppMultiPayment)) {
			//nppMultiPayment為空須中斷流程
			LogUtil.error("[Checkout-afterCredit]3D驗證回傳結果不可為空");
			orderHelper.setAfterCreditResult(returnCode);
			orderHelper.setAfterCreditErrMsg("很抱歉，暫時無法提供刷卡服務。");
			this.saveOrderHelper(orderHelper, req);
			//302 Redirect To Frontend : /estore/order/payment
			res.sendRedirect(after3dSecureRedirect);
		}

		//1. 檢查3D安全驗證內容(3D安全驗證失敗即刷退Coupon)
		Valid3dSecureBO result = checkoutFacade.validPayResult(orderHelper, nppMultiPayment);

		//2. 建立訂單
		if (result.isPass()) {
			coMaster = checkoutFacade.createCustomerOrder(orderHelper, null, pbsId, uid, sessionId);
			returnCode = ReturnCode.RTN_CODE_SUCCESS;
			returnMsg = ReturnCode.RTN_MSG_SUCCESS;
		} else {
			returnMsg = result.getErrorMsg();
		}

		//3. 處理Session資料
		//3-1. 移除CrmData
		this.removeCustomerData(req);

		//3-2. 移除購物車
		/*if(orderHelper.isCart()) {
			this.removeCartVO(req);
		}*/

		//3-3. 移除訪前瀏覽ID
		req.getSession().removeAttribute("CHANNEL_ACTIVITY_PACKAGE_BROWSING_STATISTIC_ID");

		//3-4. header離開購物流程警示訊息清空
		orderHelper.setExitMsg(null);

		//3-5. 更新3D驗證結果
		orderHelper.setAfterCreditResult(returnCode);
		orderHelper.setAfterCreditErrMsg(returnMsg);

		//3-6 3D驗證通過 更新流程控狀態
		if (result.isPass()) {
			flowControlHelper.completeStep(orderHelper.getFlowControlBean(), OrderFlowEnum.CHECKOUT);
		}

		//3-7. 更新Session
		this.saveOrderHelper(orderHelper, req);

		//4. 302 Redirect To Frontend : /estore/order/payment
        res.sendRedirect(after3dSecureRedirect);
	}


	/**
	 * 結帳流程 - 結帳完成頁取得資料（初始化）
	 *
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-01
	 * @param req
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "結帳流程 - 結帳完成頁取得資料（初始化）", description = "結帳流程 - 結帳完成頁取得資料（初始化）")
	@RequestMapping(path = { "/initComplete" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = true, output = true)
	public RestResult<OrderCompleteRes> initComplete(HttpServletRequest req) throws Exception {
		
		LogUtil.info("initComplete() - start");
		// 取得訂單資料
		OrderHelper orderHelper = getOrderHelper(req);
		
		if(orderHelper == null || !flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.COMPLETE)) {
			LogUtil.info("initComplete() - end with Error (Session 中無訂單資訊或流程錯誤)");
			return flowControlValidationFail();
		}
		
		// 轉換為畫面使用的結構
		OrderCompleteRes result = new OrderCompleteRes();
		// 取得畫面訂單資料
		result.setOrder(checkoutFacade.getCompleteOrderData(orderHelper));
		// 取得訂單資料
		result.setCart(checkoutFacade.getCartBeanData(orderHelper));
		// 設定手機保險金額
		result.setPremium(checkoutFacade.getPremium(orderHelper));
	
		LogUtil.info("initComplete() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
	}
	
	/**
	 * 手機保險產生 URL
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-09-17
	 * @param request
	 * @param session
	 * @param params
	 * @return
	 */
	@Operation(summary = "手機保險產生 URL", description = "手機保險產生 URL")
	@RequestMapping(value= "/getInsuranceUrl", method=RequestMethod.POST)
	public RestResult<Map<String, Object>> insurance(HttpServletRequest request, @RequestBody Map<String, Object> params){

		
		CoMaster coMaster = null;

		String from = (String)params.get("from");
		String cono = (String)params.get("cono");
		String btnWord = (String)params.get("btnWord");
		String daisdn = (String)params.get("daisdn");

		return buildResult(ReturnCode.RTN_CODE_SUCCESS, 
				           ReturnCode.RTN_MSG_SUCCESS, 
				           checkoutFacade.insurance(coMaster, from, cono, btnWord, daisdn));
	}



	/**
	 * 結帳頁 - 初始化
	 *
	 * @description
	 * @author Ted.Hsieh
	 * @date 2020-09-01
	 * @return
	 */
	@Operation(summary = "結帳頁 - 初始化", description = "結帳頁 - 初始化")
	@RequestMapping(path = { "/initPayment" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = false, output = true)
	public RestResult<OrderListRes> getPaymentInitData(HttpServletRequest req) throws Exception {

		LogUtil.info("getPaymentInitData() - start");

		OrderHelper orderHelper = getOrderHelper(req);

		if(orderHelper == null){
			LogUtil.warn("getPaymentInitData() - end with Error (Session 中無訂單資訊或流程錯誤)");
			return flowControlValidationFail();
		}

		//20200924 Dennis.Chen - 因3D驗證完成後會導回繳款頁，因此API /initPayment 需判斷該用戶是否信用卡繳款過，再走相對應的FlowControl
		String afterCreditResult = orderHelper.getAfterCreditResult();
		String afterCreditErrMsg = orderHelper.getAfterCreditErrMsg();
		boolean acceptIn = false;
		// "繳款成功" 驗證步驟OrderFlowEnum.COMPLETE，"繳款失敗"與"未繳款過"則驗證步驟OrderFlowEnum.CHECKOUT
		if(!StringUtil.isEmptyOrNull(afterCreditResult) && !StringUtil.isEmptyOrNull(afterCreditErrMsg)){
			if(StringUtil.equals(afterCreditResult, ReturnCode.RTN_CODE_SUCCESS)){
				acceptIn = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.COMPLETE);
			}else{
				acceptIn = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.CHECKOUT);
			}
		}else{
			acceptIn = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.CHECKOUT);
		}
		if(!acceptIn){
			LogUtil.warn("getPaymentInitData() - end with Error (Session 中無訂單資訊或流程錯誤)");
			return flowControlValidationFail();
		}

		CrmData crmData = getCustomerData(req);
		ActivityHelper activityHelper = getActivityHelper(req);
		OrderListRes result = checkoutFacade.getOrderList(orderHelper, crmData, OrderFlowEnum.CHECKOUT, activityHelper);

		//2020-10-29 Ted.Hsieh 新增 找縣市資訊和門市資訊的部分改由init一起帶入
		List<CityAreaVO> cityData = checkoutFacade.findCityAndRgn();
		List<AreaCity> storeData = checkoutFacade.findAllStoreCity();
		result.setCityData(cityData);
		result.setStoreData(storeData);

		//2020-09-21 Ted.Hsieh 確認登入狀態(結帳頁面發票載具選項出現條件 -- 有登入)
		String loginId = getFetLoginUID(req);
		Boolean cspLoginStatus = false;
		if(!StringUtil.isEmptyOrNull(loginId)){
			cspLoginStatus = true;
		}
		result.setCspLoginStatus(cspLoginStatus);

		//20200911 Dennis.Chen - 放入3D驗證結果
		result.setAfterCreditResult(afterCreditResult);
		result.setAfterCreditErrMsg(afterCreditErrMsg);

		//2020-10-08 Ted.Hsieh 新增 因facade有修改總金額
		this.saveOrderHelper(orderHelper, req);

		LogUtil.info("getPaymentInitData() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
	}

	/**
	 * @description 驗證用戶結帳資訊
	 * 1. 驗證填寫資料
	 * 2. 更新Session
	 * @author Dennis.Chen
	 * @date 2020-08-29
	 * @return
	 */
	@Operation(summary = "驗證結帳資訊", description = "驗證下列是否異常: 1. 取貨地址 2. 發票資訊 3. 推薦管道 4. 驗證新申辦門號是否已成單 5. 驗證獨賣件")
	@PostMapping("/validCheckOutInfo")
	@ApiInputOutput(input = true, output = true)
	public RestResult<Boolean> validCheckOutInfo(HttpServletRequest req, @RequestBody CheckoutSubmitReq checkoutSubmitReq){

		OrderHelper orderHelper = this.getOrderHelper(req);
		CrmData crmData = this.getCustomerData(req);
		String returnCode = ReturnCode.RTN_CODE_UNEXPECT_ERROR;
		String returnMsg = ReturnCode.RTN_MSG_UNEXPECT_ERROR;

		//異常擋件
		if(orderHelper == null){
			LogUtil.error("[Checkout-valid]Session訂單資料不可為空");
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, "您選購時間已達設定標準，為確保購物安全，請您回首頁重新選購，謝謝!", false);
		}

		if(checkoutSubmitReq == null){
			LogUtil.error("[Checkout-valid]結帳填寫資訊不可為空");
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, "請確認您的付款資訊是否異常。", false);
		}

		//1. 驗證用戶結帳資訊
		checkoutFacade.validSubmitInfo(orderHelper, checkoutSubmitReq, crmData);

		//2. 更新Session
		try {
			//2-1. 紀錄Client IP、Server IP，在後續的成立訂單(CO_MASTER)會拿來記錄
			orderHelper.setHost(InetAddress.getLocalHost().getHostAddress());
			orderHelper.setXff(req.getHeader("x-forwarded-for"));
		}catch (UnknownHostException e){
			LogUtil.error("[Checkout-驗證結帳資訊]取得Server IP位址失敗");
		}
		this.saveOrderHelper(orderHelper, req);

		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, true);
	}
	
	/**
	 * 個資頁 - 驗證員工編號
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-09-16
	 * @return
	 */
	@Operation(summary = "個資頁 - 驗證員工編號", description = "個資頁 - 驗證員工編號")
	@RequestMapping(path = { "/validRecommendSource" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<Object> validRecommendSource(@RequestParam String id) {
		
		LogUtil.info("validRecommendSource() - start");
		
		boolean result = checkoutFacade.countSalespersonID(id);
		
		if(!result) {
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR,"請您重新輸入推薦管道資料再行驗證! 若仍無法通過驗證, 為節省您寶貴時間請電洽客服人員為您服務, 謝謝",null);
		}
		
		LogUtil.info("validRecommendSource() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,null);
	}
	
    /**
     * 申購清單 - 儲存Session內的加購資訊
     *
     * @description
     * @author Alex.zhu
     * @date 2020-08-17
     * @return
     */
    @Operation(summary = "儲存加購資訊", description = "儲存加購資訊")
    @RequestMapping(path = { "/saveExtraBuyList" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
    public RestResult<String> saveExtraBuyList(HttpServletRequest req, @RequestBody(required = false) List<PremiumDiscountProd> extraBuyList) {

		LogUtil.info("saveExtraBuyList() - start");

		try {
			OrderHelper orderHelper = getOrderHelper(req);
			if(orderHelper != null) {
				orderHelper.setExtraBuyList(extraBuyList);
				saveOrderHelper(orderHelper,req);
			}

			LogUtil.info("saveExtraBuyList() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, "SUCCESS");
		}catch(Exception e) {
			LogUtil.error("儲存加購資訊失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, null);
		}

    }

	/**
	 * 驗證HappyGo是否登入過
	 * @param req
	 * @return
	 */
	@Operation(summary = "檢查是否登入HappyGo", description = "驗證session是否有HappyGo資訊")
	@RequestMapping(path = { "/checkHgStatus" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<Map<String, Object>> checkHgStatus(HttpServletRequest req) {

		LogUtil.info("checkHgStatus() - start");

		Map<String, Object> result = new HashMap<>();
		OrderHelper orderHelper = getOrderHelper(req);
		if(orderHelper != null) {
			if(StringUtil.isNotBlank(orderHelper.getHgTotalPoint())) {
				result.put("remainPoint", orderHelper.getHgTotalPoint());
				result.put("redeemPoint", orderHelper.getHgRedeemPoint());
			}
		}

		LogUtil.info("checkHgStatus() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,result);
	}
}
