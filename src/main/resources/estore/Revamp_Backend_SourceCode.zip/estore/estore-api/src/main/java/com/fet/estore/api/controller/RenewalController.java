package com.fet.estore.api.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.CrmDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.bean.CurrentPlan;
import com.fet.estore.core.bean.Product;
import com.fet.estore.core.bean.RenewInitRes;
import com.fet.estore.core.bean.req.ProductListReq;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.enums.BreadcrumsEnum;
import com.fet.estore.core.facade.ICommonFacade;
import com.fet.estore.core.facade.IFindProductFacade;
import com.fet.estore.core.facade.IRenewalFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.DataMaskerUtil;
import com.fet.estore.core.util.DataMaskerUtil.MaskerType;
import com.fet.estore.core.util.LogUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * 
 * @description 續約館的 Controller
 * @author Phil.lin
 * @date 2020-09-05
 */
@RestController
@RequestMapping("/renewal")
@Tag(name = "Renewal APIs")
public class RenewalController implements IBaseAct, CrmDataHelper {
	
	@Autowired
	private IRenewalFacade renewalFacadeImpl;
	
	@Autowired
	private IFindProductFacade findProductFacadeImpl;
	
	@Autowired
	private ICommonFacade commonFacadeImpl;
	
	@Operation(summary = "續約館大門，取得登入模式初始化", description = "取得初始化內容，取得是否使用 UID 登入的標記")
	@RequestMapping(path = {"/useUidLogin"}, method = {RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult<Boolean> useUidLogin(HttpServletRequest req) {
		
		LogUtil.info("useUidLogin() - start");
		
		Boolean res = "Y".equals(commonFacadeImpl.getSysConfig("LY_LOGIN_USE_UID"));
		
		LogUtil.info("useUidLogin() - end");
		
		return buildResult(res);
	}
	
	@Operation(summary = "續約館初始化", description = "取得初始化內容")
	@RequestMapping(path = {"/init"}, method = {RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult<RenewInitRes> initRenewal(HttpServletRequest req) {
		
		LogUtil.info("initRenewal() - start");
		RenewInitRes renewInitRes = new RenewInitRes();
		
		CrmData crmData = getCustomerData(req);
		
		if (crmData == null) {
			// Session 中無續約帳戶資料
			return buildResult(ReturnCode.RTN_CODE_DATA_NOT_FOUND, "您未符合續約資格，請重新登入", null);
		}
		

		// 1. 廠牌下拉
		renewInitRes.setBrandList(findProductFacadeImpl.getBrandList());
		// 2. 麵包屑 資訊
		renewInitRes.setBreadcrumbs(commonFacadeImpl.getBreadCrumb(BreadcrumsEnum.RENEWAL));
		// 3. 續約基本資料
		renewInitRes.setCurrentPlan(
				new CurrentPlan(
						(int)crmData.getCurrentDataPrice().intValue(), 
						DataMaskerUtil.doMask(crmData.getMsisdn(), MaskerType.Mobile),
						crmData.getContractEndDate()));
		// 4. 塞入原合約門號世代
		renewInitRes.setLyMobileGeneration(crmData.getMobileGenerationCode());
		
		LogUtil.info("initRenewal() - end");
		
		return buildResult(renewInitRes);
	}
	
	
	@Operation(summary = "續約館 - 搭手機", description = "取得手機清單資訊")
	@RequestMapping(path = {"/phone"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<Product>> getPhone(HttpServletRequest req, @RequestBody ProductListReq queryFrom) {
		
		LogUtil.info("getPhone() - start");
		
		CrmData crmData = getCustomerData(req);

		List<Product> phoneList = renewalFacadeImpl.findPhone(queryFrom, crmData);
		buildProductResult(phoneList, queryFrom.getType());
		
		LogUtil.info("getPhone() - end");
		
		return buildResult(phoneList);
	}
	
	
	@Operation(summary = "續約館 - 搭3C", description = "取得3C清單資訊")
	@RequestMapping(path = {"/3c"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<Product>> get3C(HttpServletRequest req, @RequestBody ProductListReq queryFrom) {
		
		LogUtil.info("get3c() - start");
		
		CrmData crmData = getCustomerData(req);

		List<Product> threeCList = renewalFacadeImpl.find3c(queryFrom, crmData);
		buildProductResult(threeCList, queryFrom.getType());

		LogUtil.info("get3c() - end");
		
		return buildResult(threeCList);
	}
	
	// 整理回傳商品資訊
	private List<Product> buildProductResult(List<Product> products, Boolean type) {
		if(products != null && !products.isEmpty()) {
			for(com.fet.estore.core.bean.Product product: products) {
				// 如資費或專案價為空則清空資費及專案價欄位，反之則清空商品價，避免讓頁面同時出現三種價格
				// 當查詢方式為單機時，清空月付及專案價只顯示商品價
				if(StringUtils.isBlank(product.getProjectPrice()) || type) {
					product.setRatePlan("");
					product.setProjectPrice("");
				} else {
					product.setProductPrice("");
				}
			}
		}
		return products;
	}
}
