package com.fet.estore.api.controller;

import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import com.fet.estore.core.bean.SrvResult;
import com.fet.estore.core.bean.req.CheckActivityCouponReq;
import com.fet.estore.core.bean.vo.crm.ValidationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.ActivityDataHelper;
import com.fet.estore.api.controller.helper.CrmDataHelper;
import com.fet.estore.api.controller.helper.SessionMsisdnHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.ActivityHelper;
import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.bean.LyCheckInputForm;
import com.fet.estore.core.bean.req.ValidateNameListReq;
import com.fet.estore.core.bean.req.ValidationReq;
import com.fet.estore.core.bean.vo.CrmValidationResultVO;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.enums.ValidationResultEnum;
import com.fet.estore.core.exception.EstoreException;
import com.fet.estore.core.facade.IValidationFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-10
 * @description
 */
@RestController
@RequestMapping("/validation")
@Tag(name = "Validation APIs")
public class ValidationController implements IBaseAct, CrmDataHelper, ActivityDataHelper, SessionMsisdnHelper {

	@Autowired
	@Qualifier("IValidationFacade")
	private IValidationFacade validationFacade;

	/**
	 * 門號攜碼驗證API
	 *
	 * @param validationReq 驗證Json參數
	 * @return
	 */
	@Operation(summary = "門號攜碼驗證", description = "驗證客戶端欲攜碼之門號")
	@RequestMapping(path = {"/checkNp"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<Object> checkNpAcceptable(@RequestBody(required = false) ValidationReq validationReq, HttpServletRequest req) {
		String npMdn = validationReq.getMsisdn();
		ValidationResultEnum result;
		if (StringUtil.isEmptyOrNull(npMdn)) {
			result = ValidationResultEnum.CHECK_NP_PARAMETER_EXCEPTION;
		} else {
			ActivityHelper activityHelper = getActivityHelper(req);
			try {
				result = validationFacade.checkActivityNewNp(activityHelper, npMdn);
				if (result != ValidationResultEnum.SUCCESS) {
					return buildResult(result.getCode(), result.getDescription(), null);
				}
				result = validationFacade.checkNpAcceptable(npMdn);
			} catch (Exception ex) {
				result = ValidationResultEnum.CHECK_FAIL_UNKNOWN;
				return buildResult(result.getCode(), result.getDescription() + ex.getMessage(), null);
			}
		}
		// 在 Session 中記錄通過攜碼證的門號
		setRecordMsisdn(npMdn, req);
		return buildResult(result.getCode(), result.getDescription(), null);
	}

	/**
	 * 商品明細頁 - 續約資格驗證
	 *
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-10
	 * @param req
	 * @return
	 */
	@Operation(summary = "續約資格驗證", description = "對應前端頁面, 2.續約身份驗證 -> 查詢可續約方案")
	@RequestMapping(path = {"/checkLy"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<CrmValidationResultVO> checkLyAcceptable(@RequestBody(required = false) LyCheckInputForm inputForm, HttpServletRequest req) {

		LogUtil.info("validateLyMsisdn() - start");
		LogUtil.Start("validateLyMsisdn()");
		// 要驗續約資格前先清掉原本紀錄的 CRM Data
		removeCustomerData(req);

		final CrmValidationResultVO result;

		// 輸入表單無資料
		if (inputForm == null) {
			result = new CrmValidationResultVO(ValidationResultEnum.CHECK_LY_PARAMETER_EXCEPTION);
		} else {
			LogUtil.Start("1. 活動賣場進入時取得活動 ID");
			ActivityHelper activityHelper = getActivityHelper(req);
			//只有活動賣場才有activityHelper，inputForm內的ActId從session拿防止竄改
			if (activityHelper != null && activityHelper.getActivityId() != null) {
				inputForm.setActId(activityHelper.getActivityId());
			}
			LogUtil.End("1. 活動賣場進入時取得活動 ID");
			LogUtil.Start("2. 資料檢查");
			String rocId = inputForm.getRocId();
			String msisdn = inputForm.getMsisdn();

			// 資料格式驗證
			if (!StringUtil.checkRocId(rocId)) {
				LogUtil.End("2. 資料檢查");
				// 格式錯誤
				result = new CrmValidationResultVO(ValidationResultEnum.CHECK_LY_ROCID_FORMAT_ERROR);
			} else if (!Pattern.matches("[0-9]{10}", msisdn)) {
				LogUtil.End("2. 資料檢查");
				// 格式錯誤
				result = new CrmValidationResultVO(ValidationResultEnum.CHECK_LY_MSISDN_FORMAT_ERROR);				 
			} else {
				LogUtil.End("2. 資料檢查");
				// 格式正確呼叫 Facade 做檢核
				result = validationFacade.checkLyAcceptable(inputForm);
				// 設定是否啟動 OTP
//				result.setNeedOtp(validationFacade.isLyOtp());
			}
		}
		// 有 CRM DATA 則取出來塞入 Session 中
		CrmData crmData = result.getCrmData();
		if (crmData != null) {
			saveCustomerData(crmData, req);
			// 清除result 物件的 crmData（避免將CrmData 傳回給前端
			result.setCrmData(null);
			// 取出使用者原合約 G 數
			result.setMobileGenerationCode(crmData.getMobileGenerationCode());
			//session 存入 service_channel
			putServiceChannel(req, inputForm.getServiceChannel());
		}
		
		// 名單制活動建立 ActivityId 到 Session 中
		if (result.getNameListActivityId() != null) {
			LogUtil.info("validateLyMsisdn() - 塞入名單式賣場活動 activityId : {}", result.getNameListActivityId());
			ActivityHelper activityHelper = new ActivityHelper();
			activityHelper.setActivityId(result.getNameListActivityId());
			activityHelper.setRenewAuthenticated(true);
			activityHelper.setLyMsisdn(inputForm.getMsisdn());
			activityHelper.setLyRocId(inputForm.getRocId());
			saveActivityHelper(activityHelper, req);
		}

		// 續約館時撈取錯誤對話框資訊
		if(inputForm.getIsFromRenewal() && result.getResultEnum() != ValidationResultEnum.SUCCESS) {
			result.setMsgboxInfo(validationFacade.getMsgboxInfo());
		}
		
		// 整理結果做回傳
		LogUtil.End("validateLyMsisdn()");
		LogUtil.info("validateLyMsisdn() - end");
		return buildResult(result.getReturnCode(), result.getReturnMsg(), result);
	}

	/**
	 * 續約館大門 - 確認登入狀態
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-10
	 * @param req
	 * @return
	 * @throws Exception 
	 */
	@Operation(summary = "續約館大門", description = "續約館大門 - 確認登入狀態")
	@RequestMapping(path = {"/checkLyLogin"}, method = {RequestMethod.POST, RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult<CrmValidationResultVO> checkLyLogin(HttpServletRequest req,@RequestParam String serviceChannel) throws Exception {

		LogUtil.info("checkLyLogin() - start");

		final String uid = getFetLoginUID(req);
		final String msisdn = getFetLoginMsisdn(req);
		final String rocid = getFetLoginRocId(req);

		final CrmValidationResultVO result;

		if (uid == null) {
			// uid 無值，使用者為未登入狀態
			throw new EstoreException("20100", "未登入");
		} else {
			// 使用 uid 進行續約驗證
			result = validationFacade.checkLyAcceptableForLogin(uid, msisdn, rocid);
			// 設定是否啟動 OTP
//			result.setNeedOtp(validationFacade.isLyOtp());
			// 將門號回傳給前端用（FOR AA）
			result.setMsisdn(msisdn);
		}

		// 有 CRM DATA 則取出來塞入 Session 中
		CrmData crmData = result.getCrmData();
		if (crmData != null) {
			saveCustomerData(crmData, req);
			// 清除result 物件的 crmData（避免將CrmData 傳回給前端
			result.setCrmData(null);
		}

		if (result.getResultEnum() != ValidationResultEnum.SUCCESS) {
			result.setMsgboxInfo(validationFacade.getMsgboxInfo());
		}
		
		// 名單制活動建立 ActivityId 到 Session 中
		if (result.getNameListActivityId() != null) {
			LogUtil.info("validateLyMsisdn() - 塞入名單式賣場活動 activityId : {}", result.getNameListActivityId());
			ActivityHelper activityHelper = new ActivityHelper();
			activityHelper.setActivityId(result.getNameListActivityId());
			activityHelper.setRenewAuthenticated(true);
			activityHelper.setLyMsisdn(msisdn);
			activityHelper.setLyRocId(rocid);
			saveActivityHelper(activityHelper, req);
		}
		
		//session 存入 service_channel
		if(StringUtil.isNotEmptyOrNull(serviceChannel)) {
			putServiceChannel(req,serviceChannel);
		}

		// 整理結果做回傳

		LogUtil.info("checkLyLogin() - end");
		return buildResult(result.getReturnCode(), result.getReturnMsg(), result);
	}

	@Operation(summary = "活動賣場驗證優惠券序號", description = "活動賣場驗證優惠券序號")
    @RequestMapping(path = {"/checkActivityCoupon"}, method = {RequestMethod.POST, RequestMethod.GET})
    @ApiInputOutput(input = true, output = true)
	public RestResult<String> checkActivityCoupon(HttpServletRequest req, @RequestBody CheckActivityCouponReq checkActivityCouponReq){
		String sessionId = req.getSession().getId();

		ActivityHelper activityHelper = this.getActivityHelper(req);

		SrvResult result = validationFacade.checkActivityCoupon(checkActivityCouponReq, activityHelper, sessionId);

		saveActivityHelper(activityHelper, req);

		if (result.isSuccess()) {
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result.getMessage());
		} else {
			return buildResult(ReturnCode.RTN_CODE_MANDATORY_FIELD, ReturnCode.RTN_MSG_MANDATORY_FIELD, result.getMessage());
		}
	}

	/**
	 * 活動賣場, 名單驗證
	 *
	 * @param req
	 * @return
	 * @throws Exception
	 * @description
	 * @author Klyve.Chen
	 * @date 2020-09-17
	 */
	@Operation(summary = "活動賣場, 名單驗證", description = "活動賣場, 名單驗證")
	@RequestMapping(path = {"/checkNameList"}, method = {RequestMethod.POST, RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult checkActivityNameList(HttpServletRequest req, @RequestBody ValidateNameListReq nameListReq) {
		ActivityHelper activityHelper = getActivityHelper(req);

		if (activityHelper == null) {
			return buildResult(ReturnCode.RTN_CODE_MANDATORY_FIELD, ReturnCode.RTN_MSG_MANDATORY_FIELD, null);
		}

		String verificationCode = nameListReq.getVerificationCode();

		String serialNo = nameListReq.getSerialNo();

		String sessionId = req.getSession().getId();

		LogUtil.info("秘密賣場NameList驗證: verificationCode {}, serialNo {}", verificationCode, serialNo);

		ValidationResultEnum result = validationFacade.checkActivityNameList(activityHelper, verificationCode, serialNo, sessionId);

		//若是成功將驗證資訊存入, for New Np存入給之後流程判斷使用
		if (result == ValidationResultEnum.SUCCESS) {
			activityHelper.setAuthCode(nameListReq.getVerificationCode());
			activityHelper.setAuthSerialNo(nameListReq.getSerialNo());
		}

		saveActivityHelper(activityHelper, req);
		return buildResult(result.getCode(), result.getDescription(), result.getDescription());
	}
}