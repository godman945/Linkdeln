package com.fet.estore.api.controller;

import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.BrowseHistory;
import com.fet.estore.core.bean.BrowseHistoryForm;
import com.fet.estore.core.bean.FindProductInfo;
import com.fet.estore.core.bean.Product;
import com.fet.estore.core.bean.bo.FindProductBO;
import com.fet.estore.core.bean.req.ProductListReq;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.constant.SystemConstant;
import com.fet.estore.core.enums.BreadcrumsEnum;
import com.fet.estore.core.facade.ICommonFacade;
import com.fet.estore.core.facade.IFindProductFacade;
import com.fet.estore.core.model.StickyCategory;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.LogUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

@RestController
@RequestMapping("/findProduct")
@Tag(name = "Find Product APIs")
public class FindProductController implements IBaseAct {


	@Autowired
	private IFindProductFacade findProductFacadeImpl;
	
	@Autowired
	private ICommonFacade commonFacadeImpl;
	
	/**
	 * 找商品 - 頁面初始化資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-27
	 * @return
	 * @throws SQLException
	 */
	@Operation(summary = "取得找商品頁初始化資訊", description = "取得找商品頁所需資訊，包含探索區塊、廠牌下拉清單、麵包屑")
	@RequestMapping(path = {"/init"}, method = {RequestMethod.GET})
	@ApiInputOutput(input = true, output = true)
	public RestResult<FindProductInfo> getFindProductInitData() {
		
		LogUtil.info("getFindProductInitData() - start");
		
		FindProductInfo findProductInfo = new FindProductInfo();
		// 1. 探索區塊
		findProductInfo.setSearchList(findProductFacadeImpl.getSearchList());
		// 2. 廠牌下拉
		findProductInfo.setBrandList(findProductFacadeImpl.getBrandList());
		// 3. 麵包屑 資訊
		findProductInfo.setBreadcrumbs(commonFacadeImpl.getBreadCrumb(BreadcrumsEnum.FIND_PRODUCT));
		
		LogUtil.info("getFindProductInitData() - end");
		return buildResult(findProductInfo);
	}

	/**
	 * 找商品 - 配件清單
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-28
	 * @return
	 * @throws SQLException
	 */
	@Operation(summary = "取得找商品 - 配件清單資訊", description = "取得配件資訊")
	@RequestMapping(path = {"/accessories"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<Product>> getAccessories(@RequestBody ProductListReq queryFrom) {
		
		LogUtil.info("getAccessories() - start");

		FindProductBO findProductBO = new FindProductBO(queryFrom);
		findProductBO.setStartIndex(1).setQuerySize(SystemConstant.FIND_PRODUCT_MAX_SIZE);
		findProductBO.setProductType(StickyCategory.ACCESSORY);
		// 取得配件清單
		List<Product> accessoriesList = findProductFacadeImpl.findAccessories(findProductBO);

		LogUtil.info("getAccessories() - end");
		
		return buildResult(accessoriesList);
	}
	
	/**
	 * 找商品 - 手機清單
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-28
	 * @return
	 * @throws SQLException
	 */
	@Operation(summary = "取得找商品 - 手機清單資訊", description = "取得手機清單資訊")
	@RequestMapping(path = {"/phone"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<Product>> getPhone(@RequestBody ProductListReq queryFrom) {
		
		LogUtil.info("getPhone() - start");

		FindProductBO findProductBO = new FindProductBO(queryFrom);
		List<Product> phoneList = findProductFacadeImpl.findPhone(findProductBO);
		buildProductResult(phoneList, queryFrom.getType());
		
		LogUtil.info("getPhone() - end");
		
		return buildResult(phoneList);
	}
	
	/**
	 * 找商品 - 智慧生活
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-28
	 * @return
	 * @throws SQLException
	 */
	@Operation(summary = "取得找商品 - 智慧生活資訊", description = "取得找商品 - 智慧生活資訊")
	@RequestMapping(path = {"/3c"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<Product>> get3c(@RequestBody ProductListReq queryFrom) {
		
		LogUtil.info("get3c() - start");

		FindProductBO findProductBO = new FindProductBO(queryFrom);
		List<Product> threeCList = findProductFacadeImpl.find3c(findProductBO);
		buildProductResult(threeCList, queryFrom.getType());

		LogUtil.info("get3c() - end");
		
		return buildResult(threeCList);
	}
	
	/**
	 * 找商品 - 平板電腦
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-28
	 * @return
	 * @throws SQLException
	 */
	@Operation(summary = "取得找商品 - 平板電腦資訊", description = "取得找商品 - 平板電腦資訊")
	@RequestMapping(path = {"/computer"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<Product>> getComputer(@RequestBody ProductListReq queryFrom) {
		
		LogUtil.info("getComputer() - start");

		FindProductBO findProductBO = new FindProductBO(queryFrom);
		List<Product> computerList = findProductFacadeImpl.findComputer(findProductBO);
		buildProductResult(computerList, queryFrom.getType());
		
		LogUtil.info("getComputer() - end");
		
		return buildResult(computerList);
	}
	
	/**
	 * 找商品 - 您曾瀏覽過
	 * 
	 * @description
	 * @author Alex.Zhu
	 * @date 2020-07-30
	 * @return
	 */
	@Operation(summary = "取得找商品 - 您曾瀏覽過資訊", description = "取得找商品 - 您曾瀏覽過資訊")
	@RequestMapping(path = {"/getBrowseHistory"}, method = {RequestMethod.POST})
	@ApiInputOutput(input = true, output = true)
	public RestResult<BrowseHistory> getBrowseHistory(
			@RequestBody(required = false) List<BrowseHistoryForm> products) {
		
		LogUtil.info("getBrowseHistory() - start");
		
		BrowseHistory browseHistory = new BrowseHistory();
		List<String> productIdsInAcc = new ArrayList<String>();
		List<String> productIdsInOther = new ArrayList<String>();
		List<Product> resultList = new ArrayList<Product>();
		FindProductBO findProductBO = new FindProductBO();
		List<Product> otherList = new ArrayList<Product>();
		List<Product> accList = new ArrayList<Product>();

		try {
			//將取回陣列以sort值(排序)對應productId
			LinkedHashMap<String, Integer> productMap = new LinkedHashMap<String,Integer>();

			if(null != products) {
				
				products.forEach(product->{productMap.put(product.getProductId(),product.getSort());});
				
				//products 依分類(配件類、其他類(手機、平板、智慧生活))分為兩個List
				products.forEach(product->{
					if(SystemConstant.NEWSTORE_ACC.equals(product.getCategoryGroup())) {
						productIdsInAcc.add(product.getProductId());
					}else {
						productIdsInOther.add(product.getProductId());
					}
				});
				
				//拉取其他類(手機、平板、智慧生活)商品
				if(productIdsInOther.size() > 0) {
					findProductBO.setProductIds(productIdsInOther);
					otherList = findProductFacadeImpl.getBrowseHistory(findProductBO);
				}
				
				//拉取配件類商品
				if(productIdsInAcc.size() > 0) {
					findProductBO.setProductIds(productIdsInAcc);
					accList = findProductFacadeImpl.findAccessories(findProductBO);
				}
			
				//排序
				setHistorySort(productMap,accList,otherList,resultList);
				buildProductResult(resultList, false); // 你曾瀏覽過先預設顯示搭門號 added by Roil.Li
			}
			
			browseHistory.setTitle(SystemConstant.BROWSE_HISTORY_TITLE);
			browseHistory.setCards(resultList);
			
			LogUtil.info("getBrowseHistory() - end");
			return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, browseHistory);
		}catch(Exception e) {

			LogUtil.error("取得曾瀏覽失敗", e);
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, ReturnCode.RTN_MSG_UNEXPECT_ERROR, null);
		}
		
	}

	// 整理回傳商品資訊
	private void buildProductResult(List<Product> products, Boolean type) {
		if(products != null && !products.isEmpty()) {
			for(com.fet.estore.core.bean.Product product: products) {
				// 如資費或專案價為空則清空資費及專案價欄位，反之則清空商品價，避免讓頁面同時出現三種價格
				// 當查詢方式為單機時，清空月付及專案價只顯示商品價
				if(StringUtils.isBlank(product.getRatePlan())
						|| StringUtils.isBlank(product.getProjectPrice())
						|| type) {
					product.setRatePlan(null);
					product.setProjectPrice(null);
				} else {
					product.setProductPrice(null);
				}
			}
		}
	}
	
	//您曾瀏覽過商品進行排序
	private void setHistorySort(LinkedHashMap<String,Integer> productMap,List<Product> accList,List<Product> otherList,List<Product> resultList){
		
		productMap.remove(null);
		productMap.keySet().forEach(pid->{
			
			if(accList.size() > 0) {
				accList.stream().anyMatch(acc->{
					if(pid.equals(acc.getProductId())) {
						resultList.add(acc);
						return pid.equals(acc.getProductId());
					}
					return false;
				});
			};
			
			if(otherList.size() > 0) {
				otherList.stream().anyMatch(phone->{
					if(pid.equals(phone.getProductId())) {
						resultList.add(phone);
						return pid.equals(phone.getProductId());
					}
					return false;
				});
			};
			
		});
	}
}
