package com.fet.estore.api.controller;

import com.fet.estore.api.controller.helper.CrmDataHelper;
import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.FaqItem;
import com.fet.estore.core.bean.MetaInfo;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.OtpItem;
import com.fet.estore.core.bean.UrlMetadata;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.constant.SystemConstant;
import com.fet.estore.core.enums.LoginStatusEnum;
import com.fet.estore.core.facade.ICommonFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
@RequestMapping("/common")
@Tag(name = "Common APIs")
public class CommonController implements IBaseAct, CrmDataHelper, OrderDataHelper {

	@Autowired
	ICommonFacade commonFacadeImpl;

	/**
	 * @description 取得前端所需參數
	 * @autor Dennis.Chen
	 * @date 2020-08-13
	 */
	@GetMapping("/getSysConfig/{param}")
	@Operation(summary = "取得前端所需系統參數", description = "透過指定參數取得前端所需系統參數，包含Header、Footer URL Domain")
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> getSysConfig(@PathVariable("param") String param) {

		String result = commonFacadeImpl.getSysConfig(param);

		return buildResult(result);
	}

	/**
	 * 驗證用戶是否登入
	 * @param req
	 * @return
	 * @author Roil.Li
	 * @date 2020-08-21
	 */
	@GetMapping("/checkLoginStatus")
	@Operation(summary = "確認登入狀態", description = "驗證Session內是否有登入後塞入的uid")
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> checkLoginStatus(HttpServletRequest req) {
		String result = null;
		String uid = Objects.toString(req.getSession().getAttribute("uid"), "");
		if(StringUtils.isNotBlank(uid)) {
			result = LoginStatusEnum.SIM.toString();
		} else {
			result = LoginStatusEnum.NONLOGIN.toString();
		}
		return buildResult(result);
	}

	/**
	 * 取得常見問題
	 * @author Klyve.Chen
	 * @since  2020-08-18
	 */
	@GetMapping("/getFaqItem/{pageName}")
	@Operation(summary = "取得常見問題", description = "取得常見問題")
	@ApiInputOutput(input = true, output = true)
	public RestResult<List<FaqItem>> getFaqItem(@PathVariable(name = "pageName", required = false) String pageName) {
		List<FaqItem> faqItems = commonFacadeImpl.getFaqItem(pageName);
		return buildResult(faqItems);
	}

	/**
	 * 取得網址Metadata
	 * @author Klyve.Chen
	 * @since  2020-09-02
	 */
	@GetMapping("/getMetadata/{urlPath}")
	@Operation(summary = "取得網址Metadata", description = "當前URL 去除eStore/之後的路徑取得網址Metadata")
	@ApiInputOutput(input = true, output = true)
	public RestResult<UrlMetadata> getMetadata(@PathVariable(name = "urlPath", required = false) String urlPath) {
		UrlMetadata metadata = new UrlMetadata();
		metadata.setTitle("Html Head MetaTag 標題");
		metadata.setDescription("Html Head MetaTag 說明");
		metadata.setKeywords("Html Head MetaTag 關鍵字" + Math.random());
		return buildResult(metadata);
	}

	/**
	 * 發送 OTP CODE
	 * @param req
	 * @return
	 * @author Roil.Li
	 * @date 2020-09-02
	 */
	@RequestMapping(value = "/sendOtpCode", method = RequestMethod.POST)
	@Operation(summary = "發送 OTP CODE", description = "發送 OTP CODE")
	@ApiInputOutput(input = true, output = true)
	public RestResult<OtpItem> sendOtpCode(HttpServletRequest req) {
		OrderHelper orderHelper = getOrderHelper(req);
		String msisdn = "";
		if(orderHelper != null) {
			msisdn = orderHelper.getMsisdn();
		}
		String rtnCode = ReturnCode.RTN_CODE_MANDATORY_FIELD;
		String rtnMsg = ReturnCode.RTN_MSG_MANDATORY_FIELD;
		OtpItem otpResult = null;
		try {
			if(StringUtils.isNotBlank(msisdn)) {
				otpResult = commonFacadeImpl.sendOtp(msisdn);
				req.getSession().setAttribute(SystemConstant.OTP_MESSAGE, otpResult.getMessage());
				rtnCode = ReturnCode.RTN_CODE_SUCCESS;
				rtnMsg = ReturnCode.RTN_MSG_SUCCESS;
			}
		} catch (Exception e) {
			LogUtil.error(e);
			rtnCode = ReturnCode.RTN_CODE_UNEXPECT_ERROR;
			rtnMsg = ReturnCode.RTN_MSG_UNEXPECT_ERROR;
		}
		return buildResult(rtnCode, rtnMsg, otpResult);
	}

	/**
	 * 驗證 OTP CODE
	 * @param req
	 * @return
	 * @author Roil.Li
	 * @date 2020-09-02
	 */
	@RequestMapping(value = "/checkOtp", method = RequestMethod.POST)
	@Operation(summary = "驗證 OTP CODE", description = "驗證 OTP CODE")
	@ApiInputOutput(input = true, output = true)
	public RestResult<Boolean> checkOtp(HttpServletRequest req, @RequestBody Map<String, Object> params) {
		OrderHelper orderHelper = getOrderHelper(req);
		HttpSession session = req.getSession();
		String otpCode = Objects.toString(params.get("otpCode"), "");
		String otpMessage = Objects.toString(session.getAttribute(SystemConstant.OTP_MESSAGE), "");
		String msisdn = "";
		if(orderHelper != null) {
			msisdn = orderHelper.getMsisdn();
		}
		String rtnCode = ReturnCode.RTN_CODE_MANDATORY_FIELD;
		String rtnMsg = ReturnCode.RTN_MSG_MANDATORY_FIELD;
		boolean otpResult = false;
		try {
			if(StringUtils.isNotBlank(msisdn)
				&& StringUtils.isNotBlank(otpCode)
				&& StringUtils.isNotBlank(otpMessage)) {
				otpResult = commonFacadeImpl.checkOtp(msisdn, otpCode, otpMessage);
				session.setAttribute(SystemConstant.PASS_OTP, "Y");
				rtnCode = ReturnCode.RTN_CODE_SUCCESS;
				rtnMsg = ReturnCode.RTN_MSG_SUCCESS;
			}
		} catch(Exception e) {
			LogUtil.error(e);
			rtnCode = ReturnCode.RTN_CODE_UNEXPECT_ERROR;
			rtnMsg = ReturnCode.RTN_MSG_UNEXPECT_ERROR;
		}
		return buildResult(rtnCode, rtnMsg, otpResult);
	}

	/**
	 * 取得Meta資訊
	 * @param req
	 * @return
	 * @author Roil.Li
	 * @date 2020-10-19
	 */
	@RequestMapping(value = "/getMetaInfo", method = RequestMethod.GET)
	@Operation(summary = "取得SEO所需Meta資訊", description = "用前端路徑取得該頁面Meta資訊")
	@ApiInputOutput(input = true, output = true)
	public RestResult<MetaInfo> getMetaInfo(HttpServletRequest req, @RequestParam(name = "path") String path) {
		String rtnCode = ReturnCode.RTN_CODE_MANDATORY_FIELD;
		String rtnMsg = ReturnCode.RTN_MSG_MANDATORY_FIELD;
		MetaInfo metaInfo = null;
		try {
			if (StringUtil.isNotBlank(path)) {
				metaInfo = commonFacadeImpl.getMetaInfo(path);
				rtnCode = ReturnCode.RTN_CODE_SUCCESS;
				rtnMsg = ReturnCode.RTN_MSG_SUCCESS;
			}
		} catch (Exception e) {
			LogUtil.error(e);
			rtnCode = ReturnCode.RTN_CODE_UNEXPECT_ERROR;
			rtnMsg = ReturnCode.RTN_MSG_UNEXPECT_ERROR;
		}
		return buildResult(rtnCode, rtnMsg, metaInfo);
	}
}
