package com.fet.estore.api.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.FlowControlHelper;
import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.CityAreaVO;
import com.fet.estore.core.bean.CrossCooperationData;
import com.fet.estore.core.bean.FlowControlBean;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.OrderListRes;
import com.fet.estore.core.bean.SubmitOrderRes;
import com.fet.estore.core.bean.req.CheckoutSubmitReq;
import com.fet.estore.core.bean.req.CreateShopeeOrderReq;
import com.fet.estore.core.bean.req.SubmitOrderReq;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.enums.OrderFlowEnum;
import com.fet.estore.core.exception.ValidationException;
import com.fet.estore.core.facade.ICheckoutFacade;
import com.fet.estore.core.facade.IShopeeFacade;
import com.fet.estore.core.model.AreaCity;
import com.fet.estore.core.model.TmpCoMaster;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/shopee")
@Tag(name = "蝦皮賣場 APIs")
public class ShopeeController implements IBaseAct, OrderDataHelper  {

	@Autowired
	private IShopeeFacade shopeeFacade;
	@Autowired
	private FlowControlHelper flowControlHelper;
	@Autowired
	private ICheckoutFacade checkoutFacade;
	
	@PostMapping("/createOrder")
	@Operation(summary = "建立蝦皮訂單", description = "建立蝦皮訂單")
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> createShopeeOrder(HttpServletRequest req, @RequestBody CreateShopeeOrderReq reqForm) throws Exception {
	
		LogUtil.info("createShopeeOrder() - start");
		
		LogUtil.info("cono: {}", reqForm.getCono());
		
		final boolean success;
		//訂單UUID
		final String orderUUID;

		// 檢核資料
		CrossCooperationData xCooperationData = null;
		
		try {
			 xCooperationData = shopeeFacade.validateShopeeOrder(reqForm.getCono());
		} catch(ValidationException e) {
			return buildResult(e, e.getDescription());
		}
		
		// 訂單資料
		final OrderHelper orderHelperData;
		
		if (xCooperationData == null) {
			// 驗證未過，給 null
			orderHelperData = null;
		} else {
			// 驗證通過，建立訂單
			orderHelperData = shopeeFacade.createOrderHelper(xCooperationData);
		}
		
		LogUtil.info(orderHelperData);
		
		if(orderHelperData != null) {
			// 建立流程控制器
			FlowControlBean flowControlBean = flowControlHelper.initFlowControl(orderHelperData);
			// 標記商品明細頁
			flowControlHelper.completeStep(flowControlBean, OrderFlowEnum.ORDER_SUBMIT);
			// 將流程控制器存入 Order 中
			orderHelperData.setFlowControlBean(flowControlBean);
			//2020-11-11 Ted.Hsieh 新增 產生UUID (add by Phil 2020-11-12)
			orderUUID = UUID.randomUUID().toString();
			
			saveOrderHelper(orderHelperData, req);
			// 將訂單的UUID記錄到 Session中
			saveOrderUUID(req, orderUUID);
			
			success = true;
		} else {
			orderUUID = "";
			success = false;
		}
		
		LogUtil.info("createShopeeOrder() - end , success:{}", success);
		
		return success ? buildResult(ReturnCode.RTN_CODE_SUCCESS, orderUUID,"success") : buildResult(ReturnCode.RTN_CODE_DATA_NOT_FOUND, "查無訂單或已完成申辦流程", "查無訂單或已完成申辦流程");
	}
	
	/**
	 * @description 不須繳款結帳，處理1.貨到付款、2.零元結帳、3.門市取貨 等"當前"不須繳款的結帳方式
	 * 1. 建立暫存訂單
	 * 2. 建立訂單
	 * 3. 更新ession
	 * @author Phil.Lin
	 * @date 2020-10-23
	 * @return
	 */
	@Operation(summary = "不須繳款結帳", description = "處理蝦皮訂單的訂單送出")
	@PostMapping("/nonPay")
	@ApiInputOutput(input = true, output = true)
	public RestResult<String> shopeeNonPay(HttpServletRequest req) {
		
		LogUtil.info("shopeeNonPay() - start");
		
		OrderHelper orderHelper = this.getOrderHelper(req);
		String pbsId = String.valueOf(req.getSession().getAttribute("CHANNEL_ACTIVITY_PACKAGE_BROWSING_STATISTIC_ID"));  //訪前瀏覽ID
		String uid = String.valueOf(req.getSession().getAttribute("uid"));  //登入後id
		String sessionId = req.getSession().getId(); //取得Session ID

		//異常擋件
		if(orderHelper == null){
			LogUtil.error("[Checkout]Session訂單資料不可為空");
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, "您選購時間已達設定標準，為確保購物安全，請您回首頁重新選購，謝謝!", "您選購時間已達設定標準，為確保購物安全，請您回首頁重新選購，謝謝!");
		}

		//1. 建立訂單前置作業
		TmpCoMaster tmpCoMaster;
		try {
			tmpCoMaster = shopeeFacade.prepareCustomerOrder(orderHelper);
		}catch(Exception exception){
			//20201026 Dennis.Chen - 若出現異常仍需更新Session，避免重複呼叫addAsticker、saveItem
			this.saveOrderHelper(orderHelper, req);
			throw exception;
		}

		//2. 建立訂單
		shopeeFacade.createCustomerOrder(orderHelper, tmpCoMaster, pbsId, uid, sessionId);

		//3. 處理Session資料
		//3-1. 移除訪前瀏覽ID
		req.getSession().removeAttribute("CHANNEL_ACTIVITY_PACKAGE_BROWSING_STATISTIC_ID");

		//3-2. header離開購物流程警示訊息清空
		orderHelper.setExitMsg(null);

		//3-3 更新流程狀態
		flowControlHelper.completeStep(orderHelper.getFlowControlBean(), OrderFlowEnum.CHECKOUT);
		
		//3-5. 更新Session
		this.saveOrderHelper(orderHelper, req);

		LogUtil.info("shopeeNonPay() - start");
		
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, null);
	}
	
	/**
	 * 蝦皮賣場結帳流程 - 取得申購清單
	 * 
	 * @description
	 * @author Phil.Lin
	 * @date 2020-11-17
	 * @return
	 * @throws Exception 
	 */
	@Operation(summary = "蝦皮賣場結帳流程 - 取得申購清單", description = "蝦皮賣場結帳流程 - 取得申購清單")
	@RequestMapping(path = { "/initOrderList" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = true, output = true)
	public RestResult<OrderListRes> getShopeeOrderListInitData(HttpServletRequest req) throws Exception {
		
		LogUtil.info("getShopeeOrderListInitData() - start");
		
		OrderHelper orderHelper = getOrderHelper(req);
		
		OrderListRes result = null;
		
		if(orderHelper == null) {
			LogUtil.warn("getShopeeOrderListInitData() - end with Error (Session 中無訂單資訊或流程錯誤)");
			return flowControlValidationFail();
		}
		
		boolean acceptIn = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.ORDER_LIST);
		
		if(acceptIn) {
			result = shopeeFacade.getShopeeOrderData(orderHelper);
		} else {
			LogUtil.warn("getShopeeOrderListInitData() - end with Error (流程錯誤)");
			return flowControlValidationFail();
		}

		LogUtil.info("getShopeeOrderListInitData() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
	}
	
	/**
	 * 蝦皮賣場結帳頁 - 初始化
	 *
	 * @description
	 * @author Phil.Lin
	 * @date 2020-11-17
	 * @return
	 */
	@Operation(summary = "結帳頁 - 初始化", description = "結帳頁 - 初始化")
	@RequestMapping(path = { "/initPayment" }, method = { RequestMethod.GET })
	@ApiInputOutput(input = false, output = true)
	public RestResult<OrderListRes> getShopeePaymentInitData(HttpServletRequest req) throws Exception {

		LogUtil.info("getShopeePaymentInitData() - start");

		OrderHelper orderHelper = getOrderHelper(req);

		if(orderHelper == null){
			LogUtil.warn("getShopeePaymentInitData() - end with Error (Session 中無訂單資訊或流程錯誤)");
			return flowControlValidationFail();
		}

		boolean acceptIn = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.CHECKOUT);

		if(!acceptIn){
			LogUtil.warn("getShopeePaymentInitData() - end with Error (流程錯誤)");
			return flowControlValidationFail();
		}

		OrderListRes result = shopeeFacade.getShopeeOrderData(orderHelper);
		
		result = shopeeFacade.buildPaymentPageData(orderHelper, result);

		//2020-10-29 Ted.Hsieh 新增 找縣市資訊和門市資訊的部分改由init一起帶入
		List<CityAreaVO> cityData = checkoutFacade.findCityAndRgn();
		List<AreaCity> storeData = checkoutFacade.findAllStoreCity();
		
		result.setCityData(cityData);
		result.setStoreData(storeData);

		//2020-09-21 Ted.Hsieh 確認登入狀態(結帳頁面發票載具選項出現條件 -- 有登入)
		String loginId = getFetLoginUID(req);
		Boolean cspLoginStatus = false;
		if(StringUtil.isNotEmptyOrNull(loginId)){
			cspLoginStatus = true;
		}
		result.setCspLoginStatus(cspLoginStatus);

		LogUtil.info("getShopeePaymentInitData() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, result);
	}
	
	/**
	 * @description 驗證用戶結帳資訊
	 * 1. 驗證填寫資料
	 * 2. 更新Session
	 * @author Phil.Lin
	 * @date 2020-11-17
	 * @return
	 */
	@Operation(summary = "驗證結帳資訊", description = "驗證下列是否異常: 1. 取貨地址 2. 發票資訊 3. 推薦管道 4. 驗證新申辦門號是否已成單 5. 驗證獨賣件")
	@PostMapping("/validCheckOutInfo")
	@ApiInputOutput(input = true, output = true)
	public RestResult<Boolean> shopeeValidCheckOutInfo(HttpServletRequest req, @RequestBody CheckoutSubmitReq checkoutSubmitReq){

		OrderHelper orderHelper = this.getOrderHelper(req);


		//異常擋件
		if(orderHelper == null){
			LogUtil.error("[Checkout-valid]Session訂單資料不可為空");
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, "您選購時間已達設定標準，為確保購物安全，請您回首頁重新選購，謝謝!", false);
		}

		if(checkoutSubmitReq == null){
			LogUtil.error("[Checkout-valid]結帳填寫資訊不可為空");
			return buildResult(ReturnCode.RTN_CODE_UNEXPECT_ERROR, "請確認您的付款資訊是否異常。", false);
		}

		//1. 驗證用戶結帳資訊
		shopeeFacade.validSubmitInfo(orderHelper, checkoutSubmitReq);

		//2. 更新Session
		try {
			//2-1. 紀錄Client IP、Server IP，在後續的成立訂單(CO_MASTER)會拿來記錄
			orderHelper.setHost(InetAddress.getLocalHost().getHostAddress());
			orderHelper.setXff(req.getHeader("x-forwarded-for"));
		}catch (UnknownHostException e){
			LogUtil.error("[Checkout-驗證結帳資訊]取得Server IP位址失敗");
		}
		this.saveOrderHelper(orderHelper, req);

		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, true);
	}
	
	/**
	 * 確認申購清單送出
	 * 
	 * @description
	 * @author Phil.Lin
	 * @date 2020-11-17
	 * @return
	 */
	@Operation(summary = "確認申購清單送出", description = "確認申購清單送出")
	@RequestMapping(path = { "/orderSubmit" }, method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<Object> orderSubmit(@RequestBody SubmitOrderReq form, HttpServletRequest req) throws Exception{
		
		LogUtil.info("orderSubmit() - start");
		OrderHelper orderHelper = getOrderHelper(req);

		SubmitOrderRes res = null;
		try {
			res = shopeeFacade.orderSubmit(orderHelper, form);
			if(null != orderHelper) {
				boolean isPass = flowControlHelper.completeStep(orderHelper.getFlowControlBean(), OrderFlowEnum.ORDER_LIST);
				if(isPass) {
					saveOrderHelper(orderHelper, req);
				}else {
					return flowControlValidationFail();
				}
			}else {
				return flowControlValidationFail();
			}
		}catch(Exception e) {
			LogUtil.error("申購清單送出異常", e);
			return buildResult(ReturnCode.RTN_MSG_UNEXPECT_ERROR,e.getMessage(),res);
		}
		LogUtil.info("orderSubmit() - end");
		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,res);
	}
}
