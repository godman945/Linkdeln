package com.fet.estore.api.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;
import org.springframework.session.web.http.HttpSessionIdResolver;

/**
 * @description 設定Cookie屬性 以及 覆寫RedisOperationsSessionRepository
 * @autor Dennis
 * @date 2020-04-22
 */
@Configuration
@EnableRedisHttpSession//使用此註釋，它將自動添加@Configuration到配置類
public class RedisHttpSessionConfig {
	

	@Value("#{new Boolean('${estore.cookie.secure}')}")
	private Boolean isCookieSecured;
	
    @Bean
    public HttpSessionIdResolver httpSessionIdResolver() {
        FetnetHttpSessionIdResolver resolver = new FetnetHttpSessionIdResolver();
        resolver.setCookieSerializer(cookieSerializer());
        return resolver;
    }

    /**
     * @description 設定Cookie屬性
     * @autor FET Owen
     * @date 2020-04-22
     */
    @Bean(name = "defaultCookieSerializer")
    public CookieSerializer cookieSerializer() {
        DefaultCookieSerializer serializer = new DefaultCookieSerializer();
        serializer.setUseBase64Encoding(false);
        serializer.setCookieName("FETNET_SESSION_ID");
        serializer.setCookiePath("/");
        if(isCookieSecured) {
        	serializer.setDomainName("fetnet.net");
        	serializer.setUseSecureCookie(true);
        	serializer.setSameSite("None");
        }
        return serializer;
    }
    
	
}