package com.fet.estore.api.filter;

import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;
import org.apache.http.HttpStatus;
import org.apache.logging.log4j.core.config.Order;
import org.springframework.stereotype.Component;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @description 避免分頁多開，驗證Session 內的UUID是否不一致
 * @author Dennis.Chen
 * @Date 2020-11-11
 */
@Order(1)
@WebFilter(filterName = "CheckUuidFilter", urlPatterns = {"/checkout/getOrderList",
                                                          "/checkout/orderSubmit",
                                                          "/personalInfo/credentialInit",
                                                          "/personalInfo/submitUploadCredentialocr",
                                                          "/personalInfo/initSubscriber",
                                                          "/personalInfo/submitSubscriber"})
public class CheckUuidFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession();

        if(!StringUtil.equalsIgnoreCase("OPTIONS", httpRequest.getMethod())) {
            if (StringUtil.isEmptyOrNull(httpRequest.getParameter("orderUUID")) || StringUtil.isEmptyOrNull(String.valueOf(session.getAttribute("ORDER_UUID")))) {
                httpResponse.setStatus(HttpStatus.SC_FORBIDDEN);
                chain.doFilter(request, response);
            } else {
                String reqOrderUUID = httpRequest.getParameter("orderUUID");
                String sessionOrderUUID = String.valueOf(session.getAttribute("ORDER_UUID"));
                if (!StringUtil.equals(sessionOrderUUID, reqOrderUUID)) {
                    LogUtil.error("分頁多開，阻擋API存取:{}", httpRequest.getRequestURI());
                    httpResponse.setStatus(HttpStatus.SC_FORBIDDEN);
                    chain.doFilter(request, httpResponse);
                } else {
                    chain.doFilter(request, response);
                }
            }
        }else{
            chain.doFilter(request, response);
        }
    }

    @Override
    public void init(FilterConfig filterConfig) {

    }

    @Override
    public void destroy() {

    }
}
