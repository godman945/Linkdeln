package com.fet.estore.api.config;

import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.SerializationException;
import org.springframework.stereotype.Component;

/**
 * @description 覆寫JdkSerializationRedisSerializer 序列化方法，新增Try Catch 
 * @autor Dennis.Chen
 * @date 2020-05-22
 */
@Component("springSessionDefaultRedisSerializer")
public class FetnetSessionDefaultRedisSerializer extends JdkSerializationRedisSerializer {

    /**
     * @description 
     * @autor FET Owen
     * @date 2020-05-21
     */
    @Override
    public Object deserialize(byte[] bytes) {
        Object deserialObj = null;
        try{
            deserialObj = super.deserialize(bytes);
        }catch(SerializationException serializationException){
            //20200930 Dennis.Chen - 為避免反序列化其他Channel物件而出現大量Error Log，僅留下Message部分
            //20201118 Dennis.Chen - IT表示移除Log，但也不可打開，否則SerializationException下，LogUtil再取Session會StackOverFlow。
            //                       若真的需要紀錄SerializationException Log，請在此Class建立全新logger
            //LogUtil.warn("Cannot Deserialize Unexpect Object(Maybe Other Channel): {}", serializationException.getMessage());
        }catch (Exception e){
        	//LogUtil.warn("deserialize session Object unexpect error!", e);
        }
        return deserialObj;
    }
}