package com.fet.estore.api.controller.helper;

import javax.servlet.http.HttpServletRequest;

import com.fet.estore.core.util.LogUtil;

/**
 * 處理Session中 GA 及 NP 紀錄選定門號的 Helper
 * 
 * @description
 * @author Phil.lin
 * @date 2020-08-19
 */
public abstract interface SessionMsisdnHelper {
	
	/** 在Session中存門號鎖定的 Key 值 */
	final static String RECORD_MSISDN_ATTR_NAME = "ESTORE_RECORD_MSISDN";
	
	/**
	 * 將門號存入 Seesion 中此資料給 GA 及 NP 門號檢查使用
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param msisdn
	 * @param req
	 */
	default void setRecordMsisdn(String msisdn, HttpServletRequest req) {
		logString("在Session中存入紀錄的門號", msisdn);
		req.getSession().setAttribute(RECORD_MSISDN_ATTR_NAME, msisdn);
	}
	
	/**
	 * 從 Session 中取出紀錄的門號，無資料時回傳 null，此資料給 GA 及 NP 門號檢查使用
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param req
	 * @return
	 */
	default String getRecordMsisdn(HttpServletRequest req) {
		String msisdn = (String)req.getSession().getAttribute(RECORD_MSISDN_ATTR_NAME);
		logString("從Session取出紀錄的門號", msisdn);
		return msisdn;
	}
	
	/**
	 * 清除 Session 中紀錄的門號，並回傳該資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param req
	 * @return
	 */
	default String releaseRecordMsisdn(HttpServletRequest req) {
		String msisdn = (String)req.getSession().getAttribute(RECORD_MSISDN_ATTR_NAME);
		logString("從Session中解除紀錄門號", msisdn);
		req.getSession().removeAttribute(RECORD_MSISDN_ATTR_NAME);
		return msisdn;
	}
	
	/**
	 * 輸出 LOG for 紀錄的門號 DATA 的資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param msg
	 * @param msisdn
	 */
	default void logString(String msg, String msisdn) {
		if (msisdn == null) {
			LogUtil.info(msg + ", msisdn is null.");	
		} else {
			LogUtil.info(msg + ", msisdn: {}", msisdn);
		}
	}

}