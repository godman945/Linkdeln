package com.fet.estore.api.controller;

import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.ShipmentVO;
import com.fet.estore.core.bean.bo.HappyGoBO;
import com.fet.estore.core.bean.vo.HappyGoVO;
import com.fet.estore.core.facade.ICheckoutFacade;
import com.fet.estore.core.facade.IThirdPartyProcessFacade;
import com.fet.estore.core.util.LogUtil;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Controller
public class ThirdPartyCallbackController implements OrderDataHelper {

    @Value("${frontend.domain}")
    private String frontendDomain;

    @Autowired private IThirdPartyProcessFacade thirdPartyProcessFacade;
    @Autowired private ICheckoutFacade checkoutFacade;

    /**
     * happy go callback
     * @return
     */
    @RequestMapping(value = "/shopping/hgLoginCallback")
    public String hgLoginCallback(HttpServletRequest req, HttpServletResponse res,
                                  @RequestParam("RESPONSE_CODE") String responseCode,
                                  @RequestParam("TOKEN") String token,
                                  @RequestParam("REMAIN_POINT") String remainPoint,
                                  @RequestParam("ENC_IDNO") String mpid,
                                  @RequestParam("CHK_SUM") String mpidCheckSum,
                                  @RequestParam("DATE") String date,
                                  @RequestParam("TIME") String time) throws Exception {

        OrderHelper orderHelper = getOrderHelper(req);
        String errMsg = "";
        boolean success = false;

        if(orderHelper != null) {
            HappyGoBO happyGoBO = new HappyGoBO();
            happyGoBO.setResponseCode(responseCode);
            happyGoBO.setToken(token);
            happyGoBO.setRemainPoint(remainPoint);
            happyGoBO.setMpid(mpid);
            happyGoBO.setMpidCheckSum(mpidCheckSum);
            happyGoBO.setDate(date);
            happyGoBO.setTime(time);
            happyGoBO.setMsisdn(orderHelper.getMsisdn());
            happyGoBO.setMsisdnId(orderHelper.getMsisdnId());
            happyGoBO.setOrderType(orderHelper.getOrderType());

            try {
                HappyGoVO happyGoVO = thirdPartyProcessFacade.happyGoCallbackProcess(happyGoBO);
                errMsg = happyGoVO.getErrorMsg();
                success = happyGoVO.isPass();

                // 成功時塞入session
                if(success) {
                    Calendar calendar = Calendar.getInstance();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HHmmss");
                    Date redeemTime = calendar.getTime();
                    try {
                        redeemTime = sdf.parse(String.format("%d%s %s", Calendar.getInstance().get(Calendar.YEAR), date, time));
                    } catch (ParseException e) {
                        LogUtil.error("[ThirdPartyCallbackController]", e);
                    }

                    // 存入session
                    orderHelper.setHgToken(token);
                    orderHelper.setHgTotalPoint("" + Long.parseLong(remainPoint));
                    orderHelper.setMpId(mpid);
                    orderHelper.setMpIdCheckSum(mpidCheckSum);
                    orderHelper.setHgRedeemTime(redeemTime);

                    saveOrderHelper(orderHelper, req);
                }

            } catch(Exception ex) {
                errMsg = "目前系統暫時無法處理您的需求, 為節省您的寶貴時間, 建議您稍後再試, 謝謝";
                LogUtil.error("happy go callback error", ex);
            }
        } else {
            errMsg = "您選購時間已達設定標準, 為確保購物安全, 請您回首頁重新選購, 謝謝!";
        }

        // 設定頁面參數
        req.setAttribute("success", success);
        req.setAttribute("remainPoint", remainPoint);
        req.setAttribute("errMsg", errMsg);
        req.setAttribute("frontendDomain", frontendDomain);

        return "/hgLoginCallback";
    }
    
    /**
     * store callback
     * @return
     */
    @RequestMapping(value = "/order/shipment")
    public String storeCallback(HttpServletRequest req, HttpServletResponse res) throws Exception {

        OrderHelper orderHelper = getOrderHelper(req);
     
		String[] queryString = req.getQueryString().split("&");
		ShipmentVO info = checkoutFacade.getStoreInfo(queryString);

        // 存入session
        orderHelper.setCsStoreName(info.getName());
        orderHelper.setCsStoreAddress(info.getAddr());
        orderHelper.setCsStoreTel(info.getTel());
        orderHelper.setCsStoreCvsid(info.getCvsid());
        orderHelper.setCsStoreCvsname(info.getCvsname());
        orderHelper.setCsStoreNo(info.getCvsspot());
        saveOrderHelper(orderHelper, req);
        
        LogUtil.info("CsStoreName : {}", orderHelper.getCsStoreName());
        LogUtil.info("CsStoreAddress : {}", orderHelper.getCsStoreAddress());
        LogUtil.info("CsStoreTel : {}", orderHelper.getCsStoreTel());
        LogUtil.info("CsStoreCvsid : {}", orderHelper.getCsStoreCvsid());
        LogUtil.info("CsStoreCvsname : {}", orderHelper.getCsStoreCvsname());
        LogUtil.info("CsStoreNo : {}", orderHelper.getCsStoreNo());
            
        // 設定頁面參數
        req.setAttribute("storeName", info.getName());
        req.setAttribute("storeAddr", info.getAddr());
        req.setAttribute("frontendDomain", frontendDomain);

        return "/storeCallback";
    }
}
