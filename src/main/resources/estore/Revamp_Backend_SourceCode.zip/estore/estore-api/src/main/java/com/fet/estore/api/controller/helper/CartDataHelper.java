package com.fet.estore.api.controller.helper;

import javax.servlet.http.HttpServletRequest;

import com.fet.estore.core.bean.Cart;
import com.fet.estore.core.util.LogUtil;

/**
 * 處理Session中購物車資料 Helper
 * 
 * @description
 * @author Phil.lin
 * @date 2020-08-19
 */
public abstract interface CartDataHelper {
	
	/** 在Session中存客資的 Key 值 */
	final static String CRM_CART_DATA_ATTR_NAME = "ESTORE_CART_DATA";
	
	/**
	 * 將客資存入 Seesion 中
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param cartData
	 * @param req
	 */
	default void saveCartData(Cart cartData, HttpServletRequest req) {
		logCart("在Session中存入 Cart", cartData);
		req.getSession().setAttribute(CRM_CART_DATA_ATTR_NAME, cartData);
	}
	
	/**
	 * 從 Session 中取出客資，無資料時回傳 null
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param req
	 * @return
	 */
	default Cart getCartData(HttpServletRequest req) {
		Cart cartData = (Cart)req.getSession().getAttribute(CRM_CART_DATA_ATTR_NAME);
		logCart("從Session取出 Cart", cartData);
		return cartData;
	}
	
	/**
	 * 清除 Session 中的客資，並回傳該資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param req
	 * @return
	 */
	default Cart removeCartData(HttpServletRequest req) {
		Cart cartData = (Cart)req.getSession().getAttribute(CRM_CART_DATA_ATTR_NAME);
		logCart("從Session中刪除 Cart", cartData);
		req.getSession().removeAttribute(CRM_CART_DATA_ATTR_NAME);
		return cartData;
	}
	
	/**
	 * 紀錄當前 CRM DATA 的資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param msg
	 * @param cartData
	 */
	default void logCart(String msg, Cart cartData) {
		if (cartData == null) {
			LogUtil.info(msg + ", cartData is null.");	
		} else {
			LogUtil.info(msg + ", cartData: {}", cartData);
		}
	}

}