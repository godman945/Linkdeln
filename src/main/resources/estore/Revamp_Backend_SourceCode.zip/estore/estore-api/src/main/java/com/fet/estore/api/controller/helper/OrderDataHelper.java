package com.fet.estore.api.controller.helper;

import javax.servlet.http.HttpServletRequest;

import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.util.LogUtil;

/**
 * 處理Session中訂單資料 Helper
 * 
 * @description
 * @author Phil.lin
 * @date 2020-08-19
 */
public abstract interface OrderDataHelper {
	
	/** 在Session中存訂單資料的 Key 值 */
	final static String ORDER_DATA_ATTR_NAME = "ESTORE_ORDER_DATA";
	
	/**
	 * 將訂單資料存入 Seesion 中
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param orderHelperData
	 * @param req
	 */
	default void saveOrderHelper(OrderHelper orderHelperData, HttpServletRequest req) {
		logOrderHelperData("在Session中存入 OrderHelperData", orderHelperData);
		req.getSession().setAttribute(ORDER_DATA_ATTR_NAME, orderHelperData);
	}
	
	/**
	 * 從 Session 中取出訂單資料，無資料時回傳 null
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param req
	 * @return
	 */
	default OrderHelper getOrderHelper(HttpServletRequest req) {
		OrderHelper orderData = (OrderHelper)req.getSession().getAttribute(ORDER_DATA_ATTR_NAME);
		logOrderHelperData("從Session取出 OrderHelperData", orderData);
		// 這段為測試用的 程式碼
//		if (orderData == null) {
//			orderData = loadFileToSession(DEV_ORDER_HELPER_DATA_FILE, OrderHelper.class);
//		}
		return orderData;
	}

//	default <T> T loadFileToSession(String file, Class<T> clazz) {
//		LogUtil.info("Session 中無 OrderHelperData,嘗試讀取測試環境用檔案，路徑:{}", file);
//		
//		T form  = null;
//		StringBuilder str = new StringBuilder();
//		
//		Path path = Paths.get(file);
//		try (Stream<String> lines = Files.lines(path , StandardCharsets.US_ASCII)) {
//			
//			lines.forEach(o->str.append(o));
//			form = new Gson().fromJson(str.toString() , clazz);
//			
//			LogUtil.info("測試資料讀取成功！ {}", file);
//			
//		} catch (Exception e) {
//			
//			LogUtil.info("測試資料讀取失敗！ {}, msg:{}", file, e.getMessage());
//		}
//		return form;
//	}
	
	/**
	 * 清除 Session 中的訂單資料，並回傳該資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param req
	 * @return
	 */
	default OrderHelper removeOrderHelper(HttpServletRequest req) {
		OrderHelper orderData = (OrderHelper)req.getSession().getAttribute(ORDER_DATA_ATTR_NAME);
		logOrderHelperData("從Session中刪除 OrderHelperData", orderData);
		req.getSession().removeAttribute(ORDER_DATA_ATTR_NAME);
		return orderData;
	}
	
	/**
	 * 紀錄當前 orderHelper DATA 的資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param msg
	 * @param orderHelper
	 */
	default void logOrderHelperData(String msg, OrderHelper orderHelper) {
		if (orderHelper == null) {
			LogUtil.info(msg + ", orderHelper is null.");	
		} else {
			LogUtil.info(msg + ", orderHelper {}",orderHelper);
		}
	}

}