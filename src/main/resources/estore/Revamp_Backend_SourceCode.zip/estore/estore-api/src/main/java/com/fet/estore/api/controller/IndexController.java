package com.fet.estore.api.controller;

import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.IndexInfo;
import com.fet.estore.core.bean.PromoProduct;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.enums.BreadcrumsEnum;
import com.fet.estore.core.facade.ICommonFacade;
import com.fet.estore.core.facade.IIndexFacade;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.SQLException;


@RestController
@RequestMapping("/index")
@Tag(name = "Index APIs")
public class IndexController implements IBaseAct {
	

	@Autowired
	private IIndexFacade indexFacadeImpl;
	
	@Autowired
	private ICommonFacade commonFacadeImpl;
	
	/**
	 *  首頁 - 初始化資料包
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-10
	 * @return
	 * @throws SQLException
	 */
	@Operation(summary = "取得首頁初始化資訊", description = "取得首頁所需資訊，包含麵包屑、TOP AD、個人化服務、看看大家都搜甚麼、線上申辦按鈕資訊、 我要尋找區塊")
	@GetMapping("/init")
	@ApiInputOutput(input = true, output = true)
	public RestResult<IndexInfo> getIndexInitData(HttpServletRequest req) {
		HttpSession session = req.getSession();
		String uid = (String) session.getAttribute("uid");

		IndexInfo indexInfo = new IndexInfo();

		//1. 看看大家都搜甚麼
		indexInfo.setServiceTags(indexFacadeImpl.getServiceTags());
		//2. 我要尋找區塊
		indexInfo.setProductMap(indexFacadeImpl.getProductMap());
		//3. 門號活動
		indexInfo.seteStorePromotion(indexFacadeImpl.getEstorePromotion());
		//4. 麵包屑 資訊
		indexInfo.setBreadcrumbs(commonFacadeImpl.getBreadCrumb(BreadcrumsEnum.INDEX));
		//5. Banner圖文分離資訊
		indexInfo.setSlides(commonFacadeImpl.getBanner());
		//6. 線上申辦按鈕資訊
		indexInfo.setServiceCard(commonFacadeImpl.getOnlineDeals());
		//7. 個人化服務
		indexInfo.setGreeting(indexFacadeImpl.getGreeting(uid, false));

		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS,indexInfo);
	}


	/**
	 *  首頁 - 熱門商品資訊
	 *
	 * @description
	 * @author Klyve.Chen
	 * @date 2020-11-17
	 * @return
	 * @throws SQLException
	 */
	@Operation(summary = "取得熱門商品資訊", description = "取得熱門商品資訊, 因為需要時間所以獨立API")
	@GetMapping("/getBestSellingProduct")
	@ApiInputOutput(input = true, output = true)
	public RestResult<PromoProduct> getBestSellingProduct() {
		//8. 熱門商品
		PromoProduct promoProduct = indexFacadeImpl.getPromoProductBean();

		return buildResult(ReturnCode.RTN_CODE_SUCCESS, ReturnCode.RTN_MSG_SUCCESS, promoProduct);
	}

}
