package com.fet.estore.api.controller.helper;

import javax.servlet.http.HttpServletRequest;

import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.util.LogUtil;

/**
 * 處理Session中客資資料 Helper
 * 
 * @description
 * @author Phil.lin
 * @date 2020-08-19
 */
public abstract interface CrmDataHelper {
	
	/** 在Session中存客資的 Key 值 */
	final static String CRM_DATA_ATTR_NAME = "ESTORE_CRM_DATA";
	
	/**
	 * 將客資存入 Seesion 中
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param crmData
	 * @param req
	 */
	default void saveCustomerData(CrmData crmData, HttpServletRequest req) {
		logCrmData("在Session中存入 CrmData", crmData);
		req.getSession().setAttribute(CRM_DATA_ATTR_NAME, crmData);
	}
	
	/**
	 * 從 Session 中取出客資，無資料時回傳 null
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param req
	 * @return
	 */
	default CrmData getCustomerData(HttpServletRequest req) {
		CrmData crmData = (CrmData)req.getSession().getAttribute(CRM_DATA_ATTR_NAME);
		logCrmData("從Session取出 CrmData", crmData);
		return crmData;
	}
	
	/**
	 * 清除 Session 中的客資，並回傳該資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param req
	 * @return
	 */
	default CrmData removeCustomerData(HttpServletRequest req) {
		CrmData crmData = (CrmData)req.getSession().getAttribute(CRM_DATA_ATTR_NAME);
		logCrmData("從Session中刪除 CrmData", crmData);
		req.getSession().removeAttribute(CRM_DATA_ATTR_NAME);
		return crmData;
	}
	
	/**
	 * 紀錄當前 CRM DATA 的資料
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-18
	 * @param msg
	 * @param crmData
	 */
	default void logCrmData(String msg, CrmData crmData) {
		if (crmData == null) {
			LogUtil.info(msg + ", crmData is null.");	
		} else {
			LogUtil.info(msg + ", msisdn: {}, subscriberId: {}",crmData.getMsisdn(), crmData.getSubscriberId());
		}
	}

}