package com.fet.estore.api.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fet.estore.api.controller.helper.CrmDataHelper;
import com.fet.estore.api.controller.helper.FlowControlHelper;
import com.fet.estore.api.controller.helper.OrderDataHelper;
import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.bean.CredentialInitRes;
import com.fet.estore.core.bean.CredentialSubmitRes;
import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.bean.DoOcrVRes;
import com.fet.estore.core.bean.IdNum1;
import com.fet.estore.core.bean.IdNum2;
import com.fet.estore.core.bean.IdNum31;
import com.fet.estore.core.bean.IdNum41;
import com.fet.estore.core.bean.OrderHelper;
import com.fet.estore.core.bean.SubscriberInitRes;
import com.fet.estore.core.bean.SubscriberSubmitRes;
import com.fet.estore.core.bean.bo.DoOcrBO;
import com.fet.estore.core.bean.bo.UploadCredentialBO;
import com.fet.estore.core.bean.req.CredentialSubmitReq;
import com.fet.estore.core.bean.req.DoOcrReq;
import com.fet.estore.core.bean.req.SubscriberSubmitReq;
import com.fet.estore.core.bean.vo.DoOcrVo;
import com.fet.estore.core.bean.vo.OcrIDrAreqVO;
import com.fet.estore.core.bean.vo.UploadCredentialVO;
import com.fet.estore.core.bean.vo.UploadFileInfo;
import com.fet.estore.core.constant.ReturnCode;
import com.fet.estore.core.constant.SystemConstant;
import com.fet.estore.core.enums.OrderFlowEnum;
import com.fet.estore.core.facade.IPersonalInfoFacade;
import com.fet.estore.core.model.CoMaster;
import com.fet.estore.core.restful.IBaseAct;
import com.fet.estore.core.restful.RestResult;
import com.fet.estore.core.util.StringUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/personalInfo")
@Tag(name = "Personal Info APIs")
public class PersonalInfoController implements IBaseAct, OrderDataHelper, CrmDataHelper{

	@Autowired
	private IPersonalInfoFacade personalInfoFacadeImpl;
	
	@Autowired
	private FlowControlHelper flowControlHelper;
	
	/**
	 * 證件上傳頁面初始化
	 * 
	 * @description
	 * @author Eric.Lu
	 * @return
	 */
	@Operation(summary = "證件上傳頁面初始化", description = "判斷要出現哪些圖片上傳欄位")
    @RequestMapping(value="/credentialInit",  method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
    public RestResult<CredentialInitRes> credentialInit(HttpServletRequest req, ModelMap model) {

    	CredentialInitRes res = null;
    	//20200825 Eric.Lu Jerry說補證件上傳是phase2的功能
//    	if(StringUtil.isNotEmptyOrNull(credentialInitReq.getEnCono())&&StringUtil.isNotEmptyOrNull(credentialInitReq.getUploadType())) {
//    		OrderHelper orderHelper = getOrderHelper(req);
//    		if(orderHelper==null) {
//    			orderHelper = new OrderHelper();
//    		}
//    		res = orderPageFacadeImpl.loadCredentialPage(credentialInitReq, orderHelper);
//    		saveOrderHelper(orderHelper, req);
//    	}else {
    		HttpSession session = req.getSession();
    		OrderHelper orderHelper = this.getOrderHelper(req);
    		this.setFileDataToSession(session, orderHelper);
    		CrmData crmData = this.getCustomerData(req);
    		if(null != orderHelper) {
    			boolean isPass = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.UPLOAD_CERTIFICATION);
    			if(isPass) {
    				res = personalInfoFacadeImpl.getCredentialPageConfig(orderHelper, crmData);
    				this.saveOrderHelper(orderHelper ,req);
    				this.saveCustomerData(crmData, req);
    			}else {
    				return this.flowControlValidationFail();
    			}
    		}else {
    			return this.flowControlValidationFail();
    		}
//    	}
    	
    	return buildResult(res.getErrCode(),res.getErrMsg(),res);
    }
	
	private void setFileDataToSession(HttpSession session ,OrderHelper orderHelper) {
		IdNum1 idNum1 = orderHelper.getIdNum1();
		IdNum2 idNum2 = orderHelper.getIdNum2();
		IdNum31 idNum31 = orderHelper.getIdNum31();
		IdNum41 idNum41 = orderHelper.getIdNum41();
		List<String> ocrSn = orderHelper.getOcrSn();
		
		if(idNum1!=null) {
			session.setAttribute(SystemConstant.IDNUM1,idNum1);
			orderHelper.setIdNum1(null);
		}
		if(idNum2!=null) {
			session.setAttribute(SystemConstant.IDNUM2,idNum2);
			orderHelper.setIdNum2(null);
		}
		if(idNum31!=null) {
			session.setAttribute(SystemConstant.IDNUM31,idNum31);
			orderHelper.setIdNum31(null);
		}
		if(idNum41!=null) {
			session.setAttribute(SystemConstant.IDNUM41,idNum41);
			orderHelper.setIdNum41(null);
		}
		if(ocrSn!=null) {
			session.setAttribute(SystemConstant.OCRSN,ocrSn);
			orderHelper.setOcrSn(null);
		}
		List<UploadFileInfo> uploadFileInfoList =  orderHelper.getUploadFileInfoList();
		if(uploadFileInfoList!=null) {
			for(UploadFileInfo uploadFileInfo: uploadFileInfoList) {
				String cardSection = uploadFileInfo.getCardSection();
				if(StringUtil.equals(SystemConstant.IDENTITY_FRONT, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE1NO, uploadFileInfo);
					orderHelper.setCredentialFile1No(null);
				}
				if(StringUtil.equals(SystemConstant.IDENTITY_BACK, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE2NO, uploadFileInfo);
					orderHelper.setCredentialFile2No(null);
				}
				if(StringUtil.equals(SystemConstant.SECONDARY_FRONT, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE3NO, uploadFileInfo);
					orderHelper.setCredentialFile3No(null);
				}
				if(StringUtil.equals(SystemConstant.SECONDARY_BACK, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE4NO, uploadFileInfo);
					orderHelper.setCredentialFile4No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_ONE, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE5NO, uploadFileInfo);
					orderHelper.setCredentialFile5No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_TWO, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE6NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_THREE, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE7NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_FOUR, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE8NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_FIVE, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE9NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_SIX, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE10NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_SEVEN, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE11NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_EIGHT, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE12NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_NINE, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE13NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_TEN, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE14NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_ELEVEN, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE15NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
				if(StringUtil.equals(SystemConstant.STAFF_CREDENTIAL_TWELVE, cardSection)) {
					session.setAttribute(SystemConstant.CREDENTIALFILE16NO, uploadFileInfo);
					orderHelper.setCredentialFile6No(null);
				}
			}
		}
	}
	
	/**
	 * 證件OCR驗證
	 * 
	 * @description
	 * @author Eric.Lu
	 * @return
	 */
	@Operation(summary = "證件OCR驗證", description = "證件OCR驗證")
	@RequestMapping(value="/doOcr",  method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<DoOcrVRes> doOcr(HttpServletRequest req, ModelMap model, @RequestBody DoOcrReq doOcrReq) {
		DoOcrVo vo = new DoOcrVo();
		HttpSession session = req.getSession();
		OrderHelper orderHelper = this.getOrderHelper(req);
		String orderType = orderHelper.getOrderType();
		boolean isGaOrNp = StringUtil.isInList(new String[] {CoMaster.CO_TYPE_NH, CoMaster.CO_TYPE_NC,CoMaster.CO_TYPE_PH,CoMaster.CO_TYPE_PC}, orderType);
		boolean isLy = StringUtil.isInList(new String[] {CoMaster.CO_TYPE_LC, CoMaster.CO_TYPE_LH}, orderType);
		if(orderHelper.getNeedOcr() //做ocr
				&&//而且是一證或二證正面
				(StringUtil.equals(SystemConstant.IDENTITY_FRONT, doOcrReq.getUploadFileInfo().getCardSection()) 
				||StringUtil.equals(SystemConstant.IDENTITY_BACK, doOcrReq.getUploadFileInfo().getCardSection())
				||StringUtil.equals(SystemConstant.SECONDARY_FRONT, doOcrReq.getUploadFileInfo().getCardSection()))
				&&//且不是學生方案的續約的一證
				!(isGaOrNp&&orderHelper.getIsStudentPromotion()&&
						StringUtil.equals(SystemConstant.SECONDARY_FRONT, doOcrReq.getUploadFileInfo().getCardSection())) 
				&&//不是學生方案的新申辦或攜碼的二證正面
				!(isLy&&orderHelper.getIsStudentPromotion()&&
						(StringUtil.equals(SystemConstant.IDENTITY_FRONT, doOcrReq.getUploadFileInfo().getCardSection())
						||StringUtil.equals(SystemConstant.IDENTITY_BACK, doOcrReq.getUploadFileInfo().getCardSection())))
				) {
			DoOcrBO bo = new DoOcrBO();
			bo.setCono(doOcrReq.getCono());
			bo.setFileType(doOcrReq.getFileType());
			bo.setUploadFileInfo(doOcrReq.getUploadFileInfo());
			bo.setIsCheckOnceContract9M(orderHelper.getIsCheckOnceContract9M());
			bo.setMsisdn(orderHelper.getMsisdn());
			bo.setMsisdnId(orderHelper.getMsisdnId());
			bo.setOnsalePromoListId(orderHelper.getOnsalePromoListId());
			bo.setOrderType(orderHelper.getOrderType());
			vo = personalInfoFacadeImpl.doOcr(bo, session);
		}else {
			vo.setResult(true);
		}
		if(vo.getResult()) {
			UploadCredentialBO uploadCredentialBO = new UploadCredentialBO();
			uploadCredentialBO.setUploadFileInfo(doOcrReq.getUploadFileInfo());
			if(vo.getSecondaryCredentialType()!=null) {
				uploadCredentialBO.setIsHealthIdCard(StringUtil.equals(OcrIDrAreqVO.idrType_41, vo.getSecondaryCredentialType()));
			}else {
				uploadCredentialBO.setIsHealthIdCard(false);
			}
			UploadCredentialVO uploadCredentialVO = personalInfoFacadeImpl.uploadCredentialToEform(uploadCredentialBO, orderHelper, session);
			vo.setErrMsg(uploadCredentialVO.getErrMsg());
			vo.setResult(uploadCredentialVO.getResult());
			vo.setErrCode(uploadCredentialVO.getErrCode());
		}
		DoOcrVRes res = new DoOcrVRes();
		res.setErrCode(vo.getErrCode());
		res.setErrMsg(vo.getErrMsg());
		res.setOcrErrCode(vo.getOcrErrCode());
		res.setResult(vo.getResult());
		res.setSecondaryCredentialType(vo.getSecondaryCredentialType());
		return buildResult(res.getErrCode(),res.getErrMsg(),res);
	}
	
	/**
	 * 清除員工證在session的資料
	 * 
	 * @description
	 * @author Eric.Lu
	 * @return
	 */
	@Operation(summary = "清除員工證在session的資料", description = "清除員工證在session的資料")
	@RequestMapping(value="/clearStaffInfo",  method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public void clearStaffInfo(HttpServletRequest req, ModelMap model) {
		HttpSession session = req.getSession();
		session.removeAttribute(SystemConstant.CREDENTIALFILE5NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE6NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE7NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE8NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE9NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE10NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE11NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE12NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE13NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE14NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE15NO);
		session.removeAttribute(SystemConstant.CREDENTIALFILE16NO);
	}
	
	/**
	 * 送出證件表單
	 * 
	 * @description
	 * @author Eric.Lu
	 * @return
	 */
	@Operation(summary = "送出證件表單", description = "送出證件表單")
	@RequestMapping(value="/submitUploadCredentialocr",  method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<CredentialSubmitRes> submitUploadCredentialocr(HttpServletRequest req, ModelMap model, @RequestBody CredentialSubmitReq credentialSubmitReq) {
		OrderHelper orderHelper = this.getOrderHelper(req);
		HttpSession session = req.getSession();
		this.getFileDataFromSession(session, orderHelper, credentialSubmitReq.getIsHealthIdCard());
		
		CredentialSubmitRes res = personalInfoFacadeImpl.submitUploadCredentialocr(credentialSubmitReq, orderHelper);
		
		
		this.saveOrderHelper(orderHelper ,req);

		if(ReturnCode.RTN_CODE_SUCCESS.equals(res.getErrCode())) {
			boolean isCompleteFlowPass = flowControlHelper.completeStep(orderHelper.getFlowControlBean(), OrderFlowEnum.UPLOAD_CERTIFICATION);
			if(!isCompleteFlowPass) {
				return this.flowControlValidationFail();
			}
		}
		
		return buildResult(res.getErrCode(),res.getErrMsg(),res);
	}
	
	private void getFileDataFromSession(HttpSession session ,OrderHelper orderHelper, boolean isHealthIdCard) {
		Object idNum1Obj = session.getAttribute(SystemConstant.IDNUM1);
		Object idNum2Obj = session.getAttribute(SystemConstant.IDNUM2);
		Object idNum31Obj = session.getAttribute(SystemConstant.IDNUM31);
		Object idNum41Obj = session.getAttribute(SystemConstant.IDNUM41);
		Object ocrSn = session.getAttribute(SystemConstant.OCRSN);
		Object credentialFile1No = session.getAttribute(SystemConstant.CREDENTIALFILE1NO);
		Object credentialFile2No = session.getAttribute(SystemConstant.CREDENTIALFILE2NO);
		Object credentialFile3No = session.getAttribute(SystemConstant.CREDENTIALFILE3NO);
		Object credentialFile4No = session.getAttribute(SystemConstant.CREDENTIALFILE4NO);
		Object credentialFile5No = session.getAttribute(SystemConstant.CREDENTIALFILE5NO);
		Object credentialFile6No = session.getAttribute(SystemConstant.CREDENTIALFILE6NO);
		Object credentialFile7No = session.getAttribute(SystemConstant.CREDENTIALFILE7NO);
		Object credentialFile8No = session.getAttribute(SystemConstant.CREDENTIALFILE8NO);
		Object credentialFile9No = session.getAttribute(SystemConstant.CREDENTIALFILE9NO);
		Object credentialFile10No = session.getAttribute(SystemConstant.CREDENTIALFILE10NO);
		Object credentialFile11No = session.getAttribute(SystemConstant.CREDENTIALFILE11NO);
		Object credentialFile12No = session.getAttribute(SystemConstant.CREDENTIALFILE12NO);
		Object credentialFile13No = session.getAttribute(SystemConstant.CREDENTIALFILE13NO);
		Object credentialFile14No = session.getAttribute(SystemConstant.CREDENTIALFILE14NO);
		Object credentialFile15No = session.getAttribute(SystemConstant.CREDENTIALFILE15NO);
		Object credentialFile16No = session.getAttribute(SystemConstant.CREDENTIALFILE16NO);
		if(idNum1Obj!=null) {
			orderHelper.setIdNum1((IdNum1) idNum1Obj);
			session.removeAttribute(SystemConstant.IDNUM1);
		}
		if(idNum2Obj!=null) {
			orderHelper.setIdNum2((IdNum2) idNum2Obj);
			session.removeAttribute(SystemConstant.IDNUM2);
		}
		if(idNum31Obj!=null) {
			orderHelper.setIdNum31((IdNum31) idNum31Obj);
			session.removeAttribute(SystemConstant.IDNUM31);
		}
		if(idNum41Obj!=null) {
			orderHelper.setIdNum41((IdNum41) idNum41Obj);
			session.removeAttribute(SystemConstant.IDNUM41);
		}
		if(ocrSn!=null) {
			orderHelper.setOcrSn((List<String>) ocrSn);
			session.removeAttribute(SystemConstant.OCRSN);
		}
		List<UploadFileInfo> uploadFileInfoList = new ArrayList<UploadFileInfo>();
		if(credentialFile1No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile1No;
			orderHelper.setCredentialFile1No(uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE1NO);
		}
		if(credentialFile2No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile2No;
			orderHelper.setCredentialFile2No(uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE2NO);
		}
		if(credentialFile3No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile3No;
			orderHelper.setCredentialFile3No(uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE3NO);
		}
		if(credentialFile4No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile4No;
			orderHelper.setCredentialFile4No(uploadFileInfo.getFileNo());
			if(!isHealthIdCard) {
				uploadFileInfoList.add(uploadFileInfo);
			}
			session.removeAttribute(SystemConstant.CREDENTIALFILE4NO);
		}
		if(credentialFile5No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile5No;
			orderHelper.setCredentialFile5No(uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE5NO);
		}
		List<String> credentialFile6NoArray = Arrays.asList(new String[]{"", "", "", "", "","", "", "", "", "",""});
		if(credentialFile6No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile6No;
			credentialFile6NoArray.set(0,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE6NO);
		}
		if(credentialFile7No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile7No;
			credentialFile6NoArray.set(1,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE7NO);
		}
		if(credentialFile8No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile8No;
			credentialFile6NoArray.set(2,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE8NO);
		}
		if(credentialFile9No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile9No;
			credentialFile6NoArray.set(3,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE9NO);
		}
		if(credentialFile10No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile10No;
			credentialFile6NoArray.set(4,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE10NO);
		}
		if(credentialFile11No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile11No;
			credentialFile6NoArray.set(5,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE11NO);
		}
		if(credentialFile12No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile12No;
			credentialFile6NoArray.set(6,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE12NO);
		}
		if(credentialFile13No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile13No;
			credentialFile6NoArray.set(7,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE13NO);
		}
		if(credentialFile14No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile14No;
			credentialFile6NoArray.set(8,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE14NO);
		}
		if(credentialFile15No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile15No;
			credentialFile6NoArray.set(9,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE15NO);
		}
		if(credentialFile16No!=null) {
			UploadFileInfo uploadFileInfo = (UploadFileInfo)credentialFile16No;
			credentialFile6NoArray.set(10,uploadFileInfo.getFileNo());
			uploadFileInfoList.add(uploadFileInfo);
			session.removeAttribute(SystemConstant.CREDENTIALFILE16NO);
		}
		orderHelper.setCredentialFile6No(credentialFile6NoArray);
		orderHelper.setUploadFileInfoList(uploadFileInfoList);
	}
	
	@Operation(summary = "個資填寫頁初始化", description = "個資填寫頁初始化")
	@RequestMapping(value="/initSubscriber",  method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<SubscriberInitRes> initSubscriber(HttpServletRequest req, ModelMap model) {
		OrderHelper orderHelper = this.getOrderHelper(req);
		CrmData crmData = this.getCustomerData(req);
		SubscriberInitRes res = null;
		if(null != orderHelper) {
			boolean isPass = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.CUSTOMER_INFO);
			if(isPass) {
				res = personalInfoFacadeImpl.subscriberInit(orderHelper, crmData);
			}else {
				return this.flowControlValidationFail();
			}
		}else {
			return this.flowControlValidationFail();
		}
		this.saveOrderHelper(orderHelper ,req);
		
		return buildResult(res.getErrCode(),res.getErrMsg(),res);
	}
	
	@Operation(summary = "送出個資填寫頁", description = "送出個資填寫頁")
	@RequestMapping(value="/submitSubscriber",  method = { RequestMethod.POST })
	@ApiInputOutput(input = true, output = true)
	public RestResult<SubscriberSubmitRes> submitSubscriber(HttpServletRequest req, ModelMap model, @RequestBody SubscriberSubmitReq subscriberInitReq) {
		OrderHelper orderHelper = this.getOrderHelper(req);
		CrmData crmData = this.getCustomerData(req);
		boolean isCheckVisitPass = flowControlHelper.checkVisit(orderHelper.getFlowControlBean(), OrderFlowEnum.CUSTOMER_INFO);
		if(!isCheckVisitPass) {
			return this.flowControlValidationFail();
		}
		
		SubscriberSubmitRes res = personalInfoFacadeImpl.subscriberSubmit(orderHelper, subscriberInitReq, crmData);
		this.saveOrderHelper(orderHelper ,req);
		if(ReturnCode.RTN_CODE_SUCCESS.equals(res.getErrCode())) {
			boolean isCompleteFlowPass = flowControlHelper.completeStep(orderHelper.getFlowControlBean(), OrderFlowEnum.CUSTOMER_INFO);
			if(!isCompleteFlowPass) {
				return this.flowControlValidationFail();
			}
		}

		return buildResult(res.getErrCode(),res.getErrMsg(),res);
	}
}
