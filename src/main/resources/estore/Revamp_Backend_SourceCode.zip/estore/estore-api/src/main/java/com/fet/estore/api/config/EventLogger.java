package com.fet.estore.api.config;

import org.ehcache.event.CacheEvent;
import org.ehcache.event.CacheEventListener;

import com.fet.estore.core.util.LogUtil;

public class EventLogger implements CacheEventListener<Object, Object>{

	@Override
	public void onEvent(CacheEvent<?, ?> event) {
		LogUtil.info("Event: " + event.getType() + " Key: " + event.getKey() + " old value: " + event.getOldValue() + " new value: " + event.getNewValue());
		
	}

}
