package com.fet.estore.core.bean.vo.frontend;

public class MsisdnVo {
	
	/** 商品料號。 */
	private String productId;
	/** 門號。 */
	private String msisdn;
	/** 所選費用。 */
	private Long selectionfee;
	/** 費用format。 */
	private String price;
	
	
	
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public Long getSelectionfee() {
		return selectionfee;
	}
	public void setSelectionfee(Long selectionfee) {
		this.selectionfee = selectionfee;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	
}
