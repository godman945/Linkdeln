package com.fet.estore.core.aop;

import com.fet.estore.core.annotation.ApiInputOutput;
import com.fet.estore.core.restful.RestResult;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

/**
 * @description API Input Output Log AOP
 * @author Dennis.Chen
 * @date 2020-08-25
 */
@Aspect
@Component
public class ApiInputOutputProxy {

    //此Logger為切檔用，誤修改
    Logger logger = LogManager.getLogger(ApiInputOutputProxy.class);

    @Around("execution(* com.fet.estore.api.controller..*.*(..)) and @annotation(apiInputOutput)")
    public Object apiInputOutputLog(ProceedingJoinPoint joinPoint, ApiInputOutput apiInputOutput)
            throws Throwable {

        //1. 取得Annotation設定(若apiInputOutput為空，一律不印出input output)
        boolean inputFlag = false;
        boolean outputFlag = false;
        if(apiInputOutput != null){
            inputFlag = apiInputOutput.input();
            outputFlag = apiInputOutput.output();
        }

        //2. Log 資訊
        long start = System.currentTimeMillis();
        Gson gson = new GsonBuilder().serializeNulls().create();
        Gson prettyGson = new GsonBuilder().setPrettyPrinting().create();
        Map<String, Object> logItem = new HashMap<>();
        List<Object> inputList = new ArrayList<>();
        HttpServletRequest request = null;
        InetAddress inetAddress = null;
        String ipAddress = null;
        String sessionId = null;
        String description = null;
        String returnCode = null;
        String returnMsg = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        sdf.setTimeZone(TimeZone.getTimeZone("Asia/Taipei"));

        //2-1. 取得HttpServletRequest資訊
        try {
            request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        }catch (Exception e){
            logger.error("取得HttpServletRequest失敗", e);
        }

        //2-2. 取得Host資訊
        try {
            inetAddress = InetAddress.getLocalHost();
        }catch (Exception e){
            logger.error("取得Host資訊失敗", e);
        }

        if(request != null) {
            ipAddress = getIpAddress(request);
            sessionId = request.getSession().getId();
        }

        if(inputFlag) {
            for (Object obj : joinPoint.getArgs()) {
                if (!(obj instanceof HttpServletRequest || obj instanceof HttpServletResponse)) {
                    inputList.add(obj);
                }
            }
        }

        Object proceed = joinPoint.proceed();
        RestResult output = (RestResult) proceed;
        if(output != null){
            returnCode = output.getRtnCode();
            returnMsg = output.getRtnMsg();
        }
        
        long end = System.currentTimeMillis();
        logItem.put("INPUT", (inputFlag && inputList.size() > 0) ? prettyGson.toJson(inputList) : null);
        logItem.put("OUTPUT", (outputFlag && output != null) ? prettyGson.toJson(output) : null);
        logItem.put("HOST", inetAddress != null ? inetAddress.getHostName() : "");
        logItem.put("HOST_IP", inetAddress);
        logItem.put("CLIENT_IP", ipAddress);
        logItem.put("START_TIME", sdf.format(new Date(start)));
        logItem.put("END_TIME", sdf.format(new Date(end)));
        logItem.put("CHANNEL_ID", "eStore");
        logItem.put("LOGGER", "eStoreLogger");
        logItem.put("METHOD", joinPoint.getSignature().getName());
        logItem.put("RETURN_CODE", returnCode);
        logItem.put("RETURN_MSG", returnMsg);
        logItem.put("SESSION_ID", sessionId);
        logItem.put("TIMECONSUMED", end - start);
        logItem.put("DESCRIPTION", description);

        logger.info(gson.toJson(logItem));

        return proceed;

    }

    /**
     * 取得用戶IP Address
     * @param request HttpServletRequest
     * @author Dennis.Chen
     * @date 2020-08-25
     * @return String
     */
    public String getIpAddress(HttpServletRequest request){
        String result = null;

        try {
            String ipAddress = request.getHeader("X-Forwarded-For");
            if(ipAddress != null){
                result = ipAddress.split(",")[0];
            }
            if (result == null || result.length() == 0 || "unknown".equalsIgnoreCase(result)) {
                result = request.getRemoteAddr();
            }
        } catch (Exception e) {
            logger.error("取得Client Ip Address失敗", e);
        }

        return result;
    }



}
