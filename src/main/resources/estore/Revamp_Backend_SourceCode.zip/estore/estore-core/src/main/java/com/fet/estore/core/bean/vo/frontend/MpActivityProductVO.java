package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fet.estore.core.util.StringUtil;

public class MpActivityProductVO {
	private Long mpActivityId;
	private String productId;
	private String productName;
	private Long price;
	private String fetNo;
	private Long discountId;
	private String aliasUrl;
	
	private String pic;
	private String viewDesc;
	private String viewDesc2;
	private String viewDesc3;
	private String viewDesc4;
	private String viewDesc5;
	
	private String brand;
	
	private Boolean isExclusive;
	private Long inventory;
	
	// 2013/07/10 fred add 缺貨通知狀態
	private String atrStatus;
	
	// 2013/07/10 fred add 缺貨通知期間
	private Boolean isUnavailableInform;
    private Date unavailableStartTime;
    private Date unavailableEndTime;
    
    // 2013/07/10 fred add 預購期間
    private Boolean isPreSubscribeDate;
    private Date preSubscribeBeginDate;
    private Date preSubscribeEndDate;
	
	public Long getMpActivityId() {
		return mpActivityId;
	}
	public void setMpActivityId(Long mpActivityId) {
		this.mpActivityId = mpActivityId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public Long getDiscountId() {
		return discountId;
	}
	public void setDiscountId(Long discountId) {
		this.discountId = discountId;
	}
	public String getAliasUrl() {
		return aliasUrl;
	}
	public void setAliasUrl(String aliasUrl) {
		this.aliasUrl = aliasUrl;
	}
	
	public String getPic() {
		return pic;
	}
	
	public void setPic(String pic) {
		this.pic = pic;
	}
	
	public String getViewDesc() {
		return viewDesc;
	}
	
	public void setViewDesc(String viewDesc) {
		this.viewDesc = viewDesc;
	}
	
	public String getViewDesc2() {
		return viewDesc2;
	}
	
	public void setViewDesc2(String viewDesc2) {
		this.viewDesc2 = viewDesc2;
	}
	
	public String getViewDesc3() {
		return viewDesc3;
	}
	
	public void setViewDesc3(String viewDesc3) {
		this.viewDesc3 = viewDesc3;
	}
	
	public String getViewDesc4() {
		return viewDesc4;
	}
	
	public void setViewDesc4(String viewDesc4) {
		this.viewDesc4 = viewDesc4;
	}
	
	public String getViewDesc5() {
		return viewDesc5;
	}
	
	public void setViewDesc5(String viewDesc5) {
		this.viewDesc5 = viewDesc5;
	}
	
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String[] getViewDescs() {
		List<String> list = new ArrayList<String>();
		if(StringUtil.isNotEmptyOrNull(viewDesc)) list.add(viewDesc);
		if(StringUtil.isNotEmptyOrNull(viewDesc2)) list.add(viewDesc2);
		if(StringUtil.isNotEmptyOrNull(viewDesc3)) list.add(viewDesc3);
		if(StringUtil.isNotEmptyOrNull(viewDesc4)) list.add(viewDesc4);
		if(StringUtil.isNotEmptyOrNull(viewDesc5)) list.add(viewDesc5);

		return list.toArray(new String[list.size()]);
	}
    public Boolean getIsExclusive() {
        return isExclusive;
    }
    public void setIsExclusive(Boolean isExclusive) {
        this.isExclusive = isExclusive;
    }
    public Long getInventory() {
        return inventory;
    }
    public void setInventory(Long inventory) {
        this.inventory = inventory;
    }
    
    // 2013/07/10 fred add 除錯用
    @Override
    public String toString() {
        
        StringBuffer buffer = new StringBuffer();
        buffer.append("\n\tmpActivityId: " + mpActivityId + "\n");
        buffer.append("\tprice: " + price + "\n");
        buffer.append("\tdiscountId: " + discountId + "\n");
        buffer.append("\tproductId: " + productId + "\n");
        buffer.append("\tproductName: " + productName + "\n");
        buffer.append("\taliasUrl: " + aliasUrl + "\n");
        buffer.append("\tfetNo: " + fetNo + "\n");
        buffer.append("\tisExclusive: " + isExclusive + "\n");
        buffer.append("\tinventory: " + inventory + "\n");
        buffer.append("\tbrand: " + brand + "\n");
        buffer.append("\tatrStatus: " + atrStatus + "\n");
        buffer.append("\tisPreSubscribeDate: " + isPreSubscribeDate + "\n");
        buffer.append("\tpreSubscribeBeginDate: " + preSubscribeBeginDate + "\n");
        buffer.append("\tpreSubscribeEndDate: " + preSubscribeEndDate + "\n");
        buffer.append("\tisUnavailableInform: " + isUnavailableInform + "\n");
        buffer.append("\tunavailableStartTime: " + unavailableStartTime + "\n");
        buffer.append("\tunavailableEndTime: " + unavailableEndTime + "\n");
        
        return buffer.toString();
    }
    public String getAtrStatus() {
        return atrStatus;
    }
    public void setAtrStatus(String atrStatus) {
        this.atrStatus = atrStatus;
    }
    public Boolean getIsUnavailableInform() {
        return isUnavailableInform;
    }
    public void setIsUnavailableInform(Boolean isUnavailableInform) {
        this.isUnavailableInform = isUnavailableInform;
    }
    public Date getUnavailableStartTime() {
        return unavailableStartTime;
    }
    public void setUnavailableStartTime(Date unavailableStartTime) {
        this.unavailableStartTime = unavailableStartTime;
    }
    public Date getUnavailableEndTime() {
        return unavailableEndTime;
    }
    public void setUnavailableEndTime(Date unavailableEndTime) {
        this.unavailableEndTime = unavailableEndTime;
    }
    public Boolean getIsPreSubscribeDate() {
        return isPreSubscribeDate;
    }
    public void setIsPreSubscribeDate(Boolean isPreSubscribeDate) {
        this.isPreSubscribeDate = isPreSubscribeDate;
    }
    public Date getPreSubscribeBeginDate() {
        return preSubscribeBeginDate;
    }
    public void setPreSubscribeBeginDate(Date preSubscribeBeginDate) {
        this.preSubscribeBeginDate = preSubscribeBeginDate;
    }
    public Date getPreSubscribeEndDate() {
        return preSubscribeEndDate;
    }
    public void setPreSubscribeEndDate(Date preSubscribeEndDate) {
        this.preSubscribeEndDate = preSubscribeEndDate;
    }
    
}
