package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.bean.vo.frontend.CouponVO;
import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.Coupon;

public interface NCouponDAO extends BaseDAO<Coupon, Long>{
	/**
	 * 依Coupon Ticket之COUPON_ID取得Coupon
	 * @return
	 */
	public Coupon findById(Long id);

	/**
	 * 是否為合法COUPON
	 * @param id
	 * @param checkOnsale 是否檢查上架
	 * @return
	 */
	public Integer isValidCoupon(Long id, boolean checkOnsale);
	
	/**
	 * 依活動ID取得coupon(i.e. 認証式活動)
	 * @param actId
	 * @return
	 */
	public Coupon findByActivityId(Long actId);
	
	/**
	 * 折價卷是否超出額度(單張不記名)
	 * @param id
	 * @return
	 */
	public boolean isOutOfAmount(Long id);

	/**
	 * 驗證折價卷是否合法 (多張不記名; 單張記名; 多張記名)
	 * @param id 折價卷ID
	 * @param sn 折價卷ticket serial
	 * @param pwd 折價卷ticket password
	 * @return
	 */
	public boolean isValidSerialAndPassword(Long id, String sn, String pwd, boolean checkOnsale, boolean checkExercised, boolean checkPwd);	
	
	/**
	 * 依ID取得折價卷VO
	 * @param id
	 * @return
	 */
	public CouponVO findVOById(Long id);
}
