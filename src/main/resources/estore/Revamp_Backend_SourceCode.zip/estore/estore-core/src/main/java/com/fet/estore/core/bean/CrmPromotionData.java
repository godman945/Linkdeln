package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CrmPromotionData implements Serializable {
	
	/** 客戶升級類型 - 一般取約 */
	public static final String LOYALTY_UPGRADE_TYPE_NORMAL = "NORMAL";
	/** 客戶升級類型 - 資費價差取約 */
	public static final String LOYALTY_UPGRADE_TYPE_SPREAD = "SPREAD";
	/** 客戶升級類型 - 指定資費 */
	public static final String LOYALTY_UPGRADE_TYPE_ASSIGN = "ASSIGN";
    /** 客戶升級類型 - 換約資費 */
    public static final String LOYALTY_UPGRADE_TYPE_CHANGE = "CHANGE";
	
	private String promotonId;
	
	private String msisdnType;
	
	private String upgradeType;
	
	private List<String> vipTypes = new ArrayList<String>();
	
	public boolean isVipPromotoin() {
		return this.vipTypes.size() > 0;
	}

	public String getMsisdnType() {
		return msisdnType;
	}

	public void setMsisdnType(String msisdnType) {
		this.msisdnType = msisdnType;
	}

	public String getPromotonId() {
		return promotonId;
	}

	public void setPromotonId(String promotonId) {
		this.promotonId = promotonId;
	}

	public String getUpgradeType() {
		return upgradeType;
	}

	public void setUpgradeType(String upgradeType) {
		this.upgradeType = upgradeType;
	}
	
	public List<String> getVipTypes() {
		return vipTypes;
	}

	public void setVipTypes(List<String> vipTypes) {
		this.vipTypes = vipTypes;
	}

}
