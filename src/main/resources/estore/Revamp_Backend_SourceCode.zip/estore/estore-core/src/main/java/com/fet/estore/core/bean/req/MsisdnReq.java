package com.fet.estore.core.bean.req;

import java.io.Serializable;

public class MsisdnReq implements Serializable {

	private static final long serialVersionUID = -3732089501775349151L;
	private String msisdn;
	private String channel;
	private Integer idxFrom;
	private Integer size;
	private String keyword;
	private String groupName;
	private String sortType;

	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public Integer getIdxFrom() {
		return idxFrom;
	}
	public void setIdxFrom(Integer idxFrom) {
		this.idxFrom = idxFrom;
	}
	public Integer getSize() {
		return size;
	}
	public void setSize(Integer size) {
		this.size = size;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getSortType() {
		return sortType;
	}
	public void setSortType(String sortType) {
		this.sortType = sortType;
	}
	
}
