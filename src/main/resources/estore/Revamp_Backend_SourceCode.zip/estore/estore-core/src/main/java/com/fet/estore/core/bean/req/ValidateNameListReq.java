package com.fet.estore.core.bean.req;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class ValidateNameListReq implements Serializable {

	private static final long serialVersionUID = 2292724110549143851L;
	/** 序號 */
	private String serialNo;
	/** 驗證碼 */
	private String verificationCode;

	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getVerificationCode() {
		return verificationCode;
	}
	public void setVerificationCode(String verificationCode) {
		this.verificationCode = verificationCode;
	}
}
