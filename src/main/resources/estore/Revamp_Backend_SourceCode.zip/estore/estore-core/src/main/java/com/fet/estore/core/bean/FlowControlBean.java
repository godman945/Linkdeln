package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.fet.estore.core.enums.OrderFlowEnum;

public class FlowControlBean implements Serializable {

	
	private static final long serialVersionUID = -7045878043091771028L;

	/** 已通過的驗證項目 */
	private List<OrderFlowEnum> passedFlow;
	/** 驗證規則 MAP */
	private Map<OrderFlowEnum, FlowRuleBean> ruleMap;
	/** 已完成結帳註記 */
	private boolean completeFlow;

	public List<OrderFlowEnum> getPassedFlow() {
		return passedFlow;
	}

	public void setPassedFlow(List<OrderFlowEnum> passedFlow) {
		this.passedFlow = passedFlow;
	}

	public Map<OrderFlowEnum, FlowRuleBean> getRuleMap() {
		return ruleMap;
	}

	public void setRuleMap(Map<OrderFlowEnum, FlowRuleBean> ruleMap) {
		this.ruleMap = ruleMap;
	}

	public boolean isCompleteFlow() {
		return completeFlow;
	}

	public void setCompleteFlow(boolean completeFlow) {
		this.completeFlow = completeFlow;
	}
	
}
