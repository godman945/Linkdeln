package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.fet.estore.core.constant.EstoreMdmServiceConstant;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;

public class CrmData implements Serializable {

	private static final long serialVersionUID = 8433708278016846391L;
	
	/** 門號 */
	private String msisdn;
	/** UI 輸入的證號 */
	private String uiInputRocId;
	
	// getCacheSubscriberInfoByKey
	/** subscriber id */
	private String subscriberId;
	/** customer Id */
	private String customerId;
	/** account Id */
	private String accountId;
	/**  */
	private String subscriberType;
	/**  */
	private String subStatus;
	/**  */
	private String subStatusReasonCode;
	/**  */
	private String businessEntityId;
	/**  */
	private String paymentCategory;
	/**  */
	private String mobileGenerationCode;
	
	
	// getContractComponentInfoByAdminNativeKey
	/**  */
	private String subscriberGender;
	/**  */
	private String birthday;
	/**  */
	private String subscriberRocId;
	/**  */
	private String accountRocId;
	/**  */
	private String subscriberLastName;
	/**  */
	private String subscriberName;
	/**  */
	private String subscriberIdType;
	/**  */
	private String paymentCategoryForGiftRedeem;
	/**  */
	private String residenceAddress;
	/**  */
	private String billingAddress;
	/**  */
	private String email;
	/**  */
	private String homeTel;
	/**  */
	private String homeTelPrefix;
	/**  */
	private String paymentConsolidationInd;
	/**  */
	private String billingType;
	/**  */
	private String contractComponentValue;
	
	// getContractComponentInfoByAdminNativeKey
	/**  */
	private boolean privateAccount;
	/**  */
	private String churn;
	/**  */
	private String arpb;
	/**  */
	private String vipGrade;
	/**  */
	private String vip;
	/**  */
	private String activationDate;
	/**  */
	private Integer tenure;
	/**  */
	private Date vipStartDate;
	/**  */
	private Date contractExpiryDate;
	/**  */
	private String last3MonthsGprsAverageMB;
	/**  */
	private String smartPhoneIndicator;
	/**  */
	private String happyGoIdn;
	/**  */
	private String currentHandset;
	/** mvpn */
	private boolean mvpn;
	
	// queryServicesEx
	/**  */
	private boolean mvpnSplitBill;
	/**  */
	private boolean hybrid;
	/**  */
	private boolean currentVDOffer;
	/**  */
	private boolean lineMobile;
	/**  */
	private String contractStartDate;
	/**  */
	private String contractEndDate;
	/**  */
	private String currentVoiceRate;
	/**  */
	private String currentDataRate;
	/**  */
	private String currentVoiceName;
	/**  */
	private String currentDataName;
	/**  */
	private Double currentVoicePrice;
	/**  */
	private Double currentDataPrice;
	/**  */
	private String activeProductOffering;
	/**  */
	private String oldSimNo;
	/**  */
	private String mvnpCid;

	//createDraftOrder
	/** */
	private String cohOrderId;
	/** */
	private String cohTx;
	
	// 以下非介接API來的資料
	// 促案
	private List<CrmPromotionData> promotions;
	// 續約模式
	private String loyaltyUpgradeType;
	//
	private boolean lyDataOnly;
	
	public String getMobileGenerationCode() {
		return mobileGenerationCode;
	}
	public void setMobileGenerationCode(String mobileGenerationCode) {
		this.mobileGenerationCode = mobileGenerationCode;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getSubscriberType() {
		return subscriberType;
	}
	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}
	public String getSubStatus() {
		return subStatus;
	}
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}
	public String getSubStatusReasonCode() {
		return subStatusReasonCode;
	}
	public void setSubStatusReasonCode(String subStatusReasonCode) {
		this.subStatusReasonCode = subStatusReasonCode;
	}
	public String getBusinessEntityId() {
		return businessEntityId;
	}
	public void setBusinessEntityId(String businessEntityId) {
		this.businessEntityId = businessEntityId;
	}
	public String getPaymentCategory() {
		return paymentCategory;
	}
	public void setPaymentCategory(String paymentCategory) {
		this.paymentCategory = paymentCategory;
	}
	public boolean isPrivateAccount() {
		return privateAccount;
	}
	public void setPrivateAccount(boolean privateAccount) {
		this.privateAccount = privateAccount;
	}
	public String getChurn() {
		return churn;
	}
	public void setChurn(String churn) {
		this.churn = churn;
	}
	public String getArpb() {
		return arpb;
	}
	public void setArpb(String arpb) {
		this.arpb = arpb;
	}
	public String getVipGrade() {
		return vipGrade;
	}
	public void setVipGrade(String vipGrade) {
		this.vipGrade = vipGrade;
	}
	public String getVip() {
		return vip;
	}
	public void setVip(String vip) {
		this.vip = vip;
	}
	public String getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	public Date getVipStartDate() {
		return vipStartDate;
	}
	public void setVipStartDate(Date vipStartDate) {
		this.vipStartDate = vipStartDate;
	}
	public Date getContractExpiryDate() {
		return contractExpiryDate;
	}
	public void setContractExpiryDate(Date contractExpiryDate) {
		this.contractExpiryDate = contractExpiryDate;
	}
	public String getLast3MonthsGprsAverageMB() {
		return last3MonthsGprsAverageMB;
	}
	public void setLast3MonthsGprsAverageMB(String last3MonthsGprsAverageMB) {
		this.last3MonthsGprsAverageMB = last3MonthsGprsAverageMB;
	}
	public String getSmartPhoneIndicator() {
		return smartPhoneIndicator;
	}
	public void setSmartPhoneIndicator(String smartPhoneIndicator) {
		this.smartPhoneIndicator = smartPhoneIndicator;
	}
	public String getHappyGoIdn() {
		return happyGoIdn;
	}
	public void setHappyGoIdn(String happyGoIdn) {
		this.happyGoIdn = happyGoIdn;
	}
	public String getCurrentHandset() {
		return currentHandset;
	}
	public void setCurrentHandset(String currentHandset) {
		this.currentHandset = currentHandset;
	}
	public boolean isMvpn() {
		return mvpn;
	}
	public void setMvpn(boolean mvpn) {
		this.mvpn = mvpn;
	}
	public boolean isMvpnSplitBill() {
		return mvpnSplitBill;
	}
	public void setMvpnSplitBill(boolean mvpnSplitBill) {
		this.mvpnSplitBill = mvpnSplitBill;
	}
	public boolean isHybrid() {
		return hybrid;
	}
	public void setHybrid(boolean hybrid) {
		this.hybrid = hybrid;
	}
	public boolean isCurrentVDOffer() {
		return currentVDOffer;
	}
	public void setCurrentVDOffer(boolean currentVDOffer) {
		this.currentVDOffer = currentVDOffer;
	}
	public boolean isLineMobile() {
		return lineMobile;
	}
	public void setLineMobile(boolean lineMobile) {
		this.lineMobile = lineMobile;
	}
	public String getContractStartDate() {
		return contractStartDate;
	}
	public void setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;
	}
	public String getContractEndDate() {
		return contractEndDate;
	}
	public void setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;
	}
	public String getCurrentVoiceRate() {
		return currentVoiceRate;
	}
	public void setCurrentVoiceRate(String currentVoiceRate) {
		this.currentVoiceRate = currentVoiceRate;
	}
	public String getCurrentDataRate() {
		return currentDataRate;
	}
	public void setCurrentDataRate(String currentDataRate) {
		this.currentDataRate = currentDataRate;
	}
	public String getCurrentVoiceName() {
		return currentVoiceName;
	}
	public void setCurrentVoiceName(String currentVoiceName) {
		this.currentVoiceName = currentVoiceName;
	}
	public String getCurrentDataName() {
		return currentDataName;
	}
	public void setCurrentDataName(String currentDataName) {
		this.currentDataName = currentDataName;
	}
	public Double getCurrentVoicePrice() {
		return currentVoicePrice;
	}
	public void setCurrentVoicePrice(Double currentVoicePrice) {
		this.currentVoicePrice = currentVoicePrice;
	}
	public Double getCurrentDataPrice() {
		return currentDataPrice;
	}
	public void setCurrentDataPrice(Double currentDataPrice) {
		this.currentDataPrice = currentDataPrice;
	}
	public String getActiveProductOffering() {
		return activeProductOffering;
	}
	public void setActiveProductOffering(String activeProductOffering) {
		this.activeProductOffering = activeProductOffering;
	}
	public String getOldSimNo() {
		return oldSimNo;
	}
	public void setOldSimNo(String oldSimNo) {
		this.oldSimNo = oldSimNo;
	}
	public String getMvnpCid() {
		return mvnpCid;
	}
	public void setMvnpCid(String mvnpCid) {
		this.mvnpCid = mvnpCid;
	}

	public String getCohOrderId() {
		return cohOrderId;
	}

	public void setCohOrderId(String cohOrderId) {
		this.cohOrderId = cohOrderId;
	}

	public String getCohTx() {
		return cohTx;
	}

	public void setCohTx(String cohTx) {
		this.cohTx = cohTx;
	}

	public String getSubscriberGender() {
		return subscriberGender;
	}
	public void setSubscriberGender(String subscriberGender) {
		this.subscriberGender = subscriberGender;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getSubscriberRocId() {
		return subscriberRocId;
	}
	public void setSubscriberRocId(String subscriberRocId) {
		this.subscriberRocId = subscriberRocId;
	}
	public String getAccountRocId() {
		return accountRocId;
	}
	public void setAccountRocId(String accountRocId) {
		this.accountRocId = accountRocId;
	}
	public String getSubscriberLastName() {
		return subscriberLastName;
	}
	public void setSubscriberLastName(String subscriberLastName) {
		this.subscriberLastName = subscriberLastName;
	}
	public String getSubscriberName() {
		return subscriberName;
	}
	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}
	public String getSubscriberIdType() {
		return subscriberIdType;
	}
	public void setSubscriberIdType(String subscriberIdType) {
		this.subscriberIdType = subscriberIdType;
	}
	public String getPaymentCategoryForGiftRedeem() {
		return paymentCategoryForGiftRedeem;
	}
	public void setPaymentCategoryForGiftRedeem(String paymentCategoryForGiftRedeem) {
		this.paymentCategoryForGiftRedeem = paymentCategoryForGiftRedeem;
	}
	public String getResidenceAddress() {
		return residenceAddress;
	}
	public void setResidenceAddress(String residenceAddress) {
		this.residenceAddress = residenceAddress;
	}
	public String getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHomeTel() {
		return homeTel;
	}
	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}
	public String getHomeTelPrefix() {
		return homeTelPrefix;
	}
	public void setHomeTelPrefix(String homeTelPrefix) {
		this.homeTelPrefix = homeTelPrefix;
	}
	public String getPaymentConsolidationInd() {
		return paymentConsolidationInd;
	}
	public void setPaymentConsolidationInd(String paymentConsolidationInd) {
		this.paymentConsolidationInd = paymentConsolidationInd;
	}
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public String getContractComponentValue() {
		return contractComponentValue;
	}
	public void setContractComponentValue(String contractComponentValue) {
		this.contractComponentValue = contractComponentValue;
	}
	public Integer getAge() {
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new Date());
			
			return calendar.get(Calendar.YEAR) - Integer.valueOf(this.getBirthday().substring(0, 4));
		} catch (Exception ex) {
			LogUtil.warn("轉換年齡失敗，目前生日值：{}", this.getBirthday());
			return null;
		}
	}
	public List<CrmPromotionData> getPromotions() {
		return promotions;
	}
	public void setPromotions(List<CrmPromotionData> promotions) {
		this.promotions = promotions;
	}
	public String getLoyaltyUpgradeType() {
		return loyaltyUpgradeType;
	}
	public void setLoyaltyUpgradeType(String loyaltyUpgradeType) {
		this.loyaltyUpgradeType = loyaltyUpgradeType;
	}
	public String getUiInputRocId() {
		return uiInputRocId;
	}
	public void setUiInputRocId(String uiInputRocId) {
		this.uiInputRocId = uiInputRocId;
	}
	public boolean isLyDataOnly() {
		return lyDataOnly;
	}
	public void setLyDataOnly(boolean lyDataOnly) {
		this.lyDataOnly = lyDataOnly;
	}
	
	// TODO : 這邊要移到 ValidationService中
	public String checkMsisdnStatus() {
		
//		String noPassErrMsg = "很抱歉，您的門號目前無法於遠傳網路門市進行線上續約服務，請您至全省遠傳門市辦理，謝謝。";
//		String kgtErrMsg    = "您的門號為原和信用戶，很抱歉，因系統版本因素無法於遠傳網路門市進行線上續約服務，請您至全省遠傳門市辦理，謝謝。";
//		String entErrMsg    = "很抱歉，您的門號可能因以下原因目前無法於線上辦理，謝謝。<br>原因 : 企業用戶、門號或身份不符申辦資格、續約送件中..";
//		String fet2GErrMsg  = "提醒您! 您的門號為2G門號，請至門市辦理升級3G門號的免費服務，謝謝";
//		String preErrMsg    = "很抱歉，您的門號可能因以下原因目前無法於線上辦理，謝謝。<br>原因 : 企業用戶、門號或身份不符申辦資格、續約送件中..";
//		String qwErrMsg     = "您的門號為非遠傳門號，無法於網路門市續約，建議可攜碼至遠傳電信，請洽原業者查詢合約資訊，謝謝。";
		String noPassErrMsg = "errorCode.1";
		String kgtErrMsg    = "errorCode.2";
		String entErrMsg    = "errorCode.3";
		String fet2GErrMsg  = "errorCode.4";
		String preErrMsg    = "errorCode.5";
		String qwErrMsg     = "errorCode.6";
//		String hlErrMsg     = "errorCode.7";
		
		// 判斷是否為FET/KGT, 為KGT時或兩者皆非時不合法
		String entId = this.getBusinessEntityId();
//		boolean isFet = MsisdnStatus.BUSINESS_ENTITY_FET.equals(entId);
//		boolean isKgt = MsisdnStatus.BUSINESS_ENTITY_KGT.equals(entId);
		boolean isFet = "FET".equals(entId);
		boolean isKgt = "KGT".equals(entId);
		if(!isFet && !isKgt) return entErrMsg;
		if(isKgt           ) return kgtErrMsg;
		
		// 判斷FET 2G/3G, 為2G或兩者皆非時不合法
		String mobileGenerationCode = this.getMobileGenerationCode();
		boolean is2G = EstoreMdmServiceConstant.MobileGenerationCode_2G.equals(mobileGenerationCode);
		boolean is3G = EstoreMdmServiceConstant.MobileGenerationCode_3G.equals(mobileGenerationCode);
		boolean is4G = EstoreMdmServiceConstant.MobileGenerationCode_4G.equals(mobileGenerationCode);
		boolean is5G = EstoreMdmServiceConstant.MobileGenerationCode_5G.equals(mobileGenerationCode); // 5G需求戳記
		if(!is2G && !is3G && !is4G && !is5G) return noPassErrMsg; // 5G需求戳記
		if(is2G          ) return fet2GErrMsg;

		if("H".equals(this.getSubStatus())) {
			//HL1,HL2,HL3,HL4,HL5
			return String.format("errorCode.hl.%s", this.getSubStatusReasonCode().substring(this.getSubStatusReasonCode().indexOf("L") + 1));
		}
		
		// 判斷FET 3G IF/NEWCASH/POSTCARD, 為IF/NEWCASH時不合法
		//boolean isIforNewCash  = StringUtil.isInList(new String[] {MsisdnStatus.MSISDNPRODUCTTYPE_IF, MsisdnStatus.MSISDNPRODUCTTYPE_NEWCASH}, this.getProductType());
		//Omin在這裡改了，不知道對不對，只是按照以前規則，把Nes Cash客戶擋住，但不知道有沒有擋住易付卡，因為遠傳說易付卡就是New Cash
		//boolean isIforNewCash = StringUtil.isInList(new String[] {EstoreMdmServiceConstant.SubscriberType_NEW_CASH_CRM}, this.getSubscriberType());
		boolean isIforNewCash = EstoreMdmServiceConstant.PaymentCategory_Prepaid.equals(this.getPaymentCategory());
		boolean isPostCard = EstoreMdmServiceConstant.PaymentCategory_Postpaid.equals(this.getPaymentCategory());
		if(isIforNewCash) return preErrMsg;
		
		// 判斷FET 3G POSTCARD Q/W/T, 為Q/W及不為T時不合法
		String subTp = this.getSubscriberType();
		boolean isSubQW = StringUtil.isInList(new String[] {EstoreMdmServiceConstant.SubscriberType_KING3G_CRM, EstoreMdmServiceConstant.SubscriberType_WALA_CRM},  subTp);
		//T=>3G, L=>4G
		boolean isSubT = EstoreMdmServiceConstant.SubscriberType_3G_CRM.equals(subTp) || EstoreMdmServiceConstant.SubscriberType_4G_CRM.equals(subTp) || EstoreMdmServiceConstant.SubscriberType_5G_CRM.equals(subTp); // 5G需求戳記
		if(isPostCard && isSubQW              ) return qwErrMsg;
		//code scan if(isPostCard && (!isSubQW && !isSubT)) return noPassErrMsg;
		if(isPostCard && !isSubT) return noPassErrMsg;
		
		return "";
	}
	
}
