package com.fet.estore.core.dao.base.impl;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.JdbcDAO;
@Repository
public class JdbcDAOImpl extends JdbcDaoSupport implements JdbcDAO {
	
	@Autowired
	private DataSource dataSource;

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}
	public SqlRowSet queryForRowSet(String sql){
		SqlRowSet rowSet = this.getJdbcTemplate().queryForRowSet(getValidateSql(sql));
		return rowSet;
	}
	
	public List queryForList(String sql){
		List list = this.getJdbcTemplate().queryForList(getValidateSql(sql));
		return list;
	}
	
	public void executeQuery(String sql){
		this.getJdbcTemplate().execute(getValidateSql(sql));
	}
	
	public int update(String sql){
		return this.getJdbcTemplate().update(getValidateSql(sql));
	}
	
	private String getValidateSql(String sql){
		return sql.replace("''", "'").replace(";", "").replace("--", "");
	}
}
