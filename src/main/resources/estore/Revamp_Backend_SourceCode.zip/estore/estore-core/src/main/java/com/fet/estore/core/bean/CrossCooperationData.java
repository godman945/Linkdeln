package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class CrossCooperationData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2858883728031024294L;
	/** 蝦皮訂單號碼（非加密） */
	private String orderNo;
	/** 申辦方式 */
	private String orderType;
	/** 門號 */
	private String msisdn;
	/** 門號商品 ID */
	private String msisdnId;
	/** fetno */
	private String fetno;
	/** 商品 ID */
	private String productId;
	/** 商品名稱 */
	private String productName;
	/** 商品金額 */
	private Long productPrice;
	/** 預繳金額 */
	private Long prepayPrice;
	/** onsale promotion seq */
	private String oplSeq;
	/** promotionListId */
	private String promoListId;
	/** 專案名稱 */
	private String promoName;
	/** 總金額 */
	private Long totalPrice;
	/** C約 */
	private List<String> contentOfferIdList;
	
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getMsisdnId() {
		return msisdnId;
	}
	public void setMsisdnId(String msisdnId) {
		this.msisdnId = msisdnId;
	}
	public String getFetno() {
		return fetno;
	}
	public void setFetno(String fetno) {
		this.fetno = fetno;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getOplSeq() {
		return oplSeq;
	}
	public void setOplSeq(String oplSeq) {
		this.oplSeq = oplSeq;
	}
	public String getPromoListId() {
		return promoListId;
	}
	public void setPromoListId(String promoListId) {
		this.promoListId = promoListId;
	}
	public List<String> getContentOfferIdList() {
		return this.contentOfferIdList;
	}
	public void setContentOfferIdList(List<String> contentOfferIdList) {
		this.contentOfferIdList = contentOfferIdList;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPromoName() {
		return promoName;
	}
	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}
	public Long getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Long productPrice) {
		this.productPrice = productPrice;
	}
	public Long getPrepayPrice() {
		return prepayPrice;
	}
	public void setPrepayPrice(Long prepayPrice) {
		this.prepayPrice = prepayPrice;
	}
	public Long getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}

}
