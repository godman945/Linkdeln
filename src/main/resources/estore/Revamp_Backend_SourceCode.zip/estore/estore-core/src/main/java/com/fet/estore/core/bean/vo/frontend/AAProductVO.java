package com.fet.estore.core.bean.vo.frontend;

public class AAProductVO {
    /** Adobe Analytics 需求使用的物件 -- 結帳頁面和結帳完成頁面用 */

    /** 類別名稱 */
    private String category;

    /** 項目名稱 */
    private String name;

    /** 金額 */
    private Long price;

    /** 數量 */
    private int quantity;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "AAProductVO{" +
                "category='" + category + '\'' +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                '}';
    }
}
