package com.fet.estore.core.bean.vo;

import java.io.Serializable;

public class AccessoryVO implements Serializable {

	private static final long serialVersionUID = 7261888016451011740L;
	private String type;
	private String image;
	private String meta;
	private String name;
	private Long productPrice;
	private String value;
	private String productId;
	private String defaultFetNo;
	private Long maxInventory;
	private Long originPrice;
	private String color;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getMeta() {
		return meta;
	}
	public void setMeta(String meta) {
		this.meta = meta;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Long productPrice) {
		this.productPrice = productPrice;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getDefaultFetNo() {
		return defaultFetNo;
	}
	public void setDefaultFetNo(String defaultFetNo) {
		this.defaultFetNo = defaultFetNo;
	}
	public Long getMaxInventory() {
		return maxInventory;
	}
	public void setMaxInventory(Long maxInventory) {
		this.maxInventory = maxInventory;
	}
	public Long getOriginPrice() {
		return originPrice;
	}
	public void setOriginPrice(Long originPrice) {
		this.originPrice = originPrice;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
}
