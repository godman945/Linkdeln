package com.fet.estore.core.bean.vo.integration;


public class TxidHelperVO {

	/**
	 * 0: 不扣款1: 立即扣款
	 */
	private boolean orderInd;
	
	private String orderNo;
	
	private String merchandizeName;
	
	private String merchandizeShortCode;
	
	private String receiver;
	
	/**
	 * 一律給false
	 */
	private boolean shippingAddressRequired;
	
	
	private String zipCode;
	
	private String receiverAddress;
	
	private String tel;
	
	private String mobile;
	
	private String email;
	
	private String payerName;
	
	private boolean isInvoice;
	
	private String deliveryMethod;
	
	private Long amount;
	
	private String callbackUrl;
	
	private String orderEnqUrl;
	
	private String pushbackUrl;
	
	private String accId;
	
	private boolean isFetnet;
	
	private String supportedPaymentMethod;
	
	private Integer paymentTimes;
	
	private String installmentBankId;
	
	private String txid;
	
	private String pan;
	
	private String pin;
	
	private String validMonth;
	
	private String validYear;
	
	private String txidStatus;
	
	private String cspMsisdn;
	
	private String failReason;
	
	private String homePaymentStatus;
	
	private String msisdn;
	
	private String memo;

	public String getTxidStatus() {
		return txidStatus;
	}

	public void setTxidStatus(String txidStatus) {
		this.txidStatus = txidStatus;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getTxid() {
		return txid;
	}

	public void setTxid(String txid) {
		this.txid = txid;
	}

	public String getValidMonth() {
		return validMonth;
	}

	public void setValidMonth(String validMonth) {
		this.validMonth = validMonth;
	}

	public String getValidYear() {
		return validYear;
	}

	public void setValidYear(String validYear) {
		this.validYear = validYear;
	}

	public String getAccId() {
		return accId;
	}

	public void setAccId(String accId) {
		this.accId = accId;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public String getDeliveryMethod() {
		return deliveryMethod;
	}

	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getInstallmentBankId() {
		return installmentBankId;
	}

	public void setInstallmentBankId(String installmentBankId) {
		this.installmentBankId = installmentBankId;
	}

	public boolean isFetnet() {
		return isFetnet;
	}

	public void setFetnet(boolean isFetnet) {
		this.isFetnet = isFetnet;
	}

	public boolean isInvoice() {
		return isInvoice;
	}

	public void setInvoice(boolean isInvoice) {
		this.isInvoice = isInvoice;
	}

	public String getMerchandizeName() {
		return merchandizeName;
	}

	public void setMerchandizeName(String merchandizeName) {
		this.merchandizeName = merchandizeName;
	}

	public String getMerchandizeShortCode() {
		return merchandizeShortCode;
	}

	public void setMerchandizeShortCode(String merchandizeShortCode) {
		this.merchandizeShortCode = merchandizeShortCode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getOrderEnqUrl() {
		return orderEnqUrl;
	}

	public void setOrderEnqUrl(String orderEnqUrl) {
		this.orderEnqUrl = orderEnqUrl;
	}

	public boolean isOrderInd() {
		return orderInd;
	}

	public void setOrderInd(boolean orderInd) {
		this.orderInd = orderInd;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public Integer getPaymentTimes() {
		return paymentTimes;
	}

	public void setPaymentTimes(Integer paymentTimes) {
		this.paymentTimes = paymentTimes;
	}

	public String getPushbackUrl() {
		return pushbackUrl;
	}

	public void setPushbackUrl(String pushbackUrl) {
		this.pushbackUrl = pushbackUrl;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getReceiverAddress() {
		return receiverAddress;
	}

	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}

	public boolean isShippingAddressRequired() {
		return shippingAddressRequired;
	}

	public void setShippingAddressRequired(boolean shippingAddressRequired) {
		this.shippingAddressRequired = shippingAddressRequired;
	}

	public String getSupportedPaymentMethod() {
		return supportedPaymentMethod;
	}

	public void setSupportedPaymentMethod(String supportedPaymentMethod) {
		this.supportedPaymentMethod = supportedPaymentMethod;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}	
	
	public String getCspMsisdn() {
		return cspMsisdn;
	}

	public void setCspMsisdn(String cspMsisdn) {
		this.cspMsisdn = cspMsisdn;
	}

	public String getFailReason() {
		return failReason;
	}

	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}

	public String getHomePaymentStatus() {
		return homePaymentStatus;
	}

	public void setHomePaymentStatus(String homePaymentStatus) {
		this.homePaymentStatus = homePaymentStatus;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

}
