package com.fet.estore.core.bean;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-16
 * @description
 */
public class GreetingIcon {

    private String text;

    private String link;

    private String target;

    private GreetingIconImage icon;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public GreetingIconImage getIcon() {
        return icon;
    }

    public void setIcon(GreetingIconImage icon) {
        this.icon = icon;
    }
}
