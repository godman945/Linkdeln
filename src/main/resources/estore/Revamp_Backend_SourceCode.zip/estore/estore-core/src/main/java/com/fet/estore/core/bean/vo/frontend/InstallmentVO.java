package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

//import org.apache.struts.util.LabelValueBean;

public class InstallmentVO {
	
	private Map<String, String> bankMap = new LinkedHashMap<String, String>();
	
	private Map<String, List<Integer>> installmentMap = new LinkedHashMap<String, List<Integer>>();
	
	
	
	public void addBank(String bankId, String bankName, Integer installment){
		if(!bankMap.containsKey(bankId)){
			bankMap.put(bankId, bankName);
		}
		
		List<Integer> installments = null;
		if(!installmentMap.containsKey(bankId)){
			installments = new ArrayList<Integer>();
			installmentMap.put(bankId, installments);
		}else{
			installments = installmentMap.get(bankId);
		}
		installments.add(installment);
	}
	
	public Map<String, String> getAllBanks(){		
		return bankMap;
	}
	
	public Map<String, List<Integer>> getAllInstallments(){
		return installmentMap;
	}
	
	
	

}
