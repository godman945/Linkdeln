package com.fet.estore.core.bean.vo.frontend;

import java.util.HashMap;
import java.util.Map;

public class GenericCheckVO {
	private String errorCode;
	private String descritption;
	private Map<String, Object> additionInfo = new HashMap<String, Object>();
	
	
	public void addAdditionInfo(String key, Object value) {
		this.additionInfo.put(key, value);
	}
	
	public Object getAdditionInfo(String key) {
		if(this.additionInfo.containsKey(key)) {
			return this.additionInfo.get(key);
		}else {
			return null;
		}
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getDescritption() {
		return descritption;
	}
	public void setDescritption(String descritption) {
		this.descritption = descritption;
	}
	public Map<String, Object> getAdditionInfo() {
		return additionInfo;
	}
	public void setAdditionInfo(Map<String, Object> additionInfo) {
		this.additionInfo = additionInfo;
	}

	
	
}
