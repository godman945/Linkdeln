package com.fet.estore.core.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @description API Input Output Log
 * @author Dennis.Chen
 * @date 2020-08-25
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ApiInputOutput {

    //印出Input開關
    public boolean input() default true;

    //印出Output開關
    public boolean output() default true;

}
