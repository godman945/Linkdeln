package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HandsetFunctionVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7752354848797655310L;
	
	/** 功能代碼。 */
	private Long funId;
	/** 系統序號。 */
	private Long funSeq;
	/** 功能項目。 */
	private String funItem;
	/** 母功能。 */
	private Long parentId;
	/** 對應設備的規格與規格說明。 */
	private String funDescription;
	/** 規格說明顯示判斷 Y:顯示 N:不顯示。 */
	private String funShow;
	/** 樹節點階層。 */
	private Long funLevel;/* 計算物件所在層次 */
	
	private List<HandsetFunctionVO> childVOList = new ArrayList<HandsetFunctionVO>();
	
	/** 判斷是否還有子節點。 */
	//private boolean isLeaf;
	
	/** 計算子節點數(for rowspan)。 */
	//private int leafCount;
	
	
	public Long getFunId() {
		return funId;
	}
	public void setFunId(Long funId) {
		this.funId = funId;
	}
	public Long getFunSeq() {
		return funSeq;
	}
	public void setFunSeq(Long funSeq) {
		this.funSeq = funSeq;
	}
	public String getFunItem() {
		return funItem;
	}
	public void setFunItem(String funItem) {
		this.funItem = funItem;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public String getFunDescription() {
		return funDescription;
	}
	public void setFunDescription(String funDescription) {
		this.funDescription = funDescription;
	}
	public Long getFunLevel() {
		return funLevel;
	}
	public void setFunLevel(Long funLevel) {
		this.funLevel = funLevel;
	}
	public List<HandsetFunctionVO> getChildVOList() {
		return childVOList;
	}
	public void setChildVOList(List<HandsetFunctionVO> childVOList) {
		this.childVOList = childVOList;
	}
	
	public String getFunShow() {
		return funShow;
	}
	public void setFunShow(String funShow) {
		this.funShow = funShow;
	}
	public boolean isLeaf() {
		boolean isLeaf = false;
		if ((this.childVOList != null) && (this.childVOList.size() > 0)) {
			isLeaf = false;
		} else {
			isLeaf = true;
		}
		return isLeaf;
	}
	
	public int getLeafCount() {
		int leafCount = 0;
		
		if ((this.childVOList != null) && (this.childVOList.size() > 0)) {
			for (HandsetFunctionVO childVO : childVOList) {
				if (childVO.isLeaf()) {
					leafCount = leafCount + 1;
				} else {
					leafCount = leafCount + childVO.getLeafCount();
				}
			}
		}
		
		return leafCount;
	}
}
