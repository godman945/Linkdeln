package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AdTabVO {

	private Integer adTabId;
	private Integer adCategoryId;
	private String tabName;
	private String imagePath;
	private Boolean isOnShelf;
	private String linkUrl;
	private String linkMethod;
	private Boolean isMainTab;
	private String displayName;
	private Integer displayOrder;
	private String tabType;
	private String imagePathOff;
	private Date startDate;
	private Date endDate;
	private String format;
	private String handsetCategoryId;
	 /** NDS獨家資費版型
     * 1L : 1大阪
     * 2S : 2小版
     * 1L2S : 1大2小
     * */
	private String adFormat;

	private List<AdItemVO> adItems = new ArrayList<AdItemVO>();

	private List<HandsetGroupVO> handsetGroupVOs = new ArrayList<HandsetGroupVO>();
	
	private List<AccessoryGroupVO> accessoryGroupVOs = new ArrayList<AccessoryGroupVO>();

	public Integer getAdTabId() {
		return adTabId;
	}

	public void setAdTabId(Integer adTabId) {
		this.adTabId = adTabId;
	}
	
	public Integer getAdCategoryId() {
		return adCategoryId;
	}

	public void setAdCategoryId(Integer adCategoryId) {
		this.adCategoryId = adCategoryId;
	}

	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public Boolean getIsOnShelf() {
		return isOnShelf;
	}

	public void setIsOnShelf(Boolean isOnShelf) {
		this.isOnShelf = isOnShelf;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public String getLinkMethod() {
		return linkMethod;
	}

	public void setLinkMethod(String linkMethod) {
		this.linkMethod = linkMethod;
	}

	public Boolean getIsMainTab() {
		return isMainTab;
	}

	public void setIsMainTab(Boolean isMainTab) {
		this.isMainTab = isMainTab;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Integer getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}

	public String getTabType() {
		return tabType;
	}

	public void setTabType(String tabType) {
		this.tabType = tabType;
	}

	public String getImagePathOff() {
		return imagePathOff;
	}

	public void setImagePathOff(String imagePathOff) {
		this.imagePathOff = imagePathOff;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getHandsetCategoryId() {
		return handsetCategoryId;
	}

	public void setHandsetCategoryId(String handsetCategoryId) {
		this.handsetCategoryId = handsetCategoryId;
	}

	public List<AdItemVO> getAdItems() {
		return adItems;
	}

	public void setAdItems(List<AdItemVO> adItems) {
		this.adItems = adItems;
	}

	public List<HandsetGroupVO> getHandsetGroupVOs() {
		return handsetGroupVOs;
	}

	public void setHandsetGroupVOs(List<HandsetGroupVO> handsetGroupVOs) {
		this.handsetGroupVOs = handsetGroupVOs;
	}

	public List<AccessoryGroupVO> getAccessoryGroupVOs() {
		return accessoryGroupVOs;
	}

	public void setAccessoryGroupVOs(List<AccessoryGroupVO> accessoryGroupVOs) {
		this.accessoryGroupVOs = accessoryGroupVOs;
	}

	public String getAdFormat() {
		return adFormat;
	}

	public void setAdFormat(String adFormat) {
		this.adFormat = adFormat;
	}
	
}
