package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HandsetMiddleVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	/** 識別ID */
	private Integer id;
	/** 標籤名稱 */
	private String tabName;
	/** 標題 */
	private String title;
	/** 內容 */
	private String content;
	/** 標籤圖片路徑 */
	private String imagePath;
	/** Tab連結 */
	private String linkUrl;
	/** 連結方式 */
	private String linkMethod;
	/** 標籤顯示名稱 */
	private String displayName;
	/** 頁籤顯示順序 */
	private Integer displayOrder;
	/** 版型 */
	private String format;
	/** 置頂商品圖示 */
	private String promoIconPath;
	/** 最低價格。 */
	private Long lowestPrice;
	/** 續約最低價格。 */
	private Long lyLowestPrice;
	/** 活動是否上架 */
	private Boolean onShelf;
	/** 商品是否上架 */
	private Boolean onSale;	
	/** 上架起始日 */
	private Date startDate;
	/** 上架結束日 */
	private Date endDate;
	/** 連結按鍵名稱 */
	private String buttonName;	
	/** 連結按鍵URL */
	private String buttonUrl;
	/** 按鍵連結方式 */
	private String buttonLinkMethod;
	/** 對應廣告項目List物件 */
	private List<HandsetMiddleVO> childMiddleVOs = new ArrayList<HandsetMiddleVO>();
	private String handsetGroupId;
	private String accessoryGroupId;
	private String promoIconId;
	private String itemType;
	private String handsetAliasUrl;
	private String accessoryAliasUrl;
	/** 商品原價。 */
	private Long erpPrice;
	/** 廠牌 **/
	private String brand;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public String getLinkMethod() {
		return linkMethod;
	}

	public void setLinkMethod(String linkMethod) {
		this.linkMethod = linkMethod;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Integer getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getPromoIconPath() {
		return promoIconPath;
	}

	public void setPromoIconPath(String promoIconPath) {
		this.promoIconPath = promoIconPath;
	}

	public List<HandsetMiddleVO> getChildMiddleVOs() {
		return childMiddleVOs;
	}

	public void setChildMiddleVOs(List<HandsetMiddleVO> childMiddleVOs) {
		this.childMiddleVOs = childMiddleVOs;
	}

	public Long getLowestPrice() {
		return lowestPrice;
	}

	public void setLowestPrice(Long lowestPrice) {
		this.lowestPrice = lowestPrice;
	}

	public Long getLyLowestPrice() {
		return lyLowestPrice;
	}

	public void setLyLowestPrice(Long lyLowestPrice) {
		this.lyLowestPrice = lyLowestPrice;
	}

	public String getHandsetGroupId() {
		return handsetGroupId;
	}

	public void setHandsetGroupId(String handsetGroupId) {
		this.handsetGroupId = handsetGroupId;
	}

	public String getAccessoryGroupId() {
		return accessoryGroupId;
	}

	public void setAccessoryGroupId(String accessoryGroupId) {
		this.accessoryGroupId = accessoryGroupId;
	}

	public String getPromoIconId() {
		return promoIconId;
	}

	public void setPromoIconId(String promoIconId) {
		this.promoIconId = promoIconId;
	}

	public Boolean getOnShelf() {
		return onShelf;
	}

	public void setOnShelf(Boolean onShelf) {
		this.onShelf = onShelf;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getButtonName() {
		return buttonName;
	}

	public void setButtonName(String buttonName) {
		this.buttonName = buttonName;
	}

	public String getButtonUrl() {
		return buttonUrl;
	}

	public void setButtonUrl(String buttonUrl) {
		this.buttonUrl = buttonUrl;
	}

	public String getButtonLinkMethod() {
		return buttonLinkMethod;
	}

	public void setButtonLinkMethod(String buttonLinkMethod) {
		this.buttonLinkMethod = buttonLinkMethod;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getHandsetAliasUrl() {
		return handsetAliasUrl;
	}

	public void setHandsetAliasUrl(String handsetAliasUrl) {
		this.handsetAliasUrl = handsetAliasUrl;
	}

	public String getAccessoryAliasUrl() {
		return accessoryAliasUrl;
	}

	public void setAccessoryAliasUrl(String accessoryAliasUrl) {
		this.accessoryAliasUrl = accessoryAliasUrl;
	}

	public Boolean getOnSale() {
		return onSale;
	}

	public void setOnSale(Boolean onSale) {
		this.onSale = onSale;
	}

	public Long getErpPrice() {
		return erpPrice;
	}

	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
	
}	
