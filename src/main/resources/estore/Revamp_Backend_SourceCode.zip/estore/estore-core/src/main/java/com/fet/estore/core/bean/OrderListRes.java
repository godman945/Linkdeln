package com.fet.estore.core.bean;

import com.fet.estore.core.bean.vo.frontend.Address;
import com.fet.estore.core.model.AreaCity;

import java.io.Serializable;
import java.util.List;

public class OrderListRes implements Serializable {

	private static final long serialVersionUID = 4254740828770847389L;
	
	private String orderMode;
	private String orderType;
	private OrderContent planContent;
	private OrderListBean Cart;
	/** 結帳頁 -- 合約 */
	private Contract contract;
	/** 結帳頁 -- 付款方式 */
	private List<String> payTypes;
	/** 結帳頁 -- 取貨方式 */
	private List<String> deliveryTypes;
	/** 結帳頁 -- 續約使用者的HappyGo點數 */
	private String lyHappyGoPoint;
	/** 結帳頁 -- 進入時結帳頁時的總結帳金額 */
	private Long total;
	/** 結帳頁 -- 個資頁地址(同帳單地址按鈕功能) */
	private Address registerAddress;
	/** 20200911 Dennis.Chen - 新用卡繳款結果*/
	private String afterCreditResult;
	private String afterCreditErrMsg;
	/** 是否顯示OTP視窗 modified by Roil.Li 20200918 */
	private String showOtp;
	/** 是否為登入狀態 */
	private Boolean cspLoginStatus;
	/** 結帳頁 -- 折價資訊  */
	private OrderDiscountResult paymentPageDiscount;
	/** 結帳頁 -- 縣市資訊和門市資訊 */
	private  List<CityAreaVO> cityData;
	private List<AreaCity> storeData;

	public OrderContent getPlanContent() {
		return planContent;
	}
	public void setPlanContent(OrderContent planContent) {
		this.planContent = planContent;
	}
	public OrderListBean getCart() {
		return Cart;
	}
	public void setCart(OrderListBean cart) {
		Cart = cart;
	}
	public String getOrderMode() {
		return orderMode;
	}
	public void setOrderMode(String orderMode) {
		this.orderMode = orderMode;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public Contract getContract() {
		return contract;
	}

	public void setContract(Contract contract) {
		this.contract = contract;
	}

	public List<String> getPayTypes() {
		return payTypes;
	}

	public void setPayTypes(List<String> payTypes) {
		this.payTypes = payTypes;
	}

	public List<String> getDeliveryTypes() {
		return deliveryTypes;
	}

	public void setDeliveryTypes(List<String> deliveryTypes) {
		this.deliveryTypes = deliveryTypes;
	}

	public String getLyHappyGoPoint() {
		return lyHappyGoPoint;
	}

	public void setLyHappyGoPoint(String lyHappyGoPoint) {
		this.lyHappyGoPoint = lyHappyGoPoint;
	}

	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public Address getRegisterAddress() {
		return registerAddress;
	}

	public void setRegisterAddress(Address registerAddress) {
		this.registerAddress = registerAddress;
	}

	public String getAfterCreditResult() {
		return afterCreditResult;
	}

	public void setAfterCreditResult(String afterCreditResult) {
		this.afterCreditResult = afterCreditResult;
	}

	public String getAfterCreditErrMsg() {
		return afterCreditErrMsg;
	}

	public void setAfterCreditErrMsg(String afterCreditErrMsg) {
		this.afterCreditErrMsg = afterCreditErrMsg;
	}

	public String getShowOtp() {
		return showOtp;
	}

	public void setShowOtp(String showOtp) {
		this.showOtp = showOtp;
	}

	public Boolean getCspLoginStatus() {
		return cspLoginStatus;
	}

	public void setCspLoginStatus(Boolean cspLoginStatus) {
		this.cspLoginStatus = cspLoginStatus;
	}

	public OrderDiscountResult getPaymentPageDiscount() {
		return paymentPageDiscount;
	}

	public void setPaymentPageDiscount(OrderDiscountResult paymentPageDiscount) {
		this.paymentPageDiscount = paymentPageDiscount;
	}

	public List<CityAreaVO> getCityData() {
		return cityData;
	}

	public void setCityData(List<CityAreaVO> cityData) {
		this.cityData = cityData;
	}

	public List<AreaCity> getStoreData() {
		return storeData;
	}

	public void setStoreData(List<AreaCity> storeData) {
		this.storeData = storeData;
	}
}
