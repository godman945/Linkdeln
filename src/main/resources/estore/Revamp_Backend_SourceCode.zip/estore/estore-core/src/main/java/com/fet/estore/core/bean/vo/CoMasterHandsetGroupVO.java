package com.fet.estore.core.bean.vo;

public class CoMasterHandsetGroupVO {

	private String brand;
	
	private String modelName;
	
	private Boolean three2four;

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public Boolean getThree2four() {
		return three2four;
	}

	public void setThree2four(Boolean three2four) {
		this.three2four = three2four;
	}
	
	
}
