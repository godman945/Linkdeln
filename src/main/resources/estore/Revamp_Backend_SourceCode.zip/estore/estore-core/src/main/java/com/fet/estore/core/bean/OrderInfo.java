package com.fet.estore.core.bean;

import java.io.Serializable;

public class OrderInfo implements Serializable {
	

	private static final long serialVersionUID = -1612344087747245717L;
	
	/** 以下為訂單完成頁使用的資料結構 */
	/** 訂單類型 */
	private String orderType;
	/** 勾選稍後上傳證件 */
	private boolean isUpdateLater;
	/** 訂單編號 */
    private String order_number; //: 'TLXXXXXXXX',
    /** 付款方式 */
    private String payment; //: '信用卡',
    /** 取貨方式 */
    private String receive; //: '宅配到府',
    /** 聯絡電話 */
    private String mobile; //: '0934-***-890',
    /** 收貨地址 */
    private String address; //: '台北市內湖區瑞光*************',
    /** 發票格式 */
    private String receipt; //: '電子發票電子載具',
    /** 1.時間 */
    private String coDate;
    /** 3.promotion code */
    private String promotionCode;

	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public boolean isUpdateLater() {
		return isUpdateLater;
	}
	public void setUpdateLater(boolean isUpdateLater) {
		this.isUpdateLater = isUpdateLater;
	}
	public String getOrder_number() {
		return order_number;
	}
	public void setOrder_number(String order_number) {
		this.order_number = order_number;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public String getReceive() {
		return receive;
	}
	public void setReceive(String receive) {
		this.receive = receive;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getReceipt() {
		return receipt;
	}
	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}
	public String getCoDate() {
		return coDate;
	}
	public void setCoDate(String coDate) {
		this.coDate = coDate;
	}
	public String getPromotionCode() {
		return promotionCode;
	}
	public void setPromotionCode(String promotionCode) {
		this.promotionCode = promotionCode;
	}

}
