package com.fet.estore.core.bean.vo.frontend;

public class ProdVaServiceVO {
	/** 加購服務ID */
	private String fetNo;
	/** 名稱 */
	private String name;
	/** 費率說明 */
	private String rate;
	/** 加值服務ID */
	private String description;
	
	
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}	
}
