package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AlarmMail;

public interface NAlarmMailDAO extends BaseDAO<AlarmMail, Long> {
	AlarmMail findAlarmMailByName(String name);
}
