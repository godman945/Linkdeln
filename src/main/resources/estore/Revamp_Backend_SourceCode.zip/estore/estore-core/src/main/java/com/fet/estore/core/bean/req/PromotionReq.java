package com.fet.estore.core.bean.req;

/**
 * @description 撈取促案Request物件
 * @author Dennis.Chen
 * @Date 2020-08-18
 */
public class PromotionReq {

    String orderType; //流程
    String productId; //商品ID
    String fetNo; //料號
    String needAnchorTag; //是否需要定錨中心貼標(目前只有續約館)
    Boolean isAct;

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getFetNo() {
        return fetNo;
    }

    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }

    public String getNeedAnchorTag() {
        return needAnchorTag;
    }

    public void setNeedAnchorTag(String needAnchorTag) {
        this.needAnchorTag = needAnchorTag;
    }

    public Boolean getAct() {
        return isAct;
    }

    public void setAct(Boolean act) {
        isAct = act;
    }
}
