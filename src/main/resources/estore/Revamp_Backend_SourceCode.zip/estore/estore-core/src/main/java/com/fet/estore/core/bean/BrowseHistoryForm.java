package com.fet.estore.core.bean;

import java.io.Serializable;

public class BrowseHistoryForm implements Serializable {

	private static final long serialVersionUID = -2765572526344500609L;
	private String categoryGroup;
	private String productId;
	private Integer sort;
	
	public String getCategoryGroup() {
		return categoryGroup;
	}
	public void setCategoryGroup(String categoryGroup) {
		this.categoryGroup = categoryGroup;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	
}
