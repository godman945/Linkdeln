package com.fet.estore.core.bean;

import java.io.Serializable;

public class LyCheckInputForm implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2292724110549143851L;
	/** 身分證號 */
	private String rocId;
	/** 門號 */
	private String msisdn;
	/** 活動 ID */
	private Long actId;
	/** 驗證商品類型 （HANDSET、ACCESSORY） */
	private String entryPoint;
	/** service_channel */
	private String serviceChannel;
	/** 是否來自續約館 */
	private boolean isFromRenewal;
	
	public String getServiceChannel() {
		return serviceChannel;
	}

	public void setServiceChannel(String serviceChannel) {
		this.serviceChannel = serviceChannel;
	}

	public String getRocId() {
		return rocId;
	}

	public void setRocId(String rocId) {
		this.rocId = rocId;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String lyMsisdn) {
		this.msisdn = lyMsisdn;
	}

	public Long getActId() {
		return actId;
	}

	public void setActId(Long actId) {
		this.actId = actId;
	}

	public String getEntryPoint() {
		return entryPoint;
	}

	public void setEntryPoint(String entryPoint) {
		this.entryPoint = entryPoint;
	}

	public boolean getIsFromRenewal() {
		return isFromRenewal;
	}

	public void setIsFromRenewal(boolean isFromRenewal) {
		this.isFromRenewal = isFromRenewal;
	}

}
