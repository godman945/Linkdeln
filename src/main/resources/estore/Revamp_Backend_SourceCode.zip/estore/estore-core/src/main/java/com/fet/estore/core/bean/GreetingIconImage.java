package com.fet.estore.core.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-16
 * @description
 */
public class GreetingIconImage {

    @JsonProperty("default")
    private String greetingDefault;

    private String retina;

    public String getGreetingDefault() {
        return greetingDefault;
    }

    public void setGreetingDefault(String greetingDefault) {
        this.greetingDefault = greetingDefault;
    }

    public String getRetina() {
        return retina;
    }

    public void setRetina(String retina) {
        this.retina = retina;
    }
}
