package com.fet.estore.core.bean.po;

import com.fet.estore.core.bean.vo.frontend.DiscountItemVO;

/**
 * @description 活動贈品
 * @author Dennis.Chen
 * @Date 2020-10-06
 */
public class ActivityGiftPO implements Comparable<ActivityGiftPO>{

    String aaiType;
    Long aaiActId;
    Long aaiAmount;
    String aaiCode;
    Long aaiId;
    String prodName;
    String prodFetNo;
    Long couponId;
    Long offerId;
    Long ccmId;
    String discountName;
    Boolean isShow;

    public String getAaiType() {
        return aaiType;
    }

    public void setAaiType(String aaiType) {
        this.aaiType = aaiType;
    }

    public Long getAaiActId() {
        return aaiActId;
    }

    public void setAaiActId(Long aaiActId) {
        this.aaiActId = aaiActId;
    }

    public Long getAaiAmount() {
        return aaiAmount;
    }

    public void setAaiAmount(Long aaiAmount) {
        this.aaiAmount = aaiAmount;
    }

    public String getAaiCode() {
        return aaiCode;
    }

    public void setAaiCode(String aaiCode) {
        this.aaiCode = aaiCode;
    }

    public Long getAaiId() {
        return aaiId;
    }

    public void setAaiId(Long aaiId) {
        this.aaiId = aaiId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getProdFetNo() {
        return prodFetNo;
    }

    public void setProdFetNo(String prodFetNo) {
        this.prodFetNo = prodFetNo;
    }

    public Long getCouponId() {
        return couponId;
    }

    public void setCouponId(Long couponId) {
        this.couponId = couponId;
    }

    public Long getOfferId() {
        return offerId;
    }

    public void setOfferId(Long offerId) {
        this.offerId = offerId;
    }

    public Long getCcmId() {
        return ccmId;
    }

    public void setCcmId(Long ccmId) {
        this.ccmId = ccmId;
    }

    public String getDiscountName() {
        return discountName;
    }

    public void setDiscountName(String discountName) {
        this.discountName = discountName;
    }

    public Boolean getShow() {
        return isShow;
    }

    public void setShow(Boolean show) {
        isShow = show;
    }

    @Override
    public int compareTo(ActivityGiftPO o) {
        Long l1 = this.getAaiId();
        Long l2 = o.getAaiId();
        if(l1 == null) l1 = Long.MAX_VALUE;
        if(l2 == null) l2 = Long.MAX_VALUE;
        return l1.compareTo(l2);
    }
}
