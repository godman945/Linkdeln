package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

/**
 * 商品明細頁 - 提醒資訊
 *
 * @description
 * @author Ted.Hsieh
 * @date 2020-08-11
 */

public class Notice implements Serializable  {

    private static final long serialVersionUID = 1L;

    /** 提醒資訊標題 */
    private String text;
    /** 提醒資訊Modal內容 */
    private NoticeContent modal;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public NoticeContent getModal() {
        return modal;
    }

    public void setModal(NoticeContent modal) {
        this.modal = modal;
    }
}
