package com.fet.estore.core.dao;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.enums.FlowTypeEnum;
import com.fet.estore.core.model.CfgFlowControl;

import java.util.List;

public interface ICfgFlowControlDAO extends BaseDAO<CfgFlowControl, Long> {

    public List<CfgFlowControl> findByFlowType(FlowTypeEnum flow);
}
