package com.fet.estore.core.bean.req;

public class SubscriberInitReq {

}
