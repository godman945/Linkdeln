package com.fet.estore.core.bean.vo.integration;

public class InvoiceProfileVO {
	
	/**發票載具號碼**/
	private String carrierType;
	/**載具顯碼Id**/
	private String carrierId1;
	/**載具隱碼Id**/
	private String carrierId2;
	/**是否發票捐贈**/
	private boolean donation;
	/**捐贈單位**/
	private String donationUnit;
	/**客戶別 [C] 公司戶 [I] 個人戶**/
	private String custType;
	/**營利事業統一編號**/
	private String buyerNum;
	/**電子發票寄送信箱**/
	private String email;
	/**縣市**/
	private String city;
	/**區域**/
	private String region;
	/**郵寄地址**/
	private String address;
	/**發票抬頭**/
	private String companyName;
	/**是否索取紙本[平信；掛號]；[0] 不索取 [1] 平信索取[2] 掛號索取**/
	private String acquirePaper;
		
	/**縣市Code**/
	private String cityCode;
	/**區域Code**/
	private String regionCode;
	/**地址**/
	private String addressTail;
	
	public boolean isDonation() {
		return donation;
	}
	public void setDonation(boolean donation) {
		this.donation = donation;
	}
	public String getCarrierType() {
		return carrierType;
	}
	public void setCarrierType(String carrierType) {
		this.carrierType = carrierType;
	}
	public String getCarrierId1() {
		return carrierId1;
	}
	public void setCarrierId1(String carrierId1) {
		this.carrierId1 = carrierId1;
	}
	public String getCarrierId2() {
		return carrierId2;
	}
	public void setCarrierId2(String carrierId2) {
		this.carrierId2 = carrierId2;
	}
	
	public String getDonationUnit() {
		return donationUnit;
	}
	public void setDonationUnit(String donationUnit) {
		this.donationUnit = donationUnit;
	}
	public String getCustType() {
		return custType;
	}
	public void setCustType(String custType) {
		this.custType = custType;
	}
	public String getBuyerNum() {
		return buyerNum;
	}
	public void setBuyerNum(String buyerNum) {
		this.buyerNum = buyerNum;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAcquirePaper() {
		return acquirePaper;
	}
	public void setAcquirePaper(String acquirePaper) {
		this.acquirePaper = acquirePaper;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public String getAddressTail() {
		return addressTail;
	}
	public void setAddressTail(String addressTail) {
		this.addressTail = addressTail;
	}
}
