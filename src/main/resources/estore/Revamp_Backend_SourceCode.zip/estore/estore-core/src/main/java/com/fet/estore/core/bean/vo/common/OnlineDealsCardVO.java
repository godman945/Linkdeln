package com.fet.estore.core.bean.vo.common;

public class OnlineDealsCardVO {
	
	String title;
	String link;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
}
