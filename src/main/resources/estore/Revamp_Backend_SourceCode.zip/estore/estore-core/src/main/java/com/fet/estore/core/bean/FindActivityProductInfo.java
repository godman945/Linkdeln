package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 活動商品資料結構
 * 
 * @description
 * @author Klyve.Chen
 * @date 2020-09-11
 */
public class FindActivityProductInfo implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Boolean priceFilter;

	private Boolean bandFilter;

	private Boolean brandFilter;

	private boolean categoryFilter;

	private String minisitePortalDesc;

	/** 廠牌下拉選單 */
	private BrandList brandList;
	/** 廠牌下拉選單 */
	private Map<Integer, List<CategoryView>> categoryMap;
	/** 麵包屑資訊 add by Phil.Lin 20200727*/
	private List<BreadCrumbs> breadcrumbs;

	private List<Product> products;

    private boolean doubleCheck;

	private boolean isEbu;

	public BrandList getBrandList() {
		return brandList;
	}
	public void setBrandList(BrandList brandList) {
		this.brandList = brandList;
	}
	public List<BreadCrumbs> getBreadcrumbs() {
		return breadcrumbs;
	}
	public void setBreadcrumbs(List<BreadCrumbs> breadcrumbs) {
		this.breadcrumbs = breadcrumbs;
	}
	public Map<Integer, List<CategoryView>> getCategoryMap() {
		return categoryMap;
	}
	public void setCategoryMap(Map<Integer, List<CategoryView>> categories) {
		this.categoryMap = categories;
	}
	public Boolean isPriceFilter() {
		return priceFilter != null ? priceFilter : false;
	}
	public void setPriceFilter(Boolean priceFilter) {
		this.priceFilter = priceFilter;
	}
	public Boolean isBandFilter() {
		return bandFilter != null ? bandFilter : false;
	}
	public void setBandFilter(Boolean bandFilter) {
		this.bandFilter = bandFilter;
	}
	public Boolean isBrandFilter() {
		return brandFilter != null ? brandFilter : false;
	}
	public void setBrandFilter(Boolean brandFilter) {
		this.brandFilter = brandFilter;
	}
	public boolean isCategoryFilter() {
		return categoryFilter;
	}
	public void setCategoryFilter(boolean categoryFilter) {
		this.categoryFilter = categoryFilter;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public String getMinisitePortalDesc() {
		return minisitePortalDesc;
	}
	public void setMinisitePortalDesc(String minisitePortalDesc) {
		this.minisitePortalDesc = minisitePortalDesc;
	}
	public boolean isEbu() {
		return isEbu;
	}
	public void setEbu(boolean ebu) {
		isEbu = ebu;
	}
}
