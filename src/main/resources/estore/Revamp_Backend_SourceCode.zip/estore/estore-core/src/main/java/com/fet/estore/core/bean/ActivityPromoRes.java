package com.fet.estore.core.bean;

import java.util.List;

import com.fet.estore.core.bean.vo.OnsalePromoVO;

public class ActivityPromoRes {

	public List<OnsalePromoVO> onsalePromoList;
	public String rtnCode;
	public String rtnMsg;

	public List<OnsalePromoVO> getOnsalePromoList() {
		return onsalePromoList;
	}

	public void setOnsalePromoList(List<OnsalePromoVO> onsalePromoList) {
		this.onsalePromoList = onsalePromoList;
	}

	public String getRtnCode() {
		return rtnCode;
	}

	public void setRtnCode(String rtnCode) {
		this.rtnCode = rtnCode;
	}

	public String getRtnMsg() {
		return rtnMsg;
	}

	public void setRtnMsg(String rtnMsg) {
		this.rtnMsg = rtnMsg;
	}
	
}
