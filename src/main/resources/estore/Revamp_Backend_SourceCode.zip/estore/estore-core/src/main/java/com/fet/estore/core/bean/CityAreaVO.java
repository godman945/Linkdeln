package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;
import com.fet.estore.core.bean.vo.AreaRgnVO;


public class CityAreaVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6227065261513602998L;
	private String cityCode;
	private String cityName;
	private Boolean shippingArea;
	private Integer displayOrder;
	private List<AreaRgnVO> areaRgns;
	
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public Boolean getShippingArea() {
		return shippingArea;
	}
	public void setShippingArea(Boolean shippingArea) {
		this.shippingArea = shippingArea;
	}
	public Integer getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}
	public List<AreaRgnVO> getAreaRgns() {
		return areaRgns;
	}
	public void setAreaRgns(List<AreaRgnVO> areaRgns) {
		this.areaRgns = areaRgns;
	}

}
