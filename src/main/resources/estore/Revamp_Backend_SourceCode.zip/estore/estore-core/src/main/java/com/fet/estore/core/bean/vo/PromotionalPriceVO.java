package com.fet.estore.core.bean.vo;

import com.fet.estore.core.model.HandsetGroup;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-27
 * @description
 */
public class PromotionalPriceVO {

    private String productId;

    private String modelName;

    private String detailLink;

    private String brand;

    private String seq;

    private String monthPrice;

    private String posPrc;

    private String prePrc;

    private Long projectPrice;

    private String imagePath;

    private String defaultImage;
    /** 單機或搭配促案 */
    private String sellType;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getMonthPrice() {
        return monthPrice;
    }

    public void setMonthPrice(String monthPrice) {
        this.monthPrice = monthPrice;
    }

    public String getPosPrc() {
        return posPrc;
    }

    public void setPosPrc(String posPrc) {
        this.posPrc = posPrc;
    }

    public String getPrePrc() {
        return prePrc;
    }

    public void setPrePrc(String prePrc) {
        this.prePrc = prePrc;
    }

    public Long getProjectPrice() {
        return projectPrice;
    }

    public void setProjectPrice(Long projectPrice) {
        this.projectPrice = projectPrice;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getDefaultImage() {
        return defaultImage;
    }

    public void setDefaultImage(String defaultImage) {
        this.defaultImage = defaultImage;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getDetailLink() {
        return detailLink;
    }

    public void setDetailLink(String detailLink) {
        this.detailLink = detailLink;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getSellType() {
        return sellType;
    }

    public void setSellType(String sellType) {
        this.sellType = sellType;
    }
}
