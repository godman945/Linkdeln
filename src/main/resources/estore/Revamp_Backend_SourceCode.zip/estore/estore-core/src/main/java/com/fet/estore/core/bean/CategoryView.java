package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-18
 */
public class CategoryView implements Serializable {

	private static final long serialVersionUID = 8169499615385970503L;
	
	/** 分類id 目前未定義 為空值*/
	private Long value;
	/** 小分類名稱 */
	private String text;

	public CategoryView(Long value, String text) {
		this.value = value;
		this.text = text;
	}
	public Long getValue() {
		return value;
	}
	public void setValue(Long value) {
		this.value = value;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
}
