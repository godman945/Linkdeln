package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

public class IdAndQuantityPairHelper  implements Serializable {
	String id;
	int quantity;
	boolean isMarkupProduct;
	String uuid;
	
	//加價購使用
	private Long mpActivityId;
	private Long mpActivityProductDiscountId;
	private String mpActivityUuid;
	
	private Long remainingPrice;
	
	//紅配綠使用,非紅配綠:0
	//紅配綠第一群:1,第二群:2
	int groupNumber;
	private boolean master;
	
	
	public boolean isMaster() {
		return master;
	}
	public void setMaster(boolean master) {
		this.master = master;
	}
	public Long getMpActivityId() {
		return mpActivityId;
	}
	public void setMpActivityId(Long mpActivityId) {
		this.mpActivityId = mpActivityId;
	}
	public Long getMpActivityProductDiscountId() {
		return mpActivityProductDiscountId;
	}
	public void setMpActivityProductDiscountId(Long mpActivityProductDiscountId) {
		this.mpActivityProductDiscountId = mpActivityProductDiscountId;
	}
	public boolean isMarkupProduct() {
		return isMarkupProduct;
	}
	public void setMarkupProduct(boolean isMarkupProduct) {
		this.isMarkupProduct = isMarkupProduct;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getMpActivityUuid() {
		return mpActivityUuid;
	}
	public void setMpActivityUuid(String mpActivityUuid) {
		this.mpActivityUuid = mpActivityUuid;
	}
	public Long getRemainingPrice() {
		return remainingPrice;
	}
	public void setRemainingPrice(Long remainingPrice) {
		this.remainingPrice = remainingPrice;
	}
	public int getGroupNumber() {
		return groupNumber;
	}
	public void setGroupNumber(int groupNumber) {
		this.groupNumber = groupNumber;
	}

}
