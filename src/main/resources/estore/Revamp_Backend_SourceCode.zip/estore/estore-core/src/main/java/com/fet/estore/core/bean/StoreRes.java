package com.fet.estore.core.bean;

import java.io.Serializable;

public class StoreRes implements Serializable {

	private static final long serialVersionUID = -2601552864362560230L;
	private String city;
	private String area;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
}
