package com.fet.estore.core.bean.req;

/**
 * @description 信用卡結帳後Submit物件
 * @author Dennis.Chen
 * @Date 2020-09-09
 */
public class AfterCreditReq {
    String nppMultiPayment;

    public String getNppMultiPayment() {
        return nppMultiPayment;
    }

    public void setNppMultiPayment(String nppMultiPayment) {
        this.nppMultiPayment = nppMultiPayment;
    }
}
