package com.fet.estore.core.bean.bo;

import com.fet.estore.core.bean.vo.frontend.CouponRedeemTargetVO;
import com.fet.estore.core.bean.vo.frontend.CouponVO;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 確認折價券有沒有在各類型的項目有沒有被使用或折價
 * //TODO 可以加入State check 確保確認過程的順序及正確性
 *
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-22
 * @description
 */
public class CouponCheckBO {

    public static final String REDEEM_TARGET_TYPE_ORDER_TYPE = "ORDER_TYPE";
    public static final String REDEEM_TARGET_TYPE_DEVICE = "DEVICE";
    public static final String REDEEM_TARGET_TYPE_PROMOTION = "PROMOTION";
    public static final String REDEEM_TARGET_TYPE_DELIVERY_TYPE = "DELIVERY_TYPE";
    public static final String REDEEM_TARGET_TYPE_ACCESSORY = "ACCESSORY";

    private Set<String> orderTypeIds = new HashSet<String>(){{add("ALL");}};
    private Set<String> deviceTypeIds = new HashSet<String>(){{add("ALL");}};
    private Set<String> promotionTypeIds = new HashSet<String>(){{add("ALL");}};
    private Set<String> deliveryTypeIds = new HashSet<String>(){{add("ALL");}};
    private Set<String> accessoryTypeIds = new HashSet<String>(){{add("ALL");}};

    private boolean allDev = true;
    private boolean allOt = true;
    private boolean allAcc = true;
    private boolean allPrm = true;
    private boolean allDlv = true;
    private boolean nonDev;
    private boolean nonAcc;

    private boolean hasDisc = false;

    private boolean allowDev;
    private boolean allowAcc;

    private boolean devChecked;
    private boolean accChecked;
    private boolean promotionChecked;
    private boolean deliveryChecked;
    private boolean orderTypeChecked;

    private boolean passDevCheck = false;
    private boolean passAccCheck = false;
    private boolean passPromotionCheck;
    private boolean passDeliveryTypeCheck;
    private boolean passOrderTypeCheck;
    private boolean passTotalPriceCheck;
    private boolean passDeviceTotalPriceCheck;
    private boolean passAccessoryTotalPriceCheck;

    private long totalPrice = 0L;
    private long devTotalPrice = 0L;
    private long accTotalPrice = 0L;

    private boolean successToInit;

    /**
     * Step1 : 先將所使用的coupon build起來
     * @param cpn 依據使用輸入的coupon序號得到的Coupon
     */
    public CouponCheckBO(CouponVO cpn) {
        if (cpn == null) {
            successToInit = true;
            return;
        }
        allowDev = cpn.isDeviceAllow();
        allowAcc = cpn.isAccessoryAllow();
        Set<CouponRedeemTargetVO> targets = cpn.getCouponRedeemTargets();
        Set<String> hasAllset = new HashSet<>();
        for (CouponRedeemTargetVO target : targets) {
            String type = target.getType();
            String targetId = target.getTargetId();
            if (targetId == null)
                continue;
            if ("ALL".equals(targetId)) {
                hasAllset.add(type);
            }
            switch (type) {
                case REDEEM_TARGET_TYPE_ORDER_TYPE:
                    allOt = hasAllset.contains(type);
                    if (!allOt) {
                        orderTypeIds.remove("ALL");
                    }
                    orderTypeIds.add(targetId);
                    break;
                case REDEEM_TARGET_TYPE_DEVICE:
                    allDev = hasAllset.contains(type);
                    if (!allDev) {
                        deviceTypeIds.remove("ALL");
                    }
                    deviceTypeIds.add(targetId);
                    break;
                case REDEEM_TARGET_TYPE_PROMOTION:
                    allPrm = hasAllset.contains(type);
                    if (!allPrm) {
                        promotionTypeIds.remove("ALL");
                    }
                    promotionTypeIds.add(targetId);
                    break;
                case REDEEM_TARGET_TYPE_DELIVERY_TYPE:
                    allDlv = hasAllset.contains(type);
                    if (!allDlv) {
                        deliveryTypeIds.remove("ALL");
                    }
                    deliveryTypeIds.add(targetId);
                    break;
                case REDEEM_TARGET_TYPE_ACCESSORY:
                    allAcc = hasAllset.contains(type);
                    if (!allAcc) {
                        accessoryTypeIds.remove("ALL");
                    }
                    accessoryTypeIds.add(targetId);
                    break;
            }
        }
        // 不允許設備或配件時, 清除條件(包含ALL)
        if (!cpn.isDeviceAllow())
            deviceTypeIds.clear();
        if (!cpn.isAccessoryAllow())
            accessoryTypeIds.clear();
    }

    // 計算設備/配件總金額, 以及設備/配件條件
    public void startToCheck(List<ShoppingResultProductBO> productBOs, Long prepaidPrice, Long prodVaPrice) {
        boolean hasDevMatch = false;
        boolean hasAccMatch = false;
        for (ShoppingResultProductBO prod : productBOs) {
            String prodId = prod.getProductId();
            Long discPrice = prod.getDiscPrice();
            if (prodId == null || discPrice == null)
                continue;
            boolean isAcc = prod.isAcc();

            if (!isAcc) {
                devTotalPrice += discPrice;
                hasDevMatch = hasDevMatch || orderTypeIds.contains(prodId);
            }
            if (isAcc) {
                accTotalPrice += discPrice;
                hasAccMatch = hasAccMatch || accessoryTypeIds.contains(prodId);
            }
            totalPrice += discPrice;
        }
        totalPrice = totalPrice + prepaidPrice + prodVaPrice;
        nonDev = deviceTypeIds.isEmpty();
        nonAcc = accessoryTypeIds.isEmpty();

        // 判斷設備/配件條件
        boolean ignoreDev = allDev || nonDev;
        boolean ignoreAcc = allAcc || nonAcc;

        if (ignoreDev && !ignoreAcc) {
            passDevCheck = true;
            passAccCheck = hasAccMatch;
        }
        if (!ignoreDev && ignoreAcc) {
            passDevCheck = hasDevMatch;
            passAccCheck = true;
        }
        if (!ignoreDev && !ignoreAcc) {
            passDevCheck = hasDevMatch;
            passAccCheck = hasAccMatch;
        }
        if (ignoreDev && ignoreAcc) {
            passDevCheck = true;
            passAccCheck = true;
        }
    }

    public boolean allChecked() {
        return devChecked && accChecked && deliveryChecked && promotionChecked && orderTypeChecked;
    }

    public void checkWithDiscount(boolean hasDisc) {
        // 無折扣時, 視為設備/配件無法折抵
        if (!hasDisc) {
            passDevCheck = false;
            passAccCheck = false;
        }
        devChecked = true;
        accChecked = true;
    }

    public void checkWithPromotion(boolean isDa, String oplId) {
        passPromotionCheck = allPrm || isDa || promotionTypeIds.contains(oplId);
        promotionChecked = true;
    }

    public void checkWithDelivery(String couponDeliveryType) {
        passDeliveryTypeCheck = allDlv || deliveryTypeIds.contains(couponDeliveryType);
        deliveryChecked = true;
    }

    public void checkWithOrderType(String orderType) {
        passOrderTypeCheck = allOt || orderTypeIds.contains(orderType);
        orderTypeChecked = true;
    }

    /**
     * 判斷是否通過總金額
     * @param cpn
     */
    public void checkPrice(CouponVO cpn){
        // 判斷是否通過總金額
        long minTotalPrice = cpn.getMinTotalPrice() != null ? cpn.getMinTotalPrice() : 0L;
        long minDevTotalPrice = cpn.getMinDevicePrice() != null ? cpn.getMinDevicePrice() : 0L;
        long minAccTotalPrice = cpn.getMinAccessoryPrice() != null ? cpn.getMinAccessoryPrice() : 0L;
        passTotalPriceCheck = totalPrice >= minTotalPrice;
        passDeviceTotalPriceCheck = minDevTotalPrice == 0L || (minDevTotalPrice > 0L && devTotalPrice >= minDevTotalPrice);
        passAccessoryTotalPriceCheck = minAccTotalPrice == 0L || (minAccTotalPrice > 0L && accTotalPrice >= minAccTotalPrice);
    }

    /**
     * 取得錯誤訊息, 有錯誤便跳出 TODO 檢查是否跳出選項
     * 記錄Coupon錯誤, 並回傳是否全數通過
     *
     * @param telcomOnly
     * @return
     */
    public List<String> recordCouponError(boolean telcomOnly) {
        // 取得錯誤訊息
        List<String> couponErrorList = new ArrayList<>();
        if (!passTotalPriceCheck)
            couponErrorList.add("未達結帳總金額");
        if (!passOrderTypeCheck)
            couponErrorList.add("不符合訂單類型");
        if (!isPassCouponDeviceTypeCheck() || telcomOnly)
            couponErrorList.add("不符合Coupon可折抵項目");
        if (!passDevCheck)
            couponErrorList.add("不符合設備條件");
        if (!passDeviceTotalPriceCheck)
            couponErrorList.add("不符合設備金額");
        if (!passAccCheck)
            couponErrorList.add("不符合配件條件");
        if (!passAccessoryTotalPriceCheck)
            couponErrorList.add("不符合配件金額");
        if (!passPromotionCheck)
            couponErrorList.add("不符合促代條件");
        if (!passDeliveryTypeCheck) {
            couponErrorList.add("不符合取貨方式");
        }
        return couponErrorList;
    }

    public Set<String> getDeviceTypeIds() {
        return deviceTypeIds;
    }
    public void setDeviceTypeIds(Set<String> deviceTypeIds) {
        this.deviceTypeIds = deviceTypeIds;
    }
    public Set<String> getAccessoryTypeIds() {
        return accessoryTypeIds;
    }
    public void setAccessoryTypeIds(Set<String> accessoryTypeIds) {
        this.accessoryTypeIds = accessoryTypeIds;
    }
    public boolean isAllDev() {
        return allDev;
    }
    public void setAllDev(boolean allDev) {
        this.allDev = allDev;
    }
    public boolean isAllOt() {
        return allOt;
    }
    public void setAllOt(boolean allOt) {
        this.allOt = allOt;
    }
    public boolean isAllAcc() {
        return allAcc;
    }
    public void setAllAcc(boolean allAcc) {
        this.allAcc = allAcc;
    }
    public boolean isAllPrm() {
        return allPrm;
    }
    public void setAllPrm(boolean allPrm) {
        this.allPrm = allPrm;
    }
    public boolean isAllDlv() {
        return allDlv;
    }
    public void setAllDlv(boolean allDlv) {
        this.allDlv = allDlv;
    }
    public boolean isNonDev() {
        return nonDev;
    }
    public void setNonDev(boolean nonDev) {
        this.nonDev = nonDev;
    }
    public boolean isNonAcc() {
        return nonAcc;
    }
    public void setNonAcc(boolean nonAcc) {
        this.nonAcc = nonAcc;
    }
    public boolean isPassDevCheck() {
        return passDevCheck;
    }
    public boolean isPassAccCheck() {
        return passAccCheck;
    }
    public boolean isPassPromotionCheck() {
        return passPromotionCheck;
    }
    public boolean isPassDeliveryTypeCheck() {
        return passDeliveryTypeCheck;
    }
    public boolean isPassOrderTypeCheck() {
        return passOrderTypeCheck;
    }
    public boolean isPassTotalPriceCheck() {
        return passTotalPriceCheck;
    }
    public boolean isPassDeviceTotalPriceCheck() {
        return passDeviceTotalPriceCheck;
    }
    public boolean isPassAccessoryTotalPriceCheck() {
        return passAccessoryTotalPriceCheck;
    }
    public boolean isPassCouponDeviceTypeCheck() {
        return (allowDev && allowAcc && (passDeviceTotalPriceCheck || passAccessoryTotalPriceCheck)) ||
                (allowDev && !allowAcc && passDeviceTotalPriceCheck) || (!allowDev && allowAcc && passAccessoryTotalPriceCheck);
    }
    public long getTotalPrice() {
        return totalPrice;
    }
    public void setTotalPrice(long totalPrice) {
        this.totalPrice = totalPrice;
    }
    public long getDevTotalPrice() {
        return devTotalPrice;
    }
    public void setDevTotalPrice(long devTotalPrice) {
        this.devTotalPrice = devTotalPrice;
    }
    public long getAccTotalPrice() {
        return accTotalPrice;
    }
    public void setAccTotalPrice(long accTotalPrice) {
        this.accTotalPrice = accTotalPrice;
    }
    public boolean isSuccessToInit() {
        return successToInit;
    }
    public void setSuccessToInit(boolean successToInit) {
        this.successToInit = successToInit;
    }
    public void setHasDisc(boolean hasDisc) {
        this.hasDisc = hasDisc;
    }
    public boolean isHasDisc() {
        return hasDisc;
    }
}