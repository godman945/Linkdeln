package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CouponTicketHistory;

public interface NCouponTicketHistoryDAO extends BaseDAO<CouponTicketHistory, Long>{
	
	/**
	 * 依Coupon Ticket之ID取得Coupon Ticket History之數量
	 * @param couponTicketId
	 * @return
	 */
	public Integer findHistoryCountByCouponTicketId(Long couponTicketId);
}
