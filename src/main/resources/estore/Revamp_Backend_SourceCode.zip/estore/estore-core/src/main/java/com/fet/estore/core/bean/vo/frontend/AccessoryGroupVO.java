package com.fet.estore.core.bean.vo.frontend;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.fet.estore.core.util.LogUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 配件VO
 * 
 * @author Max Chen
 * 
 */
public class AccessoryGroupVO extends HandsetGroupVO{
	
	/** 是否有置頂圖示:'Y',否:'N'。 */
	private String stickFlag;
	/** 置頂圖示位置。 */
	private String stickPicPath;
	/** 置頂圖示名稱。 */
	private String stickPicName;
	/** 配件ID */
	private String productId;
	/** 配件名稱 */
	private String name;
	/** 預設圖檔 */
	private String defaultImage;
	/** 預設第二順位圖檔 */
	private String secondImage;
	/** 圖片路徑 */
	private String imgPath;
	/** 小圖圖檔路徑 */
	private String smallImagePath;
	/** 價格 */
	private Long price;
	/** 優惠價 */
	private Long discPrice;
	/** 遠傳商品代碼(料號)。 */
	private String fetNo;
	/** 商品顏色。 */
	private String color;
	/** 商品原價。 */
	private Long erpPrice;
	/** 可用庫存。 */
	private Long inventory;
	/** 圖檔路徑。 */
	private String imagePath;
	/** 配件料號。 */
	// private String productId;
	/** 規格。 */
	private String spec;
	/** 適用機型。 */
	private String matchHandset;
	/** 說明。 */
	private String brief;
	/** 配件圖檔路徑1。 */
	private String pic1;
	/** 配件圖檔路徑2。 */
	private String pic2;
	/** 配件圖檔路徑3。 */
	private String pic3;
	/** 配件圖檔路徑4。 */
	private String pic4;
	/** 配件圖檔路徑5。 */
	private String pic5;
	/** 配件圖檔路徑6。 */
	private String pic6;
	/** 配件圖檔路徑7。 */
	private String pic7;
	/** 配件圖檔路徑8。 */
	private String pic8;
	/** 上架之員工編號。 */
	private String onsaleEmpNo;
	/** 主管審核。 */
	private String sign4onsale;
	/** 上架日期。 */
	private Date onsaleDate;
	/** 下架日期。 */
	private Date offDate;
	/** 上架狀態。 */
	private Boolean onsale;
	/** 群組名稱。 */
	private String groupName;
	/** 簡要標題。 */
	private String viewTitle;
	/** 簡要描述。 */
	private String viewDesc;
	/** 簡要描述2。 */
	private String viewDesc2;
	/** 簡要描述3。 */
	private String viewDesc3;
	/** 簡要描述4。 */
	private String viewDesc4;
	/** 簡要描述5。 */
	private String viewDesc5;	
	/** 簡要描述。 */
	private String[] viewDescs;	
	/** 修改人員編號。 */
	private String modiId;
	/** 資料異動時間。 */
	private Date modiDate;
	/** 使用說明。 */
	private String instructions;
	/** 使用預設說明單名稱。 */
	private String defaultInstructionsName;
	/** 配件分類。 */
	private String accessoryCategoryId;
	/** 遠傳統計資料用。 */
	private String costCenter;
	/** 遠傳統計資料用。 */
	private String department;
	/** 遠傳統計資料用。 */
	private String pmName;
	/** 遠傳統計資料用。 */
	private String pmEmail;
	/** 配件單買:是否有贈送Coupon。 */
	private Boolean isAwardCouponExist;
	/** 配件單買:是否有贈送贈品 。 */
	private Boolean isAwardGiftExist;
	/** 配件單買:是否有贈送折扣。 */
	private Boolean isAwardDiscountCodeExist;
	/** 配件群組 編號。 */
	private String accessoryGroupId;
	/** 配件促銷圖示 */
	private List<PromoIconVO> promoIconPromotions;
	/** 配件功能圖示 */
	private List<PromoIconVO> promoIconFunctions;
	/** 配件圖片(大) */
	private Set<String> largePicFileNames;
	/** 配件圖片(中) */
	private Set<String> mediumPicFileNames;
	/** 配件圖片(小) */
	private Set<String> smallPicFileNames;
    /** aliasUrl */
    private String aliasUrl;
    
    /** 判斷是否為預購期間 */
    private Boolean isPreSubscribeDate;
    
    /** 畫面顯示brand modelName*/
    private String showProductName;
    /** 畫面顯示brand modelName*/
    private String showViewDesc;
    /** 預設byte length*/
    private static final int SUB_BYTE_LENGTH = 30;
    /** 畫面顯示brand modelName*/
    private String showHomeProductName;   
    /** 預設byte length*/
    private static final int SUB_BYTE_LENGTH_HOME = 35;
    /** 預設超過字符*/
    private static final String OVER_STR = "..";
    /** 預設超過字符*/
    private static final String OVER_STR_W = "...";
    /* 2013/05/22 fred add 缺貨通知 */
    private Long estoreInventory;
    private Long atrInventory;
    private Long unavailableQuantity;
    private Boolean isUnavailableInform;
    private Date unavailableStartTime;
    private Date unavailableEndTime;    
    private Date preSubscribeBeginDate;
    private Date preSubscribeEndDate;
    
    private String atrStatus;
    private Boolean applyUnavailable;
    
    private Boolean isExclusive;
    private Boolean allowPickup;
    private Boolean reservation;
    
    //20140811 RS add 小網五點說明
    private String mobileViewDesc;
    private String mobileViewDesc2;
    private String mobileViewDesc3;
    private String mobileViewDesc4;
    private String mobileViewDesc5;
	/** 簡要說明清單 */
	private String[] mobileViewDescs;
	 //seo
	private String seoTitle;
	private String seoDescription;
	private String seoKeywords;
	/** 商品圖右方重點說明 */
	private String wrighthandDesc;
	/** 推薦文URL*/
	private String recommendUrl;
	
	/** 上蓋銷售量檢查 */
    private Boolean checkAtr;
	/** 是否檢查ESTORE自訂量 */
    private Boolean checkLocalAtr;
    /** ESTORE自訂量狀態 */
    private Boolean localAtrStatus;
    /** ATR檢查狀態 */
    private Boolean newAtrStatus;
  //（檢查ESTORE自訂量起始時間）
  	private Date checkLocalAtrStartTime;
  	//（檢查ESTORE自訂量結束時間）
  	private Date checkLocalAtrEndTime;
  	
  	private Integer extraBuyId;
  	
  	private Integer extraBuyItemId;
  	
  	private Integer categoryExtarBuyLimit;
  	
  	private Integer accExtarBuyLimit;

  	/** 2020-08-20 Ted.Hsieh 新增 配件產品介紹(出國上網卡規格)用欄位 */
  	private String title1;
	private String title2;
	private String title3;
	private String title4;
	private String description1;
	private String description2;
	private String description3;
	private String description4;
	private String subTypeName;
  	
  	private List<AccessoryGroupVO> subAccGroupVOs = new ArrayList<AccessoryGroupVO>();
    
    // 有貨: return true;
    // 缺貨: return false;
    public Boolean getIsOutOfStock() throws Exception {
        
        /*
        if( unavailableQuantity > 0 ) {
            return false;
        } else if ( estoreInventory == 0 && atrInventory == 0 ) {
            return false;
        } else {
            return true;
        }
        */
        
        if ( getIsUnavailableInformDate() && "UNAVAILABLE".equals(atrStatus) ) {
            return false;
        }
        
        if (checkAtr != null && checkAtr) {
            if (checkLocalAtr != null && checkLocalAtr ) {
            	Date date = new Date();
            	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            	Date start = null;
				Date end = null;
				try {
					start = sdf.parse(sdf.format(this.checkLocalAtrStartTime));
					end = sdf.parse(StringUtils.replace(sdf.format(this.checkLocalAtrEndTime), " 00:00:00", " 23:59:59"));
				} catch (Exception e) {
					LogUtil.error(e);
				}
            	if(checkLocalAtrStartTime != null && checkLocalAtrEndTime != null
            			&& start != null && end != null && date.after(start) && date.before(end)){
            		return null != localAtrStatus ? localAtrStatus.booleanValue() : true;
            	}else{
            		return null != newAtrStatus ? newAtrStatus.booleanValue() : true;
            	}                
            } else {
                return null != newAtrStatus ? newAtrStatus.booleanValue() : true;
            }
        }
        
        return true;
    }
    
    // 判斷是否為缺貨通知期間
    // 當該手機有被設定缺貨通知且今天在缺貨通知期間, return true
    // else return false
    public Boolean getIsUnavailableInformDate() throws Exception {
        boolean flag = false;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if(this.unavailableStartTime != null && this.unavailableEndTime !=null){
            Date prb = sdf.parse(sdf.format(this.unavailableStartTime));
            Date pre = sdf.parse(sdf.format(this.unavailableEndTime));
            Date today = sdf.parse(sdf.format(new Date()));
            if(Boolean.TRUE.equals(isUnavailableInform) && pre.after(today) && prb.before(today)){
                flag = true;
            }
        }
        return flag;
    }
    
    /** 判斷是否為預購期間 
     * @throws Exception */
    
    public Boolean getIsPreSubscribeDate() throws Exception {
        boolean flag = false;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if(this.preSubscribeBeginDate != null && this.preSubscribeEndDate !=null){
            Date prb = sdf.parse(sdf.format(this.preSubscribeBeginDate));
            Date pre = sdf.parse(sdf.format(this.preSubscribeEndDate));
            Date today = sdf.parse(sdf.format(new Date()));
            if(Boolean.TRUE.equals(isPreSubscribeDate) && pre.after(today) && prb.before(today)){
                flag = true;
            }
        }
        return flag;
    }
	
	public String getStickFlag() {
		return stickFlag;
	}

	public void setStickFlag(String stickFlag) {
		this.stickFlag = stickFlag;
	}

	public String getStickPicPath() {
		return stickPicPath;
	}

	public void setStickPicPath(String stickPicPath) {
		this.stickPicPath = stickPicPath;
	}

	public String getStickPicName() {
		return stickPicName;
	}

	public void setStickPicName(String stickPicName) {
		this.stickPicName = stickPicName;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public Long getDiscPrice() {
		return discPrice;
	}

	public void setDiscPrice(Long discPrice) {
		this.discPrice = discPrice;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	public String getFetNo() {
		return fetNo;
	}

	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Long getErpPrice() {
		return erpPrice;
	}

	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}

	public Long getInventory() {
		return inventory;
	}

	public void setInventory(Long inventory) {
		this.inventory = inventory;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public String getMatchHandset() {
		return matchHandset;
	}

	public void setMatchHandset(String matchHandset) {
		this.matchHandset = matchHandset;
	}

	public String getBrief() {
		return brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}

	public String getPic1() {
		return pic1;
	}

	public void setPic1(String pic1) {
		this.pic1 = pic1;
	}

	public String getPic2() {
		return pic2;
	}

	public void setPic2(String pic2) {
		this.pic2 = pic2;
	}

	public String getPic3() {
		return pic3;
	}

	public void setPic3(String pic3) {
		this.pic3 = pic3;
	}

	public String getPic4() {
		return pic4;
	}

	public void setPic4(String pic4) {
		this.pic4 = pic4;
	}

	public String getPic5() {
		return pic5;
	}

	public void setPic5(String pic5) {
		this.pic5 = pic5;
	}

	public String getPic6() {
		return pic6;
	}

	public void setPic6(String pic6) {
		this.pic6 = pic6;
	}

	public String getPic7() {
		return pic7;
	}

	public void setPic7(String pic7) {
		this.pic7 = pic7;
	}

	public String getPic8() {
		return pic8;
	}

	public void setPic8(String pic8) {
		this.pic8 = pic8;
	}

	public String getOnsaleEmpNo() {
		return onsaleEmpNo;
	}

	public void setOnsaleEmpNo(String onsaleEmpNo) {
		this.onsaleEmpNo = onsaleEmpNo;
	}

	public String getSign4onsale() {
		return sign4onsale;
	}

	public void setSign4onsale(String sign4onsale) {
		this.sign4onsale = sign4onsale;
	}

	public Date getOnsaleDate() {
		return onsaleDate;
	}

	public void setOnsaleDate(Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}

	public Date getOffDate() {
		return offDate;
	}

	public void setOffDate(Date offDate) {
		this.offDate = offDate;
	}

	public Boolean getOnsale() {
		return onsale;
	}

	public void setOnsale(Boolean onsale) {
		this.onsale = onsale;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getViewTitle() {
		return viewTitle;
	}

	public void setViewTitle(String viewTitle) {
		this.viewTitle = viewTitle;
	}

	public String getViewDesc() {
		return viewDesc;
	}

	public void setViewDesc(String viewDesc) {
		this.viewDesc = viewDesc;
	}

	public String getViewDesc2() {
		return viewDesc2;
	}

	public void setViewDesc2(String viewDesc2) {
		this.viewDesc2 = viewDesc2;
	}

	public String getViewDesc3() {
		return viewDesc3;
	}

	public void setViewDesc3(String viewDesc3) {
		this.viewDesc3 = viewDesc3;
	}

	public String getViewDesc4() {
		return viewDesc4;
	}

	public void setViewDesc4(String viewDesc4) {
		this.viewDesc4 = viewDesc4;
	}

	public String getViewDesc5() {
		return viewDesc5;
	}

	public void setViewDesc5(String viewDesc5) {
		this.viewDesc5 = viewDesc5;
	}

	public String[] getViewDescs() {
		return viewDescs;
	}

	public void setViewDescs(String[] viewDescs) {
		this.viewDescs = viewDescs;
	}

	public String getModiId() {
		return modiId;
	}

	public void setModiId(String modiId) {
		this.modiId = modiId;
	}

	public Date getModiDate() {
		return modiDate;
	}

	public void setModiDate(Date modiDate) {
		this.modiDate = modiDate;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	public String getDefaultInstructionsName() {
		return defaultInstructionsName;
	}

	public void setDefaultInstructionsName(String defaultInstructionsName) {
		this.defaultInstructionsName = defaultInstructionsName;
	}

	public String getAccessoryCategoryId() {
		return accessoryCategoryId;
	}

	public void setAccessoryCategoryId(String accessoryCategoryId) {
		this.accessoryCategoryId = accessoryCategoryId;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPmName() {
		return pmName;
	}

	public void setPmName(String pmName) {
		this.pmName = pmName;
	}

	public String getPmEmail() {
		return pmEmail;
	}

	public void setPmEmail(String pmEmail) {
		this.pmEmail = pmEmail;
	}

	public Boolean getIsAwardCouponExist() {
		return isAwardCouponExist;
	}

	public void setIsAwardCouponExist(Boolean isAwardCouponExist) {
		this.isAwardCouponExist = isAwardCouponExist;
	}

	public Boolean getIsAwardGiftExist() {
		return isAwardGiftExist;
	}

	public void setIsAwardGiftExist(Boolean isAwardGiftExist) {
		this.isAwardGiftExist = isAwardGiftExist;
	}

	public Boolean getIsAwardDiscountCodeExist() {
		return isAwardDiscountCodeExist;
	}

	public void setIsAwardDiscountCodeExist(Boolean isAwardDiscountCodeExist) {
		this.isAwardDiscountCodeExist = isAwardDiscountCodeExist;
	}

	public String getAccessoryGroupId() {
		return accessoryGroupId;
	}

	public void setAccessoryGroupId(String accessoryGroupId) {
		this.accessoryGroupId = accessoryGroupId;
	}

	public List<PromoIconVO> getPromoIconPromotions() {
		return promoIconPromotions;
	}

	public void setPromoIconPromotions(List<PromoIconVO> promoIconPromotions) {
		this.promoIconPromotions = promoIconPromotions;
	}

	public List<PromoIconVO> getPromoIconFunctions() {
		return promoIconFunctions;
	}

	public void setPromoIconFunctions(List<PromoIconVO> promoIconFunctions) {
		this.promoIconFunctions = promoIconFunctions;
	}

	public Set<String> getLargePicFileNames() {
		return largePicFileNames;
	}

	public void setLargePicFileNames(Set<String> largePicFileNames) {
		this.largePicFileNames = largePicFileNames;
	}

	public Set<String> getMediumPicFileNames() {
		return mediumPicFileNames;
	}

	public void setMediumPicFileNames(Set<String> mediumPicFileNames) {
		this.mediumPicFileNames = mediumPicFileNames;
	}

	public Set<String> getSmallPicFileNames() {
		return smallPicFileNames;
	}

	public void setSmallPicFileNames(Set<String> smallPicFileNames) {
		this.smallPicFileNames = smallPicFileNames;
	}

	public String getDefaultImage() {
		return defaultImage;
	}

	public void setDefaultImage(String defaultImage) {
		this.defaultImage = defaultImage;
	}

	public String getSecondImage() {
		return secondImage;
	}

	public void setSecondImage(String secondImage) {
		this.secondImage = secondImage;
	}

	public String getAliasUrl() {
		return aliasUrl;
	}

	public void setAliasUrl(String aliasUrl) {
		this.aliasUrl = aliasUrl;
	}

	public String getSmallImagePath() {
		return smallImagePath;
	}

	public void setSmallImagePath(String smallImagePath) {
		this.smallImagePath = smallImagePath;
	}
	
	public String getShowProductName() {
		String subProductName = null;
		try {
			subProductName = this.name;
			if(subProductName.getBytes().length > this.SUB_BYTE_LENGTH){
				subProductName = subStr(this.name,this.SUB_BYTE_LENGTH);
			}
		} catch (Exception e) {
			LogUtil.error(e);
		}
		
		return subProductName;
	}

	public void setShowProductName(String showProductName) {
		this.showProductName = showProductName;
	}
	
	
	public String getShowViewDesc() {
		String subViewDesc = null;
			try {
				subViewDesc = StringUtils.isNotBlank(this.viewDesc) ? this.viewDesc : "" ;
				if(subViewDesc.getBytes().length > this.SUB_BYTE_LENGTH){
					subViewDesc = subStr(subViewDesc,this.SUB_BYTE_LENGTH);
				}
			} catch (Exception e) {
				LogUtil.error(e);
			}
		return subViewDesc;
	}

	public void setShowViewDesc(String showViewDesc) {
		this.showViewDesc = showViewDesc;
	}

	public String getShowHomeProductName() {
		String subProductName = null;
		try {
			subProductName = this.name;
			if(subProductName.getBytes().length > this.SUB_BYTE_LENGTH_HOME){
				subProductName = subStr_W(this.name,this.SUB_BYTE_LENGTH_HOME);
			}
		} catch (Exception e) {
			LogUtil.error(e);
		}
		
		return subProductName;
	}

	public void setShowHomeProductName(String showHomeProductName) {
		this.showHomeProductName = showHomeProductName;
	}

	/**
	 * 依照byte擷取 字符 (title description)
	 * @param title
	 * @param subSLength
	 * @return 擷取擷取後的字串
	 * @throws UnsupportedEncodingException 
	 */
	private String subStr(String str, int subSLength) throws UnsupportedEncodingException{
		String subStr = null;
			int tempSubLength = subSLength;// 擷取長度
			subStr = str.substring(0, str.length() < subSLength ? str.length() : subSLength);//擷取的字串
			int subStrByetsL;
			subStrByetsL = subStr.getBytes("UTF-8").length;
			// 擷取的字符串中包含有中文
			while (subStrByetsL > tempSubLength) {
				int subSLengthTemp = --subSLength;
				subStr = str.substring(0, subSLengthTemp > str.length() ? str.length() : subSLengthTemp);
				subStrByetsL = subStr.getBytes("UTF-8").length;
				 subStrByetsL = subStr.getBytes().length;
			}
		return subStr.format(subStr+"%s", this.OVER_STR);
	}
	/**
	 * 依照byte擷取 字符 (title description)
	 * @param title
	 * @param subSLength
	 * @return 擷取擷取後的字串
	 * @throws UnsupportedEncodingException 
	 */
	private String subStr_W(String str, int subSLength) throws UnsupportedEncodingException{
		String subStr = null;
			int tempSubLength = subSLength;// 擷取長度
			subStr = str.substring(0, str.length() < subSLength ? str.length() : subSLength);//擷取的字串
			int subStrByetsL;
			subStrByetsL = subStr.getBytes("UTF-8").length;
			// 擷取的字符串中包含有中文
			while (subStrByetsL > tempSubLength) {
				int subSLengthTemp = --subSLength;
				subStr = str.substring(0, subSLengthTemp > str.length() ? str.length() : subSLengthTemp);
				subStrByetsL = subStr.getBytes("UTF-8").length;
				 subStrByetsL = subStr.getBytes().length;
			}
		return subStr.format(subStr+"%s", this.OVER_STR_W);
	}
    public Long getEstoreInventory() {
        return estoreInventory;
    }

    public void setEstoreInventory(Long estoreInventory) {
        this.estoreInventory = estoreInventory;
    }

    public Long getAtrInventory() {
        return atrInventory;
    }

    public void setAtrInventory(Long atrInventory) {
        this.atrInventory = atrInventory;
    }

    public Long getUnavailableQuantity() {
        return unavailableQuantity;
    }

    public void setUnavailableQuantity(Long unavailableQuantity) {
        this.unavailableQuantity = unavailableQuantity;
    }

    public Boolean getIsUnavailableInform() {
        return isUnavailableInform;
    }

    public void setIsUnavailableInform(Boolean isUnavailableInform) {
        this.isUnavailableInform = isUnavailableInform;
    }

    public Date getUnavailableStartTime() {
        return unavailableStartTime;
    }

    public void setUnavailableStartTime(Date unavailableStartTime) {
        this.unavailableStartTime = unavailableStartTime;
    }

    public Date getUnavailableEndTime() {
        return unavailableEndTime;
    }

    public void setUnavailableEndTime(Date unavailableEndTime) {
        this.unavailableEndTime = unavailableEndTime;
    }

    public Date getPreSubscribeBeginDate() {
        return preSubscribeBeginDate;
    }

    public void setPreSubscribeBeginDate(Date preSubscribeBeginDate) {
        this.preSubscribeBeginDate = preSubscribeBeginDate;
    }

    public Date getPreSubscribeEndDate() {
        return preSubscribeEndDate;
    }

    public void setPreSubscribeEndDate(Date preSubscribeEndDate) {
        this.preSubscribeEndDate = preSubscribeEndDate;
    }

    public String getAtrStatus() {
        return atrStatus;
    }

    public void setAtrStatus(String atrStatus) {
        this.atrStatus = atrStatus;
    }

    public void setIsPreSubscribeDate(Boolean isPreSubscribeDate) {
        this.isPreSubscribeDate = isPreSubscribeDate;
    }	
    
    @Override
    public String toString() {
        
        StringBuffer buffer = new StringBuffer();
        buffer.append("\n\tproductId: " + productId + "\n");
        buffer.append("\tname: " + name + "\n");
        buffer.append("\tfetNo: " + fetNo + "\n");
        buffer.append("\tisExclusive: " + isExclusive + "\n");
        buffer.append("\tatrStatus: " + atrStatus + "\n");
        buffer.append("\tinventory: " + inventory + "\n");
        buffer.append("\tisPreSubscribeDate: " + isPreSubscribeDate + "\n");
        buffer.append("\tpreSubscribeBeginDate: " + preSubscribeBeginDate + "\n");
        buffer.append("\tpreSubscribeEndDate: " + preSubscribeEndDate + "\n");
        buffer.append("\tisUnavailableInform: " + isUnavailableInform + "\n");
        buffer.append("\tunavailableStartTime: " + unavailableStartTime + "\n");
        buffer.append("\tunavailableEndTime: " + unavailableEndTime + "\n");
        
        return buffer.toString();
    }

    public Boolean getIsExclusive() {
        return isExclusive;
    }

    public void setIsExclusive(Boolean isExclusive) {
        this.isExclusive = isExclusive;
    }

	public Boolean getApplyUnavailable() {
		return applyUnavailable;
	}

	public void setApplyUnavailable(Boolean applyUnavailable) {
		this.applyUnavailable = applyUnavailable;
	}
	
	public Boolean getAllowPickup() {
		return allowPickup;
	}

	public void setAllowPickup(Boolean allowPickup) {
		this.allowPickup = allowPickup;
	}

	public Boolean getReservation() {
		return reservation;
	}

	public void setReservation(Boolean reservation) {
		this.reservation = reservation;
	}

	public String getMobileViewDesc() {
		return mobileViewDesc;
	}

	public void setMobileViewDesc(String mobileViewDesc) {
		this.mobileViewDesc = mobileViewDesc;
	}

	public String getMobileViewDesc2() {
		return mobileViewDesc2;
	}

	public void setMobileViewDesc2(String mobileViewDesc2) {
		this.mobileViewDesc2 = mobileViewDesc2;
	}

	public String getMobileViewDesc3() {
		return mobileViewDesc3;
	}

	public void setMobileViewDesc3(String mobileViewDesc3) {
		this.mobileViewDesc3 = mobileViewDesc3;
	}

	public String getMobileViewDesc4() {
		return mobileViewDesc4;
	}

	public void setMobileViewDesc4(String mobileViewDesc4) {
		this.mobileViewDesc4 = mobileViewDesc4;
	}

	public String getMobileViewDesc5() {
		return mobileViewDesc5;
	}

	public void setMobileViewDesc5(String mobileViewDesc5) {
		this.mobileViewDesc5 = mobileViewDesc5;
	}

	public String[] getMobileViewDescs() {
		return mobileViewDescs;
	}

	public void setMobileViewDescs(String[] mobileViewDescs) {
		this.mobileViewDescs = mobileViewDescs;
	}

	public String getSeoTitle() {
		return seoTitle;
	}

	public void setSeoTitle(String seoTitle) {
		this.seoTitle = seoTitle;
	}

	public String getSeoDescription() {
		return seoDescription;
	}

	public void setSeoDescription(String seoDescription) {
		this.seoDescription = seoDescription;
	}

	public String getSeoKeywords() {
		return seoKeywords;
	}

	public void setSeoKeywords(String seoKeywords) {
		this.seoKeywords = seoKeywords;
	}

	public String getWrighthandDesc() {
		return wrighthandDesc;
	}

	public void setWrighthandDesc(String wrighthandDesc) {
		this.wrighthandDesc = wrighthandDesc;
	}

	public String getRecommendUrl() {
		return recommendUrl;
	}

	public void setRecommendUrl(String recommendUrl) {
		this.recommendUrl = recommendUrl;
	}
	
	public Boolean getCheckAtr() {
        return checkAtr;
    }

    public void setCheckAtr(Boolean checkAtr) {
        this.checkAtr = checkAtr;
    }

    public Boolean getCheckLocalAtr() {
        return checkLocalAtr;
    }

    public void setCheckLocalAtr(Boolean checkLocalAtr) {
        this.checkLocalAtr = checkLocalAtr;
    }

    public Boolean getLocalAtrStatus() {
        return localAtrStatus;
    }

    public void setLocalAtrStatus(Boolean localAtrStatus) {
        this.localAtrStatus = localAtrStatus;
    }

    public Boolean getNewAtrStatus() {
        return newAtrStatus;
    }

    public void setNewAtrStatus(Boolean newAtrStatus) {
        this.newAtrStatus = newAtrStatus;
    }

	public Date getCheckLocalAtrStartTime() {
		return checkLocalAtrStartTime;
	}

	public void setCheckLocalAtrStartTime(Date checkLocalAtrStartTime) {
		this.checkLocalAtrStartTime = checkLocalAtrStartTime;
	}

	public Date getCheckLocalAtrEndTime() {
		return checkLocalAtrEndTime;
	}

	public void setCheckLocalAtrEndTime(Date checkLocalAtrEndTime) {
		this.checkLocalAtrEndTime = checkLocalAtrEndTime;
	}

	public List<AccessoryGroupVO> getSubAccGroupVOs() {
		return subAccGroupVOs;
	}

	public void setSubAccGroupVOs(List<AccessoryGroupVO> subAccGroupVOs) {
		this.subAccGroupVOs = subAccGroupVOs;
	}

	public Integer getExtraBuyId() {
		return extraBuyId;
	}

	public Integer getExtraBuyItemId() {
		return extraBuyItemId;
	}

	public void setExtraBuyId(Integer extraBuyId) {
		this.extraBuyId = extraBuyId;
	}

	public void setExtraBuyItemId(Integer extraBuyItemId) {
		this.extraBuyItemId = extraBuyItemId;
	}

	public Integer getCategoryExtarBuyLimit() {
		return categoryExtarBuyLimit;
	}

	public Integer getAccExtarBuyLimit() {
		return accExtarBuyLimit;
	}

	public void setCategoryExtarBuyLimit(Integer categoryExtarBuyLimit) {
		this.categoryExtarBuyLimit = categoryExtarBuyLimit;
	}

	public void setAccExtarBuyLimit(Integer accExtarBuyLimit) {
		this.accExtarBuyLimit = accExtarBuyLimit;
	}

	public String getTitle1() {
		return title1;
	}

	public void setTitle1(String title1) {
		this.title1 = title1;
	}

	public String getTitle2() {
		return title2;
	}

	public void setTitle2(String title2) {
		this.title2 = title2;
	}

	public String getTitle3() {
		return title3;
	}

	public void setTitle3(String title3) {
		this.title3 = title3;
	}

	public String getTitle4() {
		return title4;
	}

	public void setTitle4(String title4) {
		this.title4 = title4;
	}

	public String getDescription1() {
		return description1;
	}

	public void setDescription1(String description1) {
		this.description1 = description1;
	}

	public String getDescription2() {
		return description2;
	}

	public void setDescription2(String description2) {
		this.description2 = description2;
	}

	public String getDescription3() {
		return description3;
	}

	public void setDescription3(String description3) {
		this.description3 = description3;
	}

	public String getDescription4() {
		return description4;
	}

	public void setDescription4(String description4) {
		this.description4 = description4;
	}

	public String getSubTypeName() {
		return subTypeName;
	}

	public void setSubTypeName(String subTypeName) {
		this.subTypeName = subTypeName;
	}
}
