package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.Coupon;
import com.fet.estore.core.model.CouponTicket;

public interface NCouponTicketDAO extends BaseDAO<CouponTicket, Long> {

	public List<CouponTicket> findTopNValidCouponTicket(Coupon coupon, int n);
	
	public CouponTicket findBySerial(String SerialNumber);
	
	public CouponTicket findBySerialPassword(String serialNumber, String password);
	
	/**
	 * 取得目前coupon已使用張數
	 * @param cpnId
	 * @return
	 */
	public int findTicketCountByCouponId(Long cpnId);

	/**
	 * 依據 COUPON 序號取得 COUPON ID
	 * @param cpnId
	 * @return
	 */
	public String findCouponIdtBySerialNo(String serialNumber);
}
