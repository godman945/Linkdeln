package com.fet.estore.core.dao.base.impl;

import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.InstallmentPlanDAO;
import com.fet.estore.core.model.InstallmentPlan;
@Repository
public class InstallmentPlanDAOImpl extends AbstractBaseDAO<InstallmentPlan, Long> implements InstallmentPlanDAO {
}
