package com.fet.estore.core.bean;

import java.io.Serializable;

public class MsisdnVO implements Serializable {

	private static final long serialVersionUID = 3583515376516808606L;
	private String label;
	private String value;
	private String tag;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}

}
