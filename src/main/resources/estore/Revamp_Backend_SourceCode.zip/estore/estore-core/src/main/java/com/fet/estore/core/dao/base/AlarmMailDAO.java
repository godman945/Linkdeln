package com.fet.estore.core.dao.base;

import com.fet.estore.core.model.AlarmMail;

public interface AlarmMailDAO extends BaseDAO<AlarmMail, Long> {
	AlarmMail findAlarmMailByName(String name);
}
