package com.fet.estore.core.bean.vo;

import java.io.Serializable;

/**
 * 好禮多選一
 * @author guoalex
 *
 */
public class GiftRedeemItemVO implements Serializable {

	private static final long serialVersionUID = 6257194891763086070L;
	private Long id;
	private String eventId;
	private String fetNo;
	private String giftName;
	private Long maxQuantity;
	
	/** 已使用數量 */
	private Long usedQuantity;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getGiftName() {
		return giftName;
	}
	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}
	public Long getMaxQuantity() {
		return maxQuantity;
	}
	public void setMaxQuantity(Long maxQuantity) {
		this.maxQuantity = maxQuantity;
	}
	public Long getUsedQuantity() {
		return usedQuantity;
	}
	public void setUsedQuantity(Long usedQuantity) {
		this.usedQuantity = usedQuantity;
	}
	
}
