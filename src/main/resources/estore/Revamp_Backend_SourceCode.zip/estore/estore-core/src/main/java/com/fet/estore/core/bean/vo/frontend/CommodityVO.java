package com.fet.estore.core.bean.vo.frontend;

public class CommodityVO {
	
	/** 是否為獨賣件*/
	private boolean isExclusive;
	/** 總數量*/
	private Integer amount;
	
	/**erp價格*/
	private Long erpPrice;
	
	
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	public boolean isExclusive() {
		return isExclusive;
	}
	public void setExclusive(boolean isExclusive) {
		this.isExclusive = isExclusive;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	
}
