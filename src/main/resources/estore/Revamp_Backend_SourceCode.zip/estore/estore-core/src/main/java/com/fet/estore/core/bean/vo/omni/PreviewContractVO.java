package com.fet.estore.core.bean.vo.omni;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class PreviewContractVO {

	private String voicePenalty;
	private String voicePenaltyType;
	private String voicePenaltyAmount;
	private String dataPenalty;
	private String dataPenaltyType;
	private String dataPenaltyAmount;
	private String cPenalty;
	private String cPenaltyType;
	private String cPenaltyAmount;
	private String voiceStartDate;
	private String dataStartDate;
	private String voiceEndDate;
	private String cStartDate;
	private String dataEndDate;
	private String cEndDate;
	private List<String> penaltyTypes = new ArrayList<String>();
	private List<String> penaltyAmounts = new ArrayList<String>();
	
	public String getVoicePenalty() {
		return voicePenalty;
	}
	public void setVoicePenalty(String voicePenalty) {
		this.voicePenalty = voicePenalty;
	}
	public String getDataPenalty() {
		return dataPenalty;
	}
	public void setDataPenalty(String dataPenalty) {
		this.dataPenalty = dataPenalty;
	}
	public String getVoiceStartDate() {
		return voiceStartDate;
	}
	public void setVoiceStartDate(String voiceStartDate) {
		this.voiceStartDate = voiceStartDate;
	}
	public String getDataStartDate() {
		return dataStartDate;
	}
	public void setDataStartDate(String dataStartDate) {
		this.dataStartDate = dataStartDate;
	}
	public String getVoiceEndDate() {
		return voiceEndDate;
	}
	public void setVoiceEndDate(String voiceEndDate) {
		this.voiceEndDate = voiceEndDate;
	}
	public String getDataEndDate() {
		return dataEndDate;
	}
	public void setDataEndDate(String dataEndDate) {
		this.dataEndDate = dataEndDate;
	}
	public String getcPenalty() {
		return cPenalty;
	}
	public void setcPenalty(String cPenalty) {
		this.cPenalty = cPenalty;
	}
	public String getcStartDate() {
		return cStartDate;
	}
	public void setcStartDate(String cStartDate) {
		this.cStartDate = cStartDate;
	}
	public String getcEndDate() {
		return cEndDate;
	}
	public void setcEndDate(String cEndDate) {
		this.cEndDate = cEndDate;
	}
	public String getVoicePenaltyType() {
		return voicePenaltyType;
	}
	public void setVoicePenaltyType(String voicePenaltyType) {
		this.voicePenaltyType = voicePenaltyType;
	}
	public String getVoicePenaltyAmount() {
		return voicePenaltyAmount;
	}
	public void setVoicePenaltyAmount(String voicePenaltyAmount) {
		this.voicePenaltyAmount = voicePenaltyAmount;
	}
	public String getDataPenaltyType() {
		return dataPenaltyType;
	}
	public void setDataPenaltyType(String dataPenaltyType) {
		this.dataPenaltyType = dataPenaltyType;
	}
	public String getDataPenaltyAmount() {
		return dataPenaltyAmount;
	}
	public void setDataPenaltyAmount(String dataPenaltyAmount) {
		this.dataPenaltyAmount = dataPenaltyAmount;
	}
	public String getcPenaltyType() {
		return cPenaltyType;
	}
	public void setcPenaltyType(String cPenaltyType) {
		this.cPenaltyType = cPenaltyType;
	}
	public String getcPenaltyAmount() {
		return cPenaltyAmount;
	}
	public void setcPenaltyAmount(String cPenaltyAmount) {
		this.cPenaltyAmount = cPenaltyAmount;
	}	
	public List<String> getPenaltyTypes() {
		return penaltyTypes;
	}
	public void setPenaltyTypes(List<String> penaltyTypes) {
		this.penaltyTypes = penaltyTypes;
	}
	public List<String> getPenaltyAmounts() {
		return penaltyAmounts;
	}
	public void setPenaltyAmounts(List<String> penaltyAmounts) {
		this.penaltyAmounts = penaltyAmounts;
	}
	public String toString(){
		return ReflectionToStringBuilder.toString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
	
	
	
}
