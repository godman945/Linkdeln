package com.fet.estore.core.bean.vo.frontend;

public class ChubbVO {
	private String chubbUrl;
	private String subscriptionId;
	private String token;
	private String postJson;
	private String errorMessage;
	private String premium;
	
	public String getChubbUrl() {
		return chubbUrl;
	}
	public void setChubbUrl(String chubbUrl) {
		this.chubbUrl = chubbUrl;
	}
	public String getSubscriptionId() {
		return subscriptionId;
	}
	public void setSubscriptionId(String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getPostJson() {
		return postJson;
	}
	public void setPostJson(String postJson) {
		this.postJson = postJson;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}
	
	
}
