package com.fet.estore.core.bean;

public class SubscriberInitRes {

	private boolean result;
	private String errMsg;
	private String errCode;
	private String msisdn;
	private boolean isEbu;
	private String orderType;
	private String subName;
	private String subRocId;
	private String subBirthYear;
	private String subBirthMonth;
	private String subBirthDate;
	private String subRegAddrCity;
	private String subRegAddrTown;
	private String subAddress;
	private String subSecTp;
	private String subSecId;
	private boolean hasOcrData;
	private String ebuSubscriberType;
	private boolean uploadLater;
	private String subEmail;
	private String subCellphone;
	private boolean isStudentPromotion;
	
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public boolean getIsEbu() {
		return isEbu;
	}
	public void setIsEbu(boolean isEbu) {
		this.isEbu = isEbu;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}
	public String getSubRocId() {
		return subRocId;
	}
	public void setSubRocId(String subRocId) {
		this.subRocId = subRocId;
	}
	public String getSubBirthYear() {
		return subBirthYear;
	}
	public void setSubBirthYear(String subBirthYear) {
		this.subBirthYear = subBirthYear;
	}
	public String getSubBirthMonth() {
		return subBirthMonth;
	}
	public void setSubBirthMonth(String subBirthMonth) {
		this.subBirthMonth = subBirthMonth;
	}
	public String getSubBirthDate() {
		return subBirthDate;
	}
	public void setSubBirthDate(String subBirthDate) {
		this.subBirthDate = subBirthDate;
	}
	public String getSubRegAddrCity() {
		return subRegAddrCity;
	}
	public void setSubRegAddrCity(String subRegAddrCity) {
		this.subRegAddrCity = subRegAddrCity;
	}
	public String getSubRegAddrTown() {
		return subRegAddrTown;
	}
	public void setSubRegAddrTown(String subRegAddrTown) {
		this.subRegAddrTown = subRegAddrTown;
	}
	public String getSubAddress() {
		return subAddress;
	}
	public void setSubAddress(String subAddress) {
		this.subAddress = subAddress;
	}
	public String getSubSecTp() {
		return subSecTp;
	}
	public void setSubSecTp(String subSecTp) {
		this.subSecTp = subSecTp;
	}
	public String getSubSecId() {
		return subSecId;
	}
	public void setSubSecId(String subSecId) {
		this.subSecId = subSecId;
	}
	public boolean getHasOcrData() {
		return hasOcrData;
	}
	public void setHasOcrData(boolean hasOcrData) {
		this.hasOcrData = hasOcrData;
	}
	public String getEbuSubscriberType() {
		return ebuSubscriberType;
	}
	public void setEbuSubscriberType(String ebuSubscriberType) {
		this.ebuSubscriberType = ebuSubscriberType;
	}
	public boolean getUploadLater() {
		return uploadLater;
	}
	public void setUploadLater(boolean uploadLater) {
		this.uploadLater = uploadLater;
	}
	public String getSubEmail() {
		return subEmail;
	}
	public void setSubEmail(String subEmail) {
		this.subEmail = subEmail;
	}
	public String getSubCellphone() {
		return subCellphone;
	}
	public void setSubCellphone(String subCellphone) {
		this.subCellphone = subCellphone;
	}
	public boolean getIsStudentPromotion() {
		return isStudentPromotion;
	}
	public void setIsStudentPromotion(boolean isStudentPromotion) {
		this.isStudentPromotion = isStudentPromotion;
	}
	
}
