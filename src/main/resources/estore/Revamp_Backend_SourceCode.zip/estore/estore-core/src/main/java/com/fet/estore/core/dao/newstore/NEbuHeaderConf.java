package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.EbuHeaderConf;

public interface NEbuHeaderConf extends BaseDAO<EbuHeaderConf, Long>{

}
