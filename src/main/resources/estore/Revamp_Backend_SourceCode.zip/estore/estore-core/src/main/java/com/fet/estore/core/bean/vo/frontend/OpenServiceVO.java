package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

/**
 * 申請開通服務顯示畫面資料的物件紀錄。
 * 
 * @version $Id: OpenServiceVO.java,v 1.0, 2017-05-16 11:05:29Z, Evan Tung$
 */
@SuppressWarnings("serial")
public class OpenServiceVO implements Serializable {

	/** 服務名稱 */
	private String name;
	/** 計費說明 */
	private String chargeDescription;
	/** 收費方式 */
	private String collectionMethod;


	private String vasCode;

	

	
	/**
	 * @see #name
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @see #chargeDescription
	 */
	public String getChargeDescription() {
		return chargeDescription;
	}

	public void setChargeDescription(String chargeDescription) {
		this.chargeDescription = chargeDescription;
	}

	/**
	 * @see #collectionMethod
	 */
	public String getCollectionMethod() {
		return collectionMethod;
	}

	public void setCollectionMethod(String collectionMethod) {
		this.collectionMethod = collectionMethod;
	}

	public String getVasCode() {
		return vasCode;
	}

	public void setVasCode(String vasCode) {
		this.vasCode = vasCode;
	}

}
