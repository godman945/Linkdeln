package com.fet.estore.core.bean.vo.frontend;

public class PaymentPremiumVO {
	private Long id;
	private String  name;
	private Integer amount;
	private Long    totalPrice;
	private String productId;
	private Long    erpPrice;
	private boolean canDelete;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public Long getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	public boolean isCanDelete() {
		return canDelete;
	}
	public void setCanDelete(boolean canDelete) {
		this.canDelete = canDelete;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
}
