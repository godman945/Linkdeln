package com.fet.estore.core.dao.base;

import java.util.List;

import com.fet.estore.core.model.OrderBatch;

public interface OrderBatchDAO extends BaseDAO<OrderBatch, Long> {
	/**
	 * 依重送型態取回未完成之批次重送作業
	 * @param batchType 重送型態
	 * @return
	 */
	public List<OrderBatch> findIncompleteJobs(List<String> batchTypes);
}
