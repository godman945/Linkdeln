package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.List;

public class MobileActivityCategoryVO {
	
	private String coType;
	private String coTitle;
	private List<MobileActivityVO> activities = new ArrayList<MobileActivityVO>();
	
	public String getCoType() {
		return coType;
	}
	
	public void setCoType(String coType) {
		this.coType = coType;
	}
	
	public String getCoTitle() {
		return coTitle;
	}
	
	public void setCoTitle(String coTitle) {
		this.coTitle = coTitle;
	}
	
	public List<MobileActivityVO> getActivities() {
		return activities;
	}
	
	public void setActivities(List<MobileActivityVO> activities) {
		this.activities = activities;
	}
}
