package com.fet.estore.core.dao.base.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.CoMasterDAO;
import com.fet.estore.core.model.CoMaster;
import com.fet.estore.core.bean.vo.MayannVO;

@Repository
public class CoMasterDAOImpl extends AbstractBaseDAO<CoMaster, String> implements CoMasterDAO {

	@Override
	public List<MayannVO> findByMayann() {
		StringBuilder hql = new StringBuilder();
		hql.append("select a.cono as cono, ");
		hql.append(" a.CO_TYPE as coType, ");
		hql.append(" a.rid as rId, ");
		hql.append(" a.click_Id as clickId, ");
		hql.append(" a.ACTIVITY_ID as activityId, ");
		hql.append(" to_char(a.CO_DATE,'yyyy-MM-dd HH24:mm:dd') as coDate, ");
		hql.append(" to_char(a.ACTIVATION_DATE,'yyyy-MM-dd HH24:mm:dd') as activationDate, ");
		hql.append(" to_char(a.MVPN_DATE,'yyyy-MM-dd HH24:mm:dd') as mvpnServiceDate, ");
		hql.append(" b.month_price as monthPrice, ");
		hql.append(" c.limit as limit, ");
		hql.append(" c.data_limit as dataLimit "); 
		hql.append(" from co_master a  ");
		hql.append(" left join ONSALE_PROMO_LIST b on a.ONSALE_PROMO_LIST_ID = b.seq  ");
		hql.append(" left join PROMOTION_LIST c on b.PROMOTION_LIST_ID = c.ID  ");
		hql.append(" where  ");
		hql.append(" a.RID is not null ");
		hql.append(" and a.MVPN_CID = '202315' ");
		hql.append(" and a.MVPN_DATE is not null ");
		hql.append(" and a.CLICK_ID is not null ");
		hql.append(" and a.ACTIVITY_ID is not null ");
		hql.append(" and (a.IS_MAYANN_SEND is null or a.IS_MAYANN_SEND='N') ");
		//hql.append(" and to_char(a.ACTIVATION_DATE,'yyyy-MM-dd') <= to_char(sysdate-10,'yyyy-MM-dd')");
		hql.append(" and to_char(a.CO_DATE,'yyyy-MM-dd') > to_char(sysdate-30,'yyyy-MM-dd')");
		
		
		Query query = this.getSessionFactory().getCurrentSession().createSQLQuery(hql.toString())
		.addScalar("cono", StringType.INSTANCE)
		.addScalar("coType", StringType.INSTANCE)
		.addScalar("rId", 		StringType.INSTANCE)
		.addScalar("clickId", StringType.INSTANCE)
		.addScalar("activityId", LongType.INSTANCE)
		.addScalar("coDate", StringType.INSTANCE)
		.addScalar("activationDate", StringType.INSTANCE)
		.addScalar("mvpnServiceDate", StringType.INSTANCE)
		.addScalar("monthPrice", LongType.INSTANCE)
		.addScalar("limit", LongType.INSTANCE)
		.addScalar("dataLimit", LongType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(MayannVO.class));
		
        List<MayannVO> result = (List<MayannVO>)query.list();
        
		return result;
	}

	@Override
	public void updateMayannSend(List<String> conos) {
		for(String cono : conos) {
			CoMaster coMaster = this.findByCono(cono);
			coMaster.setIsMayannSend(true);
			this.update(coMaster);
		}
	}
	
	private CoMaster findByCono(String cono){
		if(cono == null){
			throw new RuntimeException("Cono cannot be null at the same time!");
		}
		StringBuilder hql = new StringBuilder("from CoMaster c where 1=1");
		if(cono != null){
			hql.append(" and c.cono = :cono");
		}
		
		Query query = this.getSessionFactory().getCurrentSession().createQuery(hql.toString());
		if(cono != null){
			query.setParameter("cono", cono);
		}
		
		
		List<CoMaster> coMasters = query.list();
		if(coMasters.size() > 0){
			return coMasters.get(0);
		}else{
			return null;
		}
	}

}
