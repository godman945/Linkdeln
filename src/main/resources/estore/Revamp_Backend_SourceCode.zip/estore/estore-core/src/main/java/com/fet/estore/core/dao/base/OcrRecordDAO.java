package com.fet.estore.core.dao.base;

import java.util.List;

import com.fet.estore.core.model.OcrRecord;

public interface OcrRecordDAO extends BaseDAO<OcrRecord, Long> {

	public List<OcrRecord> findByOcrSn(String ocrSn);
}
