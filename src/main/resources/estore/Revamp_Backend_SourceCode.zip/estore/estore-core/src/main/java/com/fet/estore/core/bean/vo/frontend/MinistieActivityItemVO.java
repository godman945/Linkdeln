package com.fet.estore.core.bean.vo.frontend;

import java.util.Date;
/**
 * 
 * @author antonis Chen
 *
 */
public class MinistieActivityItemVO {
	private Long id;
	private long minisiteActivityId;
	private String content;
	private String contentLinkMethod;
	private String contentType;
	/** 當類型為影片時此欄位為說明文字其餘存放文字連結URL  */
	private String contentUrl;
	private String imageLinkMethod;
	private String imagePath;
	private String imageUrl;
	private String moreTitle;
	private String moreUrl;
	private String title;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getContentLinkMethod() {
		return contentLinkMethod;
	}
	public void setContentLinkMethod(String contentLinkMethod) {
		this.contentLinkMethod = contentLinkMethod;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getContentUrl() {
		return contentUrl;
	}
	public void setContentUrl(String contentUrl) {
		this.contentUrl = contentUrl;
	}
	public String getImageLinkMethod() {
		return imageLinkMethod;
	}
	public void setImageLinkMethod(String imageLinkMethod) {
		this.imageLinkMethod = imageLinkMethod;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public long getMinisiteActivityId() {
		return minisiteActivityId;
	}
	public void setMinisiteActivityId(long minisiteActivityId) {
		this.minisiteActivityId = minisiteActivityId;
	}
	public String getMoreTitle() {
		return moreTitle;
	}
	public void setMoreTitle(String moreTitle) {
		this.moreTitle = moreTitle;
	}
	public String getMoreUrl() {
		return moreUrl;
	}
	public void setMoreUrl(String moreUrl) {
		this.moreUrl = moreUrl;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}
