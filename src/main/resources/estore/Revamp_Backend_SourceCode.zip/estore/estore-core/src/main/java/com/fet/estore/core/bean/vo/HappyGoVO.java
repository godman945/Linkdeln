package com.fet.estore.core.bean.vo;

public class HappyGoVO {

    private boolean isPass; // 是否登入成功
    private String errorMsg; // 錯誤訊息

    public boolean isPass() {
        return isPass;
    }

    public void setPass(boolean pass) {
        isPass = pass;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
}
