package com.fet.estore.core.bean.bo;

public class GetProductInfoInputBO {

    /** 商品連結用別名 */
    private String aliasUrl;
    /** 商品料號 */
    private String fetNo;
    /** 是否來自續約館 */
    private Boolean fromRenewal;
    /** 活動賣場代號 */
    private Long actId;
    /** 活動賣場的訂單類型 */
    private String activityOrderType;

    public String getAliasUrl() {
        return aliasUrl;
    }

    public void setAliasUrl(String aliasUrl) {
        this.aliasUrl = aliasUrl;
    }

    public String getFetNo() {
        return fetNo;
    }

    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }

    public Boolean getFromRenewal() {
        return fromRenewal;
    }

    public void setFromRenewal(Boolean fromRenewal) {
        this.fromRenewal = fromRenewal;
    }

    public Long getActId() {
        return actId;
    }

    public void setActId(Long actId) {
        this.actId = actId;
    }

    public String getActivityOrderType() {
        return activityOrderType;
    }

    public void setActivityOrderType(String activityOrderType) {
        this.activityOrderType = activityOrderType;
    }
}
