package com.fet.estore.core.bean;

import com.fet.estore.core.enums.ValidationResultEnum;
import com.fet.estore.core.bean.vo.crm.CrmVO;

public class ValidateResult {
	
	/** CRM VO  */
	private CrmData crmData;
	/** 驗證結果 */
	private ValidationResultEnum validationResult;
	/** HL  擋件 */
	private boolean isErrorCodeHL;
	/** 是否顯示前往繳款按鈕 */
	private boolean showToPay;
	/** 錯誤訊息 */
	private String errMsg;
	
	public ValidateResult() {
		
	}
	
	public ValidateResult(ValidationResultEnum validationResult) {
		super();
		this.validationResult = validationResult;
	}
	
	public CrmData getCrmData() {
		return crmData;
	}
	public void setCrmData(CrmData crmData) {
		this.crmData = crmData;
	}
	public ValidationResultEnum getValidationResult() {
		return validationResult;
	}
	public ValidateResult setValidationResult(ValidationResultEnum validationResult) {
		this.validationResult = validationResult;
		return this;
	}

	public boolean isErrorCodeHL() {
		return isErrorCodeHL;
	}

	public void setErrorCodeHL(boolean isErrorCodeHL) {
		this.isErrorCodeHL = isErrorCodeHL;
	}

	public boolean isShowToPay() {
		return showToPay;
	}

	public void setShowToPay(boolean showToPay) {
		this.showToPay = showToPay;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	

	
}
