package com.fet.estore.core.bean.vo.frontend;

/**
 * 小網社群分享設備資料VO
 * @author Max Chen
 *
 */
public class SocialHandsetVO {
	private String name;
	private String category;
	private String fetNo;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCategory() {
		return category;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getFetNo() {
		return fetNo;
	}
	
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
}
