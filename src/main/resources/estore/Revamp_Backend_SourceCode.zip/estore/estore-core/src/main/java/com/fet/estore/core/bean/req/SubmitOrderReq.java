package com.fet.estore.core.bean.req;

import java.io.Serializable;
import java.util.List;

import com.fet.estore.core.bean.PremiumDiscountProd;
import com.fet.estore.core.bean.OrderProduct;

public class SubmitOrderReq implements Serializable {

	private static final long serialVersionUID = 9036395791919866816L;

	/** 活動 Id */
	private String activityId;
	/** 商品資訊 productId */
	private String productId;
	/** 商品資訊 fetNo */
	private String fetNo;
	/** 選取商品數量 */
	private String productNumber;
	/** 申辦類型 */
	private String orderType;
	/** 門號 */
	private String msisdn;
	/** 門號商品ID、對應後端 MSISDN Table 的 Product Id */
	private String msisdnId;
	/** 資費方案 - 對應 onsalePromoList.seq*/
	private String onsalePromoListId;
	/** 資費方案 - 對應 onsalePromoList.promotionListId*/
	private String promotionListId;
	/** 20200916 Dennis.Chen - 加購商品調整為Mapping到物件*/
	private List<PremiumDiscountProd> extraBuyList;
	/** 20200916 Dennis.Chen - 好禮調整為Mapping到物件*/
	private List<PremiumDiscountProd> giftList;
	/** 加值服務 */
	private List<String> extraPlan;
	/** C約 */
	private String contentOffersId;
	/** Promotion Code */
	private String pcode;
	/** 購物車商品 */
	private List<OrderProduct> products;
	/** 結帳總金額 */
	private String total;
	/**電話費用及小額付費帳單合併*/
	private String paymentConsolidation;
	/**同意收到寄來遠傳的各種優惠不漏接*/
	private String extraVaService;
	/** 預約單號 */
	private String preorderNo;
	/** 競標門號參數 */
	private String biddingQry;
	/*
	fourVOfferId: 3000164054
	fourDOfferId: 3000164088
	fourVaServIds: 
	fourVaServCodes: 
	fourProdVaServIds: 
	fourAccIds: 
	fourUpgradeType:
*/

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getFetNo() {
		return fetNo;
	}

	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

	public String getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getMsisdnId() {
		return msisdnId;
	}

	public void setMsisdnId(String msisdnId) {
		this.msisdnId = msisdnId;
	}

	public String getOnsalePromoListId() {
		return onsalePromoListId;
	}

	public void setOnsalePromoListId(String onsalePromoListId) {
		this.onsalePromoListId = onsalePromoListId;
	}

	public String getPromotionListId() {
		return promotionListId;
	}

	public void setPromotionListId(String promotionListId) {
		this.promotionListId = promotionListId;
	}

	public List<PremiumDiscountProd> getExtraBuyList() {
		return extraBuyList;
	}

	public void setExtraBuyList(List<PremiumDiscountProd> extraBuyList) {
		this.extraBuyList = extraBuyList;
	}

	public List<PremiumDiscountProd> getGiftList() {
		return giftList;
	}

	public void setGiftList(List<PremiumDiscountProd> giftList) {
		this.giftList = giftList;
	}

	public List<String> getExtraPlan() {
		return extraPlan;
	}

	public void setExtraPlan(List<String> extraPlan) {
		this.extraPlan = extraPlan;
	}

	public String getContentOffersId() {
		return contentOffersId;
	}

	public void setContentOffersId(String contentOffersId) {
		this.contentOffersId = contentOffersId;
	}

	public String getPcode() {
		return pcode;
	}

	public void setPcode(String pcode) {
		this.pcode = pcode;
	}

	public List<OrderProduct> getProducts() {
		return products;
	}

	public void setProducts(List<OrderProduct> products) {
		this.products = products;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getPaymentConsolidation() {
		return paymentConsolidation;
	}

	public void setPaymentConsolidation(String paymentConsolidation) {
		this.paymentConsolidation = paymentConsolidation;
	}

	public String getExtraVaService() {
		return extraVaService;
	}

	public void setExtraVaService(String extraVaService) {
		this.extraVaService = extraVaService;
	}

	public String getPreorderNo() {
		return preorderNo;
	}

	public void setPreorderNo(String preorderNo) {
		this.preorderNo = preorderNo;
	}

	public String getBiddingQry() {
		return biddingQry;
	}

	public void setBiddingQry(String biddingQry) {
		this.biddingQry = biddingQry;
	}
	
}
