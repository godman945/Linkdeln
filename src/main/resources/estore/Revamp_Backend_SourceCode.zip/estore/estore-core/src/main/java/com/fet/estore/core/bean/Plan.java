package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * 商品明細頁 - 銷售類型
 *
 * @description
 * @author Ted.Hsieh
 * @date 2020-08-11
 */

public class Plan implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 銷售類型名稱 */
    private String label;
    /** 銷售類型代號 */
    private String value;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
