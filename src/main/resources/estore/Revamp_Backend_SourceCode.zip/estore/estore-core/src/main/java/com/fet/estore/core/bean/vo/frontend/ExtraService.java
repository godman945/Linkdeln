package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

public class ExtraService implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2825507691596459719L;
	String type;
	String code;
	private String addinfoValue;
	private String addinfoPromotionCode;
	private String addinfoPromotionName;
	private String addinfoName;
	private String addinfoValueset;
	private String offerType;
	private String sourceName;
	private String targetName;
	private String expirationDate;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getAddinfoValue() {
		return addinfoValue;
	}
	public void setAddinfoValue(String addinfoValue) {
		this.addinfoValue = addinfoValue;
	}
	public String getAddinfoPromotionCode() {
		return addinfoPromotionCode;
	}
	public void setAddinfoPromotionCode(String addinfoPromotionCode) {
		this.addinfoPromotionCode = addinfoPromotionCode;
	}
	public String getAddinfoPromotionName() {
		return addinfoPromotionName;
	}
	public void setAddinfoPromotionName(String addinfoPromotionName) {
		this.addinfoPromotionName = addinfoPromotionName;
	}
	public String getAddinfoName() {
		return addinfoName;
	}
	public void setAddinfoName(String addinfoName) {
		this.addinfoName = addinfoName;
	}
	public String getAddinfoValueset() {
		return addinfoValueset;
	}
	public void setAddinfoValueset(String addinfoValueset) {
		this.addinfoValueset = addinfoValueset;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public String getTargetName() {
		return targetName;
	}
	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	
}
