package com.fet.estore.core.bean.bo;

/**
 * 折扣計算 - 商品VO
 * @author Max Chen
 *
 */
public class ShoppingProductBO {

	/** 非組合活動之群組序號 */
	private static final int NON_MP_GROUP_NUM = 1;

	/** 料號 */
	private String fetNo;
	/** 數量 */
	private int qty;
	/** 是否為配件 */
	private boolean isAcc;
	/** 加價購折扣ID */
	private Long mpDiscId;
	/** 組合活動群組序號 */
	private int mpGroupNum;

	/** 是否NDS加價購 */
	private boolean isExtraBuy;
	/** NDS加價購ID */
	private Integer extraBuyId;
	/** NDS加價購項目ID */
	private Integer extraBuyItemId;
	/** NDS加價購類別 */
	private String extraBuyType;
	/** NDS加價購數量*/
	private Integer extraBuyQty;

	/** 專屬優惠ID */
	private Long premiumId;
	/** 專屬優惠群組(1:必選/2:可選) */
	private Integer premiumGroup;

	/**
	 * 一般商品
	 * @param fetNo
	 * @param qty
	 * @param isAcc
	 */
	public ShoppingProductBO(String fetNo, int qty, boolean isAcc) {
		this(fetNo, qty, isAcc, NON_MP_GROUP_NUM, null, false, null, null, null, null, null, null);
	}

	/**
	 * 組合折扣商品
	 * @param fetNo
	 * @param qty
	 * @param isAcc
	 * @param mpGroupNum
	 */
	public ShoppingProductBO(String fetNo, int qty, boolean isAcc, Integer mpGroupNum) {
		this(fetNo, qty, isAcc, mpGroupNum, null, false, null, null, null, null, null, null);
	}

	/**
	 * 加價購商品
	 * @param fetNo
	 * @param qty
	 * @param isAcc
	 * @param mpDiscId
	 */
	public ShoppingProductBO(String fetNo, int qty, boolean isAcc, Long mpDiscId) {
		this(fetNo, qty, isAcc, NON_MP_GROUP_NUM, mpDiscId, false, null, null, null, null, null, null);
	}

	/**
	 * NDS加價購商品
	 * @param fetNo
	 * @param qty
	 * @param isAcc
	 * @param extraBuyId
	 * @param extraBuyItemId
	 */
	public ShoppingProductBO(String fetNo, int qty, boolean isAcc, Integer extraBuyId, Integer extraBuyItemId, String extraBuyType) {
		this(fetNo, 1, isAcc, NON_MP_GROUP_NUM, null, true, extraBuyId, extraBuyItemId, extraBuyType, qty, null, null);
	}

	/**
	 * 專屬優惠商品
	 * @param fetNo
	 * @param qty
	 * @param isAcc
	 */
	public ShoppingProductBO(String fetNo, int qty, boolean isAcc, Long premiumId, Integer premiumGroup) {
		this(fetNo, qty, isAcc, NON_MP_GROUP_NUM, null, false, null, null, null, null, premiumId, premiumGroup);
	}

	/**
	 * (內部建構子)
	 * @param fetNo
	 * @param qty
	 * @param isAcc
	 * @param mpGroupNum
	 * @param mpDiscId
	 */
	private ShoppingProductBO(String fetNo, int qty, boolean isAcc, int mpGroupNum, Long mpDiscId, boolean isExtraBuy, Integer extraBuyId, Integer extraBuyItemId, String extraBuyType, Integer extraBuyQty, Long premiumId, Integer premiumGroup) {
		this.fetNo = fetNo;
		this.qty = qty;
		this.isAcc = isAcc;		
		this.mpGroupNum = mpGroupNum;
		this.mpDiscId = mpDiscId;
		this.isExtraBuy = isExtraBuy;
		this.extraBuyId = extraBuyId;
		this.extraBuyItemId = extraBuyItemId;
		this.extraBuyType = extraBuyType;
		this.extraBuyQty = extraBuyQty;
		this.premiumGroup = premiumGroup;
		this.premiumId = premiumId;
	}

	public String getFetNo() {
		return fetNo;
	}

	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public boolean isAcc() {
		return isAcc;
	}

	public void setAcc(boolean isAcc) {
		this.isAcc = isAcc;
	}

	public Long getMpDiscId() {
		return mpDiscId;
	}

	public void setMpDiscId(Long mpDiscId) {
		this.mpDiscId = mpDiscId;
	}

	public int getMpGroupNum() {
		return mpGroupNum;
	}

	public void setMpGroupNum(int mpGroupNum) {
		this.mpGroupNum = mpGroupNum;
	}

	public Integer getExtraBuyId() {
		return extraBuyId;
	}

	public void setExtraBuyId(Integer extraBuyId) {
		this.extraBuyId = extraBuyId;
	}

	public Integer getExtraBuyItemId() {
		return extraBuyItemId;
	}

	public void setExtraBuyItemId(Integer extraBuyItemId) {
		this.extraBuyItemId = extraBuyItemId;
	}

	public boolean isExtraBuy() {
		return isExtraBuy;
	}

	public void setExtraBuy(boolean isExtraBuy) {
		this.isExtraBuy = isExtraBuy;
	}

	public String getExtraBuyType() {
		return extraBuyType;
	}

	public void setExtraBuyType(String extraBuyType) {
		this.extraBuyType = extraBuyType;
	}

	public Integer getExtraBuyQty() {
		return extraBuyQty;
	}

	public void setExtraBuyQty(Integer extraBuyQty) {
		this.extraBuyQty = extraBuyQty;
	}

	public Long getPremiumId() {
		return premiumId;
	}

	public void setPremiumId(Long premiumId) {
		this.premiumId = premiumId;
	}

	public Integer getPremiumGroup() {
		return premiumGroup;
	}

	public void setPremiumGroup(Integer premiumGroup) {
		this.premiumGroup = premiumGroup;
	}
}
