package com.fet.estore.core.bean.vo;

import java.math.BigDecimal;

public class CmsHandsetVO {
	private String brand;
	private String modelName;
	private BigDecimal price;
	private String productId;
	private Boolean status;
	private String deviceType;
	private String aliasUrl;
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getAliasUrl() {
		return aliasUrl;
	}
	public void setAliasUrl(String aliasUrl) {
		this.aliasUrl = aliasUrl;
	}
	
}
