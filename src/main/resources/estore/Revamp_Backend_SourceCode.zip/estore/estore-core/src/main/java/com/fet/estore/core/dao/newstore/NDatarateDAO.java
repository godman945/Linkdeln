package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.Datarate;


/**
 * 數據資費資料存取層介面。
 *
 * @version $Id: NDatarateDAO.java,v 1.0, 2017-05-16 11:04:29Z, Evan Tung$
 */
public interface NDatarateDAO extends BaseDAO<Datarate, String> {

}
