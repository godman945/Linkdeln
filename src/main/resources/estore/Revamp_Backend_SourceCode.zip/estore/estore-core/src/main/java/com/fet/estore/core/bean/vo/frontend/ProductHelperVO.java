package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ProductHelperVO implements Serializable {
	
	private static final long serialVersionUID = -2185307505164048005L;
	public static final String PRODUCT_TYPE_HANDSET = "HANDSET";
	public static final String PRODUCT_TYPE_ACCESSORY = "ACCESSORY";

	/** 選購商品的fetNo */
	private String fetNo;
	/** 選購商品數量 */
	private int quantity;
	/** uuid */
	private String uuid;
	/** 是否為markUp */
	private boolean isMarkupProduct;
	/** 多組商品活動Id */
	private Long mpActivityId;
	/** 多組商品折扣活動Id */
	private Long mpActivityProductDiscountId;
	//紅配綠使用,非紅配綠:0
	//紅配綠第一群:1,第二群:2
	private int groupNumber;
	/** 是否為主商品 */
	private boolean master;
	/** 商品類型: 手機, 配件 */
	private String productType;
	/** 商品庫存。 */
	private Long inventory;
	/** 廠牌名稱 */
	private String brand;
	/** 商品型號 */
	private String modelName;
	/** 商品顏色 */
	private String color;
	/**omni lightbox 價格**/
	private Long posPrice;

	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public Long getMpActivityId() {
		return mpActivityId;
	}
	public void setMpActivityId(Long mpActivityId) {
		this.mpActivityId = mpActivityId;
	}
	public Long getMpActivityProductDiscountId() {
		return mpActivityProductDiscountId;
	}
	public void setMpActivityProductDiscountId(Long mpActivityProductDiscountId) {
		this.mpActivityProductDiscountId = mpActivityProductDiscountId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public boolean isMarkupProduct() {
		return isMarkupProduct;
	}
	public void setMarkupProduct(boolean isMarkupProduct) {
		this.isMarkupProduct = isMarkupProduct;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public boolean isMaster() {
		return master;
	}
	public void setMaster(boolean master) {
		this.master = master;
	}
	public int getGroupNumber() {
		return groupNumber;
	}
	public void setGroupNumber(int groupNumber) {
		this.groupNumber = groupNumber;
	}
	public Long getInventory() {
		return inventory;
	}
	public void setInventory(Long inventory) {
		this.inventory = inventory;
	}
	public String getFetNo_uuid() {
		StringBuilder fetNo_uuid = new StringBuilder(fetNo);
		if(uuid!=null){
			fetNo_uuid.append("_").append(this.uuid);
		}
		return fetNo_uuid.toString();
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Long getPosPrice() {
		return posPrice;
	}
	public void setPosPrice(Long posPrice) {
		this.posPrice = posPrice;
	}

}
