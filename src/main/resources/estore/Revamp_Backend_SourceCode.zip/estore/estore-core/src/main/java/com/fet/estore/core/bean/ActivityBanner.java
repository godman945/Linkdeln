package com.fet.estore.core.bean;

import com.fet.estore.core.bean.vo.common.BannerImageVO;

import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-09-03
 * @description
 */
public class ActivityBanner {

    private BannerImageVO image;

    private String title;

    private List<String> description;

    public BannerImageVO getImage() {
        return image;
    }
    public void setImage(BannerImageVO image) {
        this.image = image;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public List<String> getDescription() {
        return description;
    }
    public void setDescription(List<String> description) {
        this.description = description;
    }
}
