package com.fet.estore.core.bean;

import java.io.Serializable;

public class ProductDetailRenewalInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 是否由續約館進入 */
    private Boolean fromRenewal;
    /** 門號 */
    private String msisdn;
    /** 原門號世代 */
    private String mobileGenerationCode;

    public Boolean getFromRenewal() {
        return fromRenewal;
    }

    public void setFromRenewal(Boolean fromRenewal) {
        this.fromRenewal = fromRenewal;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

	public String getMobileGenerationCode() {
		return mobileGenerationCode;
	}

	public void setMobileGenerationCode(String mobileGenerationCode) {
		this.mobileGenerationCode = mobileGenerationCode;
	}
}
