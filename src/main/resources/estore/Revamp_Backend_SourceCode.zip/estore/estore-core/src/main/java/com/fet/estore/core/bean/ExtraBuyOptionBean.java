package com.fet.estore.core.bean;

import java.io.Serializable;

public class ExtraBuyOptionBean implements Serializable {

	private static final long serialVersionUID = -6220571477197061673L;
	
	private String productId;
	private String type;
	private String image;
	private String value;
	private String meta;
	private String name;
	private String originPrice;
	private String productPrice;
	private String color;
	private GiftModalBean modal;
	private Integer maxAmount;
	private String prodTypeNo; 	//商品分類  1:手機    2:配件
	private String fetNo;
	private String apId;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getMeta() {
		return meta;
	}
	public void setMeta(String meta) {
		this.meta = meta;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOriginPrice() {
		return originPrice;
	}
	public void setOriginPrice(String originPrice) {
		this.originPrice = originPrice;
	}
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public GiftModalBean getModal() {
		return modal;
	}
	public void setModal(GiftModalBean modal) {
		this.modal = modal;
	}
	public Integer getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(Integer maxAmount) {
		this.maxAmount = maxAmount;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProdTypeNo() {
		return prodTypeNo;
	}
	public void setProdTypeNo(String prodTypeNo) {
		this.prodTypeNo = prodTypeNo;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}

}
