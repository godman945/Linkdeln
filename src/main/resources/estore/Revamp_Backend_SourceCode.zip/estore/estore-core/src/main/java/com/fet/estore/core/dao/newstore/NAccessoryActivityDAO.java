package com.fet.estore.core.dao.newstore;

import java.util.List;
import java.util.Map;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AccessoryActivity;
import com.fet.estore.core.bean.vo.frontend.AccessoryActivityVO;
import com.fet.estore.core.bean.vo.frontend.HandsetActGiftVO;

/**
 * 配件活動DAO
 * @author Max Chen
 *
 */
public interface NAccessoryActivityDAO extends BaseDAO<AccessoryActivity, Long> {
	
	/**
	 * 取得配件活動折扣
	 * @param accProdIds
	 * @return
	 */
	public Map<String, AccessoryActivityVO> findAccessoryActivityDiscount(String[] accProdIds);
}
