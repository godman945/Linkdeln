package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.util.LogUtil;
import org.springframework.beans.factory.annotation.Value;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;


/**
 * 購物車VO
 * @author Max Chen
 *
 */
public class CartHelperVO implements Cloneable, Serializable {

	private static final long serialVersionUID = 7456513094302634767L;
    
	// properties -----------------------------------------------------------------------
	/** 購物車項目清單  */
	private Map<String, CartItemHelperVO> cartItems = new LinkedHashMap<String, CartItemHelperVO>();
	
	//20140415 CR, 購物車及下拉選單限制數量
	@Value("${cart.product.maxamount}")
	private int maxProductAmount;

	
	public int getMaxProductAmount() {
		return maxProductAmount;
	}

	public void setMaxProductAmount(int maxProductAmount) {
		this.maxProductAmount = maxProductAmount;
	}

	@Override
    // 2013/06/27 fred add 除錯測試用
    public String toString() {
        
        StringBuffer buffer = new StringBuffer();
        
        Iterator iter = cartItems.keySet().iterator();
        while( iter.hasNext() ) {
            String key = (String) iter.next();
            CartItemHelperVO item = (CartItemHelperVO) cartItems.get(key);
            
            buffer.append("\nkey:" + key + "\n");
            buffer.append("CartItemHelperVO:\n" + item.toString());
            buffer.append("\n");
        }
        
        return buffer.toString();
    }
	
	// methods --------------------------------------------------------------------------	
	
	/**
	 * 取得購物項目清單
	 * @return
	 */
	public List<CartItemHelperVO> getItems() {		
		List<CartItemHelperVO> voList = new ArrayList<CartItemHelperVO>();
		Collection<CartItemHelperVO> voCols = cartItems.values();		
		voList.addAll(voCols);
		
		// 依加入時間先後排序
		Collections.sort(voList, new Comparator<CartItemHelperVO>() {
			public int compare(CartItemHelperVO o1, CartItemHelperVO o2) {
				Date d1 = o1.getAddTime();
				Date d2 = o2.getAddTime();
				long l1 = d1 != null ? d1.getTime() : Long.MAX_VALUE;
				long l2 = d2 != null ? d2.getTime() : Long.MAX_VALUE;
				return (int)(l1 - l2);
			};
		});
		return voList;
	}
	
	
	/**
	 * 購物車是否不為空
	 * @return
	 */
	public boolean isNotEmpty() {
		return cartItems != null && !cartItems.isEmpty();
	}
	
	/**
	 * 加入購物項目
	 * @param productId
	 * @param fetNo
	 * @param amount
	 * @param price
	 */
	public void addItem(String productId, String fetNo, String name, Integer amount, Long price, boolean isAcc, String linkUrl
			, int totalAmount, boolean isExclusive) {
		if(productId == null || fetNo == null || amount == null || price == null) return;
		
		// 已存在便跳出
		//isExist被kevin改了interface，最後加了一個erp price的參數，為了解決加購商品超過5個後，要變成主商品時，沒有erp價格的問題
		//原先的程式保持不變，所以erp price帶null
		if(isExist(null, fetNo, false, totalAmount, amount, null, null, price, null)) return;
		
		// 設定數量金額
		CartItemHelperVO item = new CartItemHelperVO();
		item.setProductId(productId);
		item.setFetNo(fetNo);
		item.setName(name);
		item.setAcc(isAcc);
		item.setPrice(price);
		item.setAmount(amount);
		item.setAddTime(new Date());
		item.setLinkUrl(linkUrl);
		item.setFirst(true);
		//Kevin:這邊不知道有沒有潛在的bug，因為這個price在加價購時，帶進來的不是erp price，但在非加價購時，帶的是erp price，加價購的商品似乎不會經過這個地方
		//暫時這樣設定，在加價購的地方，已經處理這個erp price的問題了
		item.setErpPrice(price);
		
		// 計算小計
		long prc = item.getPrice() != null ? item.getPrice() : 0L;
		int amt = item.getAmount() != null ? item.getAmount() : 0;
		long subtotal = prc * amt;
		item.setSubTotal(subtotal);		
		
		cartItems.put(fetNo, item);
		//kevin加上的重排順序,按原先放進購物車的時間重排
		//這個動作放在每一次做完put的動作後
		resetItemOrder();
	}

	
	
	/**
	 * 加入購物項目
	 * @param productId
	 * @param fetNo
	 * @param amount
	 * @param price
	 */
	public void addItem(String productId, String fetNo, String name, Integer amount, Long price, boolean isAcc, String linkUrl
			, Long mpActivityId, Long mpActivityProductDiscountId, String firstFetNo, int totalAmount, boolean withMpActivity
			, boolean isFirst, boolean isExclusive, Long erpPrice) {
		if(productId == null || fetNo == null || amount == null || price == null) return;
		
		// 已存在便跳出
		//isExist被kevin改了interface，最後加了一個erp price的參數，為了解決加購商品超過5個後，要變成主商品時，沒有erp價格的問題
		//原先的程式保持不變，所以erp price帶null
		if(isExist(firstFetNo, fetNo, withMpActivity, totalAmount, amount,  mpActivityId, mpActivityProductDiscountId, price, null)) return;
			
		// 設定數量金額
		CartItemHelperVO item = new CartItemHelperVO();
		item.setProductId(productId);
		item.setFetNo(fetNo);
		item.setName(name);
		item.setAcc(isAcc);
		item.setPrice(price);
		item.setAmount(amount);
		item.setAddTime(new Date());
		item.setLinkUrl(linkUrl);
		//這是kevin補上的，原先加入購物車的物件，沒有這一個參數
		if(erpPrice != null){
			item.setErpPrice(erpPrice);
		}
		if(firstFetNo==null){
			item.setFirst(true);
		}else{
			item.setFirst(false);
		}
		
		if(isFirst){
			item.setUuid(UUID.randomUUID().toString());
		}else{
			String uuid = getFetNoFirstToUUID(firstFetNo);
			if(uuid==null){
				return;
			}else{
				item.setUuid(uuid);
			}
		}
		item.setFirstFetNo(firstFetNo);
		item.setMpActivityId(mpActivityId);
		item.setMpActivityProductDiscountId(mpActivityProductDiscountId);

		// 計算小計
		long prc = item.getPrice() != null ? item.getPrice() : 0L;
		int amt = item.getAmount() != null ? item.getAmount() : 0;
		long subtotal = prc * amt;
		item.setSubTotal(subtotal);		
		
		StringBuilder sb = new StringBuilder();
		sb.append(fetNo).append("_").append(item.getUuid());
		
		cartItems.put(sb.toString(), item);
		//kevin加上的重排順序,按原先放進購物車的時間重排
		//這個動作放在每一次做完put的動作後
		resetItemOrder();
	}
	
	
	/**
	 * 加入購物項目
	 * @param productId
	 * @param fetNo
	 * @param amount
	 * @param price
	 */
	//這個method被kevin overload，因為原先從頁傳來的price，並不是真正的erp price，可能是加價購的價格
	//所以kevin overload了一個多加了erpPrice的method。為了不影響到其它程式，其它原先的method不變，傳入erpPrice設為null
	public void addItem(String productId, String fetNo, String name, Integer amount, Long price, boolean isAcc, String linkUrl
			, Long mpActivityId, Long mpActivityProductDiscountId, String firstFetNo, int totalAmount, boolean withMpActivity
			, boolean isFirst, boolean isExclusive) {
		this.addItem(productId, fetNo, name, amount, price, isAcc, linkUrl, mpActivityId, mpActivityProductDiscountId, firstFetNo, totalAmount, withMpActivity, isFirst, isExclusive, null);
	}
	
	/**
	 * 是否已存在此料號
	 * @param fetNo
	 * @return
	 */
	//public boolean isExist(String fetNo) {
	//	return cartItems.containsKey(fetNo);
	//}
	
	/**
	 * 取得料號之數量
	 * @param fetNo
	 * @return
	 */
	public Integer getAmount(String fetNo) {
		CartItemHelperVO item = cartItems.get(fetNo);
		if(item == null) return null;
		return item.getAmount();
	}

	/**
	 * 移除購物項目
	 * @param fetNo
	 */
	public void removeItem(String fetNo) {
	    
	    LogUtil.debug("before removeItem:\n" + toString());
	    
		if(fetNo == null) return;
		
		
		CartItemHelperVO vo = cartItems.get(fetNo);
		if(vo == null)
			return;
		if(vo.getUuid()!=null){
			if(vo.getMpActivityId()!=null){
				
				String uuid = vo.getUuid();
				
				cartItems.remove(fetNo);
				
				checkVerifyOnlyFirst(uuid);
				
			}else{
				StringBuilder fetNos = new StringBuilder();
				for(CartItemHelperVO obj : cartItems.values()){
					if(vo.getUuid().equals(obj.getUuid())){
						if(fetNos.toString()!="" && fetNos.length()>0){
							fetNos.append(",");
						}
						fetNos.append(obj.getFetNo()).append("_").append(obj.getUuid());
					}
				}
				
				if(fetNos!=null){
					String[] s = fetNos.toString().split(",");
					for(int i=0;i<s.length;i++){
						CartItemHelperVO v = cartItems.get(s[i]);
						if(v!=null){
							cartItems.remove(s[i]);
							v.setUuid(null);
							cartItems.put(v.getFetNo(), v);
						}
//						cartItems.remove(s[i]);
					}
					//kevin加上的重排順序,按原先放進購物車的時間重排
					//這個動作放在每一次做完put的動作後
					resetItemOrder();
				}
				
			}
		}else{
			cartItems.remove(fetNo);
		}
		
		LogUtil.debug("after removeItem:" + toString());
	}
	
	
	public void removeAllItem(){
		this.cartItems.clear();
	}
	
	/**
	 * 更改數量
	 * @param fetNo
	 * @param amount
	 */
	public void changeAmount(String fetNo, Integer amount) {
		if(fetNo == null || !cartItems.containsKey(fetNo)) return;
		
		CartItemHelperVO item = cartItems.get(fetNo);
		item.setAmount(amount);
	}
	/**
	 * 取得父類uuid
	 */
//	public String getUUID(String fetNo) {
//		CartItemHelperVO item = cartItems.get(fetNo);
//		if(item == null) return null;
//		return item.getUuid();
//	}
	
//	public void setFetNoToUUID(String fetNo) {
//		CartItemHelperVO item = cartItems.get(fetNo);
//		item.setUuid(UUID.randomUUID().toString());
//	}
	
	/** 清空購物車 */
	public void clear() {
		cartItems.clear();
	}
	
	//取得父類的uuid
	private String getFetNoFirstToUUID(String firstFetNo){
		
		Set<Entry<String, CartItemHelperVO>> s = cartItems.entrySet();
		
		Iterator<Entry<String, CartItemHelperVO>> itr = s.iterator();
		
		String uuid = null;
		
		while(itr.hasNext()){
			Entry<String, CartItemHelperVO> vo = itr.next();
			
			if(vo.getValue().isFirst() && getCartKeyFetNo(vo.getKey())!=null && firstFetNo.equals(getCartKeyFetNo(vo.getKey()))){
				uuid = vo.getValue().getUuid();
				
				break;
			}
		}
		
		return uuid;
	}
	//取得同樣商品的數量加總  (主商品 及 加價購加總)
	public int getIsExclusiveAmount(String fetNo){
		int amount = 0;
		
		Set<Entry<String, CartItemHelperVO>> s = cartItems.entrySet();
		
		Iterator<Entry<String, CartItemHelperVO>> itr = s.iterator();
		
		while(itr.hasNext()){
			Entry<String, CartItemHelperVO> vo = itr.next();
			
			if(vo.getValue().getFetNo().equals(fetNo)){
				amount += vo.getValue().getAmount();
			}
		}
		
		return amount;
	}
	//取得購物車key的fetno
	private String getCartKeyFetNo(String fetNo){
		
		if(fetNo==null)return null;
		
		String[] value = fetNo.split("_");
		
		return value[0];
	}
	
	private boolean isExist(String firstFetNo, String fetNo, boolean withMp, int totalAmount, int amount, Long  mpActivityId, Long mpActivityProductDiscountId, Long price, Long erpPrice){
		
		Set<Entry<String, CartItemHelperVO>> s = cartItems.entrySet();
		
		Iterator<Entry<String, CartItemHelperVO>> itr = s.iterator();
		
		String firstKey = null;
		String key = null;
		boolean isExist = false;
		
		while(itr.hasNext()){
			Entry<String, CartItemHelperVO> ent = itr.next();
			CartItemHelperVO vo = ent.getValue();
			if(getCartKeyFetNo(ent.getKey())!=null && fetNo.equals(getCartKeyFetNo(ent.getKey())) ){
				//加價購商品
				if(firstFetNo!=null){
					String uuid = vo.getUuid();
					//是否有重覆商品
					if(uuid!=null){
						if(vo.getFirstFetNo() != null && vo.getFirstFetNo().equals(firstFetNo) && vo.getAmount() < this.maxProductAmount){
							if(cartItems.containsKey(String.format("%s_%s", firstFetNo, uuid))){
								isExist = true;
							}
						}
					}else{
					//有重複商品取得第一筆相同的key，在增加數量的動作
						isExist = true;
					}
					
					if(isExist){
						firstKey = ent.getKey();
						break;
					}
					
					
				}else{
					//商品的key
					if(vo.isFirst()){
						if(vo.getUuid() == null){
							firstKey = ent.getKey();
						}else{
							key = ent.getKey();
						}
						
						isExist = true;
						break;
					}
//					else{
//						//取得順序第一個的key
//						if(firstKey==null){
//							firstKey = ent.getKey();
//						}
//					}
				}
			}
		}
		
		//將購物車商品增加數量
		if(isExist){
			if(key!=null){
				addAmount(key, totalAmount, amount);
			}else if(firstKey!=null){
				if(fetNo.equals(firstKey)){
					addAmount(firstKey, totalAmount, amount);
				}else{
					changeToUUIDAddAmount(firstKey, firstFetNo, totalAmount, amount, mpActivityId, mpActivityProductDiscountId, price, erpPrice);
				}
			}
			
			String f = null;
			if(key != null)
				f = key;
			else if(firstKey!=null)
				f = firstKey;
			if(firstFetNo==null && withMp && f!=null){
				addUUID(f, null);
			}
			
			
		}else{
			if(firstKey!=null && !withMp){
				addAmount(firstKey, totalAmount, amount);
				isExist = true;
			}
		}
		
		return isExist;
	}
	

	
	
	
	
	
	
	//增加數量
	private void addAmount(String key, int totalAmount, int amount){
		
		CartItemHelperVO vo = cartItems.get(key);
		
		int countAmount = vo.getAmount() + amount;
		if(!vo.isExclusive()){
			totalAmount = this.maxProductAmount;
		}
		if(countAmount > totalAmount){
			countAmount = totalAmount;
		}
		vo.setAmount(countAmount);
	}
	
	//將一般商品加入到次商品，並且變更數量更新KEY
	//kevin加上最後的參數price。原本若是將主商品改成某一商品的加價購,則價格會維持原來主商品的價格,是錯的
	//kevin後來又再後面加上一個erp price參數，修正加價購商品帶進來的價格是加價購而非erp price的問題，為保持原先程式不變，如果有帶進來的erp price不是空的，才用帶進來的erp price,否則就用原先vo內的erp price
	private void changeToUUIDAddAmount(String key, String firstFetNo, int totalAmount, int amount, Long mpActivityId, Long mpActivityProductDiscountId, Long price, Long theErpPrice){

		CartItemHelperVO vo = new CartItemHelperVO(cartItems.get(key));
//		removeItem(key);
		
		int theRealAmount = vo.getAmount() + amount;
		Long erpPrice = theErpPrice == null ? vo.getErpPrice() : theErpPrice;
		int countAmount = vo.getAmount() + amount;
		int oldCartAmount = 0;
		if(!vo.isExclusive()){
			totalAmount = this.maxProductAmount;
		}
		if(countAmount > totalAmount){
			oldCartAmount = countAmount - totalAmount;
			
			countAmount = totalAmount;
		}
		vo.setAmount(countAmount);
		
		if(vo.getUuid() == null){
			String firstUUID = null;
			if(firstFetNo!=null){
				Set<Entry<String, CartItemHelperVO>> s = cartItems.entrySet();
				
				Iterator<Entry<String, CartItemHelperVO>> itr = s.iterator();
				while(itr.hasNext()){
					Entry<String, CartItemHelperVO> ent = itr.next();
					CartItemHelperVO firstVO = ent.getValue();
					if(firstVO.isFirst() && firstVO.getFetNo().equals(firstFetNo) && firstVO.isFirst()){
						firstUUID = firstVO.getUuid();
						break;
					}
				}
				
				CartItemHelperVO firstVO = cartItems.get(new StringBuilder().append(firstFetNo).append("_").append(firstUUID).toString());
				vo.setUuid(firstVO.getUuid());
			}else{
				firstUUID =UUID.randomUUID().toString();
				vo.setUuid(firstUUID);
			}
		}
		
		if(firstFetNo!=null){
			vo.setFirstFetNo(firstFetNo);
			vo.setFirst(false);
			vo.setMpActivityId(mpActivityId);
			vo.setMpActivityProductDiscountId(mpActivityProductDiscountId);
		}
		//kevin加的程式。原本若是將主商品改成某一商品的加價購,則價格會維持原來主商品的價格,是錯的
		if(price != null && firstFetNo == null){
			vo.setPrice(price);
		}
		
		
		StringBuilder sb = new StringBuilder();
		sb.append(key);
		if(key.indexOf("_") < 0 && vo.getUuid()!=null){
			sb.append("_").append(vo.getUuid());
		}
		
		cartItems.put(sb.toString(), vo);
		
		
		
		//這一段是Kevin加的
		int amountLeft = 0;
		//如果是加價購商品,而且不是主商品(是被加購的商品)
		//那麼多出來的數量,要試試看,還可不可以變成主商品
		if(!vo.isFirst()){
			amountLeft = theRealAmount > this.maxProductAmount ? theRealAmount - this.maxProductAmount : 0;
		}
		if(amountLeft > 0){
			this.addItem(vo.getProductId(), vo.getFetNo(), vo.getName(), amountLeft, vo.getErpPrice(), vo.isAcc(), vo.getLinkUrl(), 0, vo.isExclusive());
		}
		
		
		
		//kevin加上的重排順序,按原先放進購物車的時間重排
		//這個動作放在每一次做完put的動作後
		resetItemOrder();
		
	}
	//複製自己
	public CartHelperVO cloneVO() { 
		try { 
			// call clone in Object. 
			return (CartHelperVO) super.clone(); 
		} catch(CloneNotSupportedException e) { 
			//System.out.println("Cloning not allowed."); 
			//e.printStackTrace();
			LogUtil.error("Cloning not allowed.");
			LogUtil.error(e);
			return this; 
		} 
	}
	//是否只剩一個主商品
	private void checkVerifyOnlyFirst(String uuid){
		
		Set<Entry<String, CartItemHelperVO>> s = cartItems.entrySet();
		
		Iterator<Entry<String, CartItemHelperVO>> itr = s.iterator();
		boolean isFirst = false;
		boolean withSecond = false;
		String firstFetNo = null;
		
		while(itr.hasNext()){
			Entry<String, CartItemHelperVO> e = itr.next();
			CartItemHelperVO vo = e.getValue();
			if(vo.getUuid()!=null && vo.getUuid().equals(uuid)){
				if(vo.isFirst()){
					isFirst = true;
					firstFetNo = vo.getFetNo();
				}else{
					withSecond = true;
				}
			}
			
			if(isFirst && withSecond){
				break;
			}
		}
		
		if(isFirst && !withSecond){
			removeUUID(firstFetNo, uuid);
		}
		
	}
	
	//移除UUID並且更新KEY
	private void removeUUID(String fetNo, String uuid){
		
		String key = fetNo+"_"+uuid;
		
		CartItemHelperVO vo = new CartItemHelperVO(cartItems.get(key));
		
		vo.setUuid(null);
		cartItems.remove(key);
//		removeItem(key);
		
		cartItems.put(fetNo, vo);
		//kevin加上的重排順序,按原先放進購物車的時間重排
		//這個動作放在每一次做完put的動作後
		resetItemOrder();
	}
	
	//新增UUID並且更新KEY
	private String addUUID(String fetNo, String uuid){
		
		boolean original = false;
		CartItemHelperVO vo = new CartItemHelperVO(cartItems.get(fetNo));
		
		if(vo.getUuid()!=null){
			original = true;
		}
		
		if(uuid==null){
			vo.setUuid(UUID.randomUUID().toString());
		}
		
		String key = vo.getFetNo()+"_"+vo.getUuid();
		
		if(!original){
			cartItems.put(key, vo);
			removeItem(fetNo);
		}
		
		//kevin加上的重排順序,按原先放進購物車的時間重排
		//這個動作放在每一次做完put的動作後
		resetItemOrder();
		
		return key;
	}
	
	//組合出碰撞的主商品
	public Map<String,Object> getCollisionList(String fetNo, List<MpActivityProductVO> voList, Integer amount, Integer totalAmount){
		
		
		Set<String> keys = cartItems.keySet();
		for(String key : keys){
			LogUtil.info("Key: " + key);
		}
		
		
		
		Map<String,Object> map = new HashMap<String, Object>();
		
		Set<Entry<String, CartItemHelperVO>> s = cartItems.entrySet();
		Iterator<Entry<String, CartItemHelperVO>> itr = s.iterator();
		//碰撞商品的資料
		List<CartCollisionVO> list = new ArrayList<CartCollisionVO>();
		//選擇的數量
		int n_amount = amount;
		String same_key = null;
		//是否已經超過獨賣件數量
		boolean errorExclusive = false;
		//目前購物車的總數量
		int exclusiveCount = 0;
		//在購物車的獨賣件數量 是否超過總數量
		if(totalAmount!=null){
			while(itr.hasNext()){
				Entry<String, CartItemHelperVO> e = itr.next();
				CartItemHelperVO vo = e.getValue();
				if(vo.getFetNo().equals(fetNo)){
					exclusiveCount += vo.getAmount();
				}
			}
			if(totalAmount<exclusiveCount){
				errorExclusive = true;
			}else{
				int te_Count = totalAmount-exclusiveCount;
				if(te_Count <= this.maxProductAmount && te_Count < n_amount){
					n_amount = te_Count;
				}
			}
		}
		
		if(errorExclusive){
			map.put("error", "商品已經超過獨賣件的庫存量");
		}else{
			//Kevin:前面如果獨賣件的檢查跑過一輪,itr會跑到最後面,就沒有下一個資料了,所以要重新開始跑迴圈
			itr = s.iterator();
			//購物車放置順序 
			while(itr.hasNext()){
				if(n_amount<=0){
					break;
				}
				
				Entry<String, CartItemHelperVO> e = itr.next();
				CartItemHelperVO vo = e.getValue();
				CartCollisionVO ccVO = new CartCollisionVO();
				//是否有父類商品
				boolean withFirst = false;
				//是否已經有相同的主商品
				if(vo.isFirst() && vo.getFetNo().equals(fetNo)){
					if(vo.getAmount()<this.maxProductAmount){
						same_key = e.getKey();
						//kevin加的,這裡原本有碰撞到,但後續好像沒處理到
						ccVO.setKey(same_key);
						int a = vo.getAmount() + n_amount;
						if(a>this.maxProductAmount){
							ccVO.setAmount(this.maxProductAmount - vo.getAmount());
							n_amount = n_amount - (this.maxProductAmount - vo.getAmount());
						}else{
							ccVO.setAmount(n_amount);
							n_amount = 0;
						}
						list.add(ccVO);
					}
					if(n_amount > 0){
						map.put("error", "很抱歉，您選購的商品已達購買數量上限，請重新選擇商品，謝謝。");
					}
					break;
				}else{
					//是否有加價購父商品
					for(MpActivityProductVO mapVO : voList){
						if(vo.isFirst() && vo.getFetNo().equals(mapVO.getFetNo())){
							withFirst = true;
							ccVO.setKey(e.getKey());
							ccVO.setFirstFetNo(vo.getFetNo());
							ccVO.setMpActivityId(mapVO.getMpActivityId());
							StringBuilder key = new StringBuilder().append(fetNo);
							if(vo.getUuid()!=null){
								ccVO.setUuid(vo.getUuid());
								key.append("_").append(vo.getUuid());
							}
							//是否有此子商品
							boolean withSub = cartItems.containsKey(key.toString());
							if(!withSub){
								ccVO.setAmount(n_amount);
								n_amount = 0;
							}else{
								int subAmount = getAmount(key.toString());
								
								if(subAmount < this.maxProductAmount){
									int a = subAmount + n_amount;
									if(a>this.maxProductAmount){
										ccVO.setAmount(this.maxProductAmount - subAmount);
										n_amount = n_amount - (this.maxProductAmount - subAmount);
									}else{
										ccVO.setAmount(n_amount);
										n_amount = 0;
									}
								}else{
									withFirst = false;
								}
							}
							break;
						}
					}
				}
				
				//碰撞到的父類
				if(withFirst){
					list.add(ccVO);
					//將父類增加uuid
					if(ccVO.getUuid() == null){
						addUUID(ccVO.getFirstFetNo(), null);
					}
				}
				//選擇的數量已經為空
				if(n_amount<=0){
					break;
				}
			}
			
			//kevin改的,把這一段處理移到前面去了,請搜尋same_key
			//但是後面又加了一段code,照理說，n_amount到這裡應該要是0了，但如果不是零，表示
			//剩下的數量要被當成主商品加入購物車
			/*
			if(same_key!=null && n_amount>0){
				CartCollisionVO ccVO = new CartCollisionVO();
				ccVO.setKey(same_key);
				ccVO.setAmount(n_amount);
				list.add(ccVO);
			}
			*/
			if(n_amount > 0){
				CartCollisionVO ccVO = new CartCollisionVO();
				ccVO.setKey(fetNo);
				ccVO.setAmount(n_amount);
				list.add(ccVO);
			}
			
			
			
			
			map.put("list", list);
			
		}
		
		return map;
	}
	
	//取得購物車的key
	public List<MpActivityProductVO> checkSubToCarKey(String masterProductFetNo, List<MpActivityProductVO> vos, boolean isDevice){
		List<MpActivityProductVO> voList = new ArrayList<MpActivityProductVO>();
		
		
		
		if(isDevice){
			Set<Entry<String, CartItemHelperVO>> set = cartItems.entrySet();
			
			for(MpActivityProductVO s : vos){
				Iterator<Entry<String, CartItemHelperVO>> itr = set.iterator();
				while(itr.hasNext()){
					Entry<String, CartItemHelperVO> e = itr.next();
					if(e.getKey().equals(s.getFetNo())){
						voList.add(s);
					}
				}
			}
			
		//以下是Kevin加的程式，用來改正配件重新組合問題，因為這個method本來是設備、配件共用，所以改了配件，設備卻出錯了
		//所以，把原來設備部份的程式復原，放在上面
		}else{
		
		
		
		
			//kevin加的,如果購物車裡只有一個商品，就不用重新組合
			if(cartItems.size() < 1){
				return voList;
			}
			
			boolean productAtSlavePosition = false;
			boolean productAtMasterPosition = false;
			
			
			
			
			
			//先看看主商品是不是已經是加價購的主商品，如果是，先把uuid取出，後面檢查配件的時候，看有沒有已經在此主商品下，同樣的配件存在
			CartItemHelperVO masterProductVO = null;
			Set<String> keys = cartItems.keySet();
			for(String key : keys){
				if(key.contains(masterProductFetNo) && key.contains("_")){
					if(masterProductVO == null){
						masterProductVO = cartItems.get(key);
					}
					
					if(cartItems.get(key).getAmount() < this.maxProductAmount){
						productAtMasterPosition = true;
					}
				}
				
				if(key.contains(masterProductFetNo) && !key.contains("_") && cartItems.get(key).getAmount() < this.maxProductAmount){
					productAtSlavePosition = true;
				}
			}
			
			//Kevin：這邊已經改到不知道該怎麼改了，權宜之計，看看要加入的配件，有沒有同時出現在被加價購商品中，以及主商品中，且數量都不小於5，如果有，就回傳沒有比對到，後面的程式
			//會再進行商品的碰撞，這一部份的邏輯在商品碰撞的地方是對的
			if(productAtMasterPosition == true && productAtSlavePosition){
				return voList;
			}
			
			
			
			
			
			
			Set<Entry<String, CartItemHelperVO>> set = cartItems.entrySet();
			
			//這一段是要把購物車裡，有單獨配件的，跟主商品配對
			//	A
			//	|-- 甲（5）
			//
			//	甲
			//以上這種情形原先的程式會誤判，會把甲(5)當成獨立商品，所以加上如果uuid不是空的時候，就不用將此項商品重新組合的條件
			//另外，也會把第二個甲誤判，所以再加上其它判斷，當程式抓到第二個甲的時候，去看甲和A是不是已經有加價購存在，若存在，且數不滿5個，才重新組合
			for(MpActivityProductVO s : vos){
				Iterator<Entry<String, CartItemHelperVO>> itr = set.iterator();
				while(itr.hasNext()){
					Entry<String, CartItemHelperVO> e = itr.next();
					if(e.getKey().equals(s.getFetNo())){
						
						CartItemHelperVO myVO = e.getValue();
						
						//有加價購，不重組
						if(myVO.getUuid() != null){
							continue;
						}else{
							if(masterProductVO != null){
								String uuid = masterProductVO.getUuid();
								String myKey = String.format("%s_%s", s.getFetNo(), uuid);
								CartItemHelperVO theVO = cartItems.get(myKey);
								if(theVO.getAmount() < this.maxProductAmount){
									voList.add(s);
								}
							}else{
								voList.add(s);
							}
						}
					}
					//這邊被kevin修改過了，改成上面的程式
	//				if(e.getKey().equals(s.getFetNo())){
	//					voList.add(s);
	//				}
				}
			}
		}
		
		return voList;
	}
	
	//將獨立商品   與主商品組合成加價購
	public void changeSubData(String key, String firstFetNo, Long mpActivityId, Long mpActivityProductDiscountId){
		
		CartItemHelperVO vo = cartItems.get(key);
		
		vo.setMpActivityId(mpActivityId);
		vo.setMpActivityProductDiscountId(mpActivityProductDiscountId);
		vo.setFirst(false);
		vo.setFirstFetNo(firstFetNo);
		
		String uuid = getFetNoFirstToUUID(firstFetNo);
		if(uuid==null){
			return;
		}else{
			vo.setUuid(uuid);
		}
		
		//kevin註解掉的
		//cartItems.put(key, vo);
		
		
		
		cartItems.remove(key);
		
		cartItems.put(String.format("%s_%s", key, uuid), vo);
		
		//kevin加上的重排順序,按原先放進購物車的時間重排
		//這個動作放在每一次做完put的動作後
		resetItemOrder();
		
		
		
		//以下這段程式很詭異,被kevin註解掉了,直接把程式改在上面
		//addUUID(key, vo.getUuid());
		
	}
	
	// 2013/07/01 fred add #7703 將商品加入購物車時，若數量超過上限，
	// 目前的訊息為「抱歉，此項商品在購物車內的數量不可超過5件，請您重新選擇數量」，
	// 改為「很抱歉，您選購的商品已達購買數量上限，請重新選擇商品，謝謝。」
	// Boolean.TRUE  => 可加入
	// Boolean.FALSE => 已達購買數量上限, 不可加入
	public Boolean checkItemCountByFetno(String fetno, Integer amount) { // 檢查此料號是否可以被加入購物車
	    
	    Boolean exist = Boolean.FALSE; // 此料號不存在購物車
	    
	    if( cartItems.isEmpty() ) { // 購物車為空時, 可加入
	        return Boolean.TRUE;
	    } else { // 購物車不為空時,  
    	    Iterator iter = cartItems.keySet().iterator();
    	    while( iter.hasNext() ) {
    	        String key = (String) iter.next();
    	        
    	        if ( key.contains(fetno) ) { // key 以 fetno 或 fetno_uuid 的形式存在購物車
    	            exist = Boolean.TRUE;
    	            
    	            CartItemHelperVO item = cartItems.get(key);
    	            
    	            if( item.isFirst() ) { // 主商品
    	                if( (amount + item.getAmount()) <= this.maxProductAmount ) {
                            return Boolean.TRUE;
                        }
    	            } else { // 次商品
    	                if( (amount + item.getAmount()) <= this.maxProductAmount ) {
                            return Boolean.TRUE;
                        } else {
                            // 檢查是否有fetno以主商品的形式存在
                            Boolean first = Boolean.FALSE;
                            Iterator sub = cartItems.keySet().iterator();
                            while( sub.hasNext() ) {
                                String k = (String) sub.next();
                                if ( k.contains(fetno) ) {
                                    CartItemHelperVO itemBean = cartItems.get(k);
                                    if( itemBean.isFirst() ) {
                                        first = Boolean.TRUE;
                                        break;
                                    }
                                }
                            }
                            
                            if( !first ) {
                                return Boolean.TRUE;
                            }
                        }
    	            }
    	        }
    	    }
    	    
    	    if( !exist ) { // key 以 fetno, 或 fetno_uuid 的形式不存在購物車, 可加入
    	        return Boolean.TRUE;
    	    }
	    }
	    
	    return Boolean.FALSE;
	}
	
	
	private void resetItemOrder(){
		List<CartItemHelperVO> vos = this.getItems();
		this.cartItems.clear();
		for(CartItemHelperVO vo : vos){
			String key = vo.getUuid() == null ? vo.getFetNo() : String.format("%s_%s", vo.getFetNo(), vo.getUuid());
			cartItems.put(key, vo);
		}
	}
	
	
	
}
