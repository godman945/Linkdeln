package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AccBrand;

public interface NAccBrandDAO extends BaseDAO<AccBrand, String> {

	/**
	 * 配件館查詢品牌.
	 * @return List<RefBrand>
	 */
	public List<AccBrand> findAccBrandList();
}
