package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AreaCity;

public interface NAreaCityDAO extends BaseDAO<AreaCity, String> {
	/**
	 * 取回遞送城市
	 * @return
	 */
	public List<AreaCity> findShippableCity();
	
	/**
	 * 取回遞送城市
	 * @return
	 */
	public List<AreaCity> findShippableCity(Boolean canShip);

}
