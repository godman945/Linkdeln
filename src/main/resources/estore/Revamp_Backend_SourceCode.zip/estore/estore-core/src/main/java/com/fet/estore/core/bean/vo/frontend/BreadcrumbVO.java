package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

/**
 * 前台網站麵包屑的value object。
 * 
 * @author samho
 */
public class BreadcrumbVO implements Serializable {
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 7852672462078134234L;

	/**
	 * 網址連結方式-新視窗。
	 */
	public static final String LINK_METHOD_NEW = "NEW";
	
	/**
	 * 網址連結方式-原視窗。
	 */
	public static final String LINK_METHOD_SELF = "SELF";
	
	/**
	 * 麵包屑的顯示名稱。
	 */
	private String displayName;
	
	/**
	 * 麵包屑的連結網址。
	 */
	private String linkUrl;
	/**
	 *  FrontendNavigation中的name(唯一值)。
	 */
	private String name;
	/**
	 * 麵包屑的網址連結方式。
	 */
	private String linkMethod = BreadcrumbVO.LINK_METHOD_SELF;
	
	/**
	 * 預設建構子。
	 */
	public BreadcrumbVO() {
		super();
	}
	
	/**
	 * 建構子。
	 * 
	 * @param displayName 麵包屑的顯示名稱。
	 * @param linkUrl 麵包屑的連結網址。
	 * @param linkMethod 麵包屑的網址連結方式。
	 * @param name FrontendNavigation中的name(唯一值)。
	 */
	public BreadcrumbVO(String displayName, String linkUrl, String linkMethod, String name) {
		super();
		this.displayName = displayName;
		this.linkUrl = linkUrl;
		this.linkMethod = linkMethod;
		this.name = name;
	}

	/**
	 * 取得displayName。
	 *
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * 設定displayName。
	 *
	 * @param displayName 欲設定的displayName。
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * 取得linkUrl。
	 *
	 * @return the linkUrl
	 */
	public String getLinkUrl() {
		return linkUrl;
	}

	/**
	 * 設定linkUrl。
	 *
	 * @param linkUrl 欲設定的linkUrl。
	 */
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	/**
	 * 取得linkMethod。
	 *
	 * @return the linkMethod
	 */
	public String getLinkMethod() {
		return linkMethod;
	}

	/**
	 * 設定linkMethod。
	 *
	 * @param linkMethod 欲設定的linkMethod。
	 */
	public void setLinkMethod(String linkMethod) {
		this.linkMethod = linkMethod;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
