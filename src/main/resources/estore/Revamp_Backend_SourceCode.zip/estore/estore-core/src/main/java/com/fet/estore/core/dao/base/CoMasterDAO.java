package com.fet.estore.core.dao.base;

import java.util.List;

import com.fet.estore.core.model.CoMaster;
import com.fet.estore.core.bean.vo.MayannVO;

public interface CoMasterDAO extends BaseDAO<CoMaster, String> {
	
	/**
	 * 取得美安待發送紀錄
	 * @return
	 */
	public List<MayannVO> findByMayann();
	
	/**
	 * 更新美安已發送紀錄
	 * @return
	 */
	public void updateMayannSend(List<String> conos);

}
