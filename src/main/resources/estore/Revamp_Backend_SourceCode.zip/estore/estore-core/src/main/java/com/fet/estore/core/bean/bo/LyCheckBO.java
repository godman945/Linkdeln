package com.fet.estore.core.bean.bo;

import java.io.Serializable;

import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.bean.LyCheckInputForm;
import com.fet.estore.core.bean.ValidateResult;
import com.fet.estore.core.model.Activity;
import com.fet.estore.core.model.LoyaltyRecord;

public class LyCheckBO implements Serializable {

	private static final long serialVersionUID = -197330359205178084L;
	/** 驗證輸入參數 */
	private LyCheckInputForm inputForm;
	/** 續約活動賣場資訊 */
	private Activity activity;
	/** 客資 */
	private CrmData crmData;
	/** 是否是遠傳員工 */
	private boolean isFetEmp;
//	/** 是否為員工賣場 */
//	private boolean employeeStore;
//	/** 是否為平轉 5G */
//	private boolean preExp5GMarket;
//	/** 是否為換約 */
//	private boolean changePromoOnly;	
	/** 續約記錄用結構 */
	private LoyaltyRecord loyaltyRecord;
	
	// == 以下為結果欄位 ==
	/** 是否使用預設錯誤訊息 */
	private boolean useDefaultErrMsg;
	/** 是否可續約 */
	private boolean checkLy;
	/** 是否為換約 */
	private boolean checkChange;
	/** 是否顯示續約通知按鈕 */
	private boolean showNotifyButton;
	/** 是否顯示前往繳款按鈕 */
	private boolean showToPay;
	/** 續約基本檢查結果  */
	private ValidateResult validateResult;
	
	public LyCheckInputForm getInputForm() {
		return inputForm;
	}
	public void setInputForm(LyCheckInputForm inputForm) {
		this.inputForm = inputForm;
	}
	public CrmData getCrmData() {
		return crmData;
	}
	public void setCrmData(CrmData crmData) {
		this.crmData = crmData;
	}
	public LoyaltyRecord getLoyaltyRecord() {
		return loyaltyRecord;
	}
	public void setLoyaltyRecord(LoyaltyRecord loyaltyRecord) {
		this.loyaltyRecord = loyaltyRecord;
	}

//	public boolean isEmployeeStore() {
//		return employeeStore;
//	}
//
//	public void setAllowEmployee(boolean employeeStore) {
//		this.employeeStore = employeeStore;
//	}
//
//	public boolean isPreExp5GMarket() {
//		return preExp5GMarket;
//	}
//
//	public void setPreExp5GMarket(boolean preExp5GMarket) {
//		this.preExp5GMarket = preExp5GMarket;
//	}
//
//
//	public boolean isChangePromoOnly() {
//		return changePromoOnly;
//	}
//
//	public void setChangePromoOnly(boolean changePromoOnly) {
//		this.changePromoOnly = changePromoOnly;
//	}
	public boolean isCheckChange() {
		return checkChange;
	}
	public void setCheckChange(boolean checkChange) {
		this.checkChange = checkChange;
	}
	public boolean isShowNotifyButton() {
		return showNotifyButton;
	}
	public void setShowNotifyButton(boolean showNotifyButton) {
		this.showNotifyButton = showNotifyButton;
	}
	public ValidateResult getValidateResult() {
		return validateResult;
	}
	public void setValidateResult(ValidateResult validateResult) {
		this.validateResult = validateResult;
	}
	public Activity getActivity() {
		return activity;
	}
	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	public boolean isShowToPay() {
		return showToPay;
	}
	public void setShowToPay(boolean showToPay) {
		this.showToPay = showToPay;
	}
	public boolean isCheckLy() {
		return checkLy;
	}
	public void setCheckLy(boolean checkLy) {
		this.checkLy = checkLy;
	}
	public boolean isUseDefaultErrMsg() {
		return useDefaultErrMsg;
	}
	public void setUseDefaultErrMsg(boolean isOtherErr) {
		this.useDefaultErrMsg = isOtherErr;
	}
	public boolean getIsFetEmp() {
		return isFetEmp;
	}

	public void setIsFetEmp(boolean isFetEmp) {
		this.isFetEmp = isFetEmp;
	}	
	
}
