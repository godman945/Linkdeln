package com.fet.estore.core.dao.base.impl;

import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.CoHistoryDAO;
import com.fet.estore.core.model.CoHistory;
@Repository
public class CoHistoryDAOImpl extends AbstractBaseDAO<CoHistory, String> implements CoHistoryDAO{

}
