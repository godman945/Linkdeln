package com.fet.estore.core.bean.vo.frontend.mobile;

/**
 * 
 * @author Max Chen
 *
 */
public class AICVO {

	private String rawMsisdn;
	private String rawIp;
	private String rawPort;
	
	private String msisdn;
	private String ip;
	private Integer port;
	private boolean validMsisdn;
	
	/* Webtrend參數 */
	private String WT_dcsvid;
	private String WT_seg_1;
	private String WT_seg_2;
	private String WT_seg_3;
	private String WT_seg_4;
	private String WT_seg_5;
	
	public String getRawMsisdn() {
		return rawMsisdn;
	}

	public void setRawMsisdn(String rawMsisdn) {
		this.rawMsisdn = rawMsisdn;
	}

	public String getRawIp() {
		return rawIp;
	}

	public void setRawIp(String rawIp) {
		this.rawIp = rawIp;
	}

	public String getRawPort() {
		return rawPort;
	}

	public void setRawPort(String rawPort) {
		this.rawPort = rawPort;
	}

	public String getMsisdn() {
		return msisdn;
	}
	
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	public String getIp() {
		return ip;
	}
	
	public void setIp(String ip) {
		this.ip = ip;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public boolean isValidMsisdn() {
		return validMsisdn;
	}

	public void setValidMsisdn(boolean validMsisdn) {
		this.validMsisdn = validMsisdn;
	}

	public String getWT_dcsvid() {
		return WT_dcsvid;
	}

	public void setWT_dcsvid(String wT_dcsvid) {
		WT_dcsvid = wT_dcsvid;
	}

	public String getWT_seg_1() {
		return WT_seg_1;
	}

	public void setWT_seg_1(String wT_seg_1) {
		WT_seg_1 = wT_seg_1;
	}

	public String getWT_seg_2() {
		return WT_seg_2;
	}

	public void setWT_seg_2(String wT_seg_2) {
		WT_seg_2 = wT_seg_2;
	}

	public String getWT_seg_3() {
		return WT_seg_3;
	}

	public void setWT_seg_3(String wT_seg_3) {
		WT_seg_3 = wT_seg_3;
	}

	public String getWT_seg_4() {
		return WT_seg_4;
	}

	public void setWT_seg_4(String wT_seg_4) {
		WT_seg_4 = wT_seg_4;
	}

	public String getWT_seg_5() {
		return WT_seg_5;
	}

	public void setWT_seg_5(String wT_seg_5) {
		WT_seg_5 = wT_seg_5;
	}
}
