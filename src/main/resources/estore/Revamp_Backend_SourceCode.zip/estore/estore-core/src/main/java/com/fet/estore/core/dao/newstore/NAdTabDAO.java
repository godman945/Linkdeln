package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AdCategory;
import com.fet.estore.core.model.AdTab;
import com.fet.estore.core.bean.vo.frontend.AdTabVO;

/**
 * 圖文內容的資料存取層介面。
 * 
 * @author page.tang
 */
public interface NAdTabDAO extends BaseDAO<AdTab, Integer> {

	/**
	 * 查詢頁籤對應的分類
	 * @param categoryName 分類名稱
	 * @param maxTabSize 頁籤數量
	 * @return List<AdTab>
	 * @throws Exception 
	 */
	public List<AdTabVO> findAdTabListByCategoryName(String categoryName, Integer maxTabSize) throws Exception;

	/**
	 * 查詢NDS廣告
	 * @param categoryName
	 * @return
	 * @throws Exception
	 */
	public List<AdTabVO> findNdsAdByCategoryName(String categoryName, String tabName) throws Exception;

}
