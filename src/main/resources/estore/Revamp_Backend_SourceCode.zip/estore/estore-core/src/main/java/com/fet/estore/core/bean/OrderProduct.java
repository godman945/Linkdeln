package com.fet.estore.core.bean;

import java.io.Serializable;

public class OrderProduct implements Serializable {

	private static final long serialVersionUID = -4972751428472753850L;
	//手機名稱
	private String name;
	//原價
	private Long originPrice;
	private Integer salePrice;
	//專案價
	private Long projectPrice;
	//顏色
	private String color;
	private Integer number;
	private Integer maxAmount;
	private String productId;
	private String type;
	private String defaultFetNo;
	private String slug;
	private String storeage;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getSalePrice() {
		return salePrice;
	}
	public void setSalePrice(Integer salePrice) {
		this.salePrice = salePrice;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Long getOriginPrice() {
		return originPrice;
	}
	public void setOriginPrice(Long originPrice) {
		this.originPrice = originPrice;
	}
	public Long getProjectPrice() {
		return projectPrice;
	}
	public void setProjectPrice(Long projectPrice) {
		this.projectPrice = projectPrice;
	}
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public Integer getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(Integer maxAmount) {
		this.maxAmount = maxAmount;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDefaultFetNo() {
		return defaultFetNo;
	}
	public void setDefaultFetNo(String defaultFetNo) {
		this.defaultFetNo = defaultFetNo;
	}
	public String getSlug() {
		return slug;
	}
	public void setSlug(String slug) {
		this.slug = slug;
	}
	public String getStoreage() {
		return storeage;
	}
	public void setStoreage(String storeage) {
		this.storeage = storeage;
	}
	
}
