package com.fet.estore.core.bean;

import java.io.Serializable;

public class CurrentPlan  implements Serializable {

	private static final long serialVersionUID = 3399064779260375917L;
	/** 月租費 */
    private int price;
    /** 門號 */
    private String scid;
    /** 合約到期日 */
    private String end_at;
    
    
    public CurrentPlan() {
    	
    }
    
    public CurrentPlan(int price, String scid, String end_at) {
    	this.price = price;
    	this.scid = scid;
    	this.end_at = end_at;
    }
    
    
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getScid() {
		return scid;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	public String getEnd_at() {
		return end_at;
	}
	public void setEnd_at(String end_at) {
		this.end_at = end_at;
	}
    
    
}
