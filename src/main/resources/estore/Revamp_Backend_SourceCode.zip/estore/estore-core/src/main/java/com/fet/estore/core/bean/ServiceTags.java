package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

/**
 * 首頁 - 看看大家都搜什麽 區塊
 * 
 * @description
 * @author Phil.lin
 * @date 2020-07-10
 */
public class ServiceTags implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -802071721861088209L;
	/** 標題文字 */
	String title;
	/** 標籤 */
	List<ServiceTag> tags;
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<ServiceTag> getTags() {
		return tags;
	}
	public void setTags(List<ServiceTag> tags) {
		this.tags = tags;
	}
	
	
}
