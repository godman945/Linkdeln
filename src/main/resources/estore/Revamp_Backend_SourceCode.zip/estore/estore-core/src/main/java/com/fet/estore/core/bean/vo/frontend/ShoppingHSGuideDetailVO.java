package com.fet.estore.core.bean.vo.frontend;

import java.util.LinkedHashMap;
import java.util.Map;

public class ShoppingHSGuideDetailVO {
	
	/** 折扣 */
	private Map<String, ShoppingHSGuideDiscountVO> discounts = new LinkedHashMap<String, ShoppingHSGuideDiscountVO>();
	
	/** 商品ID */
	private String productId;	
	/** 料號 */
	private String fetNo;
	/** 名稱 */
	private String name;
	/** 數量 */
	private int quantity;
	/** 小計 */
	private Long totalPrice;
	
	/** 原價 */
	private Long erpPrice;
	
	/** 折扣價 */
	private Long discPrice;
	
	
	
	public Map<String, ShoppingHSGuideDiscountVO> getDiscounts() {
		return discounts;
	}
	public void setDiscounts(Map<String, ShoppingHSGuideDiscountVO> discounts) {
		this.discounts = discounts;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	public Long getDiscPrice() {
		return discPrice;
	}
	public void setDiscPrice(Long discPrice) {
		this.discPrice = discPrice;
	}
	public Long getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}
	
}
