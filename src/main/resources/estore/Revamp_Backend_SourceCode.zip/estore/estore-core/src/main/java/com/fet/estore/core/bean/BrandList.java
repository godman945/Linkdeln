package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class BrandList implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<Brand> phone;
	private List<Brand> computer;
	private List<Brand> threeC; //前端變數命名為'3c',java變數不允許
	private List<Brand> accessories;
	
	public List<Brand> getPhone() {
		return phone;
	}
	public void setPhone(List<Brand> phone) {
		this.phone = phone;
	}
	public List<Brand> getComputer() {
		return computer;
	}
	public void setComputer(List<Brand> computer) {
		this.computer = computer;
	}
	public List<Brand> get3c() {
		return threeC;
	}
	public void set3c(List<Brand> threeC) {
		this.threeC = threeC;
	}
	public List<Brand> getAccessories() {
		return accessories;
	}
	public void setAccessories(List<Brand> accessories) {
		this.accessories = accessories;
	}
	
	

}
