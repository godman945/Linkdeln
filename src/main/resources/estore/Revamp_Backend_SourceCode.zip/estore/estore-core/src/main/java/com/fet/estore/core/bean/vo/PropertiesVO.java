package com.fet.estore.core.bean.vo;

public class PropertiesVO implements java.io.Serializable {

	private static final long serialVersionUID = 481040969903160853L;

	public static final String META_KEYWORDS = "K";
	public static final String META_TITLE = "T";
	public static final String META_DESCRIPTION = "D";
	
	private Long id;
	private String homeId;
	private String parentId;
	private String parentName;
	private String parentDisplayName;
	private String childId;
	private String childName;
	private String childDisplayName;
	private String content;
	private String title;
	private String description;
	private String failReason;
	private String name;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getHomeId() {
		return homeId;
	}
	public void setHomeId(String homeId) {
		this.homeId = homeId;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getParentDisplayName() {
		return parentDisplayName;
	}
	public void setParentDisplayName(String parentDisplayName) {
		this.parentDisplayName = parentDisplayName;
	}
	public String getChildId() {
		return childId;
	}
	public void setChildId(String childId) {
		this.childId = childId;
	}
	public String getChildName() {
		return childName;
	}
	public void setChildName(String childName) {
		this.childName = childName;
	}
	public String getChildDisplayName() {
		return childDisplayName;
	}
	public void setChildDisplayName(String childDisplayName) {
		this.childDisplayName = childDisplayName;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFailReason() {
		return failReason;
	}
	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getMobileName(){
		String name = "";
		
		// 小網各館
		if("MOBILE_HOME".equals(this.name)){
			name = "首頁";
		}else if("MOBILE_HANDSET".equals(this.name)){
			name = "手機頁";
		}else if("MOBILE_TABLET".equals(this.name)){
			name = "平板．智慧3C頁";
		}else if("MOBILE_ACCESSORY_ALONE".equals(this.name)){
			name = "配件周邊頁";
		}else if("MOBILE_LOYALTY".equals(this.name)){
			name = "老客戶頁";
		}else if("MOBILE_MSISDN".equals(this.name)){
			name = "辦門號頁";
		}
		
		return name;
	}

}
