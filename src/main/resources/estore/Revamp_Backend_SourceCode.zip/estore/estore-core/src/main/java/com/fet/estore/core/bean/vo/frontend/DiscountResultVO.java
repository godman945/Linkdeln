package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.model.AccessoryAwardItem;
import com.fet.estore.core.model.Activity;
import com.fet.estore.core.model.CouponRedeemTarget;
import com.fet.estore.core.model.MpActivity;
import com.fet.estore.core.model.MpActivityProductDiscount;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 折扣計算結果 - 結果VO
 * @author Max Chen
 *
 */
public class DiscountResultVO {

	/** 原價 */
	private Long totalErpPrice;
	/** 折扣價 */
	private Long totalDiscPrice;
	/** 折扣金額 */
	private Long totalDiscAmount;
	
	/** 可折抵金額 */
	private Long totalCanDiscPrice;
	
	/** 預繳金額 */
	private Long prepaidPrice;
	
	/** 門號競標得標價 */
	private Long auctionPrice;
	
	/** 運費 */
	private Long shipmentPrice;
	
	/** 有折HappyGo */
	private boolean hasHg;
	
	/** 是否為組合折扣活動 */
	private boolean isHsAct;
	
	/** 組合折扣活動ID */
	private Long mpActId;
	
	/** 組合折扣活動折扣金額 */
	private Long totalHSDiscAmount;
	
	private Boolean passCouponHandsetCheck;
	private Boolean passCouponAccessoryCheck;
	private Boolean passCouponPromotionCheck;
	private Boolean passCouponDeliveryTypeCheck;
	private Boolean passCouponTotalPriceCheck;
	private Boolean passCouponHandsetTotalPriceCheck;
	private Boolean passCouponAccessoryTotalPriceCheck;
	private Boolean passCouponOrderTypeCheck;
	private Boolean isCouponApplyToDevice;
	private Boolean isCouponApplyToAccessory;
	private Boolean passCouponDeviceTypeCheck;	
	private Boolean isCouponDeliveryTypeError;
	
	private List<String> couponErrorList = new ArrayList<String>();
	

	private Map<Integer, Map<String, DiscountResultProductVO>> products = new LinkedHashMap<Integer, Map<String, DiscountResultProductVO>>();
	private List<DiscountResultSetVO> sets = new ArrayList<DiscountResultSetVO>();
	private List<DiscountResultDiscountVO> discounts = new ArrayList<DiscountResultDiscountVO>();
	
	private List<DiscountResultAwardVO> offerAwards  = new ArrayList<DiscountResultAwardVO>();
	private List<DiscountResultAwardVO> giftAwards   = new ArrayList<DiscountResultAwardVO>();
	private List<DiscountResultAwardVO> couponAwards = new ArrayList<DiscountResultAwardVO>();
	
	
	/**
	 * 取得所有商品
	 * @return
	 */
	public List<DiscountResultProductVO> getProductList() {
		List<DiscountResultProductVO> list = new ArrayList<DiscountResultProductVO>();
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				list.add(prod);
			}
		}
		return list;
	}
	
	/**
	 * 取得所有商品原價
	 * @return
	 */
	public Map<String, Long> getERPPriceByFetno() {
		Map<String, Long> erpPrices = new HashMap<String, Long>();
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				String fetNo = prod.getFetNo();
				Long erpPrice = prod.getErpPrice();
				erpPrices.put(fetNo, erpPrice);
			}
		}
		return erpPrices;
	}
	
	/**
	 * 取得所有商品優惠價
	 * @return
	 */
	public Map<String, Long> getDiscountPriceByFetno() {
		Map<String, Long> discPrices = new HashMap<String, Long>();
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				String fetNo = prod.getFetNo();
				Long discPrice = prod.getDiscPrice();
				discPrices.put(fetNo, discPrice);
			}
		}
		return discPrices;
	}
	
	/**
	 * 取得所有商品單機優惠價
	 * @return
	 */
	public Map<String, Long> getDaDiscountPriceByFetno() {
		Map<String, Long> discPrices = new HashMap<String, Long>();
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				String fetNo = prod.getFetNo();
				Long discPrice = prod.getDaDiscPrice();
				discPrices.put(fetNo, discPrice);
			}
		}
		return discPrices;
	}	
	
	/**
	 * 取得Coupon折扣金額
	 * @return
	 */
	public Long getCouponDiscountPrice() {
		Long cpnDiscPrice = 0L;
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				for(DiscountResultDiscountVO prodDisc : prod.getDiscounts()) {
					if(!DiscountResultDiscountVO.TYPE_COUPON.equals(prodDisc.getType())) continue;
					cpnDiscPrice += prodDisc.getActualDiscountAmt();
				}
			}
		}
		return cpnDiscPrice;
	}
	
	/**
	 * 取得HappyGO折扣金額/點數
	 * @return LONG [金額, 點數]
	 */
	public Long[] getHgDiscountData() {
		Long hgDiscPrice = 0L;
		Long hgDiscPoints = 0L;
		
		for(DiscountResultDiscountVO disc : this.getDiscounts()) {
			if(!DiscountResultDiscountVO.TYPE_HG.equals(disc.getType())) continue;
			hgDiscPrice += disc.getActualDiscountAmt();
			hgDiscPoints += disc.getHgActPoints();
		}
		return new Long[] {hgDiscPrice, hgDiscPoints};
	}

	/**
	 * 折扣清單排序類別
	 * @author Max Chen
	 */
	private class DiscountComparator implements Comparator<DiscountResultDiscountVO> {
		private String orderPattern = "";
		public DiscountComparator() {
			String[] tpOrderArr = {
				DiscountResultDiscountVO.TYPE_OVERALL_HG    ,
				DiscountResultDiscountVO.TYPE_OVERALL_ACC   ,
				DiscountResultDiscountVO.TYPE_ACC_ACT       ,
				DiscountResultDiscountVO.TYPE_MP_DISC_FIXED ,
				DiscountResultDiscountVO.TYPE_MP_DISC_MARKUP,
				DiscountResultDiscountVO.TYPE_MP_DISC_RATIO ,
				DiscountResultDiscountVO.TYPE_MP_ACT_FIXED  ,
				DiscountResultDiscountVO.TYPE_MP_ACT_MARKUP ,
				DiscountResultDiscountVO.TYPE_MP_ACT_RATIO  ,
				DiscountResultDiscountVO.TYPE_MP_ACT_PLUS   ,
				DiscountResultDiscountVO.TYPE_EB            ,
				DiscountResultDiscountVO.TYPE_ACT           ,
				DiscountResultDiscountVO.TYPE_COUPON        ,
				DiscountResultDiscountVO.TYPE_HG            
			};
			StringBuilder sb = new StringBuilder();
			for(String tpOrder : tpOrderArr) sb.append(String.format("[%s]", tpOrder));
			orderPattern = sb.toString();
		}

		public int compare(DiscountResultDiscountVO d1, DiscountResultDiscountVO d2) {
			String t1 = String.format("[%s]", (d1.getType() != null ? d1.getType() : ""));
			String t2 = String.format("[%s]", (d2.getType() != null ? d2.getType() : ""));
			
			int idx1 = orderPattern.indexOf(t1);
			int idx2 = orderPattern.indexOf(t2);
			if(idx1 == -1) idx1 = Integer.MAX_VALUE;
			if(idx2 == -1) idx2 = Integer.MAX_VALUE;
			
			return idx1 - idx2;
		}
	}
	private DiscountComparator discComper = new DiscountComparator();
	
	/** 取得所有折扣清單 */
	public List<DiscountResultDiscountVO> getAllDiscounts() { return getDiscounts("ALL"); }
	
	/** 取得所有折扣清單, 但包含指定折扣, 及排除部份折扣 (指定折扣優先) */
	public List<DiscountResultDiscountVO> getAllDiscounts(String[] includeTypes, String[] excludeTypes) {
		List<DiscountResultDiscountVO> discs = getDiscounts("ALL");
		boolean hasIncl = includeTypes != null && includeTypes.length > 0;
		boolean hasExcl = excludeTypes != null && excludeTypes.length > 0;
		
		List<DiscountResultDiscountVO> partialDiscs = new ArrayList<DiscountResultDiscountVO>();
		for(DiscountResultDiscountVO disc : discs) {
			String type = disc.getType();
			if(hasIncl && !StringUtil.isInList(includeTypes, type)) continue;
			if(hasExcl &&  StringUtil.isInList(excludeTypes, type)) continue;
			partialDiscs.add(disc);
		}
		
		return partialDiscs; 
	}
	
	/** 取得各折扣清單 */
	private List<DiscountResultDiscountVO> getDiscounts(String discType) {
		List<DiscountResultDiscountVO> discs = new ArrayList<DiscountResultDiscountVO>();
		if(discType == null) return discs;
		
		for(DiscountResultDiscountVO disc : discounts) {
			String type = disc.getType();
			Long actDisc = disc.getActualDiscountAmt();
			boolean isCpn = DiscountResultDiscountVO.TYPE_COUPON.equals(type);
			if(actDisc == null || (actDisc == 0L && !isCpn)) continue;			
			if(discType.equals(type) || "ALL".equals(discType)) discs.add(disc);
		}
		
		// 組合活動折扣
		for(DiscountResultSetVO set : sets) {
			List<DiscountResultDiscountVO> setdiscs = set.getDiscounts();
			for(DiscountResultDiscountVO disc : setdiscs) {
				Long actDisc = disc.getActualDiscountAmt();
				if(actDisc == null || actDisc == 0L) continue;
				discs.add(disc);
			}
		}
		
		String[] mpTypes = new String[] {DiscountResultDiscountVO.TYPE_MP_ACT_FIXED, 
										 DiscountResultDiscountVO.TYPE_MP_ACT_MARKUP, 
                                     	 DiscountResultDiscountVO.TYPE_MP_ACT_RATIO,
                                     	 DiscountResultDiscountVO.TYPE_MP_ACT_PLUS };
		
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				
				for(DiscountResultDiscountVO disc : prod.getDiscounts()) {
					String type = disc.getType();
					Long actDisc = disc.getActualDiscountAmt();
					if(actDisc == null || actDisc == 0L) continue;
					if(StringUtil.isInList(mpTypes, type)) continue; // 略過組合活動
					if(discType.equals(type) || "ALL".equals(discType)) discs.add(disc);
				}
			}
		}
		
		// 依特定折扣排序
		Collections.sort(discs, discComper);
		
		return discs;
	}
	
	/**
	 * 贈品清單排序類別
	 * @author Max Chen
	 */
	private class AwardComparator implements Comparator<DiscountResultAwardVO> {
		private String orderPattern = "";
		public AwardComparator() {
			String[] tpOrderArr = {
				Activity.AWARD_ITEM_AWARD_TYPE_GIFT,
				Activity.AWARD_ITEM_AWARD_TYPE_COUPON,
				Activity.AWARD_ITEM_AWARD_TYPE_OFFER         
			};
			StringBuilder sb = new StringBuilder();
			for(String tpOrder : tpOrderArr) sb.append(String.format("[%s]", tpOrder));
			orderPattern = sb.toString();
		}

		public int compare(DiscountResultAwardVO d1, DiscountResultAwardVO d2) {
			String t1 = String.format("[%s]", (d1.getType() != null ? d1.getType() : ""));
			String t2 = String.format("[%s]", (d2.getType() != null ? d2.getType() : ""));
			
			int idx1 = orderPattern.indexOf(t1);
			int idx2 = orderPattern.indexOf(t2);
			if(idx1 == -1) idx1 = Integer.MAX_VALUE;
			if(idx2 == -1) idx2 = Integer.MAX_VALUE;
			
			return idx1 - idx2;
		}
	}
	private AwardComparator awardComper = new AwardComparator();	

	/** 取得贈品清單 */
	public List<DiscountResultAwardVO> getGiftAwards  () { return getAwards(Activity.AWARD_ITEM_AWARD_TYPE_GIFT  ); }
	/** 取得帳單折抵清單 */
	public List<DiscountResultAwardVO> getOfferAwards () { return getAwards(Activity.AWARD_ITEM_AWARD_TYPE_OFFER ); }
	/** 取得優惠券清單 */
	public List<DiscountResultAwardVO> getCouponAwards() { return getAwards(Activity.AWARD_ITEM_AWARD_TYPE_COUPON); }
	
	/** 取得所有贈品清單 */
	public List<DiscountResultAwardVO> getAllAwards() { return getAwards("ALL"); }
	
	/** 取得各贈品清單 */
	public List<DiscountResultAwardVO> getAwards(String awardType) {
		List<DiscountResultAwardVO> awards = new ArrayList<DiscountResultAwardVO>();
		
		if(Activity.AWARD_ITEM_AWARD_TYPE_COUPON.equals(awardType) || "ALL".equals(awardType)) awards.addAll(couponAwards);
		if(Activity.AWARD_ITEM_AWARD_TYPE_GIFT  .equals(awardType) || "ALL".equals(awardType)) awards.addAll(giftAwards  );
		if(Activity.AWARD_ITEM_AWARD_TYPE_OFFER .equals(awardType) || "ALL".equals(awardType)) awards.addAll(offerAwards );
		
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				
				if(Activity.AWARD_ITEM_AWARD_TYPE_COUPON.equals(awardType) || "ALL".equals(awardType)) awards.addAll(prod.getCouponAwards());
				if(Activity.AWARD_ITEM_AWARD_TYPE_GIFT  .equals(awardType) || "ALL".equals(awardType)) awards.addAll(prod.getGiftAwards());
				if(Activity.AWARD_ITEM_AWARD_TYPE_OFFER .equals(awardType) || "ALL".equals(awardType)) awards.addAll(prod.getOfferAwards());
			}
		}
		
		// 排序贈品
		Collections.sort(awards, awardComper);
		
		return awards;
	}

	/**
	 * 計算全館折扣
	 * @param id
	 * @param discCode
	 * @param discRatio
	 * @param isAcc
	 */
	public void setOverAllDiscount(Long id, String discCode, double discRatio, Long costCenterId, String discountName, boolean isAcc) {
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				Long discPrice = prod.getDiscPrice();
				if(prod.getPremiumId() != null) continue;
				if(discPrice == null) continue;
				if(prod.isAcc() != isAcc) continue;

				// 計算折扣 
				long discAmount = discPrice - new Double(Math.floor(discPrice * discRatio)).longValue();
				long actDiscAmount = discPrice >= discAmount ? discAmount : discPrice;
				long finalDiscPrice = discPrice - actDiscAmount;
				prod.setDiscPrice(finalDiscPrice);
				prod.setDiscAmount(prod.getDiscAmount() + actDiscAmount);
				
				// 記錄折扣
				DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
				discVO.setType(!isAcc ? DiscountResultDiscountVO.TYPE_OVERALL_HG : 
					                    DiscountResultDiscountVO.TYPE_OVERALL_ACC); 
				discVO.setDiscountCode(discCode);
				discVO.setDiscountRatio(discRatio);
				discVO.setActualDiscountAmt(actDiscAmount);
				discVO.setCostCenterId(costCenterId);
				discVO.setDiscountName(discountName);
				discVO.loggingDiscount(discPrice, finalDiscPrice);
				prod.getDiscounts().add(discVO);
			}
		}
		
		this.updateResultPrice();
	}
	
	/**
	 * 計算配件折扣
	 * @param accActMap
	 */
	public void setAccActDiscount(Map<String, AccessoryActivityVO> accActMap) {
		if(accActMap == null) return;
		
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				if(prod.getPremiumId() != null) continue;
				if(!prod.isAcc()) continue;
				String productId = prod.getProductId();
				AccessoryActivityVO accActVO = accActMap.get(productId);
				if(accActVO == null) continue;
				Long discPrice = prod.getDiscPrice();
				if(discPrice == null) continue;
				
				// 計算折扣
				long discAmount = accActVO.getDiscAmt() != null ? accActVO.getDiscAmt() : 0L;
				long actDiscAmount = discPrice >= discAmount ? discAmount : discPrice;
				long finalDiscPrice = discPrice - actDiscAmount;
				prod.setDiscPrice(finalDiscPrice);
				prod.setDiscAmount(prod.getDiscAmount() + actDiscAmount);
				
				// 記錄折扣
				DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
				discVO.setType(DiscountResultDiscountVO.TYPE_ACC_ACT); 
				discVO.setDiscountCode(accActVO.getDiscCode());
				discVO.setDiscountAmt(accActVO.getDiscAmt());
				discVO.setActualDiscountAmt(actDiscAmount);
				discVO.setCostCenterId(accActVO.getCostCenterId());
				discVO.setDiscountName(accActVO.getDiscountName());
				discVO.setAccActId(accActVO.getId());
				discVO.loggingDiscount(discPrice, finalDiscPrice);
				prod.getDiscounts().add(discVO);
			}
		}
		
		this.updateResultPrice();
	}
	
	/**
	 * 計算加價購折扣
	 * @param type
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setMpMarkupDiscount(Map<Long, MpActivityProductDiscountVO> markupDiscounts) {
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				Long discPrice = prod.getDiscPrice();
				Long mpDiscId = prod.getMpDiscId();
				if(discPrice == null || mpDiscId == null) continue;
				MpActivityProductDiscountVO mpDiscVO = markupDiscounts.get(mpDiscId);
				if(mpDiscVO == null) continue;
				Long mpDiscAmt = mpDiscVO.getDiscountAmount();
				Double mpDiscRatio = mpDiscVO.getDiscountRatio();
				Long mpMarkupAmt = mpDiscVO.getMarkupAmount();
				
				// 取得折扣類型
				String type = mpDiscVO.getDiscountType();
				boolean isFixed  = MpActivityProductDiscount.DISCOUNT_TYPE_FIXED.equals(type) && mpDiscAmt != null;
				boolean isRatio  = MpActivityProductDiscount.DISCOUNT_TYPE_RATIO.equals(type) && mpDiscRatio != null;
				boolean isMarkup = MpActivityProductDiscount.DISCOUNT_TYPE_MARKUP.equals(type) && mpMarkupAmt != null;
				if(!isFixed && !isRatio && !isMarkup) continue;
				
				// 計算折扣
				long discAmount = 0L;
				if(isFixed ) discAmount = mpDiscAmt;
				if(isRatio ) discAmount = discPrice - new Double(Math.floor(discPrice * mpDiscRatio)).longValue();
				if(isMarkup) discAmount = (discPrice >= mpMarkupAmt ? discPrice - mpMarkupAmt : 0L);
				long actDiscAmount = discPrice >= discAmount ? discAmount : discPrice;
				long finalDiscPrice = discPrice - actDiscAmount;
				prod.setDiscPrice(finalDiscPrice);
				prod.setDiscAmount(prod.getDiscAmount() + actDiscAmount);
				
				// 記錄折扣
				String discType = isFixed  ? DiscountResultDiscountVO.TYPE_MP_DISC_FIXED : 
                                  isRatio  ? DiscountResultDiscountVO.TYPE_MP_DISC_RATIO :  
	                              isMarkup ? DiscountResultDiscountVO.TYPE_MP_DISC_MARKUP : null;				
				DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
				discVO.setType(discType); 
				discVO.setDiscountCode(mpDiscVO.getDiscountCode()); // FIXME
				discVO.setDiscountRatio(mpDiscRatio);
				discVO.setDiscountAmt(actDiscAmount);
				discVO.setActualDiscountAmt(actDiscAmount);
				discVO.setCostCenterId(mpDiscVO.getCostCenterId());
				discVO.setDiscountName(mpDiscVO.getDiscountName());
				discVO.setMpDiscId(mpDiscVO.getId());
				discVO.setMpActId(mpDiscVO.getActId());
				discVO.loggingDiscount(discPrice, finalDiscPrice);
				prod.getDiscounts().add(discVO);
			}
		}
	}
	
	/**
	 * 計算NDS加價購折扣
	 * @param type
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setExtraBuyDiscount(List<ExtraBuyDiscountVO> ebDiscs) {
		if(ebDiscs == null) { return; }
		
		for(ExtraBuyDiscountVO ebDisc : ebDiscs) {
			String discType = DiscountResultDiscountVO.TYPE_EB;
			String code = ebDisc.getCode();
			String name = ebDisc.getName();
			Long ccid = null; // FIXME
			
			Long discAmount = ebDisc.getDiscAmount();
			Double discRatio = ebDisc.getDiscRatio();
			Long amount = ebDisc.getAmount();
			String dispGrp = ebDisc.getDisplayGroup();
			
			DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
			discVO.setType(discType); 
			discVO.setDiscountCode(code);
			discVO.setDiscountRatio(discRatio);
			discVO.setDiscountAmt(discAmount);
			discVO.setActualDiscountAmt(amount);
			discVO.setCostCenterId(ccid);
			discVO.setDiscountName(name);
			discVO.setEbDisplayGroup(dispGrp);
			// discVO.loggingDiscount(discPrice, amount);
			discounts.add(discVO);
		}
		
		this.updateResultPrice();
	}
	
	/**
	 * 計算專屬優惠折扣
	 * @param type
	 */
	public void setPremiumDiscount(List<ActivityPremiumVO> volist) {
		if(volist == null) { return; }
		
		Map<Long, ActivityPremiumVO> voMap = new LinkedHashMap<>();
		for(ActivityPremiumVO vo : volist) { voMap.put(vo.getId(), vo); }

		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				Long discPrice = prod.getDiscPrice();
				if(discPrice == null) continue;
				
				Long premiumId = prod.getPremiumId();
				if(premiumId == null) { continue; }
				
				ActivityPremiumVO vo = voMap.get(premiumId);
				if(vo == null) { continue; }
				Integer voDiscAmount = vo.getDiscountAmount();
				Double  voDiscRatio  = vo.getDiscountRation();

				// 計算折扣 
				long actDiscAmount = 0;
				if(voDiscAmount != null) {
					actDiscAmount = Math.min(discPrice, voDiscAmount);
				}
				if(voDiscRatio != null) {
					actDiscAmount = discPrice - new Double(Math.floor(discPrice * voDiscRatio)).longValue();
				}
				long finalDiscPrice = discPrice - actDiscAmount;
				prod.setDiscPrice(finalDiscPrice);
				prod.setDiscAmount(prod.getDiscAmount() + actDiscAmount);
				
				// 記錄折扣
				List<ActivityPremiumDiscountVO> dvoList = vo.getDiscounts();
				long tmpDiscAmount = actDiscAmount;
				for(int i = 0; i < dvoList.size(); i++) {
					ActivityPremiumDiscountVO dvo = dvoList.get(i);
					String discCode = dvo.getDiscountCode();
					Double share = dvo.getShare();
					String discName = dvo.getName();
					if(share == null) { continue; }
					
					boolean last = i == dvoList.size() - 1;
					
					long shareDiscAmt = 0L;
					if( last) { shareDiscAmt = tmpDiscAmount; }
					if(!last) { shareDiscAmt = new Double(actDiscAmount * share).longValue(); }
					tmpDiscAmount -= shareDiscAmt;
					
					DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
					discVO.setType(DiscountResultDiscountVO.TYPE_PREMIUM); 
					discVO.setDiscountCode(discCode);
					discVO.setDiscountRatio(voDiscRatio);
					discVO.setDiscountAmt(shareDiscAmt);
					discVO.setActualDiscountAmt(shareDiscAmt);
					discVO.setCostCenterId(null);
					discVO.setDiscountName(discName);
					discVO.loggingDiscount(discPrice, finalDiscPrice);
					prod.getDiscounts().add(discVO);
				}
			}
		}
		
		this.updateResultPrice();
	}
	
	private static Comparator<DiscountResultProductVO> discPriceComper = new Comparator<DiscountResultProductVO>() {
		public int compare(DiscountResultProductVO o1, DiscountResultProductVO o2) {
			long l1 = o1 != null && o1.getDiscPrice() != null ? o1.getDiscPrice() : -1L;
			long l2 = o2 != null && o2.getDiscPrice() != null ? o2.getDiscPrice() : -1L;
			
			return l1 > l2 ? -1 :
				   l1 < l2 ?  1 : 0;
		}
	};
	
	/**
	 * 計算多組組合折扣
	 * @param type
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setMpActDiscount(String type, Long actId, String discountCode, Double discountRatio, Long discountAmount, Long costCenterId, String discName, Map<Integer, String> grpNames) {
		if(products.size() < 2) return;
		boolean isFixed  = MpActivity.DISCOUNT_TYPE_FIXED.equals(type) && discountAmount != null;
		boolean isRatio  = MpActivity.DISCOUNT_TYPE_RATIO.equals(type) && discountRatio != null;
		boolean isMarkup = MpActivity.DISCOUNT_TYPE_MARKUP.equals(type) && discountAmount != null;
		boolean isPlus   = MpActivity.DISCOUNT_TYPE_PLUS .equals(type) && discountAmount != null;
		
		boolean validType = isFixed || isRatio || isMarkup || isPlus;
		if(!validType) return;
		
		// 所有群組複製後, 依折扣後價格排序(高 -> 低)
		Map<Integer, List<DiscountResultProductVO>> sortedProducts = new LinkedHashMap<Integer, List<DiscountResultProductVO>>();
		for(Integer grp : products.keySet()) {
			if(!sortedProducts.containsKey(grp)) sortedProducts.put(grp, new ArrayList<DiscountResultProductVO>());
			List<DiscountResultProductVO> list = sortedProducts.get(grp);
			list.addAll(products.get(grp).values());
			Collections.sort(list, discPriceComper); 
		}		
		
		// 取得組數
		int setcnt = Integer.MAX_VALUE;
		for(Integer grp : sortedProducts.keySet()) {
			int grpcnt = sortedProducts.get(grp).size();
			setcnt = Math.min(setcnt, grpcnt);
		}
		if(setcnt == 0) return;
		
		// 建立群組
		for(int i = 0; i < setcnt; i++) {			
			DiscountResultSetVO set = new DiscountResultSetVO(); 
			for(Integer grp : sortedProducts.keySet()) {
				DiscountResultProductVO prod = sortedProducts.get(grp).get(i);
				String grpName = grpNames != null ? grpNames.get(grp) : null; // 群組名稱
				prod.setGrpName(grpName);
				set.getProducts().add(prod);
			}
			sets.add(set);
		}
		
		// 計算折扣
		for(DiscountResultSetVO set : sets) {
			long setDiscPrice = 0L;
			long setErpPrice = 0L;
			List<DiscountResultProductVO> prods = set.getProducts();
			boolean firstProd = true;
			long setPlusDisc = 0L; 
			for(DiscountResultProductVO vo : prods) {
				if(vo.getDiscPrice() == null || vo.getErpPrice() == null) continue;
				setDiscPrice += vo.getDiscPrice();
				setErpPrice += vo.getErpPrice();
				vo.setInSet(true); // 在組合之中
				
				if(isPlus && !firstProd && vo.getDiscPrice() != null) {
					setPlusDisc += (vo.getDiscPrice() - Math.min(vo.getDiscPrice(), discountAmount));
				}
				firstProd = false;
			}
			
			long discAmount = isRatio  ? setDiscPrice - new Double(Math.floor(setDiscPrice * discountRatio)).longValue() :
				              isFixed  ? discountAmount : 
				              isMarkup ? (setDiscPrice >= discountAmount ? setDiscPrice - discountAmount : 0L) :
				              isPlus   ? setPlusDisc :
				              0L;
			long actDiscAmount = setDiscPrice >= discAmount ? discAmount : setDiscPrice;
			
			// 組合折扣再回頭折進設備(分比例)
			long tmpFinalDiscAmt = actDiscAmount;
			for(int i = 0; i < prods.size(); i++) {
				DiscountResultProductVO vo = prods.get(i);
				Long prodDiscPrice = vo.getDiscPrice();
				Long prodErpPrice = vo.getErpPrice();
				if(prodDiscPrice == null || prodErpPrice == null || setErpPrice == 0) continue;
				
				boolean last = (i == prods.size() - 1);
				boolean first = (i == 0);
				long restDiscAmt = last                ? tmpFinalDiscAmt : 
		                           isRatio             ? prodDiscPrice - new Double(Math.floor(prodDiscPrice * discountRatio)).longValue() :
		                           (isPlus && !first)  ? prodDiscPrice - Math.min(prodDiscPrice, discountAmount) :
		                           isFixed || isMarkup ? new Double((double)actDiscAmount * (double)prodErpPrice / (double)setErpPrice).longValue() : 0L;
		                           
				restDiscAmt = prodDiscPrice >= restDiscAmt ? restDiscAmt : prodDiscPrice;				
				tmpFinalDiscAmt -= restDiscAmt;
				long restDiscPrice = prodDiscPrice - restDiscAmt;
				vo.setDiscPrice(restDiscPrice);
				vo.setDiscAmount(vo.getDiscAmount() + restDiscAmt);
				
				// 記錄折扣
				String discType = isFixed  ? DiscountResultDiscountVO.TYPE_MP_ACT_FIXED : 
                                  isRatio  ? DiscountResultDiscountVO.TYPE_MP_ACT_RATIO :  
	                              isMarkup ? DiscountResultDiscountVO.TYPE_MP_ACT_MARKUP : 
	                              isPlus   ? DiscountResultDiscountVO.TYPE_MP_ACT_PLUS   : null;
				DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
				discVO.setType(discType); 
				discVO.setDiscountCode(discountCode);
				discVO.setDiscountAmt(restDiscAmt);
				discVO.setDiscountRatio(discountRatio);
				discVO.setActualDiscountAmt(restDiscAmt);
				discVO.setCostCenterId(costCenterId);
				discVO.setDiscountName(discName);
				discVO.setMpActId(actId);
				discVO.loggingDiscount(prodDiscPrice, restDiscPrice, setErpPrice, prodErpPrice, actDiscAmount, last, discountRatio);
				vo.getDiscounts().add(discVO);
			}			
			
			// 記錄折扣
			String discType = isFixed  ? DiscountResultDiscountVO.TYPE_MP_ACT_FIXED : 
		                      isRatio  ? DiscountResultDiscountVO.TYPE_MP_ACT_RATIO :  
			                  isMarkup ? DiscountResultDiscountVO.TYPE_MP_ACT_MARKUP : 
			                  isPlus   ? DiscountResultDiscountVO.TYPE_MP_ACT_PLUS   : null;
			DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
			discVO.setType(discType); 
			discVO.setDiscountCode(discountCode);
			discVO.setDiscountAmt(discAmount);
			discVO.setDiscountRatio(discountRatio);
			discVO.setActualDiscountAmt(actDiscAmount);
			discVO.setCostCenterId(costCenterId);
			discVO.setDiscountName(discName);
			discVO.setMpActId(actId);
			set.getDiscounts().add(discVO);
		}
		
		this.updateResultPrice();
	}
	
	/**
	 * 計算單組組合折扣
	 * @param type
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setMpActAloneDiscount(String type, Long actId, String discountCode, Double discountRatio, Long discountAmount, int minChoice, Long costCenterId, String discName, String grpName) {
		if(products.size() != 1 || minChoice < 1) return;
		
		boolean isFixed  = MpActivity.DISCOUNT_TYPE_FIXED.equals(type) && discountAmount != null;
		boolean isRatio  = MpActivity.DISCOUNT_TYPE_RATIO.equals(type) && discountRatio != null;
		boolean isMarkup = MpActivity.DISCOUNT_TYPE_MARKUP.equals(type) && discountAmount != null;
		
		boolean validType = isFixed || isRatio || isMarkup;
		if(!validType) return;
		
		// 所有商品複製後, 依折扣後價格排序(高 -> 低)
		List<DiscountResultProductVO> sortedProducts = new ArrayList<DiscountResultProductVO>();		
		for(Integer grp : products.keySet()) {
			sortedProducts.addAll(products.get(grp).values());
			Collections.sort(sortedProducts, discPriceComper); 
			break;
		}		
		
		// 取得組數
		int setcnt = sortedProducts.size() / minChoice;
		if(setcnt == 0) return;
		
		// 建立群組
		for(int i = 0; i < setcnt; i++) sets.add(new DiscountResultSetVO());
		for(int i = 0; i < sortedProducts.size(); i++) {
			int grpidx = i / minChoice;
			if(grpidx >= sets.size()) continue;
			DiscountResultProductVO prod = sortedProducts.get(i);
			prod.setGrpName(grpName);
			sets.get(grpidx).getProducts().add(prod);
		}
		
		// 計算折扣
		for(DiscountResultSetVO set : sets) {
			long setDiscPrice = 0L;
			long setErpPrice = 0L;
			List<DiscountResultProductVO> prods = set.getProducts();
			for(DiscountResultProductVO vo : prods) {
				if(vo.getDiscPrice() == null || vo.getErpPrice() == null) continue;
				setDiscPrice += vo.getDiscPrice();
				setErpPrice += vo.getErpPrice();
				vo.setInSet(true); // 在組合之中
			}
			
			long discAmount = isRatio  ? setDiscPrice - new Double(Math.floor(setDiscPrice * discountRatio)).longValue() :
				              isFixed  ? discountAmount : 
				              isMarkup ? (setDiscPrice >= discountAmount ? setDiscPrice - discountAmount : 0L) :
				              0L;
			long actDiscAmount = setDiscPrice >= discAmount ? discAmount : setDiscPrice;

			// 組合折扣再回頭折進設備(分比例)
			long tmpFinalDiscAmt = actDiscAmount;
			for(int i = 0; i < prods.size(); i++) {
				DiscountResultProductVO vo = prods.get(i);
				Long prodDiscPrice = vo.getDiscPrice();
				Long prodErpPrice = vo.getErpPrice();
				if(prodDiscPrice == null || prodErpPrice == null || setErpPrice == 0) continue;
				
				boolean last = (i == prods.size() - 1);
				long restDiscAmt = last                ? tmpFinalDiscAmt : 
					               isRatio             ? prodDiscPrice - new Double(Math.floor(prodDiscPrice * discountRatio)).longValue() :
					               isFixed || isMarkup ? new Double((double)actDiscAmount * (double)prodErpPrice / (double)setErpPrice).longValue() : 0L;

				restDiscAmt = prodDiscPrice >= restDiscAmt ? restDiscAmt : prodDiscPrice;	
				tmpFinalDiscAmt -= restDiscAmt;
				long restDiscPrice = prodDiscPrice - restDiscAmt;
				vo.setDiscPrice(restDiscPrice);
				vo.setDiscAmount(vo.getDiscAmount() + restDiscAmt);
				
				// 記錄折扣
				String discType = isFixed  ? DiscountResultDiscountVO.TYPE_MP_ACT_FIXED : 
                                  isRatio  ? DiscountResultDiscountVO.TYPE_MP_ACT_RATIO :  
	                              isMarkup ? DiscountResultDiscountVO.TYPE_MP_ACT_MARKUP : null;
				DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
				discVO.setType(discType); 
				discVO.setDiscountCode(discountCode);
				discVO.setDiscountAmt(restDiscAmt);
				discVO.setDiscountRatio(discountRatio);
				discVO.setActualDiscountAmt(restDiscAmt);
				discVO.setCostCenterId(costCenterId);
				discVO.setDiscountName(discName);
				discVO.setMpActId(actId);
				discVO.loggingDiscount(prodDiscPrice, restDiscPrice, setErpPrice, prodErpPrice, actDiscAmount, last, discountRatio);
				vo.getDiscounts().add(discVO);
			}				
			
			// 記錄折扣
			String discType = isFixed  ? DiscountResultDiscountVO.TYPE_MP_ACT_FIXED : 
		                      isRatio  ? DiscountResultDiscountVO.TYPE_MP_ACT_RATIO :  
			                  isMarkup ? DiscountResultDiscountVO.TYPE_MP_ACT_MARKUP : null;
			DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
			discVO.setType(discType); 
			discVO.setDiscountCode(discountCode);
			discVO.setDiscountAmt(discAmount);
			discVO.setDiscountRatio(discountRatio);
			discVO.setActualDiscountAmt(actDiscAmount);
			discVO.setCostCenterId(costCenterId);
			discVO.setDiscountName(discName);
			discVO.setMpActId(actId);
			set.getDiscounts().add(discVO);
		}
		
		this.updateResultPrice();
	}	

	/**
	 * 計算促銷活動折扣
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setActDiscount(DiscountVO dscVO, boolean isAcc) {
		if(dscVO == null) return;
		Map<String, Map<String, Set<DiscountItemVO>>> prodDiscMap = dscVO.getProductDiscountMap();
		if(prodDiscMap == null || prodDiscMap.isEmpty()) return;
		
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				if(prod.isAcc() != isAcc) continue;
				if(prod.getPremiumId() != null) continue;
				
				String discTp = !isAcc ? Activity.AWARD_ITEM_AWARD_TYPE_DEVICEDISCOUNT : 
					                     Activity.AWARD_ITEM_AWARD_TYPE_ACCESSORYDSICOUNT;
				String prodId = prod.getProductId(); 
				Set<DiscountItemVO> discountItems = prodDiscMap.get(prodId) != null && prodDiscMap.get(prodId).get(discTp) != null ? 
	                       							prodDiscMap.get(prodId).get(discTp) : new LinkedHashSet<DiscountItemVO>();
				for(DiscountItemVO item : discountItems) {
					if(item == null) continue;					
					Long discPrice = prod.getDiscPrice();
					if(discPrice == null || discPrice == 0L) continue;					
					
					// 計算折扣 
					long discAmount = item.getAmount();
					long actDiscAmount = discPrice >= discAmount ? discAmount : discPrice;
					long finalDiscPrice = discPrice - actDiscAmount;
					prod.setDiscPrice(finalDiscPrice);
					prod.setDiscAmount(prod.getDiscAmount() + actDiscAmount);
					
					// 記錄折扣
					DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
					discVO.setType(DiscountResultDiscountVO.TYPE_ACT); 
					discVO.setDiscountCode(item.getCode());
					discVO.setDiscountAmt(item.getAmount());
					discVO.setActualDiscountAmt(actDiscAmount);
					discVO.setActId(item.getActivityId());
					discVO.setCostCenterId(item.getCostCenterId());
					discVO.setDiscountName(item.getDiscountName());
					discVO.loggingDiscount(discPrice, finalDiscPrice);
					prod.getDiscounts().add(discVO);
				}
			}
		}
		
		this.updateResultPrice();
	}
	
	/**
	 * 計算合併商品活動之促銷活動折扣
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setActDiscountForMpAct(DiscountVO dscVO) {
		if(dscVO == null) return;
		Map<String, Map<String, Set<DiscountItemVO>>> prodDiscMap = dscVO.getProductDiscountMap();
		if(prodDiscMap == null || prodDiscMap.isEmpty()) return;
		
		for(DiscountResultSetVO set : sets) {
			// 取得組合可用之折扣
			Map<Integer, List<Integer>> setDiscMapping = new LinkedHashMap<Integer, List<Integer>>();
			List<DiscountItemVO> setDiscs = new ArrayList<DiscountItemVO>();
			List<DiscountResultProductVO> prods = set.getProducts();
			for(int i = 0; i < prods.size(); i++) {
				DiscountResultProductVO prod = prods.get(i);
				boolean isAcc = prod.isAcc();
				String discTp = !isAcc ? Activity.AWARD_ITEM_AWARD_TYPE_DEVICEDISCOUNT : 
					                     Activity.AWARD_ITEM_AWARD_TYPE_ACCESSORYDSICOUNT;
				String prodId = prod.getProductId();
				Set<DiscountItemVO> prodDiscs = prodDiscMap.get(prodId) != null && prodDiscMap.get(prodId).get(discTp) != null ? 
												prodDiscMap.get(prodId).get(discTp) : new LinkedHashSet<DiscountItemVO>();
				
				// 記錄折扣可折之商品
				for(DiscountItemVO prodDisc : prodDiscs) {
					int setDiscIdx = -1;
					for(int j = 0; j < setDiscs.size(); j++) {
						DiscountItemVO setDisc = setDiscs.get(j);
						if(setDisc != prodDisc) continue;
						setDiscIdx = j;
						break;
					}
					
					if(setDiscIdx == -1) { // 加入清單
						setDiscIdx = setDiscs.size();
						setDiscs.add(prodDisc);
					}
					
					if(!setDiscMapping.containsKey(setDiscIdx)) setDiscMapping.put(setDiscIdx, new ArrayList<Integer>());
					setDiscMapping.get(setDiscIdx).add(i);
				}
			}
			
			// 開始折商品金額
			for(Integer setDiscIdx : setDiscMapping.keySet()) { 
				if(setDiscIdx == null) continue;
				DiscountItemVO setDisc = setDiscs.get(setDiscIdx);
				long setDiscAmt = setDisc.getAmount() != null ? setDisc.getAmount() : 0L;
				String discCode = setDisc.getCode();
				Long setCostCenterId = setDisc.getCostCenterId();
				String setDiscName = setDisc.getDiscountName();
				Long setActId = setDisc.getActivityId();
				
				for(int i = 0; i < setDiscMapping.get(setDiscIdx).size(); i++) {
					Integer prodIdx = setDiscMapping.get(setDiscIdx).get(i);
					if(setDiscAmt == 0L) continue;
					
					DiscountResultProductVO prod = prods.get(prodIdx);
					Long discPrice = prod.getDiscPrice();
					if(discPrice == null) continue;				
					
					long actDiscAmount = discPrice >= setDiscAmt ? setDiscAmt : discPrice;
					long finalDiscPrice = discPrice - actDiscAmount;
					prod.setDiscPrice(finalDiscPrice);
					prod.setDiscAmount(prod.getDiscAmount() + actDiscAmount);
					
					// 記錄折扣				
					DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
					discVO.setType(DiscountResultDiscountVO.TYPE_ACT); 
					discVO.setDiscountCode(discCode); 
					discVO.setDiscountAmt(setDiscAmt);
					discVO.setActualDiscountAmt(actDiscAmount);
					discVO.setCostCenterId(setCostCenterId);
					discVO.setDiscountName(setDiscName);
					discVO.setActId(setActId);
					discVO.loggingDiscount(discPrice, finalDiscPrice);
					prod.getDiscounts().add(discVO);
					
					setDiscAmt -= actDiscAmount; // 已折掉
				}
			}
		}
		this.updateResultPrice();
	}	
	
	/**
	 * 計算折價券折扣
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setCouponDiscount(CouponVO cpn, String couponSn, String orderType, String oplId, String deliveryType, long prodVaPrice, long prepaidPrice) {
		this.updateResultPrice();
		if(cpn == null || totalDiscPrice == null) return;

		boolean allowDev = cpn.isDeviceAllow();
		boolean allowAcc = cpn.isAccessoryAllow(); 
		
		// coupon限制條件清單
		String[] types = new String[] {
			CouponRedeemTarget.REDEEM_TARGET_TYPE_ORDER_TYPE,
			CouponRedeemTarget.REDEEM_TARGET_TYPE_PROMOTION,
			CouponRedeemTarget.REDEEM_TARGET_TYPE_DEVICE,
			CouponRedeemTarget.REDEEM_TARGET_TYPE_ACCESSORY,
			CouponRedeemTarget.REDEEM_TARGET_TYPE_DELIVERY_TYPE,
		};
		
		// 取得coupon條件
		Map<String, Set<String>> targetMap = new HashMap<String, Set<String>>();
		for(String type : types) {
			targetMap.put(type, new HashSet<String>());
			targetMap.get(type).add("ALL");
		}
		Set<CouponRedeemTargetVO> targets = cpn.getCouponRedeemTargets();
		for(CouponRedeemTargetVO target : targets) {
			String type = target.getType();
			String targetId = target.getTargetId();
			if(!StringUtil.isInList(types, type) || targetId == null) continue;
			
			Set<String> targetSet = targetMap.get(type);
			targetSet.remove("ALL");
			targetSet.add(targetId);
		}
		Set<String> otTargetSet  = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_ORDER_TYPE);
		Set<String> devTargetSet = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_DEVICE);
		Set<String> accTargetSet = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_ACCESSORY);
		Set<String> dlvTargetSet = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_DELIVERY_TYPE);
		Set<String> prmTargetSet = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_PROMOTION);

		// 不允許設備或配件時, 清除條件(包含ALL)
		if(!allowDev) devTargetSet.clear();
		if(!allowAcc) accTargetSet.clear();
		
		// 取得各條件
		//boolean isDev   = StringUtil.isInList(new String[] {"NH", "PH", "LH", "DA" }, orderType);
		boolean isPromo = StringUtil.isInList(new String[] {"NC", "PC", "LC"       }, orderType);
		boolean isDa    = StringUtil.isInList(new String[] {"DA"                   }, orderType);
		
		boolean allDev = devTargetSet.contains("ALL");
		boolean allOt  = otTargetSet .contains("ALL");
		boolean allAcc = accTargetSet.contains("ALL");
		boolean allPrm = prmTargetSet.contains("ALL");
		boolean allDlv = dlvTargetSet.contains("ALL");
		boolean nonDev = devTargetSet.isEmpty();
		boolean nonAcc = accTargetSet.isEmpty();		
		
		deliveryType = deliveryType == null     ? "ALL"   :
				       "H".equals(deliveryType) ? "HOME"  :
			           "S".equals(deliveryType) ? "STORE" : deliveryType;
		
		boolean passPromotionCheck    = allPrm || isDa || prmTargetSet.contains(oplId);
		boolean passDeliveryTypeCheck = allDlv || dlvTargetSet.contains(deliveryType);
		boolean passOrderTypeCheck    = allOt  || otTargetSet.contains(orderType);

		// 計算設備/配件總金額, 以及設備/配件條件
		long totalPrice    = 0L;
		long devTotalPrice = 0L;
		long accTotalPrice = 0L;	
		boolean hasDevMatch = false;
		boolean hasAccMatch = false;
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				if(prod.isExtraBuy()) { continue; } // NDS加購不適用coupon
				String prodId = prod.getProductId();
				Long discPrice = prod.getDiscPrice();
				if(prodId == null || discPrice == null) continue;
				boolean isAcc = prod.isAcc();
				
				if(!isAcc) {
					devTotalPrice += discPrice;
					hasDevMatch = hasDevMatch || devTargetSet.contains(prodId);
				}
				if(isAcc ) {
					accTotalPrice += discPrice;
					hasAccMatch = hasAccMatch || accTargetSet.contains(prodId);
				}
				totalPrice += discPrice;
			}
		}
		totalPrice = totalPrice + prepaidPrice + prodVaPrice;
		
		// 判斷設備/配件條件
		boolean ignoreDev = allDev || nonDev;
		boolean ignoreAcc = allAcc || nonAcc;
		boolean passDevCheck = false;
		boolean passAccCheck = false; 
		if(ignoreDev && !ignoreAcc) {
			passDevCheck = true;
			passAccCheck = hasAccMatch;
		}		
		if(!ignoreDev && ignoreAcc) {
			passDevCheck = hasDevMatch;
			passAccCheck = true;
		}
		if(!ignoreDev && !ignoreAcc) {
			passDevCheck = hasDevMatch;
			passAccCheck = hasAccMatch;
		}
		if(ignoreDev && ignoreAcc) {
			passDevCheck = true;
			passAccCheck = true;
		}

		// 判斷是否通過總金額
		long minTotalPrice    = cpn.getMinTotalPrice    () != null ? cpn.getMinTotalPrice()     : 0L;
		long minDevTotalPrice = cpn.getMinDevicePrice   () != null ? cpn.getMinDevicePrice()    : 0L;
		long minAccTotalPrice = cpn.getMinAccessoryPrice() != null ? cpn.getMinAccessoryPrice() : 0L;
		boolean passTotalPriceCheck          = totalPrice    >= minTotalPrice;
		boolean passDeviceTotalPriceCheck    = minDevTotalPrice == 0L || (minDevTotalPrice > 0L && devTotalPrice >= minDevTotalPrice);
		boolean passAccessoryTotalPriceCheck = minAccTotalPrice == 0L || (minAccTotalPrice > 0L && accTotalPrice >= minAccTotalPrice);

		// 開始折coupon
		long cpnDiscAmt = cpn.getDiscountAmount() != null ? cpn.getDiscountAmount() : 0L;
		String cpnDiscCode = cpn.getDiscountCode();
		Long cpnCostCenterId = cpn.getCostCenterMasterId();
		boolean hasDisc = false;
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				if(prod.isExtraBuy()) { continue; } // NDS加購不適用coupon
				String prodId = prod.getProductId();
				Long discPrice = prod.getDiscPrice();
				boolean isAcc = prod.isAcc();
				if(prodId == null || discPrice == null || cpnDiscAmt == 0L) continue;
				
				// 判斷可不可折
				boolean canHg  = !isAcc && (allDev || devTargetSet.contains(prodId));
				boolean canAcc =  isAcc && (allAcc || accTargetSet.contains(prodId));
				if(!canHg && !canAcc) continue;
				
				long actDiscAmount = discPrice >= cpnDiscAmt ? cpnDiscAmt : discPrice;
				if(actDiscAmount == 0L) continue;
				long finalDiscPrice = discPrice - actDiscAmount;
				prod.setDiscPrice(finalDiscPrice);
				prod.setDiscAmount(prod.getDiscAmount() + actDiscAmount);
				
				// 記錄折扣				
				hasDisc = true;
				DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
				discVO.setType(DiscountResultDiscountVO.TYPE_COUPON); 
				discVO.setDiscountCode(cpnDiscCode); 
				discVO.setDiscountAmt(cpnDiscAmt);
				discVO.setActualDiscountAmt(actDiscAmount);
				discVO.setCostCenterId(cpnCostCenterId);
				discVO.setDiscountName(cpn.getDiscountName());
				discVO.setCouponId(cpn.getId());
				discVO.setCouponSn(couponSn);
				discVO.loggingDiscount(discPrice, finalDiscPrice);
				prod.getDiscounts().add(discVO);
				
				cpnDiscAmt -= actDiscAmount; // 已折掉
			}
		}		
		
		// 無折扣時, 視為設備/配件無法折抵
		if(!hasDisc) {
			passDevCheck = false;
			passAccCheck = false;
		}
		
		// 取得錯誤訊息, 有錯誤便跳出
		recordCouponError(allowDev, allowAcc, passOrderTypeCheck, 
						  passDevCheck, passAccCheck, passPromotionCheck,  
                          passDeliveryTypeCheck, passTotalPriceCheck, passDeviceTotalPriceCheck, 
                          passAccessoryTotalPriceCheck, isPromo);		

		this.updateResultPrice();
	}
	
	/**
	 * 計算合併商品活動之折價券折扣
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setCouponDiscountForMpAct(CouponVO cpn, String couponSn, String orderType, String oplId, String deliveryType, long prodVaPrice, long prepaidPrice) {
		this.updateResultPrice();
		if(cpn == null || totalDiscPrice == null) return;

		boolean allowDev = cpn.isDeviceAllow();
		boolean allowAcc = cpn.isAccessoryAllow();
		
		// coupon限制條件清單
		String[] types = new String[] {
			CouponRedeemTarget.REDEEM_TARGET_TYPE_ORDER_TYPE,
			CouponRedeemTarget.REDEEM_TARGET_TYPE_PROMOTION,
			CouponRedeemTarget.REDEEM_TARGET_TYPE_DEVICE,
			CouponRedeemTarget.REDEEM_TARGET_TYPE_ACCESSORY,
			CouponRedeemTarget.REDEEM_TARGET_TYPE_DELIVERY_TYPE,
		};
		
		// 取得coupon條件
		Map<String, Set<String>> targetMap = new HashMap<String, Set<String>>();
		for(String type : types) {
			targetMap.put(type, new HashSet<String>());
			targetMap.get(type).add("ALL");
		}
		Set<CouponRedeemTargetVO> targets = cpn.getCouponRedeemTargets();
		for(CouponRedeemTargetVO target : targets) {
			String type = target.getType();
			String targetId = target.getTargetId();
			if(!StringUtil.isInList(types, type) || targetId == null) continue;
			
			Set<String> targetSet = targetMap.get(type);
			targetSet.remove("ALL");
			targetSet.add(targetId);
		}
		Set<String> otTargetSet  = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_ORDER_TYPE);
		Set<String> devTargetSet = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_DEVICE);
		Set<String> accTargetSet = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_ACCESSORY);
		Set<String> dlvTargetSet = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_DELIVERY_TYPE);
		Set<String> prmTargetSet = targetMap.get(CouponRedeemTarget.REDEEM_TARGET_TYPE_PROMOTION);
		
		// 不允許設備或配件時, 清除條件(包含ALL)
		if(!allowDev) devTargetSet.clear();
		if(!allowAcc) accTargetSet.clear();
		
		// 取得各條件
		//boolean isDev   = StringUtil.isInList(new String[] {"NH", "PH", "LH", "DA" }, orderType);
		boolean isPromo = StringUtil.isInList(new String[] {"NC", "PC", "LC"       }, orderType);
		boolean isDa    = StringUtil.isInList(new String[] {"DA"                   }, orderType);
		
		boolean allDev = devTargetSet.contains("ALL");
		boolean allOt  = otTargetSet .contains("ALL");
		boolean allAcc = accTargetSet.contains("ALL");
		boolean allPrm = prmTargetSet.contains("ALL");
		boolean allDlv = dlvTargetSet.contains("ALL");
		boolean nonDev = devTargetSet.isEmpty();
		boolean nonAcc = accTargetSet.isEmpty();			
		
		deliveryType = deliveryType == null     ? "ALL"   :
				       "H".equals(deliveryType) ? "HOME"  :
			           "S".equals(deliveryType) ? "STORE" : deliveryType;
		
		boolean passPromotionCheck    = allPrm || isDa || prmTargetSet.contains(oplId);
		boolean passDeliveryTypeCheck = allDlv || dlvTargetSet.contains(deliveryType);
		boolean passOrderTypeCheck    = allOt  || otTargetSet.contains(orderType);

		// 計算設備/配件總金額, 以及設備/配件條件
		long totalPrice    = 0L;
		long devTotalPrice = 0L;
		long accTotalPrice = 0L;
		boolean hasDevMatch = false;
		boolean hasAccMatch = false;
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				String prodId = prod.getProductId();
				Long discPrice = prod.getDiscPrice();
				if(prodId == null || discPrice == null) continue;
				boolean isAcc = prod.isAcc();
				
				if(!isAcc) {
					devTotalPrice += discPrice;
					hasDevMatch = hasDevMatch || devTargetSet.contains(prodId);
				}
				if(isAcc ) {
					accTotalPrice += discPrice;
					hasAccMatch = hasAccMatch || accTargetSet.contains(prodId);
				}
				totalPrice += discPrice;
			}
		}
		totalPrice = totalPrice + prepaidPrice + prodVaPrice;
		
		// 判斷設備/配件條件
		boolean ignoreDev = allDev || nonDev;
		boolean ignoreAcc = allAcc || nonAcc;
		boolean passDevCheck = false;
		boolean passAccCheck = false; 
		if(ignoreDev && !ignoreAcc) {
			passDevCheck = true;
			passAccCheck = hasAccMatch;
		}		
		if(!ignoreDev && ignoreAcc) {
			passDevCheck = hasDevMatch;
			passAccCheck = true;
		}
		if(!ignoreDev && !ignoreAcc) {
			passDevCheck = hasDevMatch;
			passAccCheck = hasAccMatch;
		}
		if(ignoreDev && ignoreAcc) {
			passDevCheck = true;
			passAccCheck = true;
		}

		// 判斷是否通過總金額
		long minTotalPrice    = cpn.getMinTotalPrice    () != null ? cpn.getMinTotalPrice()     : 0L;
		long minDevTotalPrice = cpn.getMinDevicePrice   () != null ? cpn.getMinDevicePrice()    : 0L;
		long minAccTotalPrice = cpn.getMinAccessoryPrice() != null ? cpn.getMinAccessoryPrice() : 0L;
		boolean passTotalPriceCheck          = totalPrice    >= minTotalPrice;
		boolean passDeviceTotalPriceCheck    = minDevTotalPrice == 0L || (minDevTotalPrice > 0L && devTotalPrice >= minDevTotalPrice);
		boolean passAccessoryTotalPriceCheck = minAccTotalPrice == 0L || (minAccTotalPrice > 0L && accTotalPrice >= minAccTotalPrice);
		
		// 開始折coupon
		long cpnDiscAmt = cpn.getDiscountAmount() != null ? cpn.getDiscountAmount() : 0L;
		String cpnDiscCode = cpn.getDiscountCode();
		Long cpnCostCenterId = cpn.getCostCenterMasterId();		
		boolean hasDisc = false;
		for(DiscountResultSetVO set : sets) {
			// 取得符合的設備索引
			List<Integer> matchIdxs = new ArrayList<Integer>();
			List<DiscountResultProductVO> prods = set.getProducts();
			for(int i = 0; i < prods.size(); i++) {
				DiscountResultProductVO prod = prods.get(i);
				Long discPrice = prod.getDiscPrice();
				if(discPrice == null) continue;
				String prodId = prod.getProductId();
				boolean isAcc = prod.isAcc();
				boolean match = (!isAcc && (allDev || devTargetSet.contains(prodId))) ||
						        ( isAcc && (allAcc || accTargetSet.contains(prodId)));
				if(!match) continue;
				matchIdxs.add(i);
			}
			
			// 開始折金額
			for(int i = 0; i < matchIdxs.size(); i++) {
				if(cpnDiscAmt == 0L) continue;
				int idx = matchIdxs.get(i);
				DiscountResultProductVO prod = prods.get(idx);
				Long discPrice = prod.getDiscPrice();
				boolean isAcc = prod.isAcc();
				String prodId = prod.getProductId();
				if(discPrice == null) continue;	
				
				// 判斷可不可折
				boolean canHg  = !isAcc && (allDev || devTargetSet.contains(prodId));
				boolean canAcc =  isAcc && (allAcc || accTargetSet.contains(prodId));
				if(!canHg && !canAcc) continue;
				
				long actDiscAmount = discPrice >= cpnDiscAmt ? cpnDiscAmt : discPrice;
				long finalDiscPrice = discPrice - actDiscAmount;
				prod.setDiscPrice(finalDiscPrice);
				prod.setDiscAmount(prod.getDiscAmount() + actDiscAmount);
				
				// 記錄折扣		
				hasDisc = true;
				DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
				discVO.setType(DiscountResultDiscountVO.TYPE_COUPON); 
				discVO.setDiscountCode(cpnDiscCode); 
				discVO.setDiscountAmt(cpnDiscAmt);
				discVO.setActualDiscountAmt(actDiscAmount);
				discVO.setCostCenterId(cpnCostCenterId);
				discVO.setDiscountName(cpn.getDiscountName());
				discVO.setCouponId(cpn.getId());
				discVO.setCouponSn(couponSn);				
				discVO.loggingDiscount(discPrice, finalDiscPrice);
				prod.getDiscounts().add(discVO);
				
				cpnDiscAmt -= actDiscAmount; // 已折掉
			}
		}
		
		// 無折扣時, 視為設備/配件無法折抵
		if(!hasDisc) {
			passDevCheck = false;
			passAccCheck = false;
		}
		
		// 取得錯誤訊息, 有錯誤便跳出
		recordCouponError(allowDev, allowAcc, passOrderTypeCheck, 
						  passDevCheck, passAccCheck, passPromotionCheck, 
						  passDeliveryTypeCheck, passTotalPriceCheck, passDeviceTotalPriceCheck, 
					  	  passAccessoryTotalPriceCheck, isPromo);		
		
		this.updateResultPrice();
	}	

	/**
	 * 計算0元認證式活動之折價券折扣 (i.e. 單通話認證式活動)
	 * @param cpn
	 * @param couponSn
	 */
	public void setCouponForZeroRegAct(CouponVO cpn, String couponSn) {
		// 開始折coupon
		long cpnDiscAmt = cpn.getDiscountAmount() != null ? cpn.getDiscountAmount() : 0L;
		String cpnDiscCode = cpn.getDiscountCode();
		Long cpnCostCenterId = cpn.getCostCenterMasterId();	
		
		DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
		discVO.setType(DiscountResultDiscountVO.TYPE_COUPON); 
		discVO.setDiscountCode(cpnDiscCode); 
		discVO.setDiscountAmt(cpnDiscAmt);
		discVO.setActualDiscountAmt(0L);
		discVO.setCostCenterId(cpnCostCenterId);
		discVO.setDiscountName(cpn.getDiscountName());
		discVO.setCouponId(cpn.getId());
		discVO.setCouponSn(couponSn);
		discVO.loggingDiscount(0L, 0L);
		this.getDiscounts().add(discVO);
	}

	/**
	 * 記錄Coupon錯誤, 並回傳是否全數通過
	 * @return
	 */
	private boolean recordCouponError(boolean allowDev, boolean allowAcc, boolean passOrderTypeCheck,
			                          boolean passHandsetCheck, boolean passAccessoryCheck, 
			                          boolean passPromotionCheck, boolean passDeliveryTypeCheck,
			                          boolean passTotalPriceCheck, boolean passDeviceTotalPriceCheck, boolean passAccessoryTotalPriceCheck,
			                          boolean isPromo) {
//		if(passHandsetCheck || passAccessoryCheck) { // 任一商品符合, 便表示可扣
//			passHandsetCheck   = true;
//			passAccessoryCheck = true;
//		}		
		
		this.isCouponApplyToDevice       = allowDev;
		this.isCouponApplyToAccessory    = allowAcc;
		
		this.passCouponOrderTypeCheck    = passOrderTypeCheck;
		this.passCouponHandsetCheck      = passHandsetCheck; 
		this.passCouponAccessoryCheck    = passAccessoryCheck;
		this.passCouponPromotionCheck    = passPromotionCheck;
		this.passCouponDeliveryTypeCheck = passDeliveryTypeCheck;
		
		this.passCouponTotalPriceCheck          = passTotalPriceCheck;
		this.passCouponHandsetTotalPriceCheck   = passDeviceTotalPriceCheck;
		this.passCouponAccessoryTotalPriceCheck = passAccessoryTotalPriceCheck;
		
		this.passCouponDeviceTypeCheck = ( allowDev &&  allowAcc && (passDeviceTotalPriceCheck || passAccessoryTotalPriceCheck)) ||
				                         ( allowDev && !allowAcc && passDeviceTotalPriceCheck   ) ||
				                         (!allowDev &&  allowAcc && passAccessoryTotalPriceCheck) ||
			 	                         isPromo;		
		
		// 取得錯誤訊息
		couponErrorList.clear();
		if(!passCouponTotalPriceCheck         ) couponErrorList.add("未達結帳總金額");
		if(!passCouponOrderTypeCheck          ) couponErrorList.add("不符合訂單類型");
		if(!passCouponDeviceTypeCheck         ) couponErrorList.add("不符合Coupon可折抵項目");
		if(!passCouponHandsetCheck            ) couponErrorList.add("不符合設備條件");
		if(!passCouponHandsetTotalPriceCheck  ) couponErrorList.add("不符合設備金額");
		if(!passCouponAccessoryCheck          ) couponErrorList.add("不符合配件條件");
		if(!passCouponAccessoryTotalPriceCheck) couponErrorList.add("不符合配件金額");
		if(!passCouponPromotionCheck          ) couponErrorList.add("不符合促代條件");
		if(!passCouponDeliveryTypeCheck       ) {
			couponErrorList.add("不符合取貨方式");
			isCouponDeliveryTypeError = couponErrorList.size() == 1;
		}		
		return couponErrorList.isEmpty();
	}

	/**
	 * 計算Happygo折扣
	 * @param discountRatio
	 * @param discountAmount
	 */
	public void setHappyGoDiscount(Long hgPoints, Long hgPrice, Long hgUnit, Long hgAmt, String discNm, String hgDiscCode) {
		this.updateResultPrice();
		if(hasHg) return;
		if(hgPrice == null || totalCanDiscPrice == null || hgUnit == null || hgAmt == null) return;

		long maxPoints = (totalCanDiscPrice / hgAmt) * hgUnit;
		long actDiscPoints = hgPoints >= maxPoints ? maxPoints : hgPoints;
		long actDiscAmount = (actDiscPoints / hgUnit) * hgAmt;
		if(actDiscAmount == 0L) return; 
		
		// 記錄折扣
		DiscountResultDiscountVO discVO = new DiscountResultDiscountVO();
		discVO.setType(DiscountResultDiscountVO.TYPE_HG); 
		discVO.setDiscountCode(hgDiscCode);
		discVO.setDiscountAmt(actDiscAmount);
		discVO.setActualDiscountAmt(actDiscAmount);
		discVO.setCostCenterId(null);
		discVO.setDiscountName(discNm);
		discVO.setHgPoints(hgPoints);
		discVO.setHgActPoints(actDiscPoints);
		
		discVO.loggingDiscount(totalCanDiscPrice, totalCanDiscPrice - actDiscAmount);
		this.getDiscounts().add(discVO);
		
		this.updateResultPrice();
	}

	/**
	 * 設定預繳金額
	 * @param prepaidPrice
	 */
	public void setPrepaidPrice(Long prepaidPrice) {
		this.prepaidPrice = prepaidPrice;
	}
	
	/**
	 * 設定門號競標得標價
	 * @param auctionPrice
	 */
	public void setAuctionPrice(Long auctionPrice) {
		this.auctionPrice = auctionPrice;
	}

	/**
	 * 設定運費
	 * @param accMinPrice
	 * @param accShipmentFee
	 */
	public void setShipmentFee(Long accMinPrice, Long accShipmentFee) {
		if(accMinPrice == null || accShipmentFee == null) return;
		
		// 取得所有設備
		List<DiscountResultProductVO> prods = this.getProductList();
		
		boolean isAllAcc = !prods.isEmpty() ? true : false;
		long accTotalPrice = 0L;
		for(DiscountResultProductVO prod : prods) {
			Long discPrice = prod.getDiscPrice();
			if(discPrice == null) continue;
			
			boolean isAcc = prod.isAcc();
			accTotalPrice += isAcc ? discPrice : 0L;
			isAllAcc = isAllAcc && isAcc;
		}
		
		if(isAllAcc && accTotalPrice < accMinPrice) shipmentPrice = accShipmentFee;
		
		updateResultPrice();
	}
	
	/**
	 * 設定促銷活動贈品
	 * @param discountItems
	 */
	public void setActAwards(DiscountVO dscVO, boolean isMpAct, boolean isDa) {
		if(dscVO == null) return;
		Map<String, Map<String, Set<DiscountItemVO>>> prodDiscMap = dscVO.getProductDiscountMap();
		if(prodDiscMap == null || prodDiscMap.isEmpty()) return;
		
		String[] awards = new String[] {
			Activity.AWARD_ITEM_AWARD_TYPE_COUPON, 
			Activity.AWARD_ITEM_AWARD_TYPE_GIFT, 
			Activity.AWARD_ITEM_AWARD_TYPE_OFFER,
			"HANDSET_GIFT"
		};
		
		// 單通話
		if(products.isEmpty()) {
			Map<String, Set<DiscountItemVO>> allDiscs = dscVO.getAllDiscount();
			for(String award : awards) {
				Set<DiscountItemVO> discItems = allDiscs.get(award);
				if(discItems == null) continue;
				
				for(DiscountItemVO discItem : discItems) {
					DiscountResultAwardVO awardVO = new DiscountResultAwardVO();
					
	            	awardVO.setAaiId(discItem.getAaiId());
	            	awardVO.setActivityId(discItem.getActivityId());
	            	awardVO.setCode(discItem.getCode());
	            	awardVO.setCouponId(discItem.getCouponId());
	            	awardVO.setFetNo(discItem.getFetNo());
	            	awardVO.setName(discItem.getName());
	            	awardVO.setOfferId(discItem.getOfferId());
	            	awardVO.setSourceType(DiscountResultAwardVO.SOURCE_TYPE_ACT);
	            	awardVO.setType(award);
	            	
	            	if(Activity.AWARD_ITEM_AWARD_TYPE_COUPON.equals(award)) couponAwards.add(awardVO);
	            	if(Activity.AWARD_ITEM_AWARD_TYPE_OFFER .equals(award)) offerAwards .add(awardVO);
	            	if(Activity.AWARD_ITEM_AWARD_TYPE_GIFT  .equals(award)) giftAwards  .add(awardVO);	            	
				}
			}
		}

		// 取得贈品數量
		Map<Long, Integer> aaiCnts = getAaiCnts(prodDiscMap, isDa);
		
		// 搭手機, 單買
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				
				String prodId = prod.getProductId();
//				String fetNo = prod.getFetNo();
				
				for(String award : awards) {
		            Set<DiscountItemVO> discItems = prodDiscMap.get(prodId) != null && prodDiscMap.get(prodId).get(award) != null ? 
		            								prodDiscMap.get(prodId).get(award) : new LinkedHashSet<DiscountItemVO>();
		            for(DiscountItemVO discItem : discItems) {
		            	DiscountResultAwardVO awardVO = new DiscountResultAwardVO();
		            	boolean isHandsetGift = "HANDSET_GIFT".equals(award);
		            	String sourceType = isHandsetGift ? DiscountResultAwardVO.SOURCE_TYPE_HANDSET_GIFT : 
                                                            DiscountResultAwardVO.SOURCE_TYPE_ACT;		    
		            	String handsetName = prod.getName();
		            	String type = isHandsetGift ? Activity.AWARD_ITEM_AWARD_TYPE_GIFT : award;

		            	// 檢查贈品可用數量
		            	Long aaiId = discItem.getAaiId();
		            	if(aaiId != null && aaiCnts.containsKey(aaiId) && !isHandsetGift) {
		            		int cnt = aaiCnts.get(aaiId) != null ? aaiCnts.get(aaiId) : 0;
		            		if(cnt == 0) continue;
		            		aaiCnts.put(aaiId, cnt - 1);
		            	}
		            	
		            	awardVO.setAaiId(discItem.getAaiId());
		            	awardVO.setActivityId(discItem.getActivityId());
		            	awardVO.setCode(discItem.getCode());
		            	awardVO.setCouponId(discItem.getCouponId());
		            	awardVO.setFetNo(discItem.getFetNo());
		            	awardVO.setName(discItem.getName());
		            	awardVO.setOfferId(discItem.getOfferId());
		            	awardVO.setType(type);
		            	awardVO.setSourceType(sourceType);
		            	awardVO.setHandsetName(handsetName);
		            	
		            	if(Activity.AWARD_ITEM_AWARD_TYPE_COUPON.equals(type)) prod.getCouponAwards().add(awardVO);
		            	if(Activity.AWARD_ITEM_AWARD_TYPE_OFFER .equals(type)) prod.getOfferAwards() .add(awardVO);
		            	if(Activity.AWARD_ITEM_AWARD_TYPE_GIFT  .equals(type)) prod.getGiftAwards()  .add(awardVO);
		            }
				}
			}
		}
	}

	/**
	 * 計算活動贈品贈送數量
	 * @param prodDiscMap
	 * @param isDa
	 * @return
	 */
	private Map<Long, Integer> getAaiCnts(Map<String, Map<String, Set<DiscountItemVO>>> prodDiscMap, boolean isDa) {
		Map<Long, Integer> aaiCnts = new LinkedHashMap<Long, Integer>();
		if(prodDiscMap == null) return aaiCnts;
		
		// 取得贈品對應之設備清單
		Map<Long, Set<String>> aaiProdIds = new LinkedHashMap<Long, Set<String>>();
		for(String prodId : prodDiscMap.keySet()) {
			Map<String, Set<DiscountItemVO>> prodDiscs = prodDiscMap.get(prodId);
			for(String discTp : prodDiscs.keySet()) {
				Set<DiscountItemVO> discItems = prodDiscs.get(discTp);
				for(DiscountItemVO discItem : discItems) {
					Long aaiId = discItem.getAaiId();
					if(aaiId == null) continue;
					if(!aaiProdIds.containsKey(aaiId)) aaiProdIds.put(aaiId, new LinkedHashSet<String>());
					aaiProdIds.get(aaiId).add(prodId);
				}
			}
		}

		// 依贈品累計數量
		for(Long aaiId : aaiProdIds.keySet()) {
			Set<String> prodIds = aaiProdIds.get(aaiId);
			boolean allHg  = prodIds.contains("ALL_HG");
			boolean allAcc = prodIds.contains("ALL_ACC");
			boolean noneHg  = prodIds.contains("NONE_HG");
			boolean noneAcc = prodIds.contains("NONE_ACC");
			
			int hgcnt = 0;
			int acccnt = 0;
			int allhgcnt = 0;
			int allacccnt = 0;
			for(DiscountResultProductVO prodvo : this.getProductList()) {
				String voProdid = prodvo.getProductId();
				boolean isAcc = prodvo.isAcc();
				
				// 依原本活動條件累加, 計算符合所有設備/符合特定設備/符合所有配件/符合特定配件之數量
				if( allHg  && !noneHg  && !isAcc) allhgcnt++;
				if( allAcc && !noneAcc &&  isAcc) allacccnt++;
				if(!allHg  && !noneHg  && prodIds.contains(voProdid) && !isAcc) hgcnt++;
				if(!allAcc && !noneAcc && prodIds.contains(voProdid) &&  isAcc) acccnt++;
			}

			int cnt = 0;
			if(!noneHg && !noneAcc) {
				cnt =  allHg &&  allAcc ? allhgcnt + allacccnt :
					   allHg && !allAcc ? allhgcnt + acccnt    :
					  !allHg &&  allAcc ? hgcnt    + allacccnt :
					  !allHg && !allAcc ? Math.min(hgcnt, acccnt) : 0;
			} else if(!noneHg){
				cnt = allHg  ? allhgcnt  : hgcnt;
			} else if(!noneAcc) {
				cnt = allAcc ? allacccnt : acccnt;
			}
					  
			if(!isDa && cnt > 0) cnt = 1; // 非單買只送一份
			aaiCnts.put(aaiId, cnt);
		}
		return aaiCnts;
	}

	/**
	 * 設定配件活動贈品
	 * @param discMap
	 */
	public void setAccActAwards(Map<String, Map<String, List<DiscountItemVO>>> discMap) {
		if(discMap == null || discMap.isEmpty()) return;
		
		String[] awards = new String[] {
			AccessoryAwardItem.AWARD_TYPE_COUPON, 
			AccessoryAwardItem.AWARD_TYPE_GIFT
		};
		
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				if(prod == null || !prod.isAcc()) continue;
				String prodId = prod.getProductId();
				
				for(String award : awards) {
			   		List<DiscountItemVO> discItems = discMap.get(prodId) != null && discMap.get(prodId).get(award) != null ? 
			   										 discMap.get(prodId).get(award) : new ArrayList<DiscountItemVO>();
					for(DiscountItemVO discItem : discItems) {
		            	DiscountResultAwardVO awardVO = new DiscountResultAwardVO();
		            	
		            	awardVO.setType(award);
		            	awardVO.setSourceType(DiscountResultAwardVO.SOURCE_TYPE_ACC_ACT);
		            	awardVO.setAaiId(discItem.getAaiId());
		            	awardVO.setActivityId(discItem.getActivityId());
		            	awardVO.setCode(discItem.getCode());
		            	awardVO.setCouponId(discItem.getCouponId());
		            	awardVO.setFetNo(discItem.getFetNo());
		            	awardVO.setName(discItem.getName());
		            	awardVO.setOfferId(discItem.getOfferId());
		            	
		            	if(AccessoryAwardItem.AWARD_TYPE_COUPON.equals(award)) prod.getCouponAwards().add(awardVO);
		            	if(AccessoryAwardItem.AWARD_TYPE_GIFT  .equals(award)) prod.getGiftAwards()  .add(awardVO);
					}
				}
			}
		}
	}
	
	/**
	 * 設定配件贈品
	 * @param discMap
	 */
	public void setAccGifts(Map<String, List<AccessoryGiftVO>> accGiftMap) {
		if(accGiftMap == null || accGiftMap.isEmpty()) return;
		
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				if(prod == null || !prod.isAcc()) continue;
				String prodId = prod.getProductId();
				
				List<AccessoryGiftVO> gifts = accGiftMap.get(prodId);
				if(gifts == null) continue;
				for(AccessoryGiftVO gift : gifts) {
	            	DiscountResultAwardVO awardVO = new DiscountResultAwardVO();
	            	
	            	awardVO.setType(AccessoryAwardItem.AWARD_TYPE_GIFT);
	            	awardVO.setSourceType(DiscountResultAwardVO.SOURCE_TYPE_ACC_GIFT);
	            	awardVO.setAaiId(null);
	            	awardVO.setActivityId(null);
	            	awardVO.setCode(gift.getGiftProdId());
	            	awardVO.setCouponId(null);
	            	awardVO.setFetNo(gift.getGiftProdId());
	            	awardVO.setName(gift.getGiftName());
	            	awardVO.setOfferId(null);
	            	
	            	prod.getGiftAwards().add(awardVO);
				}
			}
		}
	}
	
	/**
	 * 更新金額
	 */
	public void updateResultPrice() {
		
		long erpPrice = 0L;
		long discPrice = 0L;
		long discAmount = 0L;
		long hsDiscAmount = 0L;
		
		// 計算單項商品價
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				if(prod.getErpPrice()   == null ||
				   prod.getDiscPrice()  == null ||
				   prod.getDiscAmount() == null) continue;
				
				// 原價依各商品計算, 但若在組合中之折扣則另計 
				if(prod.isExtraBuy()) {
					Integer ebQty = prod.getExtraBuyQty();
					if(ebQty == null) { continue; }
					erpPrice  += prod.getErpPrice() * ebQty;
					discPrice += prod.getErpPrice() * ebQty;
				} else {
					erpPrice += prod.getErpPrice();
					discPrice += prod.getDiscPrice();
				}
				discAmount += prod.getDiscAmount();

				// 計算單機優惠價 / 組合活動折扣金額
				long daDiscAmount = 0L;
				for(DiscountResultDiscountVO disc : prod.getDiscounts()) {
					String type = disc.getType();
					boolean hasHsDisc = StringUtil.isInList(new String[] {DiscountResultDiscountVO.TYPE_MP_ACT_FIXED, 
												                          DiscountResultDiscountVO.TYPE_MP_ACT_MARKUP, 
												                          DiscountResultDiscountVO.TYPE_MP_ACT_RATIO,
												                          DiscountResultDiscountVO.TYPE_MP_ACT_PLUS  }, type);
					boolean hasDaDisc = StringUtil.isInList(new String[] {DiscountResultDiscountVO.TYPE_OVERALL_HG, 
                                                                          DiscountResultDiscountVO.TYPE_OVERALL_ACC, 
                                                                          DiscountResultDiscountVO.TYPE_ACC_ACT    ,
                                                                          DiscountResultDiscountVO.TYPE_ACT           }, type);
					Long actDiscAmt = disc.getActualDiscountAmt();
					
					if(hasDaDisc && actDiscAmt != null && actDiscAmt > 0L ) daDiscAmount += actDiscAmt;
					if(hasHsDisc && actDiscAmt != null && actDiscAmt > 0L ) hsDiscAmount += actDiscAmt;
				}
				Long daDiscPrice = (prod.getErpPrice() != null && daDiscAmount > 0L) ? prod.getErpPrice() - daDiscAmount : null;
				prod.setDaDiscPrice(daDiscPrice);
			}
		}
		
		// 計算ExtraBuy
		for(DiscountResultDiscountVO disc : this.discounts) {
			String discType = disc.getType();
			boolean isEb     = DiscountResultDiscountVO.TYPE_EB    .equals(discType);
			if(!isEb) continue;
			
			Long amt = disc.getActualDiscountAmt(); 
			if(amt == null) continue;
	
			long actAmt = amt;
			discPrice -= actAmt;
			discAmount += actAmt;
			
			disc.setActualDiscountAmt(actAmt);
		}
		
		// 可折抵金額
		this.totalCanDiscPrice = discPrice;
		
		// 計算happyGO
		for(DiscountResultDiscountVO disc : this.discounts) {
			String discType = disc.getType();
			boolean isHg     = DiscountResultDiscountVO.TYPE_HG    .equals(discType);
			
			Long amt = disc.getDiscountAmt();
			if(amt == null) continue;
			
			if(isHg) {
				long actAmt = discPrice >= amt ? amt : discPrice;
				discPrice -= actAmt;
				discAmount += actAmt;
				
				disc.setActualDiscountAmt(actAmt);
				this.hasHg = true;
			}
		}
		
		this.totalErpPrice   = erpPrice;
		this.totalDiscAmount = erpPrice - discPrice; // discAmount
		this.totalDiscPrice  = discPrice; 
		this.totalHSDiscAmount = hsDiscAmount;
	}

	/**
	 * 顯示資料
	 */
	public void showInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append("show discount result: \n");		
		
		// 顯示組合價
		for(int i = 0; i < sets.size(); i++) {
			DiscountResultSetVO set = sets.get(i);
			List<DiscountResultDiscountVO> setdiscs = set.getDiscounts();
			
			sb.append(String.format("set #%s ------------------------------------------- \n", i));
			sb.append(String.format("    discprice   : %6d\n", set.getDiscPrice()));
			sb.append(String.format("    discamount  : %6d\n", set.getDiscAmount()));
			
			List<DiscountResultProductVO> prods = set.getProducts();
			for(int j = 0; j < prods.size(); j++) {
				DiscountResultProductVO prod = prods.get(j);
				
				String prodInfo = showProductInfo(prod, String.format("set #%s", i), j);
				sb.append(prodInfo);
			}
			
			sb.append(showDisc(String.format("set #%s", i), setdiscs));
			
			sb.append("\n");
		}
		
		// 顯示單項商品
		int idx = 0;
		for(Integer grp : products.keySet()) {
			for(String k : products.get(grp).keySet()) {
				DiscountResultProductVO prod = products.get(grp).get(k);
				if(prod.isInSet()) continue;
				String prodInfo = showProductInfo(prod, "indep.", idx);
				sb.append(prodInfo);
				idx++;
			}
		}
		
		sb.append(showDisc("result", this.discounts));

		sb.append(String.format("award summery ------------------------------------------- \n"));
		sb.append(showAward("summery", giftAwards,   "gift"));
		sb.append(showAward("summery", offerAwards,  "offer"));
		sb.append(showAward("summery", couponAwards, "coupon"));		
		
		sb.append(String.format("summery ------------------------------------------- \n"));
		sb.append(String.format("    totalErpPrice  : %6d \n", totalErpPrice));
		sb.append(String.format("    totalDiscAmount: %6d \n", totalDiscAmount));
		sb.append(String.format("    totalHSDscAmt  : %6d \n", totalHSDiscAmount));
		sb.append(String.format("    shipmentPrice  : %6d \n", shipmentPrice != null ? shipmentPrice : 0L));
		sb.append(String.format("    prepaidPrice   : %6d \n", prepaidPrice != null ? prepaidPrice : 0L));
		sb.append(String.format("    auctionPrice   : %6d \n", auctionPrice != null ? auctionPrice : 0L));
		sb.append(String.format("    canDiscPrice   : %6d \n", totalCanDiscPrice != null ? totalCanDiscPrice : 0L));
		sb.append(String.format("    totalDiscPrice : %6d \n", totalDiscPrice));
		
		
		LogUtil.warn(sb.toString());
	}
	
	private String showProductInfo(DiscountResultProductVO prod, String prefix, int idx) {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("    %s product #%s ------------------------------------------- \n", prefix, idx));
		
		sb.append(String.format("        name        : %s\n", prod.getName()));
		sb.append(String.format("        fetno       : %s\n", prod.getFetNo()));
		sb.append(String.format("        productid   : %s\n", prod.getProductId()));
		sb.append(String.format("        erpprice    : %6d\n", prod.getErpPrice()));
		sb.append(String.format("        discprice   : %6d\n", prod.getDiscPrice()));
		sb.append(String.format("        discamount  : %6d\n", prod.getDiscAmount()));
		sb.append(String.format("        dadiscprice : %6d\n", prod.getDaDiscPrice()));
		
		if(prod.isExtraBuy()) {
			String ebDesc = String.format("buyid: %s, buyitemid: %s", prod.getExtraBuyId(), prod.getExtraBuyItemId());
			sb.append(String.format("        extrabuy    : %s\n", ebDesc));
		}

		sb.append("\n");
		
		sb.append(showDisc("prod", prod.getDiscounts()));
		
		sb.append(showAward("prod", prod.getGiftAwards(),   "gift"));
		sb.append(showAward("prod", prod.getOfferAwards(),  "offer"));
		sb.append(showAward("prod", prod.getCouponAwards(), "coupon"));

		return sb.toString();
	}
	
	private String showDisc(String prefix, List<DiscountResultDiscountVO> discs) {
		StringBuilder sb = new StringBuilder();

		for(int k = 0; k < discs.size(); k++) {
			DiscountResultDiscountVO disc = discs.get(k);
			
			sb.append(String.format("        %s #%s discount (%-15s)--------------------------------------- \n", prefix, k, disc.getType()));
			sb.append(String.format("             code   : %s \n", disc.getDiscountCode()));
			sb.append(String.format("             amount : %s \n", disc.getDiscountAmt()));
			sb.append(String.format("             ratio  : %s \n", disc.getDiscountRatio()));
			sb.append(String.format("             actdisc: %s \n", disc.getActualDiscountAmt()));
			sb.append(String.format("          costCenter: %s \n", disc.getCostCenterId()));
			sb.append(String.format("              discNm: %s \n", disc.getDiscountName()));
			sb.append(String.format("               actId: %s \n", disc.getActId()));
			sb.append(String.format("            accActId: %s \n", disc.getAccActId()));
			
			for(String memo : disc.getDiscountMemo()) {
				sb.append(String.format("             memo   : %s \n", memo));	
			}
			
			sb.append("\n");
		}
		
		return sb.toString();
	}
	
	private String showAward(String prefix, List<DiscountResultAwardVO> awards, String type) {
		StringBuilder sb = new StringBuilder();

		for(int k = 0; k < awards.size(); k++) {
			DiscountResultAwardVO prodaward = awards.get(k);
			
			sb.append(String.format("        %s #%s %-8s     (%-15s)--------------------------------------- \n", prefix, k, type, prodaward.getType()));
			sb.append(String.format("             code   : %s \n", prodaward.getCode()));
			sb.append(String.format("             name   : %s \n", prodaward.getName()));
			sb.append(String.format("           source   : %s \n", prodaward.getSourceType()));
			sb.append(String.format("            actId   : %s \n", prodaward.getActivityId()));
			sb.append(String.format("            aaiId   : %s \n", prodaward.getAaiId()));
			
			sb.append("\n");
		}
		
		return sb.toString();
	}

	public Long getTotalErpPrice() {
		return totalErpPrice;
	}

	public Long getTotalDiscPrice() {
		return totalDiscPrice;
	}

	public Long getTotalDiscAmount() {
		return totalDiscAmount;
	}
	
	public boolean isHasHg() {
		return hasHg;
	}

	public Map<Integer, Map<String, DiscountResultProductVO>> getProducts() {
		return products;
	}

	public List<DiscountResultSetVO> getSets() {
		return sets;
	}

	public List<DiscountResultDiscountVO> getDiscounts() {
		return discounts;
	}

	public Boolean getPassCouponHandsetCheck() {
		return passCouponHandsetCheck;
	}

	public Boolean getPassCouponAccessoryCheck() {
		return passCouponAccessoryCheck;
	}

	public Boolean getPassCouponPromotionCheck() {
		return passCouponPromotionCheck;
	}

	public Boolean getPassCouponDeliveryTypeCheck() {
		return passCouponDeliveryTypeCheck;
	}

	public Boolean getPassCouponTotalPriceCheck() {
		return passCouponTotalPriceCheck;
	}

	public Boolean getPassCouponHandsetTotalPriceCheck() {
		return passCouponHandsetTotalPriceCheck;
	}

	public Boolean getPassCouponAccessoryTotalPriceCheck() {
		return passCouponAccessoryTotalPriceCheck;
	}

	public Boolean getPassCouponOrderTypeCheck() {
		return passCouponOrderTypeCheck;
	}

	public Boolean getIsCouponApplyToDevice() {
		return isCouponApplyToDevice;
	}

	public Boolean getIsCouponApplyToAccessory() {
		return isCouponApplyToAccessory;
	}

	public Boolean getPassCouponDeviceTypeCheck() {
		return passCouponDeviceTypeCheck;
	}

	public Long getShipmentPrice() {
		return shipmentPrice;
	}

	public Long getPrepaidPrice() {
		return prepaidPrice;
	}

	public Long getTotalCanDiscPrice() {
		return totalCanDiscPrice;
	}

	public Boolean getIsCouponDeliveryTypeError() {
		return isCouponDeliveryTypeError;
	}

	public List<String> getCouponErrorList() {
		return couponErrorList;
	}

	public boolean isHsAct() {
		return isHsAct;
	}

	public void setHsAct(boolean isHsAct) {
		this.isHsAct = isHsAct;
	}

	public Long getMpActId() {
		return mpActId;
	}

	public void setMpActId(Long mpActId) {
		this.mpActId = mpActId;
	}

	public Long getTotalHSDiscAmount() {
		return totalHSDiscAmount;
	}

	public Long getAuctionPrice() {
		return auctionPrice;
	}
}
