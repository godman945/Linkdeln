package com.fet.estore.core.bean.vo.frontend;

/**
 * 驗證地址VO
 * @author Max Chen
 *
 */
public class ValidationAddressVO {
	/** 郵遞區號 */
	private String zipCode;
	/** 縣市名稱 */
	private String cityStr;
	/** 縣市ID */
	private String cityCode;
	/** 鄉鎮名稱 */
	private String rgnStr;
	/** 鄉鎮ID */
	private String rgnCode;
	/** 地址(不含縣市) */
	private String addr;
	/** 完整地址 */
	private String fullAddr;
	/** 是否有錯誤 */
	private boolean isErr;
	/** 錯誤訊息 */
	private String errMsg;
	/** 是否為外島、離島 */
	private Boolean isOffshoreIsland;
	
	
	
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCityStr() {
		return cityStr;
	}
	public void setCityStr(String cityStr) {
		this.cityStr = cityStr;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getRgnStr() {
		return rgnStr;
	}
	public void setRgnStr(String rgnStr) {
		this.rgnStr = rgnStr;
	}
	public boolean isErr() {
		return isErr;
	}
	public void setErr(boolean isErr) {
		this.isErr = isErr;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getFullAddr() {
		return fullAddr;
	}
	public void setFullAddr(String fullAddr) {
		this.fullAddr = fullAddr;
	}
	public String getRgnCode() {
		return rgnCode;
	}
	public void setRgnCode(String rgnCode) {
		this.rgnCode = rgnCode;
	}
	public Boolean getIsOffshoreIsland() {
		return isOffshoreIsland;
	}
	public void setIsOffshoreIsland(Boolean isOffshoreIsland) {
		this.isOffshoreIsland = isOffshoreIsland;
	}
}
