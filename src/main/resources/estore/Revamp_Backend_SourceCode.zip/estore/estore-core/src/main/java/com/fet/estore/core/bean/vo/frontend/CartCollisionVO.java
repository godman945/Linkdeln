package com.fet.estore.core.bean.vo.frontend;

public class CartCollisionVO {
	
	private String key;
	private String firstFetNo;
	private Integer amount;
	private Long mpActivityId;
	private String uuid;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public Long getMpActivityId() {
		return mpActivityId;
	}
	public void setMpActivityId(Long mpActivityId) {
		this.mpActivityId = mpActivityId;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getFirstFetNo() {
		return firstFetNo;
	}
	public void setFirstFetNo(String firstFetNo) {
		this.firstFetNo = firstFetNo;
	}
	
}
