package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CallingCard;

public interface NCallingCardDAO extends BaseDAO<CallingCard, Long> {

    /**
	 * 由料號取得CallingCard
	 * @param fetno
	 * @return
	 */
	public List<CallingCard> findCallingCardsByFetNo(String fetno);
}