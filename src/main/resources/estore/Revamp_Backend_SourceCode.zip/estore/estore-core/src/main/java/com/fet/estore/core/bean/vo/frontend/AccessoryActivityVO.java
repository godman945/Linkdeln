package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.bean.vo.IDiscountItem;

/**
 * 
 * @author Max Chen
 *
 */
public class AccessoryActivityVO implements IDiscountItem {

	private Long id;
	private String discCode;
	private Long discAmt;
	private String accId;
	private Long costCenterId;
	private String discountName;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDiscCode() {
		return discCode;
	}
	public void setDiscCode(String discCode) {
		this.discCode = discCode;
	}
	public Long getDiscAmt() {
		return discAmt;
	}
	public void setDiscAmt(Long discAmt) {
		this.discAmt = discAmt;
	}
	public String getAccId() {
		return accId;
	}
	public void setAccId(String accId) {
		this.accId = accId;
	}
	public Long getCostCenterId() {
		return costCenterId;
	}
	public void setCostCenterId(Long costCenterId) {
		this.costCenterId = costCenterId;
	}
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}

	@Override
	public Long getAaiId() {
		return null;
	}
	@Override
	public String getCode() {
		return discCode;
	}
	@Override
	public String getFetNo() {
		return null;
	}
	@Override
	public Long getActivityId() {
		return null;
	}
	@Override
	public String getName() {
		return discountName;
	}
	@Override
	public Long getAmount() {
		return discAmt;
	}
	@Override
	public Long getCouponId() {
		return null;
	}
	@Override
	public Long getOfferId() {
		return null;
	}
	@Override
	public Double getDiscountRatio() {
		return null;
	}
	@Override
	public Long getActualDiscountAmt() {
		return null;
	}
	@Override
	public String getDisplayGroup() {
		return null;
	}
}
