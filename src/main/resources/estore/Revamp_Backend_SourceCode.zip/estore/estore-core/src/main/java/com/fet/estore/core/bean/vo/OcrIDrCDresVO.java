package com.fet.estore.core.bean.vo;

import java.util.Date;

public class OcrIDrCDresVO implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 辨識任務代號，8 碼日期+7 碼流水號 共 15 碼，例： 201702020000001
	 */
	String ocrSN;

	/**
	 * 取回的 csv 或 xml 檔案的 binery
	 */
	String recogFileBinary;

	/**
	 * 取回的 csv 或 xml 檔案的副檔名
	 */
	String recogFileType;

	/**
	 * 取回的 csv 或 xml 檔案的副檔名定義碼 例:取回的定義碼為 1，該檔案則為影像處理過的結果 1: 是指辨識前，經過影像處理後的影像 2 :
	 * 是指辨識後，找到的證件位置，裁切出的影像，(可打 上浮水印，也可不打) 3: 上述 1+2 的影像 4 :
	 * 是指辨識後，若有找到的證件中的頭像位置，裁切出的 頭像影像
	 */
	String recogFileTypeNum;

	/**
	 * 判斷是否有錯誤或權限不足或是該資料不存在的代碼
	 */
	String errorCode;

	public String getOcrSN() {
		return ocrSN;
	}

	public void setOcrSN(String ocrSN) {
		this.ocrSN = ocrSN;
	}

	public String getRecogFileBinary() {
		return recogFileBinary;
	}

	public void setRecogFileBinary(String recogFileBinary) {
		this.recogFileBinary = recogFileBinary;
	}

	public String getRecogFileType() {
		return recogFileType;
	}

	public void setRecogFileType(String recogFileType) {
		this.recogFileType = recogFileType;
	}

	public String getRecogFileTypeNum() {
		return recogFileTypeNum;
	}

	public void setRecogFileTypeNum(String recogFileTypeNum) {
		this.recogFileTypeNum = recogFileTypeNum;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	

}
