package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-18
 */
public class Cart implements Serializable {

	private static final long serialVersionUID = 8169499615385970503L;
	
	/** 購物車清單 */
	private List<CartItem> list;
	/** 購物車id 目前未定義 為空值*/
	private String id;
	/** 其他Field可以往下新增 */

	public void add(CartItem cartItem) {
		if (this.list == null) {
			this.list = new ArrayList<>();
		}
		this.list.add(cartItem);
	}
	public List<CartItem> getList() {
		return list;
	}
	public void setList(List<CartItem> list) {
		this.list = list;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}
