package com.fet.estore.core.dao;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CrossCooperation;

/**
 * 
 * @description
 * @author Phil.lin
 * @date 2020-10-13
 */
public interface ICrossCooperationDAO extends BaseDAO<CrossCooperation, String> {

}
