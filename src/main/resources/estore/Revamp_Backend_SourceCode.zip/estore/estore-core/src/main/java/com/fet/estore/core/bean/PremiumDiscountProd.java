package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * @description 專屬優惠商品(Ex. 好禮、加構商品)
 * 用戶所選購的加購商品、好禮(商品明細頁送出)
 * @author Dennis.Chen
 * @Date 2020-09-16
 */
public class PremiumDiscountProd implements Serializable {

    private static final long serialVersionUID = 6378714847302475329L;
    String productId; //DB - PRODUCT.ID
    String apId; //DB - ACTIVITY_PREMIUM.ID(活動優惠id)
    Integer number; //購買數量
    String prodTypeNo; //DB - ACTIVITY_PREMIUM.PRODTYPE_NO 1:手機, 2:配件, 3:贈品, 4:預繳金, 6:門號, 10:加購服務, 12:競標門號
    String fetNo; //商品料號
    Integer maxAmount; //購買上限
    String color;//顏色

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getApId() {
        return apId;
    }

    public void setApId(String apId) {
        this.apId = apId;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getProdTypeNo() {
        return prodTypeNo;
    }

    public void setProdTypeNo(String prodTypeNo) {
        this.prodTypeNo = prodTypeNo;
    }

    public String getFetNo() {
        return fetNo;
    }

    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }

    public Integer getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(Integer maxAmount) {
        this.maxAmount = maxAmount;
    }

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
    
}
