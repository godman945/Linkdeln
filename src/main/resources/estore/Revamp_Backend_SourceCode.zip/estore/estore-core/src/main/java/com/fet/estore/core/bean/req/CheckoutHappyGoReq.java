package com.fet.estore.core.bean.req;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-09-30
 * @description
 */
public class CheckoutHappyGoReq {

    private Long point;

    public Long getPoint() {
        return point;
    }

    public void setPoint(Long point) {
        this.point = point;
    }
}
