package com.fet.estore.core.bean.vo;

import java.io.Serializable;

import com.fet.estore.core.enums.ValidationResultEnum;
import com.fet.estore.core.exception.OrderValidationException;
import com.fet.estore.core.util.LogUtil;

public class OrderValidationResultVO implements Serializable {

	private static final long serialVersionUID = 8447660362561228448L;
	
	/** 回傳碼 */
	private String returnCode;
	/** 回傳訊息 */
	private String returnMsg;
	/** 結果狀態 Enum */
	private ValidationResultEnum resultEnum;
	
	public OrderValidationResultVO() {
		
	}
	
	public OrderValidationResultVO(ValidationResultEnum resultEnum) {
		LogUtil.info("Create Result VO: {}", resultEnum);
		this.resultEnum = resultEnum;
		this.returnCode = resultEnum.getCode();
		this.returnMsg = resultEnum.getDescription();
	}

	
	public OrderValidationResultVO(OrderValidationException e) {
		LogUtil.info("Create Result VO with Exception: {}", e.getResultEnum());
		this.resultEnum = e.getResultEnum();
		this.returnCode = e.getReturnCode();
		this.returnMsg = e.getReturnMsg();
	}

	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMsg() {
		return returnMsg;
	}
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
	public ValidationResultEnum getResultEnum() {
		return resultEnum;
	}
	public void setResultEnum(ValidationResultEnum resultEnum) {
		this.resultEnum = resultEnum;
	}
	
}
