package com.fet.estore.core.bean.vo.frontend;

public class ShoppingGuideDetailVO {
	/** 手機廠牌 */
	private String brand;
	/** 遠傳商品代碼。 */
	private String fetNo;
	/** 手機型號 */
	private String modelName;
	/** 顏色 */
	private String color;
	/**	各種名稱 */
	private String detailName;
	/** 商品庫存。 */
	private Long inventory;
	/** 已選擇的購買數量 */
	private Integer quantity;
	private String productId;
	
	private String uuid;
	private Long mpActivityId;
	private Long mpActivityProductDiscountId;
	private String fetNo_uuid;
	/**
	 * 紅配綠使用,非紅配綠:0
	 * 紅配綠第一群:1,第二群:2
	 * Russell Lee add
	 */
	private int groupNumber;
	
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getDetailName() {
		return detailName;
	}
	public void setDetailName(String detailName) {
		this.detailName = detailName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Long getInventory() {
		return inventory;
	}
	public void setInventory(Long inventory) {
		this.inventory = inventory;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public Long getMpActivityId() {
		return mpActivityId;
	}
	public void setMpActivityId(Long mpActivityId) {
		this.mpActivityId = mpActivityId;
	}
	public Long getMpActivityProductDiscountId() {
		return mpActivityProductDiscountId;
	}
	public void setMpActivityProductDiscountId(Long mpActivityProductDiscountId) {
		this.mpActivityProductDiscountId = mpActivityProductDiscountId;
	}
	public int getGroupNumber() {
		return groupNumber;
	}
	public void setGroupNumber(int groupNumber) {
		this.groupNumber = groupNumber;
	}
	public String getFetNo_uuid() {
		return fetNo_uuid;
	}
	public void setFetNo_uuid(String fetNo_uuid) {
		this.fetNo_uuid = fetNo_uuid;
	}
}
