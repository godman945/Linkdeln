package com.fet.estore.core.bean;

public class CheckRppRes {

	private boolean isMayannPC;
	private boolean isRpp;
	private boolean isShopee;
	public boolean getIsMayannPC() {
		return isMayannPC;
	}
	public void setIsMayannPC(boolean isMayannPC) {
		this.isMayannPC = isMayannPC;
	}
	public boolean getIsRpp() {
		return isRpp;
	}
	public void setIsRpp(boolean isRpp) {
		this.isRpp = isRpp;
	}
	public boolean getIsShopee() {
		return isShopee;
	}
	public void setIsShopee(boolean isShopee) {
		this.isShopee = isShopee;
	}
}
