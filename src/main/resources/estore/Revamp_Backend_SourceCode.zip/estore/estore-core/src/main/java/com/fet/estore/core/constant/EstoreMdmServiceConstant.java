package com.fet.estore.core.constant;

/** Mdm API 代碼表 */
public class EstoreMdmServiceConstant {
	
	//SubscriberType, 參照代碼表 CDCONTRCOMPTP
	/** SubscriberType - 3G */
	public static final String SubscriberType_EID = "1";//E
	/** SubscriberType - 3G */
	public static final String SubscriberType_2G = "2";//G
	/** SubscriberType - 4G */
	public static final String SubscriberType_CID = "3";//P
	/** SubscriberType - 4G */
	public static final String SubscriberType_KING3G = "4";//Q
	/** SubscriberType - 3G */
	public static final String SubscriberType_3G = "5";//T
	/** SubscriberType - 3G */
	public static final String SubscriberType_WALA = "6";//W
	/** SubscriberType - 3G */
	public static final String SubscriberType_WIMAX_POSTPAID = "7";//X
	/** SubscriberType - 3G */
	public static final String SubscriberType_NEW_CASH = "8";//V
	/** SubscriberType - 4G */
	public static final String SubscriberType_4G = "9";//L
	/** SubscriberType - 4G */
	public static final String SubscriberType_KING2G = "10";//K
	/** SubscriberType - 4G */
	public static final String SubscriberType_HYBRID = "11";//H
	/** SubscriberType - 4G */
	//public static final String SubscriberType_Hybrid = "12";
	/** SubscriberType - 4G */
	public static final String SubscriberType_KING4G = "13";//U
	/** SubscriberType - 4G */
	public static final String SubscriberType_OTHER = "999";//OTHER
	
	/** SubscriberType - 3G */
	public static final String SubscriberType_EID_CRM = "E";//1
	/** SubscriberType - 3G */
	public static final String SubscriberType_2G_CRM = "G";//2
	/** SubscriberType - 4G */
	public static final String SubscriberType_CID_CRM = "P";//3
	/** SubscriberType - 4G */
	public static final String SubscriberType_KING3G_CRM = "Q";//4
	/** SubscriberType - 3G */
	public static final String SubscriberType_3G_CRM = "T";//5
	/** SubscriberType - 3G */
	public static final String SubscriberType_WALA_CRM = "W";//6
	/** SubscriberType - 3G */
	public static final String SubscriberType_WIMAX_POSTPAID_CRM = "X";//7
	/** SubscriberType - 3G */
	public static final String SubscriberType_NEW_CASH_CRM = "V";//8
	/** SubscriberType - 4G */
	public static final String SubscriberType_4G_CRM = "L";//9
	/** SubscriberType - 4G */
	public static final String SubscriberType_KING2G_CRM = "K";//10
	/** SubscriberType - 4G */
	public static final String SubscriberType_HYBRID_CRM = "H";//11
	/** SubscriberType - 4G */
	//public static final String SubscriberType_Hybrid_CRM = "12";
	/** SubscriberType - 4G */
	public static final String SubscriberType_KING4G_CRM = "U";//13
	/** SubscriberType - 4G */
	public static final String SubscriberType_OTHER_CRM = "OTHER";//14
	/** SubscriberType - 5G */
	public static final String SubscriberType_5G_CRM = "F";
	
	
	
	/** 主門號類別 - 3G voice number */
	public static final String PrimResourceCategory_3GVoice = "3GMDN";
	/** 主門號類別 - 4G voice number */
	public static final String PrimResourceCategory_4GVoice = "4GMDN";

	/** 世代別 - 2G */
	public static final String MobileGenerationCode_2G = "2";
	/** 世代別 - 3G */
	public static final String MobileGenerationCode_3G = "3";
	/** 世代別 - 4G */
	public static final String MobileGenerationCode_4G = "4";
	/** 世代別 - 5G */
	public static final String MobileGenerationCode_5G = "5";
	
	/** 付款類別 - Postpaid */
	public static final String PaymentCategory_Postpaid = "PS";
	/** 付款類別 - Prepaid */
	public static final String PaymentCategory_Prepaid = "PP";
	
	/** 合約角色類型 - 客戶 */
	public static final String RoleType_Customer = "11";
	/** 合約角色類型 - 用戶 */
	public static final String RoleType_Subscriber = "21";
	/** 合約角色類型 - 帳戶 */
	public static final String RoleType_Account = "31";
	/** 合約角色類型 - 法定代理人 */
	public static final String RoleType_LegalAgent = "41";
	/** 合約角色類型 - 代理人 */
	public static final String RoleType_Agent = "51";
	
	/** 國別, 參照代碼表 CDCOUNTRYTP */
	public static final String CountryType = "294";
	/** 省別, 參照代碼表 CDPROVSTATETP */
	public static final String ProvinceStateType = "294";
	
	//姓名用途, 參照代碼表 CDNAMEUSAGETP
	/** 姓名用途 - 自然人全名（中文) */
	public static final String NameUsageType_FullNameCht = "11";
	
	//稱謂, 參照代碼表 CDPREFIXNAMETP
	/** 稱謂 - 先生 */
	public static final String Gender_Male = "0";
	/** 稱謂 - 小姐 */
	public static final String Gender_Female = "1";
	/** 稱謂 - 其它 */
	public static final String Gender_Other = "999";
	
	//地址類別 , 參照代碼表 CDADDRUSAGETP
	/** 地址類別 - 戶籍地址 */
	public static final String Address_Residence = "1";
	/** 地址類別 - 聯絡地址 */
	public static final String Address_Contact = "2";
	/** 地址類別 - 帳單地址 */
	public static final String Address_Billing = "3";
	
	//帳單寄送方式 , 參照代碼表 CDBILLDELIVERMETHTP
	/** 帳單寄送方式 - 無 */
	public static final String BillDeliveryMethod_Na = "0";
	/** 帳單寄送方式 - 書面帳單 */
	public static final String BillDeliveryMethod_Paper = "1";
	/** 帳單寄送方式 - 列印書面帳款及電子帳單 */
	public static final String BillDeliveryMethod_PaperAndEmail = "2";
	/** 帳單寄送方式 - 電子帳單(過渡期) */
	public static final String BillDeliveryMethod_Email_Transition = "3";
	/** 帳單寄送方式 - 電子帳單 */
	public static final String BillDeliveryMethod_Email = "4";
	/** 帳單寄送方式 - 書面變更電子帳單確認中 */
	public static final String BillDeliveryMethod_Paper2Email_Confirm = "5";
	/** 帳單寄送方式 - 簡訊帳單(過渡期) */
	public static final String BillDeliveryMethod_SMS_Transition = "6";
	/** 帳單寄送方式 - 簡訊帳單 */
	public static final String BillDeliveryMethod_SMS = "7";
	/** 帳單寄送方式 - 簡訊變更電子帳單確認中 */
	public static final String BillDeliveryMethod_SMS2Email_Confirm = "8";
	/** 帳單寄送方式 - 其它 */
	public static final String BillDeliveryMethod_Other = "999";
	
	//帳單提醒信函, 參照代碼表 CDBILLREMINDERTP
	/** 帳單提醒信函 - 無 */
	public static final String BillReminder_Na = "0";
	/** 帳單提醒信函 - 電子帳單寄送提醒函 */
	public static final String BillReminder_Email = "1";
	/** 帳單提醒信函 - 電子帳單寄送+繳款提醒函 */
	public static final String BillReminder_EmailPayment = "2";
	/** 帳單提醒信函 - 電子帳單寄送+繳款提醒函+繳款提醒簡訊 */
	public static final String BillReminder_EmailPaymentSMS = "3";
	/** 帳單提醒信函 - 電子帳單寄送+繳款提醒簡訊 */
	public static final String BillReminder_EmailSMS = "4";
	/** 帳單提醒信函 - 繳款提醒簡訊 */
	public static final String BillReminder_SMS = "5";
	/** 帳單提醒信函 - 催收提醒函 */
	public static final String BillReminder_Overdue = "6";
	/** 帳單提醒信函 - 催收+繳款提醒函 */
	public static final String BillReminder_OverduePayment = "7";
	/** 帳單提醒信函 - 其它 */
	public static final String BillReminder_Other = "999";

	//帳單格式, 參照代碼表 CDBILLFORMATTP
	/** 帳單格式 - 一般帳單 */
	public static final String BillFormat_Common = "1";
	/** 帳單格式 - 簡易帳單 */
	public static final String BillFormat_Simple = "2";
	/** 帳單格式 - 公司戶一般帳單 */
	public static final String BillFormat_Company = "3";
	/** 帳單格式 - 一般及簡易帳單 */
	public static final String BillFormat_Both = "4";
	/** 帳單格式 - 其它 */
	public static final String BillFormat_Other = "999";
	
	/** 聯繫方式 - 電話（住家） */
	public static final String ContactMethod_Tel_Home = "11";
	/** 聯繫方式 - 電話（公司） */
	public static final String ContactMethod_Tel_Company = "12";
	/** 聯繫方式 - 電話（行動） */
	public static final String ContactMethod_Tel_Mobile = "13";
	/** 聯繫方式 - 電話（其他） */
	public static final String ContactMethod_Tel_Other = "14";
	/** 聯繫方式 - 傳真 */
	public static final String ContactMethod_Fax = "21";
	/** 聯繫方式 - 電子信箱（個人） */
	public static final String ContactMethod_Email_Person = "31";
	/** 聯繫方式 - 電子信箱（公司） */
	public static final String ContactMethod_Email_Company = "32";
	/** 聯繫方式 - 電子信箱（帳單） */
	public static final String ContactMethod_Email_Billing = "33";
	/** 聯繫方式 - 電子信箱（其他） */
	public static final String ContactMethod_Email_Other = "34";
	/** 聯繫方式 - 電子信箱（收件人其他） */
	public static final String ContactMethod_Email_Other2 = "35";
	/** 聯繫方式 - LINE */
	public static final String ContactMethod_Social_Line = "41";
	/** 聯繫方式 - Facebook */
	public static final String ContactMethod_Social_Facebook = "42";
	/** 聯繫方式 - Twitter */
	public static final String ContactMethod_Social_Twitter = "43";

	//證件類別, 參照代碼表CDIDTP
	/** 證件類別 - 外籍人士證件號碼 */
	public static final String Identification_ForeignerLicense = "0";
	/** 證件類別 - 國民身分證 */
	public static final String Identification_Rocid = "1";
	/** 證件類別 - 統一編號 */
	public static final String Identification_UniformNumber = "2";
	/** 證件類別 - 稅籍編號 */
	public static final String Identification_TaxCodeNumber = "3";
	/** 證件類別 - 駕駛執照 */
	public static final String Identification_DrivingLicense = "4";
	/** 證件類別 - 全民健保卡 */
	public static final String Identification_HealthIDCard = "5";
	/** 證件類別 - 其它 */
	public static final String Identification_Other = "6";
	/** 證件類別 - 在台居留證 */
	public static final String Identification_ResidentPermit = "7";
	/** 證件類別 - 在台工作證 */
	public static final String Identification_ProofOfEmployment = "8";
	/** 證件類別 - 護照 */
	public static final String Identification_Passport = "9";
	/** 證件類別 - 軍人身分證 */
	public static final String Identification_MilitaryIDCard = "10";
	/** 證件類別 - 戶口名簿 */
	public static final String Identification_AccountBook = "11";
	/** 證件類別 - 學生證 */
	public static final String Identification_StudentIDCard = "12";
	/** 證件類別 - 入出境許可證 */
	public static final String Identification_EntryPermit = "13";
	/** 證件類別 - 簽證 */
	public static final String Identification_EntryVisa = "14";
	/** 證件類別 - 外藉其他 */
	public static final String Identification_ForeignerOther = "15";
	/** 證件類別 - 船員漁工證 */
	public static final String Identification_FisherLicense = "16";
	/** 證件類別 - 大陸居民往來台灣通行證 */
	public static final String Identification_TaiwanPass = "17";
	/** 證件類別 - 店組代碼 */
	public static final String Identification_StoreId = "18";
	/** 證件類別 - 未知 */
	public static final String Identification_Unknown = "99999";
	
	//IVR語言偏好, 參照代碼表 CDPREFLANGTP
	/** IVR語言 - 中文 */
	public static final String IVRLanguage_Chinese = "8";
	/** IVR語言 - 中文 */
	public static final String IVRLanguage_Mandarin = "6";
	
	//業務系統類型; 參照代碼表 CDADMINFLDNMTP
	/** 業務系統類型 - CUSTOMER_ID  */
	public static final String AdminField_Customer = "110";
	/** 業務系統類型 - SUBSCRIBER_ID */
	public static final String AdminField_SUBSCRIBER = "120";
	/** 業務系統類型 - ACCOUNT_ID */
	public static final String AdminField_ACCOUNT = "130";
	/** 業務系統類型 - MSISDN */
	public static final String AdminField_MSISDN = "150";
}