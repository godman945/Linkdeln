package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CoNumber;

public interface NCoNumberDAO extends BaseDAO<CoNumber, String>  {

	/**
	 * 取得下一訂單編號
	 * @return
	 */
	public Integer nextCoNumber(boolean isMobile);
}
