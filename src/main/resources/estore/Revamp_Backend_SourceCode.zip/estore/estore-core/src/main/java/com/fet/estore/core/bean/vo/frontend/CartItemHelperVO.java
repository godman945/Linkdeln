package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.util.Date;

/**
 * 購物車項目VO
 * @author Max Chen
 *
 */
public class CartItemHelperVO implements Serializable {


    
    /**
	 * 
	 */
	private static final long serialVersionUID = -2998721719449271811L;

	@Override
    // 2013/06/27 fred add 除錯測試用
    public String toString() {
        
        StringBuffer buffer = new StringBuffer();
        buffer.append("\tproductId = " + productId + "\n");
        buffer.append("\tfetNo = " + fetNo + "\n");
        buffer.append("\tname = " + name + "\n");
        buffer.append("\tisAcc = " + isAcc + "\n");
        buffer.append("\tamount = " + amount + "\n");
        buffer.append("\tprice = " + price + "\n");
        buffer.append("\tsubTotal = " + subTotal + "\n");
        buffer.append("\taddTime = " + addTime + "\n");
        buffer.append("\tlinkUrl = " + linkUrl + "\n");
        buffer.append("\tuuid = " + uuid + "\n");
        buffer.append("\tmpActivityId = " + mpActivityId + "\n");
        buffer.append("\tmpActivityProductDiscountId = " + mpActivityProductDiscountId + "\n");
        buffer.append("\tfirst = " + first + "\n");
        buffer.append("\tisExclusive = " + isExclusive + "\n");
        buffer.append("\tfirstFetNo = " + firstFetNo + "\n");
        buffer.append("\terpPrice = " + erpPrice + "\n");
        
        return buffer.toString();
    }
    
	/** 商品ID */
	private String productId;
	/** 料號ID */
	private String fetNo;
	/** 名稱 */
	private String name;
	/** 是否為配件 */
	private boolean isAcc;
	/** 數量 */
	private Integer amount;
	/** 單價 */
	private Long price;
	/** 小計 */
	private Long subTotal;	
	/** 加入時間 */
	private Date addTime;
	/** 商品連結網址 */
	private String linkUrl;
	/** uuid*/
	private String uuid;
	/** 加價購活動ID*/
	private Long mpActivityId;
	/** 加價購活動的折扣ID*/
	private Long mpActivityProductDiscountId;
	/** 是否為父類*/
	private boolean first;
	/** 是否為獨賣件*/
	private boolean isExclusive;
	/** 主商品fetNo*/
	private String firstFetNo;
	/**單機價格**/
	private Long erpPrice;
	
	public CartItemHelperVO() {
		super();
	}
	public CartItemHelperVO(CartItemHelperVO cihVO) {
		this.productId = cihVO.productId;
		this.fetNo = cihVO.fetNo;
		this.name = cihVO.name;
		this.isAcc = cihVO.isAcc;
		this.amount = cihVO.amount;
		this.price = cihVO.price;
		this.subTotal = cihVO.subTotal;
		this.addTime = cihVO.addTime;
		this.linkUrl = cihVO.linkUrl;
		this.uuid = cihVO.uuid;
		this.mpActivityId = cihVO.mpActivityId;
		this.mpActivityProductDiscountId = cihVO.mpActivityProductDiscountId;
		this.first = cihVO.first;
		this.isExclusive = cihVO.isExclusive;
		this.firstFetNo = cihVO.firstFetNo;
		this.erpPrice = cihVO.getErpPrice();
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public Long getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(Long subTotal) {
		this.subTotal = subTotal;
	}
	public Date getAddTime() {
		return addTime;
	}
	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}
	public boolean isAcc() {
		return isAcc;
	}
	public void setAcc(boolean isAcc) {
		this.isAcc = isAcc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLinkUrl() {
		return linkUrl;
	}
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public Long getMpActivityId() {
		return mpActivityId;
	}
	public void setMpActivityId(Long mpActivityId) {
		this.mpActivityId = mpActivityId;
	}
	public Long getMpActivityProductDiscountId() {
		return mpActivityProductDiscountId;
	}
	public void setMpActivityProductDiscountId(Long mpActivityProductDiscountId) {
		this.mpActivityProductDiscountId = mpActivityProductDiscountId;
	}
	public boolean isFirst() {
		return first;
	}
	public void setFirst(boolean first) {
		this.first = first;
	}
	public boolean isExclusive() {
		return isExclusive;
	}
	public void setExclusive(boolean isExclusive) {
		this.isExclusive = isExclusive;
	}
	public String getFirstFetNo() {
		return firstFetNo;
	}
	public void setFirstFetNo(String firstFetNo) {
		this.firstFetNo = firstFetNo;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}

}
