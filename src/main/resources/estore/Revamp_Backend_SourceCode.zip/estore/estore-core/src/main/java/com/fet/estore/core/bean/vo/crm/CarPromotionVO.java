package com.fet.estore.core.bean.vo.crm;

import java.util.ArrayList;
import java.util.List;

public class CarPromotionVO {
	/** 升級資費類型 - 一般資費 */
	public static final String LOYALTY_UPGRADE_TYPE_NORMAL = "NORMAL";
	/** 升級資費類型 - 價差資費 */
	public static final String LOYALTY_UPGRADE_TYPE_SPREAD = "SPREAD";
	/** 升級資費類型 - 指定資費 */
	public static final String LOYALTY_UPGRADE_TYPE_ASSIGN = "ASSIGN";
    /** 升級資費類型 - 換約資費 */
    public static final String LOYALTY_UPGRADE_TYPE_CHANGE = "CHANGE";
	
	private String promotonId;
	
	private String pmAtuh;
	
	private Integer overlapDayAllowed;
	
	private List<String> vipTypes = new ArrayList<String>();
	
	private List<CarPromotionVO> subPromotions = new ArrayList<CarPromotionVO>();
	
	private String msisdnType;
	
	private String upgradeType;

	public String getMsisdnType() {
		return msisdnType;
	}

	public void setMsisdnType(String msisdnType) {
		this.msisdnType = msisdnType;
	}

	public boolean isVipPromotoin() {
		return this.vipTypes.size() > 0;
	}

	public String getPromotonId() {
		return promotonId;
	}

	public void setPromotonId(String promotonId) {
		this.promotonId = promotonId;
	}

	public List<String> getVipTypes() {
		return vipTypes;
	}

	public void setVipTypes(List<String> vipTypes) {
		this.vipTypes = vipTypes;
	}

	public List<CarPromotionVO> getSubPromotions() {
		return subPromotions;
	}

	public void setSubPromotions(List<CarPromotionVO> subPromotions) {
		this.subPromotions = subPromotions;
	}

	public Integer getOverlapDayAllowed() {
		return overlapDayAllowed;
	}

	public void setOverlapDayAllowed(Integer overlapDayAllowed) {
		this.overlapDayAllowed = overlapDayAllowed;
	}

	public String getPmAtuh() {
		return pmAtuh;
	}

	public void setPmAtuh(String pmAtuh) {
		this.pmAtuh = pmAtuh;
	}

	public String getUpgradeType() {
		return upgradeType;
	}

	public void setUpgradeType(String upgradeType) {
		this.upgradeType = upgradeType;
	}
}
