package com.fet.estore.core.bean;

import java.io.Serializable;

public class ReservationOrderForm implements Serializable {

	private static final long serialVersionUID = -1901406626178548828L;
	private String name;
	private String phone;
	private String email;
	private String orderType;
	private String productId;
	private String deviceType;
	private String aliasUrl;
	private String category;
	private String fetNo;
	private String rocId;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getAliasUrl() {
		return aliasUrl;
	}
	public void setAliasUrl(String aliasUrl) {
		this.aliasUrl = aliasUrl;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getRocId() {
		return rocId;
	}
	public void setRocId(String rocId) {
		this.rocId = rocId;
	}
	
}
