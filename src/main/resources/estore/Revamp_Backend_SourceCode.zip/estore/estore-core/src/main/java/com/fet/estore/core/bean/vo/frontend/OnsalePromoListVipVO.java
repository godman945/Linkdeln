package com.fet.estore.core.bean.vo.frontend;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

/**
 * VIP資費條件VO
 * @author Max Chen
 *
 */
public class OnsalePromoListVipVO {
	
	private Set<String> conds = new HashSet<String>();
	
	public void addCond(String promotionListId, String vOfferId, String dOfferId) {
		String key = toKey(promotionListId, vOfferId, dOfferId);
		conds.add(key);
	}
	
	
	public boolean isExist(String promotionListId, String vOfferId, String dOfferId) {
		String keyOne = toKey(promotionListId, vOfferId, dOfferId);
		String keyAll = toKey(promotionListId, "ALL", "ALL");
		return conds.contains(keyOne) || conds.contains(keyAll);
	}
	
	private String toKey(String promotionListId, String vOfferId, String dOfferId) {
		if(StringUtils.isEmpty(promotionListId) || StringUtils.isEmpty(vOfferId) ||
			StringUtils.isEmpty(dOfferId)) return null;
		
		String key = String.format("[%s|%s|%s]", promotionListId, vOfferId, dOfferId);
		return key;
	}
	
}
