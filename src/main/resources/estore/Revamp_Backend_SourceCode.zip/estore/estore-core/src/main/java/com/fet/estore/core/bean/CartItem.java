package com.fet.estore.core.bean;

import com.fet.estore.core.bean.bo.ShoppingResultDiscountBO;

import java.io.Serializable;
import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-18
 */
public class CartItem implements Serializable {

	/** 購物車單品數量 */
	private Integer	number;
	/** 購物車單品顏色 */
	private String color;
	/** 單品商品編號 */
	private String productId;
	/** 單品商品fetNo編號 */
	private String defaultFetNo;
	/** 售價 */
	private Integer salePrice;
	/** 原價 */
	private Integer originPrice;
	/** 庫存量 */
	private Integer storage;
	/** 類別 */
	private String type;
	/** 商品名 */
	private String name;
	/** slug */
	private String slug;
	/** 折扣資訊 */
	private List<ShoppingResultDiscountBO> discountInfo;

	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getDefaultFetNo() {
		return defaultFetNo;
	}
	public void setDefaultFetNo(String defaultFetNo) {
		this.defaultFetNo = defaultFetNo;
	}
	public Integer getSalePrice() {
		return salePrice;
	}
	public void setSalePrice(Integer salePrice) {
		this.salePrice = salePrice;
	}
	public Integer getOriginPrice() {
		return originPrice;
	}
	public void setOriginPrice(Integer originPrice) {
		this.originPrice = originPrice;
	}
	public Integer getStorage() {
		return storage;
	}
	public void setStorage(Integer storage) {
		this.storage = storage;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSlug() {
		return slug;
	}
	public void setSlug(String slug) {
		this.slug = slug;
	}

	public List<ShoppingResultDiscountBO> getDiscountInfo() {
		return discountInfo;
	}

	public void setDiscountInfo(List<ShoppingResultDiscountBO> discountInfo) {
		this.discountInfo = discountInfo;
	}
}
