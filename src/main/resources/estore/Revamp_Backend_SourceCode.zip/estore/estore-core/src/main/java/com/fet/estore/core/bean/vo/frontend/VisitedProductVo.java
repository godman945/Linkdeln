package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

/**
 * 商品瀏覽記錄的value Object。
 * 
 * @author samho
 */
public class VisitedProductVo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4125447473010113038L;

	/**
	 * 商品編號。
	 */
	private String productId;
	
	/**
	 * 商品名稱。
	 */
	private String productName;
	
	/**
	 * 所在的館別。
	 */
	private EntryPointEnum entryPoint;
	
	/**
	 * 商品連結網址。
	 */
	private String linkUrl;
	
	/**
	 * 商品圖片位址。
	 */
	private String imageSrc;

	/**
	 * 取得productId。
	 *
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * 設定productId。
	 *
	 * @param productId 欲設定的productId。
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * 取得productName。
	 *
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * 設定productName。
	 *
	 * @param productName 欲設定的productName。
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * 取得entryPoint。
	 *
	 * @return the entryPoint
	 */
	public EntryPointEnum getEntryPoint() {
		return entryPoint;
	}

	/**
	 * 設定entryPoint。
	 *
	 * @param entryPoint 欲設定的entryPoint。
	 */
	public void setEntryPoint(EntryPointEnum entryPoint) {
		this.entryPoint = entryPoint;
	}

	/**
	 * 取得linkUrl。
	 *
	 * @return the linkUrl
	 */
	public String getLinkUrl() {
		return linkUrl;
	}

	/**
	 * 設定linkUrl。
	 *
	 * @param linkUrl 欲設定的linkUrl。
	 */
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	/**
	 * 取得imageSrc。
	 *
	 * @return the imageSrc
	 */
	public String getImageSrc() {
		return imageSrc;
	}

	/**
	 * 設定imageSrc。
	 *
	 * @param imageSrc 欲設定的imageSrc。
	 */
	public void setImageSrc(String imageSrc) {
		this.imageSrc = imageSrc;
	}	
}
