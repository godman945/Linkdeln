package com.fet.estore.core.dao.base;

import com.fet.estore.core.model.OcrFail;

public interface OcrFailDAO extends BaseDAO<OcrFail, Long> {

}
