package com.fet.estore.core.bean;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-09-09
 * @description
 */
public class SrvResult<T> {

    private boolean success;
    private String message;
    private T object;

    public <T> SrvResult(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public SrvResult(boolean success, String message, T object) {
        this.success = success;
        this.message = message;
        this.object = object;
    }

    public boolean isSuccess() {
        return success;
    }
    public String getMessage() {
        return message;
    }
    public T getObject() {
        return object;
    }
}
