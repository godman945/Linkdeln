package com.fet.estore.core.bean;

public class SubmitOrderRes {

	private boolean skipUpload;

	public boolean getSkipUpload() {
		return skipUpload;
	}

	public void setSkipUpload(boolean skipUpload) {
		this.skipUpload = skipUpload;
	}
}
