package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.DataPromoMapping;
import com.fet.estore.core.model.DataPromoMappingId;
import com.fet.estore.core.model.Datarate;

public interface NDataPromoMappingDAO extends BaseDAO<DataPromoMapping, DataPromoMappingId> {

}
