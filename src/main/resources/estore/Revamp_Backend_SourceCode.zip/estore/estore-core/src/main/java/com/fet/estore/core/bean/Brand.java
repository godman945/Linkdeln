package com.fet.estore.core.bean;

import java.io.Serializable;

public class Brand implements Serializable {

	private static final long serialVersionUID = 7501627468882696385L;
	/** 文字 */
	private String text;
	/** 值 */
	private String value;
	
	public Brand() {
		super();
	}
	
	public Brand(String text,String value) {
		super();
		this.text = text;
		this.value = value;
	}
	
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
