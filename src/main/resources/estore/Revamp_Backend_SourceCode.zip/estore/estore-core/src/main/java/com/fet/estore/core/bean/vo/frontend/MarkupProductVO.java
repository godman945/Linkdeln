package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MarkupProductVO implements Serializable {
	
	private String uuid;
	
	private List<ProductHelperVO> masterProducts = new ArrayList<ProductHelperVO>();
	
	private List<ProductHelperVO> slaveProducts = new ArrayList<ProductHelperVO>();

	public List<ProductHelperVO> getMasterProducts() {
		return masterProducts;
	}

	public void setMasterProducts(List<ProductHelperVO> masterProducts) {
		this.masterProducts = masterProducts;
	}

	public List<ProductHelperVO> getSlaveProducts() {
		return slaveProducts;
	}

	public void setSlaveProducts(List<ProductHelperVO> slaveProducts) {
		this.slaveProducts = slaveProducts;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	

}
