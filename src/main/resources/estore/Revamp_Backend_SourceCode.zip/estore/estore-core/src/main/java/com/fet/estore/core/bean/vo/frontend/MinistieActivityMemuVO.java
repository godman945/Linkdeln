package com.fet.estore.core.bean.vo.frontend;
/**
 * 
 * @author antonis Chen
 *
 */
public class MinistieActivityMemuVO {
	
	private String menuId;
	private String minisiteActivityId;
	private String adItemId;
	private String title;
	
	
	
	public String getMenuId() {
		return menuId;
	}
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMinisiteActivityId() {
		return minisiteActivityId;
	}
	public void setMinisiteActivityId(String minisiteActivityId) {
		this.minisiteActivityId = minisiteActivityId;
	}
	public String getAdItemId() {
		return adItemId;
	}
	public void setAdItemId(String adItemId) {
		this.adItemId = adItemId;
	}
	
	
	
}
