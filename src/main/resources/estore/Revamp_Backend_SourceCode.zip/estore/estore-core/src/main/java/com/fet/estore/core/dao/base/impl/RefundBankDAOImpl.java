package com.fet.estore.core.dao.base.impl;


import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.RefundBankDAO;
import com.fet.estore.core.model.RefundBank;
@Repository
public class RefundBankDAOImpl extends AbstractBaseDAO<RefundBank, String> implements RefundBankDAO {
}
