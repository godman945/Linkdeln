package com.fet.estore.core.dao.base;

import com.fet.estore.core.model.InstallmentPlan;

public interface InstallmentPlanDAO extends BaseDAO<InstallmentPlan, Long> {

}
