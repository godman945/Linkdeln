package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * 找商品畫面的卡牌 TYPE 為 Promotion 時的 資料結構
 * 
 * @description
 * @author Phil.lin
 * @date 2020-08-04
 */
public class PromotionAction implements Serializable {
	
	private static final long serialVersionUID = 9045449260067960863L;
	
	/** 了解更多 */
	private String text = "了解更多";
	/** 超連結 URL */
	private String link;
	/** target */
	private String target = "_self";
	
	public PromotionAction() {
		this.link = "";
	}
	
	public PromotionAction(String text, String link) {
		this.link = link;
		this.text = text;
	}
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	
	
}
