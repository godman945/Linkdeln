package com.fet.estore.core.bean.po;

/**
 * @author Dennis.Chen
 * @Date 2020-10-06
 */
public class OpenActivityPO {

    Long actId;
    Integer isDaHandSet;
    Integer isDaAccessory;
    String type;
    String targetId;

    public Long getActId() {
        return actId;
    }

    public void setActId(Long actId) {
        this.actId = actId;
    }

    public Integer getIsDaHandSet() {
        return isDaHandSet;
    }

    public void setIsDaHandSet(Integer isDaHandSet) {
        this.isDaHandSet = isDaHandSet;
    }

    public Integer getIsDaAccessory() {
        return isDaAccessory;
    }

    public void setIsDaAccessory(Integer isDaAccessory) {
        this.isDaAccessory = isDaAccessory;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }
}
