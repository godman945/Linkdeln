package com.fet.estore.core.bean.vo.frontend;

import java.text.NumberFormat;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fet.estore.core.model.CallingCardDetail;
import com.fet.estore.core.model.Product;

/**
 * 在client顯示的物件 
 */
public class CallingCardVO {
	private Long id;
	private String description;
	private String descriptionFilePath;
	private Long discountAmount;
	private String discountCode;
	private Product product;
	private String name;
	private java.util.Date offDate;
	private Boolean onsale;
	private java.util.Date onsaleDate;
	private java.util.Set<CallingCardDetail> callingCardDetails;
	private String password;
	private Long faceValue;
	private int quantity;
	private Long price;

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public CallingCardVO() {
    }

	public Long getId() {
		return this.id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescriptionFilePath() {
		return this.descriptionFilePath;
	}
	public void setDescriptionFilePath(String descriptionFilePath) {
		this.descriptionFilePath = descriptionFilePath;
	}

	public Long getDiscountAmount() {
		return this.discountAmount;
	}
	public void setDiscountAmount(Long discountAmount) {
		this.discountAmount = discountAmount;
	}

	public String getDiscountCode() {
		return this.discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}

	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public java.util.Date getOffDate() {
		return this.offDate;
	}
	public void setOffDate(java.util.Date offDate) {
		this.offDate = offDate;
	}

	public Boolean getOnsale() {
		return this.onsale;
	}
	public void setOnsale(Boolean onsale) {
		this.onsale = onsale;
	}

	public java.util.Date getOnsaleDate() {
		return this.onsaleDate;
	}
	public void setOnsaleDate(java.util.Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}

	//uni-directional many-to-one association to CallingCardDetail
	public java.util.Set<CallingCardDetail> getCallingCardDetails() {
		return this.callingCardDetails;
	}
	public void setCallingCardDetails(java.util.Set<CallingCardDetail> callingCardDetails) {
		this.callingCardDetails = callingCardDetails;
	}

	public String toString() {
		return new ToStringBuilder(this)
			.append("id", getId())
			.toString();
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(Long faceValue) {
		this.faceValue = faceValue;
	}
	
	public String getFaceValueStr() {
		return faceValue != null ? getNumberFormat(getFaceValue()) : null;
	}
	
	public String getNumberFormat(long price) {
		NumberFormat nf = NumberFormat.getInstance();
		return nf.format(price);
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
