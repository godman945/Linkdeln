package com.fet.estore.core.bean.bo;

import com.fet.estore.core.bean.req.ProductListReq;
import com.fet.estore.core.enums.AccSearchMethodEnum;
import com.fet.estore.core.enums.OrderTypeEnum;

import java.util.List;

public class FindProductBO {
    /** true:單機、false:搭門號 */
    private Boolean type;
    /** 廠牌 */
    private String brand;
    /** 配件搜尋排序方式 */
    private AccSearchMethodEnum accSearchMethod;
    /** 關鍵字 */
    private String keyword;
    /** 主分類 */
    private String categoryGroup;
    /** 次分類 */
    private String category;
    /** 次分類Name(給熱門商品次分類查詢用)*/
    private String categoryName;
    /** ProductId Array 注意Sql一千筆限制 */
    private List<String> productIds;
    /** 須排除的Product 注意Sql一千筆限制 */
    private List<String> excludeProductIds;
    /** 起始筆數 */
    private Integer startIndex;
    /** 撈取筆數 */
    private Integer querySize;
    /** 置頂標籤(用以查詢SQL判斷是否須置頂)*/
    private boolean sticky;
    /** 置頂/推薦 類別 */
    private String productType;
    /** 定錨資費 */
    private Long anchorMonthPrice;
    /** 活動ID*/
    private Long activityId;
    /** 申辦方式*/
    private OrderTypeEnum orderType;

    public FindProductBO() {
        super();
        accSearchMethod = AccSearchMethodEnum.DEFAULT_WITH_STICKY;
    }

    public FindProductBO(ProductListReq productListReq) {
        this.type = productListReq.getType();
        this.brand = productListReq.getBrand();
        this.accSearchMethod = productListReq.getAccSearchMethod();
        this.keyword = productListReq.getKeyword();
        this.categoryGroup = productListReq.getCategoryGroup();
        this.category = productListReq.getCategory();
        this.startIndex = productListReq.getStartIndex();
        this.querySize = productListReq.getQuerySize();
    }

    public Boolean getType() {
        return type;
    }

    public FindProductBO setType(Boolean type) {
        this.type = type;
        return this;
    }

    public String getBrand() {
        return brand;
    }

    public FindProductBO setBrand(String brand) {
        this.brand = brand;
        return this;
    }

    public AccSearchMethodEnum getAccSearchMethod() {
        if (accSearchMethod == null) {
            return AccSearchMethodEnum.DEFAULT_WITH_STICKY;
        }
        return accSearchMethod;
    }

    public FindProductBO setAccSearchMethod(AccSearchMethodEnum accSearchMethod) {
        this.accSearchMethod = accSearchMethod;
        return this;
    }

    public String getKeyword() {
        return keyword;
    }

    public FindProductBO setKeyword(String keyword) {
        this.keyword = keyword;
        return this;
    }

    public String getCategoryGroup() {
        return categoryGroup;
    }

    public FindProductBO setCategoryGroup(String categoryGroup) {
        this.categoryGroup = categoryGroup;
        return this;
    }

    public String getCategory() {
        return category;
    }

    public FindProductBO setCategory(String category) {
        this.category = category;
        return this;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public FindProductBO setCategoryName(String categoryName) {
        this.categoryName = categoryName;
        return this;
    }

    public List<String> getProductIds() {
        return productIds;
    }

    public FindProductBO setProductIds(List<String> productIds) {
        this.productIds = productIds;
        return this;
    }

    public List<String> getExcludeProductIds() {
        return excludeProductIds;
    }

    public FindProductBO setExcludeProductIds(List<String> excludeProductIds) {
        this.excludeProductIds = excludeProductIds;
        return this;
    }

    public Integer getStartIndex() {
        return startIndex;
    }

    public FindProductBO setStartIndex(Integer startIndex) {
        this.startIndex = startIndex;
        return this;
    }

    public Integer getQuerySize() {
        return querySize;
    }

    public FindProductBO setQuerySize(Integer querySize) {
        this.querySize = querySize;
        return this;
    }

    public boolean isSticky() {
        return sticky;
    }

    public FindProductBO setSticky(boolean sticky) {
        this.sticky = sticky;
        return this;
    }

    public String getProductType() {
        return productType;
    }

    public FindProductBO setProductType(String productType) {
        this.productType = productType;
        return this;
    }

    public Long getAnchorMonthPrice() {
        return anchorMonthPrice;
    }

    public FindProductBO setAnchorMonthPrice(Long anchorMonthPrice) {
        this.anchorMonthPrice = anchorMonthPrice;
        return this;
    }

    public Long getActivityId() {
        return activityId;
    }

    public FindProductBO setActivityId(Long activityId) {
        this.activityId = activityId;
        return this;
    }

    public OrderTypeEnum getOrderType() {
        return orderType;
    }

    public FindProductBO setOrderType(OrderTypeEnum orderType) {
        this.orderType = orderType;
        return this;
    }
}
