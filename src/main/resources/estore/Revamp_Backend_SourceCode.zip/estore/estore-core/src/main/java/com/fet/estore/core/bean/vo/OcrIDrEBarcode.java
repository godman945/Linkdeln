package com.fet.estore.core.bean.vo;

import java.util.Date;

public class OcrIDrEBarcode implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 第 N 個 Barcode 文字資
	料,例: 
	10604TM624820453025 
	 */
	 
	 String barcodeText; 
	
	/**
	 * 第 N 個 Barcode 格式名
	稱,例: QR code 
	 */
	 String BarcodeType;
	
	
	/**
	 * 第 N 個 Barcode 位置座
	標,例: 
	(603,2556),(1193,312
	9) 
	 */
	 String barcodePosition;
	
}
