package com.fet.estore.core.bean.vo.frontend;

import org.apache.commons.lang3.StringUtils;


/**
 *
 * @author Max Chen
 *
 */
public class ActivityVO {
	private Long    id;
	private String  title;
	private String  mobilePortalImage1;
	private String  mobilePortalImage2;
	private String  minisitePortalImage1;
	private String  minisitePortalImage2;
	private String  minisitePortalDesc;
	private Boolean isDaHandset;
	private Boolean isDaAccessory;
	private Boolean isAccessoryPreorder;
	private String  exitMessage;

	private String description;
	private String coType;
	private String url;
	private String imagePath;
	/**指定上傳名單處理狀態,成功只存SUCCESS**/
	private String nameListStatus;
	/**指定上傳名單處理欄位 0,1,2**/
	private String nameListColumn;
	private String couponId;

	private String activityType;
	private Long amount;
	private String targetId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMinisitePortalDesc() {
		return minisitePortalDesc;
	}

	public void setMinisitePortalDesc(String minisitePortalDesc) {
		this.minisitePortalDesc = minisitePortalDesc;
	}

	public Boolean getIsDaHandset() {
		return isDaHandset;
	}

	public void setIsDaHandset(Boolean isDaHandset) {
		this.isDaHandset = isDaHandset;
	}

	public Boolean getIsDaAccessory() {
		return isDaAccessory;
	}

	public void setIsDaAccessory(Boolean isDaAccessory) {
		this.isDaAccessory = isDaAccessory;
	}

	public Boolean getIsAccessoryPreorder() {
		return isAccessoryPreorder;
	}

	public void setIsAccessoryPreorder(Boolean isAccessoryPreorder) {
		this.isAccessoryPreorder = isAccessoryPreorder;
	}

	public String getExitMessage() {
		return exitMessage;
	}

	public void setExitMessage(String exitMessage) {
		this.exitMessage = exitMessage;
	}

	public String getMobilePortalImage1() {
		return mobilePortalImage1;
	}

	public void setMobilePortalImage1(String mobilePortalImage1) {
		this.mobilePortalImage1 = mobilePortalImage1;
	}

	public String getMobilePortalImage2() {
		return mobilePortalImage2;
	}

	public void setMobilePortalImage2(String mobilePortalImage2) {
		this.mobilePortalImage2 = mobilePortalImage2;
	}

	public String getDescription() {
		if(description!=null && description.length()>30){
			return StringUtils.substring(description, 0, 30)+"..";
		}else{
			return StringUtils.substring(description, 0, 30);
		}
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCoType() {
		return coType;
	}

	public void setCoType(String coType) {
		this.coType = coType;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getNameListStatus() {
		return nameListStatus;
	}

	public void setNameListStatus(String nameListStatus) {
		this.nameListStatus = nameListStatus;
	}

	public String getNameListColumn() {
		return nameListColumn;
	}

	public void setNameListColumn(String nameListColumn) {
		this.nameListColumn = nameListColumn;
	}

	public String getCouponId() {
		return couponId;
	}

	public void setCouponId(String couponId) {
		this.couponId = couponId;
	}

	public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

	public String getMinisitePortalImage1() {
		return minisitePortalImage1;
	}

	public void setMinisitePortalImage1(String minisitePortalImage1) {
		this.minisitePortalImage1 = minisitePortalImage1;
	}

	public String getMinisitePortalImage2() {
		return minisitePortalImage2;
	}

	public void setMinisitePortalImage2(String minisitePortalImage2) {
		this.minisitePortalImage2 = minisitePortalImage2;
	}

}
