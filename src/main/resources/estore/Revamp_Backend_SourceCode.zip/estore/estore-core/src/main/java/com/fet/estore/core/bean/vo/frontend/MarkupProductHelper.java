package com.fet.estore.core.bean.vo.frontend;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MarkupProductHelper {
	
	
	

	Map<String, List<ProductHelperVO>> masterProductMap = new HashMap<String, List<ProductHelperVO>>();
	Map<String, List<ProductHelperVO>> slaveProductMap = new HashMap<String, List<ProductHelperVO>>();
	
	
	public void addMarkupProducts(List<ProductHelperVO> masterProducts, List<ProductHelperVO> slaveProducts){
		String uuid = null;
		for(ProductHelperVO productHelperVO : masterProducts){
			uuid = productHelperVO.getUuid();
			break;
		}
		
		this.masterProductMap.put(uuid, masterProducts);
		this.slaveProductMap.put(uuid, slaveProducts);
		
	}
	
	public Set<String> getMarkupProductKey(){
		return this.masterProductMap.keySet();
	}
	
	public List<ProductHelperVO> getMasterProductByKey(String key){
		if(this.masterProductMap.containsKey(key)){
			return this.masterProductMap.get(key);
		}
		
		return null;
	}
	
	public List<ProductHelperVO> getSlaveProductByKey(String key){
		if(this.slaveProductMap.containsKey(key)){
			return this.slaveProductMap.get(key);
		}
		return null;
	}
	

}
