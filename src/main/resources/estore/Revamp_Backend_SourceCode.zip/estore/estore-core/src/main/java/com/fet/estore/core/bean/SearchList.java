package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class SearchList implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<SearchDataList> phone;
	private List<SearchDataList> computer;
	private List<SearchDataList> threeC; //前端變數命名為'3c',java變數不允許
	private List<SearchDataList> accessories;
	
	public List<SearchDataList> getPhone() {
		return phone;
	}
	public void setPhone(List<SearchDataList> phone) {
		this.phone = phone;
	}
	public List<SearchDataList> getComputer() {
		return computer;
	}
	public void setComputer(List<SearchDataList> computer) {
		this.computer = computer;
	}
	public List<SearchDataList> get3c() {
		return threeC;
	}
	public void set3c(List<SearchDataList> threeC) {
		this.threeC = threeC;
	}
	public List<SearchDataList> getAccessories() {
		return accessories;
	}
	public void setAccessories(List<SearchDataList> accessories) {
		this.accessories = accessories;
	}
	
	

}
