package com.fet.estore.core.bean.req;

public class CheckActivityCouponReq {
	private String couponSn;//序號
	private String couponPwd;//驗證碼
	public String getCouponSn() {
		return couponSn;
	}
	public void setCouponSn(String couponSn) {
		this.couponSn = couponSn;
	}
	public String getCouponPwd() {
		return couponPwd;
	}
	public void setCouponPwd(String couponPwd) {
		this.couponPwd = couponPwd;
	}
}
