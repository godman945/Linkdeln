package com.fet.estore.core.bean.req;

public class ActivityPromoReq {

	String orderType;

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
}
