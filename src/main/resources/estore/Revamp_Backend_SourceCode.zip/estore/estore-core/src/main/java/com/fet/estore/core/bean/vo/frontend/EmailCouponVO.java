package com.fet.estore.core.bean.vo.frontend;

/**
 * 成單寄送email顯示贈送Coupon資料
 * @author Administrator
 *
 */
public class EmailCouponVO {

	private String couponSerialNumber;
	private String price;
	private String beginDate;
	private String endDate;
	
	/**
	 * 取回Coupon序號
	 * @return
	 */
	public String getCouponSerialNumber() {
		return couponSerialNumber;
	}
	
	/**
	 * 指定Coupon序號
	 * @param couponSerialNumber
	 */
	public void setCouponSerialNumber(String couponSerialNumber) {
		this.couponSerialNumber = couponSerialNumber;
	}
	
	/**
	 * 取回折抵金額
	 * @return
	 */
	public String getPrice() {
		return price;
	}
	
	/**
	 * 指定折抵金額
	 * @param price
	 */
	public void setPrice(String price) {
		this.price = price;
	}
	
	/**
	 * 取回有效期間-開始時間
	 * @return
	 */
	public String getBeginDate() {
		return beginDate;
	}
	
	/**
	 * 指定有效期間-開始時間
	 * @param beginDate
	 */
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	
	/**
	 * 取回有效期間-結束時間
	 * @return
	 */
	public String getEndDate() {
		return endDate;
	}
	
	/**
	 * 指定有效期間-結束時間
	 * @param endDate
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
}
