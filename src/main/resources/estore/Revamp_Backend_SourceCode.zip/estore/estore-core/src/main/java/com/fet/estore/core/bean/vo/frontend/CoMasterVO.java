package com.fet.estore.core.bean.vo.frontend;

public class CoMasterVO {
	
	/** 訂單編號。 */
	private String cono;
	/** 訂單金額 **/
	private Long coPrice;	
	/**
	 * 訂單類型。
	 * <p>
	 * NH: 新啟用手機、NC: 新啟用通話、
	 * LH: 續約手機、LC: 續約通話、
	 * BB: 大寬頻新約、BH: 大寬頻續約、BC: 大寬頻續約、
	 * PH: 門號可攜新啟用手機、PC: 門號可攜新啟用通話。
	 */
	private String coType;
	/** 門號。 */
	private String msisdn;
	
	public String getCono() {
		return cono;
	}
	public void setCono(String cono) {
		this.cono = cono;
	}
	public Long getCoPrice() {
		return coPrice;
	}
	public void setCoPrice(Long coPrice) {
		this.coPrice = coPrice;
	}
	public String getCoType() {
		return coType;
	}
	public void setCoType(String coType) {
		this.coType = coType;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	
}
