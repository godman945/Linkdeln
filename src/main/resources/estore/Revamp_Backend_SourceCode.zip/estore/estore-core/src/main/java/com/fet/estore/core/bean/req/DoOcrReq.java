package com.fet.estore.core.bean.req;

import com.fet.estore.core.bean.vo.UploadFileInfo;

public class DoOcrReq {
	
	private String fileType;
	private String cono;
	private UploadFileInfo uploadFileInfo;
	
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getCono() {
		return cono;
	}
	public void setCono(String cono) {
		this.cono = cono;
	}
	public UploadFileInfo getUploadFileInfo() {
		return uploadFileInfo;
	}
	public void setUploadFileInfo(UploadFileInfo uploadFileInfo) {
		this.uploadFileInfo = uploadFileInfo;
	}
}
