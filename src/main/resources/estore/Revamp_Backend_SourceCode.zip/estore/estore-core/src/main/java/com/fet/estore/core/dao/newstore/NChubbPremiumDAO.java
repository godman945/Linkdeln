package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.ChubbPremium;

public interface NChubbPremiumDAO extends BaseDAO<ChubbPremium, Long> {
	public ChubbPremium findByPrice(Long price);
}
