package com.fet.estore.core.bean;

import java.io.Serializable;

public class OrderHappygo implements Serializable {
	
	private static final long serialVersionUID = -6201197324805955259L;

	/** happy go 折抵點數 */
	private Integer number;

	private Long amount;

	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
}
