package com.fet.estore.core.bean.vo.frontend;

/**
 * 活動配件VO
 * @author Max Chen
 *
 */
public class ActivityAccessoryGroupVO {

	/** 設備ID */
	private String productId;
	/** 料號 */
	private String fetNo;
	/** 廠牌 */
	private String brandName;
	/** 名稱 */
	private String name;
	/** 價格抬頭 */
	private String priceTitle;
	/** 圖檔 */
	private String img;
	/** 價格 */
	private Long price;
	/** 活動價 */
	private Long activityPrice;
	/** 最大庫存 */
	private Long maxInventory;
	/** 優惠價 */
	private Long discPrice;
	/** 顏色 */
	private String color;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPriceTitle() {
		return priceTitle;
	}
	public void setPriceTitle(String priceTitle) {
		this.priceTitle = priceTitle;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public Long getActivityPrice() {
		return activityPrice;
	}
	public void setActivityPrice(Long activityPrice) {
		this.activityPrice = activityPrice;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public Long getMaxInventory() {
		return maxInventory;
	}
	public void setMaxInventory(Long maxInventory) {
		this.maxInventory = maxInventory;
	}
	public Long getDiscPrice() {
		return discPrice;
	}
	public void setDiscPrice(Long discPrice) {
		this.discPrice = discPrice;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
}
