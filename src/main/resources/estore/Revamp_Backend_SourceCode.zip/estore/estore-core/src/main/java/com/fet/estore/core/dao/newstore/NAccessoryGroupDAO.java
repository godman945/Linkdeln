package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.bean.MetaInfo;
import com.fet.estore.core.bean.vo.frontend.AccessoryGroupVO;
import com.fet.estore.core.bean.vo.frontend.ActivityAccessoryGroupVO;
import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AccessoryGroup;

import java.util.List;

/**
 * 活動DAO
 * @author Max Chen
 *
 */
public interface NAccessoryGroupDAO extends BaseDAO<AccessoryGroup, String>  {

	/**
	 * 取出 配件 設備相關明細資料.
	 * 
	 * @param productId 商品代碼;資料庫表格系統代碼(uuid)
	 * @return List<AccessoryGroupVO>
	 */
	public List<AccessoryGroupVO> findAccessoryDetail4BuyAlone(String productId, boolean isEstore, boolean isMobile);


	/**
	 * 取得活動配件清單
	 * @param actId 活動ID
	 * @param uploadPath 圖片上傳目錄
	 * @param cartMaxInv 可選購之數量上限
	 * @param channel 適用通路
	 */
	public List<ActivityAccessoryGroupVO> findAccessoryGroupByActivity(Long actId, String channel, Integer pageSize, Integer pageNo, boolean isPreOrder, Integer cartMaxInv, String[] fetNos);
	
	/**
	 * 取得活動配件清單
	 * @param actId 活動ID
	 * @param uploadPath 圖片上傳目錄
	 * @param cartMaxInv 可選購之數量上限
	 */
	public List<ActivityAccessoryGroupVO> findAccessoryGroupByActivity(Long actId, boolean isPreOrder, Integer cartMaxInv);

	/**
	 * 用AliasUrl查詢配件Meta資訊
	 * @param aliasUrl
	 * @return
	 * @author Roil.Li
	 * @date 2020-10-22
	 */
	public MetaInfo findAccessoryMetaByAliasUrl(String aliasUrl);

}
