package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

import com.fet.estore.core.bean.vo.common.BannerVO;
import com.fet.estore.core.bean.vo.common.OnlineDealsVO;

/**
 * 首頁資料結構
 * 
 * @description
 * @author Phil.lin
 * @date 2020-07-10
 */
public class IndexInfo implements Serializable {

	private static final long serialVersionUID = -1041933377786630067L;
	/** 看看大家都搜什麽 */
	ServiceTags serviceTags;
	/** 我要尋找區塊 */
	SearchLink productMap;
	/** 門號活動 */
	EstorePromotion eStorePromotion;
	/** 麵包屑資訊 add by Dennis.Chen 20200716*/
	List<BreadCrumbs> breadcrumbs;
	/** Banner圖文分離資訊 add by Dennis.Chen 20200716*/
	List<BannerVO> slides;
	/** 線上申辦資訊 add by Dennis.Chen 20200716*/
	OnlineDealsVO serviceCard;
	/** 問候資訊 */
	Greeting greeting;

	public ServiceTags getServiceTags() {
		return serviceTags;
	}
	public void setServiceTags(ServiceTags serviceTags) {
		this.serviceTags = serviceTags;
	}
	public SearchLink getProductMap() {
		return productMap;
	}
	public void setProductMap(SearchLink productMap) {
		this.productMap = productMap;
	}
	public EstorePromotion geteStorePromotion() {
		return eStorePromotion;
	}
	public void seteStorePromotion(EstorePromotion eStorePromotion) {
		this.eStorePromotion = eStorePromotion;
	}
	public List<BreadCrumbs> getBreadcrumbs() {
		return breadcrumbs;
	}
	public void setBreadcrumbs(List<BreadCrumbs> breadcrumbs) {
		this.breadcrumbs = breadcrumbs;
	}
	public List<BannerVO> getSlides() {
		return slides;
	}
	public void setSlides(List<BannerVO> slides) {
		this.slides = slides;
	}
	public OnlineDealsVO getServiceCard() {
		return serviceCard;
	}
	public void setServiceCard(OnlineDealsVO serviceCard) {
		this.serviceCard = serviceCard;
	}
	public Greeting getGreeting() {
		return greeting;
	}
	public void setGreeting(Greeting greeting) {
		this.greeting = greeting;
	}
}
