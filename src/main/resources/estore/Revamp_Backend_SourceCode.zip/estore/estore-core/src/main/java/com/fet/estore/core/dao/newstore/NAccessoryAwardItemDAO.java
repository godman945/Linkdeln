package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.bean.vo.frontend.DiscountItemVO;
import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AccessoryAwardItem;

import java.util.List;
import java.util.Map;

public interface NAccessoryAwardItemDAO extends BaseDAO<AccessoryAwardItem, Long> {

	/**
	 * 取得配件贈品/折價卷
	 * @param prodIds 
	 * @return
	 */
	public Map<String, Map<String, List<DiscountItemVO>>> findAwardsForProducts(String[] prodIds);
}
