package com.fet.estore.core.bean.vo.crm;

import com.fet.estore.core.util.LogUtil;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.Set;

public class Handler1 implements SOAPHandler<SOAPMessageContext> {
	public Set<QName> getHeaders() {
		return Collections.emptySet();
	}
	
	/**
     * Returns the message encoding (e.g. utf-8)
     *
     * @param msg
     * @return
     * @throws javax.xml.soap.SOAPException
     */
    private String getMessageEncoding(SOAPMessage msg) throws SOAPException {
        String encoding = "utf-8";
        if (msg.getProperty(SOAPMessage.CHARACTER_SET_ENCODING) != null) {
            encoding = msg.getProperty(SOAPMessage.CHARACTER_SET_ENCODING).toString();
        }
        return encoding;
    }


    /**
     * Dump SOAP Message to console
     *
     * @param msg
     */
    private void dumpSOAPMessage(SOAPMessage msg) {
        if (msg == null) {
            LogUtil.debug("SOAP Message is null");
            return;
        }
        LogUtil.info("");
        LogUtil.info("--------------------");
        LogUtil.info("DUMP OF SOAP MESSAGE");
        LogUtil.info("--------------------");
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            msg.writeTo(baos);
            LogUtil.info(baos.toString(getMessageEncoding(msg)));

            // show included values
//            String values = msg.getSOAPBody().
//            System.out.println("Included values:" + values);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	

	public boolean handleMessage(SOAPMessageContext context) {
		 //Inquire incoming or outgoing message.
        boolean outbound = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

        try {

            if (outbound) {
                LogUtil.info("Direction=outbound (handleMessage)");
                SOAPMessage msg = ((SOAPMessageContext) context).getMessage();

                // get SOAP-Part
                SOAPPart sp = msg.getSOAPPart();

                //edit Envelope
                SOAPEnvelope env = sp.getEnvelope();

                // add namespaces
               
                dumpSOAPMessage(msg);


            } else {
                // INBOUND

                LogUtil.info("Direction=inbound (handleMessage)");
                SOAPMessage msg = ((SOAPMessageContext) context).getMessage();
                dumpSOAPMessage(msg);

             }

        } catch (Exception e) {

            //All other unhandled problems.
            e.printStackTrace();
        }
        return true;
	}

	public boolean handleFault(SOAPMessageContext messageContext) {
		return true;
	}

	public void close(MessageContext messageContext) {
	}
}