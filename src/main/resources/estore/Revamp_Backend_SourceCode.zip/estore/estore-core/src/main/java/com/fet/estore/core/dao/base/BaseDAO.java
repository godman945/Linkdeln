/**
 * $Id: BaseDAO.java,v 1.0, 2017-05-16 10:53:51Z, Evan Tung$
 * Copyright (c) 2007-2008 Stark Technology	Inc. All Rights	Reserved.
 */
package	com.fet.estore.core.dao.base;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;

import com.fet.estore.core.model.support.Page;
import com.fet.estore.core.model.support.Restriction;
import com.fet.estore.core.model.support.RestrictionBetween;
import com.fet.estore.core.model.support.RestrictionIn;

/**
 * Data	access object (DAO)	for	domain model
 *
 * @version		$Id: BaseDAO.java,v 1.0, 2017-05-16 10:53:51Z, Evan Tung$
 */
public interface BaseDAO<T,	ID extends Serializable>  {

	boolean	exists (ID id);

	T findById(ID id);

	void save(T	entity);

	void saveAll(List<T> entities);

	void delete(T entity);

	void deleteAll(List<T> entities);

	void deleteById(ID id);

	List<T>	findAll();

	List<T>	findByExample(T	entity,	String[] ascProperties,
			String[] descProperties);
	List<T>	findByExample(T	entity,	List<RestrictionIn>	ins, List<RestrictionBetween> rbs, String[]	ascProperties,
			String[] descProperties);
	List<T>	findByExample(T	entity,	List<Restriction> restrictions,	String[] ascProperties,
			String[] descProperties);
	List<T>	findByExample(T	entity,	int	pageNo,	int	pageSize,
			String[] ascProperties,	String[] descProperties);

	Integer	count(T	entity);

	List<T>	findByProperty(String property,	Object value);
	List<T>	findByPropertyLike (String property, String	value);
	List<T>	findByPropertyLike (String property, String	value, int pageSize);

	T merge(T entity);

	void attachDirty(T entity);

	void attachClean(T entity);

	Page<T>	pageQueryByExample(T entity, int pageNo, int pageSize);

	Page<T>	pageQueryByExample(T entity, String[] ascProperties, String[] descProperties, int pageNo, int pageSize);

	Page<T>	pageQueryByLikeExample(T entity, int pageNo, int pageSize);
    Page<T> pageQueryByLikeExample(T entity, int pageNo, int pageSize, String[] ascProperties, String[] descProperties);

	void evict(T entity);

	void update(T entity);

	/**
	 * This	method will	makes Hibernate	QBE	(Query by Example) work	with the
	 * identifier property of the entity.
	 * <p>
	 * Use this method instead of the following codes:
	 * <pre>
	 *   Criteria criteria = createCriteria();
	 *   criteria.add(Example.create(entity));
	 * </pre>
	 */
	Criteria createEnhancedCriteriaByExample (T	entity);
	
	/**
	 * 以物件識別取得物件。
	 * @param ids 物件識別陣列
	 * @return 對應物件
	 */
	List<T> findByIds(Collection<ID> ids);
}