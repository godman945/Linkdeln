package com.fet.estore.core.bean;

import com.fet.estore.core.bean.bo.ShoppingResultBO;
import com.fet.estore.core.bean.bo.ShoppingResultDiscountBO;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 商品明細頁 - 商品詳細資訊
 *
 * @description
 * @author Ted.Hsieh
 * @date 2020-08-11
 */

public class ProductDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final String PRODUCT_DETAIL_SPEC = "產品規格";
    public static final String PRODUCT_DETAIL_INTRO = "產品介紹";
    public static final String PRODUCT_DETAIL_FEATURE = "產品特色";


    /** 商品ID */
    private String productId;
    /** 商品類別 */
    private String type;
    /** 麵包屑之商品名稱 */
    private String slug;
    /** 頁面顯示商品名稱 */
    private String name;
    /** 行銷標籤 對應方式 CFG_PRODUCT_TAG.TYPE = '1' */
    private String ribbon;
    /** 商品屬性標籤 對應方式 CFG_PRODUCT_TAG.TYPE = '3' */
    private List<String> tag;
    /** 頁面預設選擇料號(顏色) */
    private String defaultFetNo;
    /** 商品顏色和對應圖片清單 */
    private Map<String, List<String>> images;
    /** 商品顏色和對應圖片清單 */
    private List<ProductFetnoDetail> colors;
    /** 商品預約按鈕顯示狀態 */
    private Map<String, String> buttonStatus;
    /** 商品提醒資訊 */
    private List<Notice> notice;
    /** 商品對應可銷售類型(搭門號,買單機) */
    private List<Plan> withPlan;
    /** 商品原價 */
    private Long originPrice;
    /** 商品銷售價 */
    private Long salePrice;
    /** 商品專案價 */
    private Long projectPrice;
    /** 折扣資訊(商品對應的折扣詳細內容) */
    private List<ShoppingResultDiscountBO> discountInfo;
    /** 商品是否為獨賣件 */
    private boolean exclusiveStatus;
    /** 系統設定最大購買上限 */
    private Long systemMaxAllowBuyAmount;
    /** 可申辦類別 */
    private List<String> orderTypeList;

    private String activityOrderType;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRibbon() {
        return ribbon;
    }

    public void setRibbon(String ribbon) {
        this.ribbon = ribbon;
    }

    public List<String> getTag() {
        return tag;
    }

    public void setTag(List<String> tag) {
        this.tag = tag;
    }

    public String getDefaultFetNo() {
        return defaultFetNo;
    }

    public void setDefaultFetNo(String defaultFetNo) {
        this.defaultFetNo = defaultFetNo;
    }

    public Map<String, List<String>> getImages() {
        return images;
    }

    public void setImages(Map<String, List<String>> images) {
        this.images = images;
    }

    public List<ProductFetnoDetail> getColors() {
        return colors;
    }

    public void setColors(List<ProductFetnoDetail> colors) {
        this.colors = colors;
    }

    public Map<String, String> getButtonStatus() {
        return buttonStatus;
    }

    public void setButtonStatus(Map<String, String> buttonStatus) {
        this.buttonStatus = buttonStatus;
    }

    public List<Notice> getNotice() {
        return notice;
    }

    public void setNotice(List<Notice> notice) {
        this.notice = notice;
    }

    public List<Plan> getWithPlan() {
        return withPlan;
    }

    public void setWithPlan(List<Plan> withPlan) {
        this.withPlan = withPlan;
    }

    public Long getOriginPrice() {
        return originPrice;
    }

    public void setOriginPrice(Long originPrice) {
        this.originPrice = originPrice;
    }

    public Long getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Long salePrice) {
        this.salePrice = salePrice;
    }

    public Long getProjectPrice() {
        return projectPrice;
    }

    public void setProjectPrice(Long projectPrice) {
        this.projectPrice = projectPrice;
    }

    public List<ShoppingResultDiscountBO> getDiscountInfo() {
        return discountInfo;
    }

    public void setDiscountInfo(List<ShoppingResultDiscountBO> discountInfo) {
        this.discountInfo = discountInfo;
    }

    public boolean isExclusiveStatus() {
        return exclusiveStatus;
    }

    public void setExclusiveStatus(boolean exclusiveStatus) {
        this.exclusiveStatus = exclusiveStatus;
    }

    public Long getSystemMaxAllowBuyAmount() {
        return systemMaxAllowBuyAmount;
    }

    public void setSystemMaxAllowBuyAmount(Long systemMaxAllowBuyAmount) {
        this.systemMaxAllowBuyAmount = systemMaxAllowBuyAmount;
    }

    public List<String> getOrderTypeList() {
        return orderTypeList;
    }

    public void setOrderTypeList(List<String> orderTypeList) {
        this.orderTypeList = orderTypeList;
    }

    public String getActivityOrderType() {
        return activityOrderType;
    }

    public void setActivityOrderType(String activityOrderType) {
        this.activityOrderType = activityOrderType;
    }
}
