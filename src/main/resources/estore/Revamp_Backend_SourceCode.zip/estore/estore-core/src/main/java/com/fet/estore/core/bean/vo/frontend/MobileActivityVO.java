package com.fet.estore.core.bean.vo.frontend;

public class MobileActivityVO {
	
	private String orderType;
	private String actTitle;
	private Long actId;
	private String portalImage1;
	
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getActTitle() {
		return actTitle;
	}
	public void setActTitle(String actTitle) {
		this.actTitle = actTitle;
	}
	public Long getActId() {
		return actId;
	}
	public void setActId(Long actId) {
		this.actId = actId;
	}
	public String getPortalImage1() {
		return portalImage1;
	}
	public void setPortalImage1(String portalImage1) {
		this.portalImage1 = portalImage1;
	}
}
