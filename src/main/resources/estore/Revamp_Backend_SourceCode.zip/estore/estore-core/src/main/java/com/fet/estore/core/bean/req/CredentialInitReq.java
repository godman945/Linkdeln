package com.fet.estore.core.bean.req;

public class CredentialInitReq {
	private boolean isEbu;
	private Long activityId;
	private String orderType;
	
	//補證件上傳傳入參數
//	private String uploadType;
//	private String enCono;
//	private String certUploadType;
//	private String certCono;
//	private String fromWhere;
	//補證件上傳傳入參數
	public boolean getIsEbu() {
		return isEbu;
	}
	public void setIsEbu(boolean isEbu) {
		this.isEbu = isEbu;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
}
