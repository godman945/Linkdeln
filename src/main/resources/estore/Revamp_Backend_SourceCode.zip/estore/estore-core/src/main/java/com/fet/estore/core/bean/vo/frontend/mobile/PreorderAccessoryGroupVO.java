/**
 * 程式資訊摘要：小網活動預約首頁設備/配件物件
 * 類別名稱：.java
 * 程式內容說明：
 * 版本資訊：
 * 程式設計人員姓名：陳建智
 * 程式修改記錄：2014-08-15
 * 版權宣告：
 */
package com.fet.estore.core.bean.vo.frontend.mobile;

import java.util.List;

import com.fet.estore.core.model.MobilePreorderActProduct;
import com.fet.estore.core.bean.vo.frontend.AccessoryGroupVO;;
/**
 * 
 */
public class PreorderAccessoryGroupVO {
	
	private String productId = null;
	
	private String fetNo = null;

	private List<AccessoryGroupVO> accessoryGroupVOList = null;
	
	private MobilePreorderActProduct mobilePreorderActProduct = null;
	
	private boolean showStartSfcationBox = false;
	
	private boolean showEndSfcationBox = false;
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public String getFetNo() {
		return fetNo;
	}

	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

	public List<AccessoryGroupVO> getAGVOList() {
		return accessoryGroupVOList;
	}

	public void setAGVOList(List<AccessoryGroupVO> accessoryGroupVOList) {
		this.accessoryGroupVOList = accessoryGroupVOList;
	}
	
	public Long getErpPrice() {
		if(accessoryGroupVOList == null || accessoryGroupVOList.size() == 0) {
			return 0L;
		}
		return accessoryGroupVOList.get(0).getErpPrice();
	}

	public MobilePreorderActProduct getMPAP() {
		return mobilePreorderActProduct;
	}

	public void setMPAP(MobilePreorderActProduct mobilePreorderActProduct) {
		this.mobilePreorderActProduct = mobilePreorderActProduct;
	}

	public boolean getShowStartSfcationBox() {
		return showStartSfcationBox;
	}

	public void setShowStartSfcationBox(boolean showStartSfcationBox) {
		this.showStartSfcationBox = showStartSfcationBox;
	}

	public boolean getShowEndSfcationBox() {
		return showEndSfcationBox;
	}

	public void setShowEndSfcationBox(boolean showEndSfcationBox) {
		this.showEndSfcationBox = showEndSfcationBox;
	}
}
