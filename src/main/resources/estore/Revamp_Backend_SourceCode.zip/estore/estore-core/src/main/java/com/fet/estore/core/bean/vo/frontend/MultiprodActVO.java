package com.fet.estore.core.bean.vo.frontend;

import java.util.Date;

public class MultiprodActVO {
    
    private Long id;
    private String title;
    private String description;
    private String pcImagePath;
    private String mobileImagePath;
    /** 上架時間 */
    private Date onsaleDate;
    /** 下架時間 */
    private Date offDate;
    private String entryPoint;
    private String deliveryType;
    private String activityUrl;
    private String activityUrlType;
    private String shareTitle;
    private String shareDescription;
    private String shareImagePath;
    private Boolean isNameList;
    private String nameListStatus;
    private String nameListColumn;
    private Boolean isNhAward;
    private Boolean isLhAward;
    private Boolean isNpAward;
    private Long awardCouponId;
    private String awardCouponDesc;
    private Integer awardDiscountAmount;
    private String awardDiscountDesc;
    private String awardDiscountDisplayName;
    /** 優惠贈送圖檔(pc) */
	private String awardIcon;
	/** 優惠贈送圖檔(mobile) */
	private String awardIconMobile;
	/** 瞭解更多url */
	private String awardDetailUrl;
	/**成本中心代碼**/
	private String awardDiscountCode;
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getActivityUrl() {
        return activityUrl;
    }

    public void setActivityUrl(String activityUrl) {
        this.activityUrl = activityUrl;
    }

    public String getActivityUrlType() {
        return activityUrlType;
    }

    public void setActivityUrlType(String activityUrlType) {
        this.activityUrlType = activityUrlType;
    }

    public String getAwardCouponDesc() {
        return awardCouponDesc;
    }
    
    public void setAwardCouponDesc(String awardCouponDesc) {
        this.awardCouponDesc = awardCouponDesc;
    }
    
    public Long getAwardCouponId() {
        return awardCouponId;
    }
    
    public void setAwardCouponId(Long awardCouponId) {
        this.awardCouponId = awardCouponId;
    }
    
    public Integer getAwardDiscountAmount() {
        return awardDiscountAmount;
    }
    
    public void setAwardDiscountAmount(Integer awardDiscountAmount) {
        this.awardDiscountAmount = awardDiscountAmount;
    }
    
    public String getAwardDiscountDesc() {
        return awardDiscountDesc;
    }
    
    public void setAwardDiscountDesc(String awardDiscountDesc) {
        this.awardDiscountDesc = awardDiscountDesc;
    }
    
    public String getAwardDiscountDisplayName() {
		return awardDiscountDisplayName;
	}

	public void setAwardDiscountDisplayName(String awardDiscountDisplayName) {
		this.awardDiscountDisplayName = awardDiscountDisplayName;
	}

	public String getDeliveryType() {
        return deliveryType;
    }
    
    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getEntryPoint() {
        return entryPoint;
    }
    
    public void setEntryPoint(String entryPoint) {
        this.entryPoint = entryPoint;
    }
    
    public Boolean getIsLhAward() {
        return isLhAward;
    }
    
    public void setIsLhAward(Boolean isLhAward) {
        this.isLhAward = isLhAward;
    }
    
    public Boolean getIsNameList() {
        return isNameList;
    }
    
    public void setIsNameList(Boolean isNameList) {
        this.isNameList = isNameList;
    }
    
    public Boolean getIsNhAward() {
        return isNhAward;
    }
    
    public void setIsNhAward(Boolean isNhAward) {
        this.isNhAward = isNhAward;
    }
    
    public Boolean getIsNpAward() {
        return isNpAward;
    }
    
    public void setIsNpAward(Boolean isNpAward) {
        this.isNpAward = isNpAward;
    }
    
    public String getMobileImagePath() {
        return mobileImagePath;
    }
    
    public void setMobileImagePath(String mobileImagePath) {
        this.mobileImagePath = mobileImagePath;
    }
    
    public String getNameListStatus() {
        return nameListStatus;
    }

    public void setNameListStatus(String nameListStatus) {
        this.nameListStatus = nameListStatus;
    }

    public String getNameListColumn() {
        return nameListColumn;
    }
    
    public void setNameListColumn(String nameListColumn) {
        this.nameListColumn = nameListColumn;
    }
    
    public String getPcImagePath() {
        return pcImagePath;
    }
    
    public void setPcImagePath(String pcImagePath) {
        this.pcImagePath = pcImagePath;
    }
    
    public String getShareDescription() {
        return shareDescription;
    }
    
    public void setShareDescription(String shareDescription) {
        this.shareDescription = shareDescription;
    }
    
    public String getShareImagePath() {
        return shareImagePath;
    }
    
    public void setShareImagePath(String shareImagePath) {
        this.shareImagePath = shareImagePath;
    }
    
    public String getShareTitle() {
        return shareTitle;
    }
    
    public void setShareTitle(String shareTitle) {
        this.shareTitle = shareTitle;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }

	public Date getOnsaleDate() {
		return onsaleDate;
	}

	public void setOnsaleDate(Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}

	public Date getOffDate() {
		return offDate;
	}

	public void setOffDate(Date offDate) {
		this.offDate = offDate;
	}

	public String getAwardIcon() {
		return awardIcon;
	}

	public void setAwardIcon(String awardIcon) {
		this.awardIcon = awardIcon;
	}

	public String getAwardIconMobile() {
		return awardIconMobile;
	}

	public void setAwardIconMobile(String awardIconMobile) {
		this.awardIconMobile = awardIconMobile;
	}

	public String getAwardDetailUrl() {
		return awardDetailUrl;
	}

	public void setAwardDetailUrl(String awardDetailUrl) {
		this.awardDetailUrl = awardDetailUrl;
	}

	public String getAwardDiscountCode() {
		return awardDiscountCode;
	}

	public void setAwardDiscountCode(String awardDiscountCode) {
		this.awardDiscountCode = awardDiscountCode;
	}

}
