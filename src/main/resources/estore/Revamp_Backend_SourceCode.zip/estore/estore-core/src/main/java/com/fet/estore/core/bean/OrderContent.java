package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class OrderContent implements Serializable {

	private static final long serialVersionUID = 736730294422502606L;
	private String title;
	//方案內容
	private List<Object> content;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<Object> getContent() {
		return content;
	}
	public void setContent(List<Object> content) {
		this.content = content;
	}
}
