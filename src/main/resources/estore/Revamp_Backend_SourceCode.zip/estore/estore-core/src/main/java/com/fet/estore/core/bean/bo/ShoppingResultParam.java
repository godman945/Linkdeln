package com.fet.estore.core.bean.bo;

import com.fet.estore.core.bean.IShoppingResultParam;
import com.fet.estore.core.bean.vo.frontend.CouponVO;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-20
 * @description
 */
public class ShoppingResultParam implements IShoppingResultParam {

    private CouponVO cpn;
    private String couponSn;
    private String orderType;
    private String oplId;
    private String deliveryType;
    private Long prodVaPrice;
    // prepaidPrice目前沒有被用, 預設null
    // 註解: omni 不使用預繳金查詢,改用ANote取得
    private Long prepaidPrice;
    private Long hgPoints;
    private Long hgPrice;
    private Long activityId;
    /** 門號競標 */
    private String auctionMsisdn;
    private Integer auctionActivityId;
    private String auctionRocId;
    private Integer auctionPrice;
    /** 銷售通道 */
    private String channel;

    /** 多組商品標籤 */
    private boolean mpAct;
    private boolean markup;

    /** 控制流程內的計算標籤*/
    private boolean actDisc;
    private Boolean hgDetail;
    private Boolean accDetail;

    /** 不知道未來會不會用到 */
    private boolean regAct;

    private String mainFetNo;
    private List<ShoppingProductBO> productBOs = new ArrayList<>();

    String[] prodIdArr;
    String[] accIdArr;
    Long[] mpDiscIdArr;

    public CouponVO getCpn() {
        return cpn;
    }
    public void setCpn(CouponVO cpn) {
        this.cpn = cpn;
    }
    public String getRedeemCouponSerial() {
        return couponSn;
    }
    public void setRedeemCouponSerial(String couponSn) {
        this.couponSn = couponSn;
    }
    public String getOrderType() {
        return orderType;
    }
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    public String getOnsalePromoListId() {
        return oplId;
    }
    public void setOnsalePromoListId(String oplId) {
        this.oplId = oplId;
    }
    public String getDeliveryType() {
        return deliveryType;
    }
    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }
    public Long getProdVaPrice() {
        return prodVaPrice;
    }
    public void setProdVaPrice(Long prodVaPrice) {
        this.prodVaPrice = prodVaPrice;
    }
    public Long getPrepaidPrice() {
        return prepaidPrice;
    }
    public void setPrepaidPrice(Long prepaidPrice) {
        this.prepaidPrice = prepaidPrice;
    }
    public Long getHgRedeemPoint() {
        return hgPoints;
    }
    public void setHgRedeemPoint(Long hgPoints) {
        this.hgPoints = hgPoints;
    }
    public Long getHgRedeemPrice() {
        return hgPrice;
    }
    public void setHgRedeemPrice(Long hgPrice) {
        this.hgPrice = hgPrice;
    }
    public String getAuctionMsisdn() {
        return auctionMsisdn;
    }
    public void setAuctionMsisdn(String auctionMsisdn) {
        this.auctionMsisdn = auctionMsisdn;
    }
    public Integer getAuctionActivityId() {
        return auctionActivityId;
    }
    public void setAuctionActivityId(Integer auctionActivityId) {
        this.auctionActivityId = auctionActivityId;
    }
    public String getAuctionRocId() {
        return auctionRocId;
    }
    public void setAuctionRocId(String auctionRocId) {
        this.auctionRocId = auctionRocId;
    }
    public Integer getAuctionPrice() {
        return auctionPrice;
    }
    public void setAuctionPrice(Integer auctionPrice) {
        this.auctionPrice = auctionPrice;
    }
    public Long getActivityId() {
        return activityId;
    }
    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }
    public boolean isMpAct() {
        return mpAct;
    }
    public void setMpAct(boolean mpAct) {
        this.mpAct = mpAct;
    }
    public boolean isMarkup() {
        return markup;
    }
    public void setMarkup(boolean markup) {
        this.markup = markup;
    }
    public boolean hasActDisc() {
        return actDisc;
    }
    public void setActDisc(boolean actDisc) {
        this.actDisc = actDisc;
    }
    public Boolean hasHgDetail() {
        return hgDetail;
    }
    public void setHgDetail(Boolean hgDetail) {
        this.hgDetail = hgDetail;
    }
    public Boolean hasAccDetail() {
        return accDetail;
    }
    public void setAccDetail(Boolean accDetail) {
        this.accDetail = accDetail;
    }
    public String[] getProdIdArr() {
        return prodIdArr;
    }
    public void setProdIdArr(String[] prodIdArr) {
        this.prodIdArr = prodIdArr;
    }
    public String[] getAccIdArr() {
        return accIdArr;
    }
    public void setAccIdArr(String[] accIdArr) {
        this.accIdArr = accIdArr;
    }
    public Long[] getMpDiscIdArr() {
        return mpDiscIdArr;
    }
    public void setMpDiscIdArr(Long[] mpDiscIdArr) {
        this.mpDiscIdArr = mpDiscIdArr;
    }
    public String getMainFetNo() {
        return mainFetNo;
    }
    public void setMainFetNo(String mainFetNo) {
        this.mainFetNo = mainFetNo;
    }
    public List<ShoppingProductBO> getProductBOs() {
        return productBOs;
    }
    public void setProductBOs(List<ShoppingProductBO> productBOs) {
        this.productBOs = productBOs;
    }
    public boolean isRegAct() {
        return regAct;
    }
    public void setRegAct(boolean regAct) {
        this.regAct = regAct;
    }
}
