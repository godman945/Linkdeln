package com.fet.estore.core.bean.req;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-09-04
 * @description
 */
public class InitActivityReq {

    @JsonProperty("event_id")
    private Long activityId;

    private Integer siteId;

    @JsonProperty("co_type")
    private String orderType;

    @JsonProperty("prod_id")
    private String handsetProductId;

    @JsonProperty("p_code")
    private String onsalePromoListId;

    @JsonProperty("coupon_id")
    private String couponSn;

    @JsonProperty("pwd")
    private String couponPwd;

    @JsonProperty("da_type")
    private String flowDaType;

    @JsonProperty("acc_fetnos")
    private String actAccFetNos;

    @JsonProperty("acc_qtys")
    private String actAccQtys;

    //private String mobileWeb;

    private String trial;

    @JsonProperty("coupon_verified")
    private String paraCouponVerified;

    @JsonProperty("UID")
    private String fridayUid;

    @JsonProperty("FNO")
    private String fridayOrderNo;

    private String param;

    private String ebu;

    @JsonProperty("RID")
    private String rId;

    @JsonProperty("Click_ID")
    private String clickId;

    private String chId;

    private String chActId;

    @JsonProperty("WT.mc_Id")
    private String wtMcId;

    @JsonProperty("WTshort_k")
    private String wtShortK;

    private String app;

    private String eservice;

    private String serviceChannel;

    private String dOfferid;

    private String onnetOfferid;

    private String offnetOfferid;

    private String friday;

    @JsonProperty("SSO")
    private String eserviceUid;

    private String captcha;

    private boolean mobile;

    public Long getActivityId() {
        return activityId;
    }
    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }
    public Integer getSiteId() {
        return siteId;
    }
    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }
    public String getOrderType() {
        return orderType;
    }
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    public String getHandsetProductId() {
        return handsetProductId;
    }
    public void setHandsetProductId(String handsetProductId) {
        this.handsetProductId = handsetProductId;
    }
    public String getOnsalePromoListId() {
        return onsalePromoListId;
    }
    public void setOnsalePromoListId(String onsalePromoListId) {
        this.onsalePromoListId = onsalePromoListId;
    }
    public String getCouponSn() {
        return couponSn;
    }
    public void setCouponSn(String couponSn) {
        this.couponSn = couponSn;
    }
    public String getCouponPwd() {
        return couponPwd;
    }
    public void setCouponPwd(String couponPwd) {
        this.couponPwd = couponPwd;
    }
    public String getFlowDaType() {
        return flowDaType;
    }
    public void setFlowDaType(String flowDaType) {
        this.flowDaType = flowDaType;
    }
    public String getActAccFetNos() {
        return actAccFetNos;
    }
    public void setActAccFetNos(String actAccFetNos) {
        this.actAccFetNos = actAccFetNos;
    }
    public String getActAccQtys() {
        return actAccQtys;
    }
    public void setActAccQtys(String actAccQtys) {
        this.actAccQtys = actAccQtys;
    }
    public String getTrial() {
        return trial;
    }
    public void setTrial(String trial) {
        this.trial = trial;
    }
    public String getParaCouponVerified() {
        return paraCouponVerified;
    }
    public void setParaCouponVerified(String paraCouponVerified) {
        this.paraCouponVerified = paraCouponVerified;
    }
    public String getFridayUid() {
        return fridayUid;
    }
    public void setFridayUid(String fridayUid) {
        this.fridayUid = fridayUid;
    }
    public String getFridayOrderNo() {
        return fridayOrderNo;
    }
    public void setFridayOrderNo(String fridayOrderNo) {
        this.fridayOrderNo = fridayOrderNo;
    }
    public String getParam() {
        return param;
    }
    public void setParam(String param) {
        this.param = param;
    }
    public String getEbu() {
        return ebu;
    }
    public void setEbu(String ebu) {
        this.ebu = ebu;
    }
    public String getrId() {
        return rId;
    }
    public void setrId(String rId) {
        this.rId = rId;
    }
    public String getClickId() {
        return clickId;
    }
    public void setClickId(String clickId) {
        this.clickId = clickId;
    }
    public String getChId() {
        return chId;
    }
    public void setChId(String chId) {
        this.chId = chId;
    }
    public String getChActId() {
        return chActId;
    }
    public void setChActId(String chActId) {
        this.chActId = chActId;
    }
    public String getWtMcId() {
        return wtMcId;
    }
    public void setWtMcId(String wtMcId) {
        this.wtMcId = wtMcId;
    }
    public String getWtShortK() {
        return wtShortK;
    }
    public void setWtShortK(String wtShortK) {
        this.wtShortK = wtShortK;
    }
    public String getApp() {
        return app;
    }
    public void setApp(String app) {
        this.app = app;
    }
    public String getEservice() {
        return eservice;
    }
    public void setEservice(String eservice) {
        this.eservice = eservice;
    }
    public String getServiceChannel() {
        return serviceChannel;
    }
    public void setServiceChannel(String serviceChannel) {
        this.serviceChannel = serviceChannel;
    }
    public String getdOfferid() {
        return dOfferid;
    }
    public void setdOfferid(String dOfferid) {
        this.dOfferid = dOfferid;
    }
    public String getOnnetOfferid() {
        return onnetOfferid;
    }
    public void setOnnetOfferid(String onnetOfferid) {
        this.onnetOfferid = onnetOfferid;
    }
    public String getOffnetOfferid() {
        return offnetOfferid;
    }
    public void setOffnetOfferid(String offnetOfferid) {
        this.offnetOfferid = offnetOfferid;
    }
    public String getFriday() {
        return friday;
    }
    public void setFriday(String friday) {
        this.friday = friday;
    }
    public String getEserviceUid() {
        return eserviceUid;
    }
    public void setEserviceUid(String eserviceUid) {
        this.eserviceUid = eserviceUid;
    }
    public String getCaptcha() {
        return captcha;
    }
    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }
    public boolean isMobile() {
        return mobile;
    }
    public void setMobile(boolean mobile) {
        this.mobile = mobile;
    }
}
