package com.fet.estore.core.bean;

import java.io.Serializable;

public class OrderCoupon implements Serializable {
	
	private static final long serialVersionUID = 8102629038272769860L;
	
	/** 酷碰券號碼 */
	private String code;
	/** 酷碰券名稱 */
	private String name;
	/** 酷碰券折抵金額 */
	private Long amount;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
