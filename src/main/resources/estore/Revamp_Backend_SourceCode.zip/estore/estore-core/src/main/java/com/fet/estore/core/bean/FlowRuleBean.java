package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

import com.fet.estore.core.enums.OrderFlowEnum;

public class FlowRuleBean implements Serializable {

	private static final long serialVersionUID = 8773031348067129L;
	
	/** 流程資料 */
	private OrderFlowEnum ruleEnum;
	/** 流程完成點 */
	private boolean completeFlow;
	/** 完成頁面 */
	private boolean finishPage;
	/** 驗證規則 MAP */
	private List<OrderFlowEnum> ruleList;
	
	public FlowRuleBean get() {
		return this;
	}
	
	public boolean isCompleteFlow() {
		return completeFlow;
	}
	public void setCompleteFlow(boolean completeFlow) {
		this.completeFlow = completeFlow;
	}
	public boolean isFinishPage() {
		return finishPage;
	}
	public void setFinishPage(boolean finishPage) {
		this.finishPage = finishPage;
	}
	public List<OrderFlowEnum> getRuleList() {
		return ruleList;
	}
	public void setRuleList(List<OrderFlowEnum> ruleMap) {
		this.ruleList = ruleMap;
	}
	public OrderFlowEnum getRuleEnum() {
		return ruleEnum;
	}
	public void setRuleEnum(OrderFlowEnum ruleEnum) {
		this.ruleEnum = ruleEnum;
	}

	
}
