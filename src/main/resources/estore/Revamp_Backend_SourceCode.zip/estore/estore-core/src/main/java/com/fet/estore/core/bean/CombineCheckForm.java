package com.fet.estore.core.bean;

import java.io.Serializable;

public class CombineCheckForm implements Serializable {

	private static final long serialVersionUID = -4556570731343151972L;
	private String mdn;
	private String rocId;
	private String orderType;
	
	public String getMdn() {
		return mdn;
	}
	public void setMdn(String mdn) {
		this.mdn = mdn;
	}
	public String getRocId() {
		return rocId;
	}
	public void setRocId(String rocId) {
		this.rocId = rocId;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
}
