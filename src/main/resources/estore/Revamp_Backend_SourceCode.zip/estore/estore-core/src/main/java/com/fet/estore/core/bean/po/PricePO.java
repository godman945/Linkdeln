package com.fet.estore.core.bean.po;

import java.io.Serializable;

/**
 * @author Klyve.Chen
 * @since 2020-08-22
 */
public class PricePO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String productId;

    private String fetNo;

    private Long erpPrice;

    private Long posPrice;

    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
    public String getFetNo() {
        return fetNo;
    }
    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }
    public Long getErpPrice() {
        return erpPrice;
    }
    public void setErpPrice(Long erpPrice) {
        this.erpPrice = erpPrice;
    }
    public Long getPosPrice() {
        return posPrice;
    }
    public void setPosPrice(Long posPrice) {
        this.posPrice = posPrice;
    }
}
