package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CfgFaqItem;

import java.util.List;

public interface ICfgFaqItemDao extends BaseDAO<CfgFaqItem, String>{

	public List<CfgFaqItem> findByPageName(String name);

}
