package com.fet.estore.core.bean.vo.common;

import java.io.Serializable;

/**
 * @description Banner圖文分離Buttoon資料結構
 * @autor Dennis.Chen
 * @date 2020-07-14
 */
public class BannerActionVO implements Serializable{
	
	private static final long serialVersionUID = -169024033397800843L;
	String text; //Button文字
	String link; //Button連結
	String btnStyle; //Button外觀格式
	String target; // 連結開啟方式

	public BannerActionVO() {
	}
	
	public BannerActionVO(String text, String link, String btnStyle, String target) {
		super();
		this.text = text;
		this.link = link;
		this.btnStyle = btnStyle;
		this.target = target;
	}
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getBtnStyle() {
		return btnStyle;
	}
	public void setBtnStyle(String btnStyle) {
		this.btnStyle = btnStyle;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
}
