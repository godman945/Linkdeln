package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 紅配綠活動購物VO
 * @author Max Chen
 *
 */
public class ShoppingHSGuideVO {
	
	/** 活動ID */
	private Long actId;
	
	/** 活動折扣清單 */
	private List<DiscountResultDiscountVO> discounts = new ArrayList<DiscountResultDiscountVO>();
	
	/** 商品清單 */
	private Map<String, Map<String, ShoppingHSGuideDetailVO>> detailMaps = new LinkedHashMap<String, Map<String, ShoppingHSGuideDetailVO>>();

	/** 小計 */
	private Long totalPrice;
	
	/** 折扣金額 */
	private Long discAmount;


	public Long getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Long getActId() {
		return actId;
	}

	public void setActId(Long actId) {
		this.actId = actId;
	}

	public Map<String, Map<String, ShoppingHSGuideDetailVO>> getDetailMaps() {
		return detailMaps;
	}

	public void setDetailMaps(Map<String, Map<String, ShoppingHSGuideDetailVO>> detailMaps) {
		this.detailMaps = detailMaps;
	}

	public Long getDiscAmount() {
		return discAmount;
	}

	public void setDiscAmount(Long discAmount) {
		this.discAmount = discAmount;
	}

	public List<DiscountResultDiscountVO> getDiscounts() {
		return discounts;
	}

	public void setDiscounts(List<DiscountResultDiscountVO> discounts) {
		this.discounts = discounts;
	}
}
