/**
 * 配件 頁籤分類設定檔
 */
package com.fet.estore.core.bean.vo.frontend;

/**
 * @author Brian
 * 
 */
public class AdTabAccessoryCategoryVO {

	/** 頁籤編號 */
	private String adTabId;
	/** 分類編號 */
	private String accessoryCategoryId;

	public String getAdTabId() {
		return adTabId;
	}

	public void setAdTabId(String adTabId) {
		this.adTabId = adTabId;
	}

	public String getAccessoryCategoryId() {
		return accessoryCategoryId;
	}

	public void setAccessoryCategoryId(String accessoryCategoryId) {
		this.accessoryCategoryId = accessoryCategoryId;
	}
}
