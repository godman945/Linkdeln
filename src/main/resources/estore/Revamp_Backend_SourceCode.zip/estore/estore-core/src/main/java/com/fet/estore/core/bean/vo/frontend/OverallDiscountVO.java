package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.bean.vo.IDiscountItem;

public class OverallDiscountVO implements IDiscountItem {

	public static String TYPE_HANDSET = "HANDSET";

	public static String TYPE_ACCESSORY = "ACCESSORY";//原值TYPE_ACCESSORY

	private String type;	
	private Long id;
	private String discountCode;
	private Double discountRatio;
	private Long costCenterId;
	private String discountName;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Deprecated
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public Double getDiscountRatio() {
		return discountRatio;
	}
	public void setDiscountRatio(Double discountRatio) {
		this.discountRatio = discountRatio;
	}
	public Long getCostCenterId() {
		return costCenterId;
	}
	public void setCostCenterId(Long costCenterId) {
		this.costCenterId = costCenterId;
	}
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}


	@Override
	public Long getAaiId() {
		return null;
	}
	@Override
	public String getCode() {
		return discountCode;
	}
	@Override
	public String getFetNo() {
		return null;
	}
	@Override
	public Long getActivityId() {
		return null;
	}
	@Override
	public String getName() {
		return discountName;
	}
	@Override
	public Long getAmount() {
		return null;
	}
	@Override
	public Long getCouponId() {
		return null;
	}
	@Override
	public Long getOfferId() {
		return null;
	}
	@Override
	public Long getActualDiscountAmt() {
		return null;
	}
	@Override
	public String getDisplayGroup() {
		return null;
	}

}
