package com.fet.estore.core.bean.vo.frontend;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.fet.estore.core.model.ActivityAwardItem;

/**
 * 折扣VO
 * @author Max Chen
 *
 */
public class DiscountVO {
	// property -------------------------------------------------------------------------
	private Map<String, Set<DiscountItemVO>> discountItemMap = new TreeMap<String, Set<DiscountItemVO>>();
	private Map<String, Map<String, Set<DiscountItemVO>>> promoDiscountMap = new TreeMap<String, Map<String, Set<DiscountItemVO>>>();
	private Map<String, Map<String, Set<DiscountItemVO>>> productDiscountMap = new TreeMap<String, Map<String, Set<DiscountItemVO>>>();
	
	// business method ------------------------------------------------------------------
	
	/**
	 * 取得所有折扣
	 * @return
	 */
	public Map<String, Set<DiscountItemVO>> getAllDiscount() {
		return discountItemMap;
	}
	
	/**
	 * 取得配件折扣
	 * @return
	 */
	public Set<DiscountItemVO> getAccessoryDiscount() {
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_ACCESSORY)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_ACCESSORY);
		}else{
			return new HashSet<DiscountItemVO>();
		}
		
	}
	
	/**
	 * 取得設備折扣
	 * @return
	 */
	public Set<DiscountItemVO> getDeviceDiscount() {		
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_DEVICE)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_DEVICE);
		}else{
			return new HashSet<DiscountItemVO>();
		}
	}
	
	/**
	 * 取得帳單折扣
	 * @return
	 */
	public Set<DiscountItemVO> getOfferDiscount() {	
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_OFFER)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_OFFER);
		}else{
			return new HashSet<DiscountItemVO>();
		}
	}
	
	/**
	 * 取得折價卷折扣
	 * @return
	 */
	public Set<DiscountItemVO> getCouponDiscount() {	
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_COUPON)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_COUPON);
		}else{
			return new HashSet<DiscountItemVO>();
		}
	}
	
	/**
	 * 取得贈品
	 * @return
	 */
	public Set<DiscountItemVO> getGiftDiscount() {	
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_GIFT)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_GIFT);
		}else{
			return new HashSet<DiscountItemVO>();
		}
	}	
	
	
	/**
	 * 依促案及類別取得折扣
	 * @param oplId
	 * @return
	 */
	public Set<DiscountItemVO> getDiscountByPromo(String oplId, String awardType) {
		Set<DiscountItemVO> result = new TreeSet<DiscountItemVO>();
		Map<String, Set<DiscountItemVO>> discMap = promoDiscountMap.get(oplId);
		if(discMap != null) {
			if(discMap.get(awardType) != null)  {
				result = discMap.get(awardType);
			}
		}
		return result;
	}
	
	/**
	 * 依設備及類別取得折扣
	 * @param oplId
	 * @return
	 */
	public Set<DiscountItemVO> getDiscountByProduct(String prodId, String awardType) {
		Set<DiscountItemVO> result = new TreeSet<DiscountItemVO>();
		Map<String, Set<DiscountItemVO>> discMap = productDiscountMap.get(prodId);
		if(discMap != null) {
			if(discMap.get(awardType) != null)  {
				result = discMap.get(awardType);
			}
		}
		return result;
	}
		
	// getter / setter ------------------------------------------------------------------
	public Map<String, Set<DiscountItemVO>> getDiscountItemMap() {
		return discountItemMap;
	}

	public void setDiscountItemMap(Map<String, Set<DiscountItemVO>> discountItemMap) {
		this.discountItemMap = discountItemMap;
	}

	public Map<String, Map<String, Set<DiscountItemVO>>> getPromoDiscountMap() {
		return promoDiscountMap;
	}

	public void setPromoDiscountMap(Map<String, Map<String, Set<DiscountItemVO>>> promoDiscountMap) {
		this.promoDiscountMap = promoDiscountMap;
	}

	public Map<String, Map<String, Set<DiscountItemVO>>> getProductDiscountMap() {
		return productDiscountMap;
	}

	public void setProductDiscountMap(Map<String, Map<String, Set<DiscountItemVO>>> productDiscountMap) {
		this.productDiscountMap = productDiscountMap;
	}
}
