package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CoMasterCredential;

/**
 * 訂單證件上傳資料DAO
 * @author johnny
 *
 */
public interface NCoMasterCredentialDAO extends BaseDAO<CoMasterCredential, Long> {

}
