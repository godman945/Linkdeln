package com.fet.estore.core.bean.vo;

import java.io.Serializable;
import java.util.List;

import com.fet.estore.core.model.AreaRgn;

public class CityVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8815391301321223907L;
	private String cityCode;
	private String cityName;
	private Boolean shippingArea;
	private Integer displayOrder;

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Boolean getShippingArea() {
		return shippingArea;
	}

	public void setShippingArea(Boolean shippingArea) {
		this.shippingArea = shippingArea;
	}

	public Integer getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}
	
}
