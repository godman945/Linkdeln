package com.fet.estore.core.bean.bo;


import java.io.Serializable;


public class MsisdnQueryBO implements Serializable {

    private static final long serialVersionUID = -197330359205178084L;

    /** Msisdn的狀態 */
    private String status;
	/** 檢索門號的關鍵字 */
    private String keyword;
	/** 選費上限 */
	private Integer maxSelectionFee;
	/** 選費下限 */
	private Integer minSelectionFee;
	/** 來源通道 */
    private String channel;
	/**  排序條件 */
    private Integer sortType;
	/**  排序條件 */
	private String groupName;

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public Integer getMaxSelectionFee() {
		return maxSelectionFee;
	}
	public void setMaxSelectionFee(Integer maxSelectionFee) {
		this.maxSelectionFee = maxSelectionFee;
	}
	public Integer getMinSelectionFee() {
		return minSelectionFee;
	}
	public void setMinSelectionFee(Integer minSelectionFee) {
		this.minSelectionFee = minSelectionFee;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public Integer getSortType() {
		return sortType;
	}
	public void setSortType(Integer sortType) {
		this.sortType = sortType;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
}
