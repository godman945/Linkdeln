package com.fet.estore.core.bean.vo.frontend;

public class PaymentCreditInstBankVO {
	private Integer  inst ;
	private Long     price;
	private String   bank ;
	private String[] banks;
	
	public Integer getInst() {
		return inst;
	}
	public void setInst(Integer inst) {
		this.inst = inst;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String[] getBanks() {
		return banks;
	}
	public void setBanks(String[] banks) {
		this.banks = banks;
	}
}
