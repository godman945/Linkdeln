package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.model.AccessoryAwardItem;

public class AccessoryAwardItemVO extends AccessoryAwardItem{
	private String giftName;
	private String fetNo;
	
	public String getGiftName() {
		return giftName;
	}
	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	
}
