package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.ExtraBuy;
import com.fet.estore.core.model.ExtraBuyItem;
import com.fet.estore.core.bean.vo.frontend.ExtraBuyDiscountVO;

public interface NExtraBuyDAO extends BaseDAO<ExtraBuy, Long> {
	/**
	 * 取得加購商品價格及折扣
	 * @param keys key格式: 料號_加購ID_加購項目ID
	 * @param qtys 數量
	 * @return
	 */
	public List<ExtraBuyDiscountVO> findExtraBuyDiscounts(String[] keys, Integer[] qtys);
}
