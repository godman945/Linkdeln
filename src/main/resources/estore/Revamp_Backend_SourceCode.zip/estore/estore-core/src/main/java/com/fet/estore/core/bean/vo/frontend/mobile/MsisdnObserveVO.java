package com.fet.estore.core.bean.vo.frontend.mobile;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * 門號觀察VO
 * @author Max Chen
 *
 */
public class MsisdnObserveVO implements Serializable {
	
	private Set<String> mdnIds = new LinkedHashSet<String>();

	public Set<String> getMdnIds() {
		return mdnIds;
	}

	public void setMdnIds(Set<String> mdnIds) {
		this.mdnIds = mdnIds;
	}
}
