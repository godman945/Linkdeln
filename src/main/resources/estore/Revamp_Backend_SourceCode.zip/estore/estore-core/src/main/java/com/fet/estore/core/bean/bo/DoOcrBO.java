package com.fet.estore.core.bean.bo;

import com.fet.estore.core.bean.vo.UploadFileInfo;

public class DoOcrBO {
	private String orderType;
	private String cono;
	private String fileType;
	private UploadFileInfo uploadFileInfo;
	/** 2020/03/12 add 是否要驗證九個月一證一號 */
	private Boolean isCheckOnceContract9M;
	private String onsalePromoListId;
	private String msisdn;
	/**
	 *新約選擇的門號ID 
	 */
	private String msisdnId;
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getCono() {
		return cono;
	}
	public void setCono(String cono) {
		this.cono = cono;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public Boolean getIsCheckOnceContract9M() {
		return isCheckOnceContract9M;
	}
	public void setIsCheckOnceContract9M(Boolean isCheckOnceContract9M) {
		this.isCheckOnceContract9M = isCheckOnceContract9M;
	}
	public String getOnsalePromoListId() {
		return onsalePromoListId;
	}
	public void setOnsalePromoListId(String onsalePromoListId) {
		this.onsalePromoListId = onsalePromoListId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getMsisdnId() {
		return msisdnId;
	}
	public void setMsisdnId(String msisdnId) {
		this.msisdnId = msisdnId;
	}
	public UploadFileInfo getUploadFileInfo() {
		return uploadFileInfo;
	}
	public void setUploadFileInfo(UploadFileInfo uploadFileInfo) {
		this.uploadFileInfo = uploadFileInfo;
	}
	
}
