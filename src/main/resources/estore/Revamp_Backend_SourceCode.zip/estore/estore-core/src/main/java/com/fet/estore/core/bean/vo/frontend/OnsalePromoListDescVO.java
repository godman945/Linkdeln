package com.fet.estore.core.bean.vo.frontend;

/**
 * 促案方案說明VO
 * @author Max Chen
 *
 */
public class OnsalePromoListDescVO {
	/** 說明 */
	private String frontendDesc;
	/** 附約說明 */
	private String subPromotionDesc;
	
	private String commonAnote;
	
	private String projectName;
	
	public String getFrontendDesc() {
		return frontendDesc;
	}
	public void setFrontendDesc(String frontendDesc) {
		this.frontendDesc = frontendDesc;
	}
	public String getSubPromotionDesc() {
		return subPromotionDesc;
	}
	public void setSubPromotionDesc(String subPromotionDesc) {
		this.subPromotionDesc = subPromotionDesc;
	}
	public String getCommonAnote() {
		return commonAnote;
	}
	public void setCommonAnote(String commonAnote) {
		this.commonAnote = commonAnote;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	
}
