package com.fet.estore.core.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-16
 * @description
 */
public class Greeting {

    public enum Type {
        icons, text, cards
    }

    private String greetingMsg;

    private List<Object> bubbles = null;

    public String getGreetingMsg() {
        return greetingMsg;
    }

    public void setGreetingMsg(String greetingMsg) {
        this.greetingMsg = greetingMsg;
    }

    public void addBubble(Object bubble) {
        if (bubbles == null) {
            bubbles = new ArrayList<>();
        }
        bubbles.add(bubble);
    }

    public List<Object> getBubbles() {
        return bubbles;
    }

    public void setBubbles(List<Object> bubbles) {
        this.bubbles = bubbles;
    }
}
