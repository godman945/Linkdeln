package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.ActivityNameList;

public interface NActivityNameListDAO extends BaseDAO<ActivityNameList, Long> {
	/**
	 * 判斷指定名單式內容是否存在
	 * @param actId
	 * @return
	 */
	public boolean findNameListById(Long actId);
	/**
	 * 判斷指定名單式內容是否存在
	 * @param actId
	 * @param nameListColumn
	 * @param column1
	 * @param column2
	 * @return
	 */
	public ActivityNameList findNameListByColumnValue(Long actId, String nameListColumn, 
			String column1, String column2, boolean isCono);
	/**
	 * 更新名單內的成單單號	
	 * @param nameListId
	 * @param cono
	 */
	public void updateNameList(Long nameListId, String cono);
}
