package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-10-05
 * @description
 */
public class OrderDiscountResult implements Serializable {

    private static final long serialVersionUID = 1L;

    private OrderCoupon coupon;

    private OrderHappygo happygo;

    private Boolean swipeCard;

    public OrderCoupon getCoupon() {
        return coupon;
    }
    public void setCoupon(OrderCoupon coupon) {
        this.coupon = coupon;
    }
    public OrderHappygo getHappygo() {
        return happygo;
    }
    public void setHappygo(OrderHappygo happygo) {
        this.happygo = happygo;
    }
    public Boolean getSwipeCard() {
        return swipeCard;
    }
    public void setSwipeCard(Boolean swipeCard) {
        this.swipeCard = swipeCard;
    }
}
