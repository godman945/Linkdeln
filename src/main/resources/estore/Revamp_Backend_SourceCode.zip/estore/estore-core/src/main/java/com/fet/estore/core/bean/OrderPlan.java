package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class OrderPlan implements Serializable {

	private static final long serialVersionUID = 337666662366216507L;
	private String ribbon;
	//方案名稱
	private String value;
	private String sticker;
	private String unit;
	private Integer price;
	//預繳金
	private Long prepay;
	private String month;
	private String note;
	private List<Object> list;
	private List<String> tags;
	private OrderContent modal;
	//促案代碼
	private String pCode;
	private String projectName;
	
	public String getRibbon() {
		return ribbon;
	}
	public void setRibbon(String ribbon) {
		this.ribbon = ribbon;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getSticker() {
		return sticker;
	}
	public void setSticker(String sticker) {
		this.sticker = sticker;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Long getPrepay() {
		return prepay;
	}
	public void setPrepay(Long prepay) {
		this.prepay = prepay;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public List<Object> getList() {
		return list;
	}
	public void setList(List<Object> list) {
		this.list = list;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	public OrderContent getModal() {
		return modal;
	}
	public void setModal(OrderContent modal) {
		this.modal = modal;
	}
	public String getpCode() {
		return pCode;
	}
	public void setpCode(String pCode) {
		this.pCode = pCode;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
}
