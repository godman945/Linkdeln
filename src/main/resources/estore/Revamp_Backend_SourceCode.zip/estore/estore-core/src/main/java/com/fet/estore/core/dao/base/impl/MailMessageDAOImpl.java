package com.fet.estore.core.dao.base.impl;

import java.util.List;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.MailMessageDAO;
import com.fet.estore.core.model.MailMessage;
import com.fet.estore.core.model.MailReceiver;
@Repository
public class MailMessageDAOImpl extends AbstractBaseDAO<MailMessage, Long>
		implements MailMessageDAO {

	/**
	 * @see com.fet.estore.core.dao.MailMessageDAO#findUnSentMail()
	 */
	@SuppressWarnings("unchecked")
	public List<MailMessage> findUnSentMail(long startId, Integer size) {
		
		SQLQuery query = this.getSessionFactory().getCurrentSession().createSQLQuery("select * from MAIL_MESSAGE where IS_SENT = 0 and SUBMIT_TIME <= sysdate and ID > :startId order by ID asc").addEntity(MailMessage.class);
		query.setParameter("startId", startId);
		query.setFirstResult(0);
		query.setMaxResults(size);
		List<MailMessage> results = query.list();
		
		return results;
	}
	

	@Override
	public void save(MailMessage entity) {
		//if(entity.getMailReceivers().size() == 0)
		//	throw new RuntimeException("You must specify at least one receiver!");
		
		for(MailReceiver receiver : entity.getMailReceivers()){
			if(receiver.getReceiverType() == null || receiver.getReceiverType().equals("")){
				receiver.setReceiverType(MailMessage.RECEIVER_TYPE_RECEIVER);
			}
		}
		
		if(entity.getSubmitTime() == null)
			entity.setSubmitTime(new java.util.Date());
		if(entity.getSendingTime() == null)
			entity.setSendingTime(new java.util.Date());
		
		super.save(entity);
	}

	@Override
	public void saveAll(List<MailMessage> entities) {
		for(MailMessage entity : entities){
			//if(entity.getMailReceivers().size() == 0)
			//	throw new RuntimeException("You must specify at least one receiver!");
			
			for(MailReceiver receiver : entity.getMailReceivers()){
				if(receiver.getReceiverType() == null || receiver.getReceiverType().equals("")){
					receiver.setReceiverType(MailMessage.RECEIVER_TYPE_RECEIVER);
				}
			}
			
			if(entity.getSubmitTime() == null)
				entity.setSubmitTime(new java.util.Date());
			if(entity.getSendingTime() == null)
				entity.setSendingTime(new java.util.Date());
		}
		super.saveAll(entities);
	}
	
	
	
	

	
}
