package com.fet.estore.core.dao.base.impl;

import java.util.Calendar;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.OrderBatchDAO;
import com.fet.estore.core.model.OrderBatch;
@Repository
public class OrderBatchDAOImpl extends AbstractBaseDAO<OrderBatch, Long> implements OrderBatchDAO {
	/**
	 * @see com.fet.estore.core.dao.OrderBatchDAO#findIncompleteJobs()
	 */
	@SuppressWarnings("unchecked")
	public List<OrderBatch> findIncompleteJobs(List<String> batchTypes){
		//STATUS = 'INCOMPLETE'
		/*
		OrderBatch orderBatch = new OrderBatch();
		orderBatch.setStatus(OrderBatch.BATCH_STATUS_INCOMPLETE);
		return this.findByExample(orderBatch, null, null);
		*/
		
		String hql = "from OrderBatch o where o.status = 'INCOMPLETE' and o.timesTried < o.timesToTry and o.batchType in (:batchTypes) and o.submitTime > :submitTime";
		Query query = this.getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameterList("batchTypes", batchTypes);
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 2018);
		calendar.set(Calendar.MONTH, 11);
		calendar.set(Calendar.DATE, 4);
		query.setParameter("submitTime", calendar.getTime());
		
		return query.list();
		
		
	}

}
