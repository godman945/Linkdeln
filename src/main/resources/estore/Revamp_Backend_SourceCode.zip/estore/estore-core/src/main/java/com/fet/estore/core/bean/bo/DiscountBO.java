package com.fet.estore.core.bean.bo;

import com.fet.estore.core.bean.vo.IDiscountItem;
import com.fet.estore.core.bean.vo.IDiscountItem;
import com.fet.estore.core.model.ActivityAwardItem;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * 折扣VO
 * @author Max Chen
 *
 */
public class DiscountBO {
	// property -------------------------------------------------------------------------
	private Map<String, Set<IDiscountItem>> discountItemMap = new HashMap<>();
	private Map<String, Map<String, Set<IDiscountItem>>> promoDiscountMap = new HashMap<>();
	private Map<String, Map<String, Set<IDiscountItem>>> productDiscountMap = new HashMap<>();
	
	// business method ------------------------------------------------------------------
	
	/**
	 * 取得所有折扣
	 * @return
	 */
	public Map<String, Set<IDiscountItem>> getAllDiscount() {
		return discountItemMap;
	}
	
	/**
	 * 取得配件折扣
	 * @return
	 */
	public Set<IDiscountItem> getAccessoryDiscount() {
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_ACCESSORY)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_ACCESSORY);
		}else{
			return new HashSet<>();
		}
		
	}
	
	/**
	 * 取得設備折扣
	 * @return
	 */
	public Set<IDiscountItem> getDeviceDiscount() {
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_DEVICE)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_DEVICE);
		}else{
			return new HashSet<>();
		}
	}
	
	/**
	 * 取得帳單折扣
	 * @return
	 */
	public Set<IDiscountItem> getOfferDiscount() {
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_OFFER)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_OFFER);
		}else{
			return new HashSet<>();
		}
	}
	
	/**
	 * 取得折價卷折扣
	 * @return
	 */
	public Set<IDiscountItem> getCouponDiscount() {
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_COUPON)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_COUPON);
		}else{
			return new HashSet<>();
		}
	}
	
	/**
	 * 取得贈品
	 * @return
	 */
	public Set<IDiscountItem> getGiftDiscount() {
		if(discountItemMap.containsKey(ActivityAwardItem.AWARD_TYPE_GIFT)){
			return discountItemMap.get(ActivityAwardItem.AWARD_TYPE_GIFT);
		}else{
			return new HashSet<>();
		}
	}	
	
	
	/**
	 * 依促案及類別取得折扣
	 * @param oplId
	 * @return
	 */
	public Set<IDiscountItem> getDiscountByPromo(String oplId, String awardType) {
		Set<IDiscountItem> result = new HashSet<>();
		Map<String, Set<IDiscountItem>> discMap = promoDiscountMap.get(oplId);
		if(discMap != null) {
			if(discMap.get(awardType) != null)  {
				result = discMap.get(awardType);
			}
		}
		return result;
	}
	
	/**
	 * 依設備及類別取得折扣
	 * @param prodId
	 * @param awardType
	 * @return
	 */
	public Set<IDiscountItem> getDiscountByProduct(String prodId, String awardType) {
		Set<IDiscountItem> result = new HashSet<>();
		Map<String, Set<IDiscountItem>> discMap = productDiscountMap.get(prodId);
		if(discMap != null) {
			if(discMap.get(awardType) != null)  {
				result = discMap.get(awardType);
			}
		}
		return result;
	}
		
	// getter / setter ------------------------------------------------------------------
	public Map<String, Set<IDiscountItem>> getDiscountItemMap() {
		return discountItemMap;
	}

	public void setDiscountItemMap(Map<String, Set<IDiscountItem>> discountItemMap) {
		this.discountItemMap = discountItemMap;
	}

	public Map<String, Map<String, Set<IDiscountItem>>> getPromoDiscountMap() {
		return promoDiscountMap;
	}

	public void setPromoDiscountMap(Map<String, Map<String, Set<IDiscountItem>>> promoDiscountMap) {
		this.promoDiscountMap = promoDiscountMap;
	}

	public Map<String, Map<String, Set<IDiscountItem>>> getProductDiscountMap() {
		return productDiscountMap;
	}

	public void setProductDiscountMap(Map<String, Map<String, Set<IDiscountItem>>> productDiscountMap) {
		this.productDiscountMap = productDiscountMap;
	}
}
