package com.fet.estore.core.bean.vo.frontend.mobile;

public class StoreVO {

	private String name;
	private String city;
	private String storeno;
	private String area;
	private String address;
	private Boolean cncStore;
	
	public String getName() {
		return name;
	}
	public String getStoreno() {
		return storeno;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setStoreno(String storeno) {
		this.storeno = storeno;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Boolean getCncStore() {
		return cncStore;
	}
	public void setCncStore(Boolean cncStore) {
		this.cncStore = cncStore;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
