package com.fet.estore.core.bean.vo.frontend;

public class MultiprodActPriceVO {
    
    /**
     * from Product
     */
    private String fetNo;
    
    /**
     * from OnsalePromoList
     */
    private String seq;
    
    /**
     * from Pos
     */
    private Long price;

    public String getFetNo() {
        return fetNo;
    }

    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }
    
}
