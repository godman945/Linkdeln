package com.fet.estore.core.bean.vo.frontend;

public class AuctionMsisdnVO {
	/** 活動ID */
	private Integer activityId;
	/** 門號 */
	private String msisdn;
	/** 得標者身份證字號 */
	private String rocId;
	/** 得標價 */
	private Integer price;
	/** 門號類型(3G/4G) */
	private String msisdnType;
	/** 限門市取貨 */
	private boolean storeOnly;
	/** 活動是否可申辦 */
	private boolean onAvailDuration;
	/** 已成單訂單號碼 */
	private String cono;
	
	public Integer getActivityId() {
		return activityId;
	}
	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getRocId() {
		return rocId;
	}
	public void setRocId(String rocId) {
		this.rocId = rocId;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getMsisdnType() {
		return msisdnType;
	}
	public void setMsisdnType(String msisdnType) {
		this.msisdnType = msisdnType;
	}
	public boolean isStoreOnly() {
		return storeOnly;
	}
	public void setStoreOnly(boolean storeOnly) {
		this.storeOnly = storeOnly;
	}
	public boolean isOnAvailDuration() {
		return onAvailDuration;
	}
	public void setOnAvailDuration(boolean onAvailDuration) {
		this.onAvailDuration = onAvailDuration;
	}
	public String getCono() {
		return cono;
	}
	public void setCono(String cono) {
		this.cono = cono;
	}
}
