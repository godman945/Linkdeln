package com.fet.estore.core.bean.vo;

import java.util.Date;

public class ATRStatusVO {
	
	private String fetNo;
	//上蓋銷售量檢查 
	private Boolean checkAtr;
	//eStore only ATR量
	private Long newAtrEstoreAtr;
	//加量
	private Long newAtrIncrement;
	//eStore庫存量
	private Long newAtrEstoreInventory;
	//ATR檢查狀態
	private Boolean newAtrStatus;
	//eStore only ATR量下載時間
	private Date newAtrModifyTime;
	//自訂量檢查
	private Boolean checkLocalAtr;
	//自訂量檢查區間
	private Date checkLocalAtrStartTime;
	//自訂量檢查區間
	private Date checkLocalAtrEndTime;
	//自訂量
	private Long localAtrQuantity;
	//ATR 狀態檢查規則後回存
	private Boolean localAtrStatus;	
	//上蓋量
	private Long countNewAtrQty;
	//上蓋量計算後的可銷售量
	private Long onSaleNewAtrQty;
	//自訂可銷售量
	private Long onSaleLocalAtrQty;
	
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public Boolean getCheckAtr() {
		return checkAtr;
	}
	public void setCheckAtr(Boolean checkAtr) {
		this.checkAtr = checkAtr;
	}
	public Long getNewAtrEstoreAtr() {
		return newAtrEstoreAtr;
	}
	public void setNewAtrEstoreAtr(Long newAtrEstoreAtr) {
		this.newAtrEstoreAtr = newAtrEstoreAtr;
	}
	public Long getNewAtrIncrement() {
		return newAtrIncrement;
	}
	public void setNewAtrIncrement(Long newAtrIncrement) {
		this.newAtrIncrement = newAtrIncrement;
	}
	public Long getNewAtrEstoreInventory() {
		return newAtrEstoreInventory;
	}
	public void setNewAtrEstoreInventory(Long newAtrEstoreInventory) {
		this.newAtrEstoreInventory = newAtrEstoreInventory;
	}
	public Boolean getNewAtrStatus() {
		return newAtrStatus;
	}
	public void setNewAtrStatus(Boolean newAtrStatus) {
		this.newAtrStatus = newAtrStatus;
	}
	public Date getNewAtrModifyTime() {
		return newAtrModifyTime;
	}
	public void setNewAtrModifyTime(Date newAtrModifyTime) {
		this.newAtrModifyTime = newAtrModifyTime;
	}
	public Boolean getCheckLocalAtr() {
		return checkLocalAtr;
	}
	public void setCheckLocalAtr(Boolean checkLocalAtr) {
		this.checkLocalAtr = checkLocalAtr;
	}
	public Date getCheckLocalAtrStartTime() {
		return checkLocalAtrStartTime;
	}
	public void setCheckLocalAtrStartTime(Date checkLocalAtrStartTime) {
		this.checkLocalAtrStartTime = checkLocalAtrStartTime;
	}
	public Date getCheckLocalAtrEndTime() {
		return checkLocalAtrEndTime;
	}
	public void setCheckLocalAtrEndTime(Date checkLocalAtrEndTime) {
		this.checkLocalAtrEndTime = checkLocalAtrEndTime;
	}
	public Long getLocalAtrQuantity() {
		return localAtrQuantity;
	}
	public void setLocalAtrQuantity(Long localAtrQuantity) {
		this.localAtrQuantity = localAtrQuantity;
	}
	public Boolean getLocalAtrStatus() {
		return localAtrStatus;
	}
	public void setLocalAtrStatus(Boolean localAtrStatus) {
		this.localAtrStatus = localAtrStatus;
	}
	public Long getCountNewAtrQty() {
		return countNewAtrQty;
	}
	public void setCountNewAtrQty(Long countNewAtrQty) {
		this.countNewAtrQty = countNewAtrQty;
	}
	public Long getOnSaleNewAtrQty() {
		return onSaleNewAtrQty;
	}
	public void setOnSaleNewAtrQty(Long onSaleNewAtrQty) {
		this.onSaleNewAtrQty = onSaleNewAtrQty;
	}
	public Long getOnSaleLocalAtrQty() {
		return onSaleLocalAtrQty;
	}
	public void setOnSaleLocalAtrQty(Long onSaleLocalAtrQty) {
		this.onSaleLocalAtrQty = onSaleLocalAtrQty;
	}	
}
