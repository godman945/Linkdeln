package com.fet.estore.core.bean.vo;

import java.io.Serializable;

public class UploadFileInfo implements Serializable{
	private String fileNo;
    private String cardSection;
	private String imageString;
	private String fileSize;
	public String getCardSection() {
		return cardSection;
	}
	public void setCardSection(String cardSection) {
		this.cardSection = cardSection;
	}
	public String getImageString() {
		return imageString;
	}
	public void setImageString(String imageString) {
		this.imageString = imageString;
	}
	public String getFileNo() {
		return fileNo;
	}
	public void setFileNo(String fileNo) {
		this.fileNo = fileNo;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
}
