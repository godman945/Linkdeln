package com.fet.estore.core.bean.bo;

/**
 * 折扣計算結果 - 贈品VO
 * @author Max Chen
 *
 */
public class ShoppingResultAwardBO {

	/** 贈品來源類型 - 促銷活動 */
	public static final String SOURCE_TYPE_ACT          = "ACT";
	/** 贈品來源類型 - 設備贈品 */
	public static final String SOURCE_TYPE_HANDSET_GIFT = "HANDSET_GIFT";
	/** 贈品來源類型 - 配件活動 */
	public static final String SOURCE_TYPE_ACC_ACT      = "ACC_ACT";
	/** 贈品來源類型 - 配件贈品 */
	public static final String SOURCE_TYPE_ACC_GIFT     = "ACC_GIFT";	
	
	/** 贈品來源 */
	private String sourceType;
	/** 贈品類型 */
	private String type;
	/** 原始贈品ID */
	private Long aaiId;
	/** 原始設定CODE */
	private String code;
	/** 折扣料號 */
	private String fetNo;
	/** 折扣所屬活動 */
	private Long activityId;
	/** 折扣名稱 */
	private String name;
	/** 折扣金額 */
	private Long amount;
	/** COUPON ID */
	private Long couponId;
	/** 帳單折抵ID */
	private Long offerId;
	
	/** 設備名稱 */
	private String handsetName;
	/**多主商品贈品,coupon說明**/
	private String description;
	
	public Long getAaiId() {
		return aaiId;
	}
	public void setAaiId(Long aaiId) {
		this.aaiId = aaiId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public Long getCouponId() {
		return couponId;
	}
	public void setCouponId(Long couponId) {
		this.couponId = couponId;
	}
	public Long getOfferId() {
		return offerId;
	}
	public void setOfferId(Long offerId) {
		this.offerId = offerId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSourceType() {
		return sourceType;
	}
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	public String getHandsetName() {
		return handsetName;
	}
	public void setHandsetName(String handsetName) {
		this.handsetName = handsetName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
