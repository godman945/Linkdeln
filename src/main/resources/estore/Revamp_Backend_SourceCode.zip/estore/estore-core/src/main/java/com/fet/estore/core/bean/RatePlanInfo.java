package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;


public class RatePlanInfo implements Serializable {

	private static final long serialVersionUID = -8397294015147868643L;
	
	/** 麵包屑資訊 */
	List<BreadCrumbs> breadcrumbs;

	public List<BreadCrumbs> getBreadcrumbs() {
		return breadcrumbs;
	}

	public void setBreadcrumbs(List<BreadCrumbs> breadcrumbs) {
		this.breadcrumbs = breadcrumbs;
	}

}
