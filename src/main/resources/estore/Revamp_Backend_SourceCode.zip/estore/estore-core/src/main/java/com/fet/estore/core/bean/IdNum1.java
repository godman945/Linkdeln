package com.fet.estore.core.bean;

public class IdNum1 implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	/**
	 * 身份證號
	 */
	String id; 
	
	/**
	 * 姓名
	 */
	String name;
	
	/**
	 * 生日
	 */
	String birthday;    
	
	/**
	 * 發行日期
	 */
	String issuedDate; 
	
	/**
	 * 發行狀態 
	換、補、初 
	換發傳回換、補發傳回
	補、初發傳回初 
	 */
	String issuedStatus;  
	
	
	/**
	 * 發行狀態 換發、補發、初發 
	 */
	String issuedStatusFull;
	
	/**
	 *  發行城市 身份證正面的發照城市
	 */
	String issuedCity;
	
	/**
	 * 性別
	 */
	String sex;
	
	/**
	 * 生日八碼數字 19781005
	 */
	String birthdayYyyymmdd;
	
	//解析身分證(ISSUED_DATE)與駕照(ISSUED_DATE)、行照(REGISTRATION_DATE)的發證日期轉換八個數字 YYYYMMDD 
	/**
	 * 發證日期八碼數字 19781005 
	 */
	String issuedateYyyymmdd;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(String issuedDate) {
		this.issuedDate = issuedDate;
	}

	public String getIssuedStatus() {
		return issuedStatus;
	}

	public void setIssuedStatus(String issuedStatus) {
		this.issuedStatus = issuedStatus;
	}

	public String getIssuedStatusFull() {
		return issuedStatusFull;
	}

	public void setIssuedStatusFull(String issuedStatusFull) {
		this.issuedStatusFull = issuedStatusFull;
	}

	public String getIssuedCity() {
		return issuedCity;
	}

	public void setIssuedCity(String issuedCity) {
		this.issuedCity = issuedCity;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getBirthdayYyyymmdd() {
		return birthdayYyyymmdd;
	}

	public void setBirthdayYyyymmdd(String birthdayYyyymmdd) {
		this.birthdayYyyymmdd = birthdayYyyymmdd;
	}

	public String getIssuedateYyyymmdd() {
		return issuedateYyyymmdd;
	}

	public void setIssuedateYyyymmdd(String issuedateYyyymmdd) {
		this.issuedateYyyymmdd = issuedateYyyymmdd;
	}
	
	
}
