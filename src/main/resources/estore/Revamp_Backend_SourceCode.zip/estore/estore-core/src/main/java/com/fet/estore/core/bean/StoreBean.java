package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

import com.fet.estore.core.bean.vo.frontend.mobile.StoreVO;
import com.fet.estore.core.model.AreaCity;

public class StoreBean implements Serializable {

	private static final long serialVersionUID = 249487886293047176L;
	private List<AreaCity> cities;
	private List<StoreVO> areas;
	private List<StoreVO> stores;
	
	public List<AreaCity> getCities() {
		return cities;
	}
	public void setCities(List<AreaCity> cities) {
		this.cities = cities;
	}
	public List<StoreVO> getAreas() {
		return areas;
	}
	public void setAreas(List<StoreVO> areas) {
		this.areas = areas;
	}
	public List<StoreVO> getStores() {
		return stores;
	}
	public void setStores(List<StoreVO> stores) {
		this.stores = stores;
	}
	
}
