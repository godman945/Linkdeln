package com.fet.estore.core.dao.base;

import java.util.List;

import org.springframework.jdbc.support.rowset.SqlRowSet;

public interface JdbcDAO {
	public SqlRowSet queryForRowSet(String sql);
	
	public List queryForList(String sql);
	
	public void executeQuery(String sql);
	
	public int update(String sql);
}
