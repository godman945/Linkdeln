package com.fet.estore.core.bean;

public class OtpItem {

    private String statusCode;
    private String message;
    private boolean isSuccess;
    private boolean isExceed;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean getIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    public boolean isExceed() {
        return isExceed;
    }

    public void setExceed(boolean exceed) {
        isExceed = exceed;
    }
}
