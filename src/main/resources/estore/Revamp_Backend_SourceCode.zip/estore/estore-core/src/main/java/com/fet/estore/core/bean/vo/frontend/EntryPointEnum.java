package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

public enum EntryPointEnum implements Serializable   {

	/** 首頁*/
	HOME,
	
	/** 手機館*/
	HANDSET,
	
	/** 平板.3C館*/
	TABLET,
	
	/** 配件館*/
	ACCESSORY,
	
	/** 續約館*/
	LOYALTY,
	
	/** 門號館*/
	MSISDN,
	
	/** 門號可攜館*/
	//NP,(revamp無門號可攜館)
	
	/** 家用寬頻館*/
	BROADBAND,
	
	/** 國際電話館*/
	CALLING_CARD,
	
	/** 資費館*/
	RATE_PLAN,
	
	/** 其他 (e.g. 促銷活動) */
	OTHER,
	
	/**紅配綠**/
	MPACTIVITY,
	
	/** 小網首頁*/
	MOBILE_HOME,
	
	/** 小網手機館*/
	MOBILE_HANDSET,
	
	/** 小網平板.3C館*/
	MOBILE_TABLET,
	
	/** 小網配件館*/
	MOBILE_ACCESSORY,
	
	/** 小網續約館(老客戶頁)*/
	MOBILE_LOYALTY,
	
	/** 小網門號館*/
	MOBILE_MSISDN,
	;
}
