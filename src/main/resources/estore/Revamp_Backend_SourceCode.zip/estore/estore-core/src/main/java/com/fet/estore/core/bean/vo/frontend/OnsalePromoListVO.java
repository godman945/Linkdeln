package com.fet.estore.core.bean.vo.frontend;

import java.util.Date;
import java.util.List;

import com.fet.estore.core.model.ContentOffer;

/**
 * 促案VO
 * @author Max Chen
 *
 */
public class OnsalePromoListVO {
	
	/** 促案ID */
	private String onsalePromoListId;
	/** 促案原始ID */
	private String promotionListId;
	/** 促案名稱 */
	private String promoName;	
	/** 語音資費ID */
	private String vOfferId;
	/** 語音月租費 */
	private Long vPrice;
	/** 數據資費ID */
	private String dOfferId;
	/** 數據月租費 */
	private Long dPrice;
	/** 是否合併語音數據 */
	private boolean isVD;
	/** 語音數據月租費 */
	private Long vdPrice;
	/** 方案期數 */
	private Integer limit;		
	/** 預繳金額 */
	private Long prepaidPrice;
	/** 結帳總金額 */
	private Long totalPrice;

	/** 折扣前商品價 */
	private Long orgPrice;
	/** 折扣前分期期數 */
	private Integer orgInst;	
	/** 折扣前分期金額 */
	private Long orgInstPrice;
	
	/** 折扣後商品價 */
	private Long discPrice;		
	/** 折扣後分期期數 */
	private Integer discInst;
	/** 折扣後分期金額 */
	private Long discInstPrice;
	
	/** 是否可宅配 */
	private boolean homeDelivery;
	/** 是否可門市取貨 */
	private boolean storeDelivery;
	/** 是否為主打促代 */
	private boolean isHit;
	/** 是否為VIP促案 */
	private boolean isVip;	
	/** 是否有優惠贈送連結 */
	private boolean hasGiftLink;
	/** 是否有費率說明連結 */
	private boolean hasRateLink;
	
	/** 推薦開始時間 */
	private Date recommendStartTime;

	/** 主打促代名稱 */
	private String recommendName;
	
	/** 升級類型 */
	private String upgradeType;
	
	/** 資費群組。 */
    private String voicegroup;
    
    /** 促案月租費(排序用)。 */
    private Long monthPrice;
    
	/** 資費群組。 */
    private String promoFilterType;
   
    //nds add
    private String recommendDesc;
    private String dataUsageAmount;
    private String speedDesc;
    private String voicePremium;//語音優惠(= voicePremium1 + voicePremium2 + voicePremium3 + voicePremium4)
    private String voicePremium1;//網內語音優惠
    private String voicePremium2;//網外語音優惠
    private String voicePremium3;//市話語音優惠
    private String voicePremium4;//空白
    private String otherPremium;
	private Date onsaleDate;
	private Boolean noLimit;//是否吃到飽
	private String otherDesc;//其它說明
	//Omin後,新申和續約用這個金額
	private Integer prepaymentPrice;
	private Boolean isExclusive;//是否獨家
	private String bubbleText;
	private String pcode;//促銷代碼
	// 5G需求 added by Roil 2020/03/30
	private ContentOffer contentOffer; // C約物件
	private List<ContentOffer> contentOffers; // C約物件清單; 給秘密買場搭商品用，因為現在只有秘密賣場搭商品回前端時是用這個物件
	
	public String getOnsalePromoListId() {
		return onsalePromoListId;
	}
	public void setOnsalePromoListId(String onsalePromoListId) {
		this.onsalePromoListId = onsalePromoListId;
	}
	public String getPromoName() {
		return promoName;
	}
	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}
	public String getvOfferId() {
		return vOfferId;
	}
	public void setvOfferId(String vOfferId) {
		this.vOfferId = vOfferId;
	}
	public String getdOfferId() {
		return dOfferId;
	}
	public void setdOfferId(String dOfferId) {
		this.dOfferId = dOfferId;
	}
	public Long getOrgPrice() {
		return orgPrice;
	}
	public void setOrgPrice(Long orgPrice) {
		this.orgPrice = orgPrice;
	}
	public Long getvPrice() {
		return vPrice;
	}
	public void setvPrice(Long vPrice) {
		this.vPrice = vPrice;
	}
	public Long getdPrice() {
		return dPrice;
	}
	public void setdPrice(Long dPrice) {
		this.dPrice = dPrice;
	}
	public Long getPrepaidPrice() {
		return prepaidPrice;
	}
	public void setPrepaidPrice(Long prepaidPrice) {
		this.prepaidPrice = prepaidPrice;
	}
	public Long getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Integer getLimit() {
		return limit;
	}
	public void setLimit(Integer limit) {
		this.limit = limit;
	}
	public boolean isHomeDelivery() {
		return homeDelivery;
	}
	public void setHomeDelivery(boolean homeDelivery) {
		this.homeDelivery = homeDelivery;
	}
	public boolean isStoreDelivery() {
		return storeDelivery;
	}
	public void setStoreDelivery(boolean storeDelivery) {
		this.storeDelivery = storeDelivery;
	}
	public boolean isHit() {
		return isHit;
	}
	public void setHit(boolean isHit) {
		this.isHit = isHit;
	}
	public boolean isVip() {
		return isVip;
	}
	public void setVip(boolean isVip) {
		this.isVip = isVip;
	}
	public Integer getOrgInst() {
		return orgInst;
	}
	public void setOrgInst(Integer orgInst) {
		this.orgInst = orgInst;
	}
	public Long getOrgInstPrice() {
		return orgInstPrice;
	}
	public void setOrgInstPrice(Long orgInstPrice) {
		this.orgInstPrice = orgInstPrice;
	}
	public Long getDiscPrice() {
		return discPrice;
	}
	public void setDiscPrice(Long discPrice) {
		this.discPrice = discPrice;
	}
	public Integer getDiscInst() {
		return discInst;
	}
	public void setDiscInst(Integer discInst) {
		this.discInst = discInst;
	}
	public Long getDiscInstPrice() {
		return discInstPrice;
	}
	public void setDiscInstPrice(Long discInstPrice) {
		this.discInstPrice = discInstPrice;
	}
	public boolean isHasRateLink() {
		return hasRateLink;
	}
	public void setHasRateLink(boolean hasRateLink) {
		this.hasRateLink = hasRateLink;
	}
	public Date getRecommendStartTime() {
		return recommendStartTime;
	}
	public void setRecommendStartTime(Date recommendStartTime) {
		this.recommendStartTime = recommendStartTime;
	}
	public String getRecommendName() {
		return recommendName;
	}
	public void setRecommendName(String recommendName) {
		this.recommendName = recommendName;
	}
	public String getPromotionListId() {
		return promotionListId;
	}
	public void setPromotionListId(String promotionListId) {
		this.promotionListId = promotionListId;
	}
	public boolean isHasGiftLink() {
		return hasGiftLink;
	}
	public void setHasGiftLink(boolean hasGiftLink) {
		this.hasGiftLink = hasGiftLink;
	}
	public Long getVdPrice() {
		return vdPrice;
	}
	public void setVdPrice(Long vdPrice) {
		this.vdPrice = vdPrice;
	}
	public boolean isVD() {
		return isVD;
	}
	public void setVD(boolean isVD) {
		this.isVD = isVD;
	}
	public String getUpgradeType() {
		return upgradeType;
	}
	public void setUpgradeType(String upgradeType) {
		this.upgradeType = upgradeType;
	}
    public String getVoicegroup() {
        return voicegroup;
    }
    public void setVoicegroup(String voicegroup) {
        this.voicegroup = voicegroup;
    }
    public Long getMonthPrice() {
        return monthPrice;
    }
    public void setMonthPrice(Long monthPrice) {
        this.monthPrice = monthPrice;
    }
	public String getPromoFilterType() {
		return promoFilterType;
	}
	public void setPromoFilterType(String promoFilterType) {
		this.promoFilterType = promoFilterType;
	}
	public String getRecommendDesc() {
		return recommendDesc;
	}
	public void setRecommendDesc(String recommendDesc) {
		this.recommendDesc = recommendDesc;
	}
	public String getDataUsageAmount() {
		return dataUsageAmount;
	}
	public void setDataUsageAmount(String dataUsageAmount) {
		this.dataUsageAmount = dataUsageAmount;
	}
	public String getSpeedDesc() {
		return speedDesc;
	}
	public void setSpeedDesc(String speedDesc) {
		this.speedDesc = speedDesc;
	}
	public String getVoicePremium() {
		return voicePremium;
	}
	public void setVoicePremium(String voicePremium) {
		this.voicePremium = voicePremium;
	}
	public String getVoicePremium1() {
		return voicePremium1;
	}
	public void setVoicePremium1(String voicePremium1) {
		this.voicePremium1 = voicePremium1;
	}
	public String getVoicePremium2() {
		return voicePremium2;
	}
	public void setVoicePremium2(String voicePremium2) {
		this.voicePremium2 = voicePremium2;
	}
	public String getVoicePremium3() {
		return voicePremium3;
	}
	public void setVoicePremium3(String voicePremium3) {
		this.voicePremium3 = voicePremium3;
	}
	public String getVoicePremium4() {
		return voicePremium4;
	}
	public void setVoicePremium4(String voicePremium4) {
		this.voicePremium4 = voicePremium4;
	}
	public String getOtherPremium() {
		return otherPremium;
	}
	public void setOtherPremium(String otherPremium) {
		this.otherPremium = otherPremium;
	}
	public Date getOnsaleDate() {
		return onsaleDate;
	}
	public void setOnsaleDate(Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}
	public Boolean isNoLimit() {
		return noLimit;
	}
	public void setNoLimit(Boolean noLimit) {
		this.noLimit = noLimit;
	}
	public String getOtherDesc() {
		return otherDesc;
	}
	public void setOtherDesc(String otherDesc) {
		this.otherDesc = otherDesc;
	}
	public Integer getPrepaymentPrice() {
		return prepaymentPrice;
	}
	public void setPrepaymentPrice(Integer prepaymentPrice) {
		this.prepaymentPrice = prepaymentPrice;
	}
	public Boolean getNoLimit() {
		return noLimit;
	}
	public Boolean getIsExclusive() {
		return isExclusive;
	}
	public void setIsExclusive(Boolean isExclusive) {
		this.isExclusive = isExclusive;
	}
	public String getBubbleText() {
		return bubbleText;
	}
	public void setBubbleText(String bubbleText) {
		this.bubbleText = bubbleText;
	}
	public String getPcode() {
		return pcode;
	}
	public void setPcode(String pcode) {
		this.pcode = pcode;
	}
	public ContentOffer getContentOffer() {
		return contentOffer;
	}
	public void setContentOffer(ContentOffer contentOffer) {
		this.contentOffer = contentOffer;
	}
	public List<ContentOffer> getContentOffers() {
		return contentOffers;
	}
	public void setContentOffers(List<ContentOffer> contentOffers) {
		this.contentOffers = contentOffers;
	}
}
