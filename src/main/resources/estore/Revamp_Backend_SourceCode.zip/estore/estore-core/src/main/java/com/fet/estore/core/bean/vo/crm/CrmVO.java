package com.fet.estore.core.bean.vo.crm;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fet.estore.core.constant.EstoreMdmServiceConstant;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CrmVO implements java.io.Serializable {

	private static final long serialVersionUID = -5394324043292756317L;
	
	/** 客戶升級類型 - 一般取約 */
	public static final String LOYALTY_UPGRADE_TYPE_NORMAL = "NORMAL";
	/** 客戶升級類型 - 資費價差取約 */
	public static final String LOYALTY_UPGRADE_TYPE_SPREAD = "SPREAD";
	/** 客戶升級類型 - 指定資費 */
	public static final String LOYALTY_UPGRADE_TYPE_ASSIGN = "ASSIGN";
    /** 客戶升級類型 - 換約資費 */
    public static final String LOYALTY_UPGRADE_TYPE_CHANGE = "CHANGE";
	
	/** SDP.UID */
    private String sdpUid;
	private String uiInputRocId;
    
    
	//CRMCustBizService.getContractByAccountIdOrSubscriberId
	private String msisdn; 
	private String subscriberID; 
	private String subscriberRocID; 
	private String accountID; 
	private String accountRocID; 
	private String subscriberName;
	private String birthday;//計算age	
	private String subscriberIDType;
	private String residenceAddress;
	private String billingAddress;
	private String email = ""; //20200601 Dennis.Chen - 預設空字串
	private String mobileGenerationCode;
	private String subscriberGender;//crm回傳0,1；這裡代換成M,F
	private String subscriberLastName;
	private String billingType;
	private String paymentConsolidationInd;
	private String homeTelPrefix = ""; //20200601 Dennis.Chen - 預設空字串
	private String homeTel = ""; //20200601 Dennis.Chen - 預設空字串
	private String contractComponentValue;
	private String paymentCategoryForGiftRedeem;



	//CRMCustBizService.getCacheSubscriberInfoByKey
	private String partyId;
	private String customerID; 
	private String customerType; 
	private String subscriberType; 
	private String subStatus; 
	private String subStatusReasonCode; 
	private String businessEntityID;
	private String paymentCategory;
	private String productType;
	private String accountContractComponentId;
    private String contractComponentId;
    private String serviceProvider;

	//CRMOExBizService.
	private String contractEndDate;
	private String contractStartDate;
	private String cancelDate;
	//????
	private String isLastContract;

	//CRMCustBizService.getContractComponentInfoByAdminNativeKey
	private String activationDate;
	private String vip;
	private String vipGrade;
	private String arpb;
	private String churn;
	private int tenure;
	private Date vipStartDate;
	private Date contractExpiryDate;
	private String last3MonthsGprsAverageMB;
	private String smartPhoneIndicator;
	private String happyGoIdn;
	private String currentHandset;
	
	
	//CRMCustInsightBizService.getRecordBySubscrId
	//private String mvpn;

	

	//CRMOExBizService.QueryServicesEx
	private boolean mvpn;
	private boolean isHybrid;
	private boolean mvpnSplitBill;//公司分帳
	private String currentVoiceRate;
	private String currentDataRate;
	private List<String> activeProductOffering = new ArrayList<String>();
	private String mvnpCid;
	
	private Integer nonPrepaymentCount;
	private Integer sMaxPSArpb;
	private Integer sMaxPSTenure;
	private boolean privateAccount;
	private boolean lineMobile;
	
	
	
	
	//value from database
	private String currentVoiceName;
	private Double currentVoicePrice;
	private String currentDataName;
	private Double currentDataPrice;
	private boolean lyDataOnly;
	
	
	//value from program
	private String loyaltyUpgradeType;
	private boolean passVipLoyalty;
	private String cohOrderId;
	private String subscriptionItemId;
	private String oldSimNo;
	private String cohTx;
	
	private String subscriberContractComponentId;
	private String accountContractId;
	private String customerContractId;
	private String customerContractConpomentId;
	
	private String lastContractEndDate;
	
	//是否為升轉加量
	private boolean isUpgradePlus;
	
	
	//手扶程式需要
	private String cohDealerCode;
	private String cohAgentCode;
	private String cohIvrCode;
	
	//現在資費是否為VD offer
	boolean currentVDOffer;

	private List<CrmPromotionVO> promotions;
	
	
	public String getCohDealerCode() {
		return cohDealerCode;
	}


	public void setCohDealerCode(String cohDealerCode) {
		this.cohDealerCode = cohDealerCode;
	}


	public String getCohAgentCode() {
		return cohAgentCode;
	}


	public void setCohAgentCode(String cohAgentCode) {
		this.cohAgentCode = cohAgentCode;
	}


	public String getCohIvrCode() {
		return cohIvrCode;
	}


	public void setCohIvrCode(String cohIvrCode) {
		this.cohIvrCode = cohIvrCode;
	}


	public String checkMsisdnStatus() {
		
//		String noPassErrMsg = "很抱歉，您的門號目前無法於遠傳網路門市進行線上續約服務，請您至全省遠傳門市辦理，謝謝。";
//		String kgtErrMsg    = "您的門號為原和信用戶，很抱歉，因系統版本因素無法於遠傳網路門市進行線上續約服務，請您至全省遠傳門市辦理，謝謝。";
//		String entErrMsg    = "很抱歉，您的門號可能因以下原因目前無法於線上辦理，謝謝。<br>原因 : 企業用戶、門號或身份不符申辦資格、續約送件中..";
//		String fet2GErrMsg  = "提醒您! 您的門號為2G門號，請至門市辦理升級3G門號的免費服務，謝謝";
//		String preErrMsg    = "很抱歉，您的門號可能因以下原因目前無法於線上辦理，謝謝。<br>原因 : 企業用戶、門號或身份不符申辦資格、續約送件中..";
//		String qwErrMsg     = "您的門號為非遠傳門號，無法於網路門市續約，建議可攜碼至遠傳電信，請洽原業者查詢合約資訊，謝謝。";
		String noPassErrMsg = "errorCode.1";
		String kgtErrMsg    = "errorCode.2";
		String entErrMsg    = "errorCode.3";
		String fet2GErrMsg  = "errorCode.4";
		String preErrMsg    = "errorCode.5";
		String qwErrMsg     = "errorCode.6";
		String hlErrMsg     = "errorCode.7";
		
		// 判斷是否為FET/KGT, 為KGT時或兩者皆非時不合法
		String entId = this.getBusinessEntityID();
//		boolean isFet = MsisdnStatus.BUSINESS_ENTITY_FET.equals(entId);
//		boolean isKgt = MsisdnStatus.BUSINESS_ENTITY_KGT.equals(entId);
		boolean isFet = "FET".equals(entId);
		boolean isKgt = "KGT".equals(entId);
		if(!isFet && !isKgt) return entErrMsg;
		if(isKgt           ) return kgtErrMsg;
		
		// 判斷FET 2G/3G, 為2G或兩者皆非時不合法
		String mobileGenerationCode = this.getMobileGenerationCode();
		boolean is2G = EstoreMdmServiceConstant.MobileGenerationCode_2G.equals(mobileGenerationCode);
		boolean is3G = EstoreMdmServiceConstant.MobileGenerationCode_3G.equals(mobileGenerationCode);
		boolean is4G = EstoreMdmServiceConstant.MobileGenerationCode_4G.equals(mobileGenerationCode);
		boolean is5G = EstoreMdmServiceConstant.MobileGenerationCode_5G.equals(mobileGenerationCode); // 5G需求戳記
		if(!is2G && !is3G && !is4G && !is5G) return noPassErrMsg; // 5G需求戳記
		if(is2G          ) return fet2GErrMsg;

		if("H".equals(this.getSubStatus())) {
			//HL1,HL2,HL3,HL4,HL5
			return String.format("errorCode.hl.%s", this.getSubStatusReasonCode().substring(this.getSubStatusReasonCode().indexOf("L") + 1));
		}
		
		// 判斷FET 3G IF/NEWCASH/POSTCARD, 為IF/NEWCASH時不合法
		//boolean isIforNewCash  = StringUtil.isInList(new String[] {MsisdnStatus.MSISDNPRODUCTTYPE_IF, MsisdnStatus.MSISDNPRODUCTTYPE_NEWCASH}, this.getProductType());
		//Omin在這裡改了，不知道對不對，只是按照以前規則，把Nes Cash客戶擋住，但不知道有沒有擋住易付卡，因為遠傳說易付卡就是New Cash
		//boolean isIforNewCash = StringUtil.isInList(new String[] {EstoreMdmServiceConstant.SubscriberType_NEW_CASH_CRM}, this.getSubscriberType());
		boolean isIforNewCash = EstoreMdmServiceConstant.PaymentCategory_Prepaid.equals(this.getPaymentCategory());
		boolean isPostCard = EstoreMdmServiceConstant.PaymentCategory_Postpaid.equals(this.getPaymentCategory());
		if(isIforNewCash) return preErrMsg;
		
		// 判斷FET 3G POSTCARD Q/W/T, 為Q/W及不為T時不合法
		String subTp = this.getSubscriberType();
		boolean isSubQW = StringUtil.isInList(new String[] {EstoreMdmServiceConstant.SubscriberType_KING3G_CRM, EstoreMdmServiceConstant.SubscriberType_WALA_CRM},  subTp);
		//T=>3G, L=>4G
		boolean isSubT = EstoreMdmServiceConstant.SubscriberType_3G_CRM.equals(subTp) || EstoreMdmServiceConstant.SubscriberType_4G_CRM.equals(subTp) || EstoreMdmServiceConstant.SubscriberType_5G_CRM.equals(subTp); // 5G需求戳記
		if(isPostCard && isSubQW              ) return qwErrMsg;
		//code scan if(isPostCard && (!isSubQW && !isSubT)) return noPassErrMsg;
		if(isPostCard && !isSubT) return noPassErrMsg;
		
		return "";
	}
	
	
	public boolean isBillingMethodMidifiable() {
		if(this.getBillingType() == null || this.getBillingType().equals(""))
			return true;
		
		if(EstoreMdmServiceConstant.BillDeliveryMethod_Paper.equals(this.getBillingType())){
			return true;
		}
		
		return false;
	}
	
	
	public String getRateplanDisplayName() {
		StringBuilder sb = new StringBuilder();
		
		if(EstoreMdmServiceConstant.MobileGenerationCode_3G.equals(mobileGenerationCode)) {
			if(!"3000118949".equals(this.currentVoiceRate)){
				sb.append(this.currentVoiceName);
			}
			
			if(!"3000118952".equals(this.currentDataRate)) {
				if(sb.length() > 0 && this.currentDataName != null) {
					sb.append("/");
				}
				sb.append(this.currentDataName);
			}
		}else if(EstoreMdmServiceConstant.MobileGenerationCode_4G.equals(mobileGenerationCode)
					|| EstoreMdmServiceConstant.MobileGenerationCode_5G.equals(mobileGenerationCode)) { // 5G需求戳記
			if(!this.isCurrentVDOffer()) {
				sb.append(this.currentVoiceName);
			}
			if(sb.length() > 0) {
				sb.append("/");
			}
			sb.append(this.currentDataName);
		}
		return sb.toString();
	}
	
	
	

	public String getMsisdn() {
		return msisdn;
	}


	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


	public String getSubscriberID() {
		return subscriberID;
	}


	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}


	public String getSubscriberRocID() {
		return subscriberRocID;
	}


	public void setSubscriberRocID(String subscriberRocID) {
		this.subscriberRocID = subscriberRocID;
	}


	public String getAccountID() {
		return accountID;
	}


	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}


	public String getAccountRocID() {
		return accountRocID;
	}


	public void setAccountRocID(String accountRocID) {
		this.accountRocID = accountRocID;
	}


	public String getSubscriberName() {
		return subscriberName;
	}


	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public String getBirthday() {
		return birthday;
	}


	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	
	public Integer getAge() {
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new Date());
			
			return calendar.get(Calendar.YEAR) - Integer.valueOf(this.getBirthday().substring(0, 4));
		} catch (Exception ex) {
			LogUtil.warn("轉換年齡失敗，目前生日值：{}", this.getBirthday());
			return null;
		}
	}


	public String getSubscriberIDType() {
		return subscriberIDType;
	}


	public void setSubscriberIDType(String subscriberIDType) {
		this.subscriberIDType = subscriberIDType;
	}


	public String getCustomerID() {
		return customerID;
	}


	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}


	public String getCustomerType() {
		return customerType;
	}


	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}


	public String getSubscriberType() {
		return subscriberType;
	}


	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}


	public String getSubStatus() {
		return subStatus;
	}


	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}


	public String getSubStatusReasonCode() {
		return subStatusReasonCode;
	}


	public void setSubStatusReasonCode(String subStatusReasonCode) {
		this.subStatusReasonCode = subStatusReasonCode;
	}


	public String getBusinessEntityID() {
		return businessEntityID;
	}


	public void setBusinessEntityID(String businessEntityID) {
		this.businessEntityID = businessEntityID;
	}


	public String getPaymentCategory() {
		return paymentCategory;
	}


	public void setPaymentCategory(String paymentCategory) {
		this.paymentCategory = paymentCategory;
	}


	public String getProductType() {
		return productType;
	}


	public void setProductType(String productType) {
		this.productType = productType;
	}


	public String getContractEndDate() {
		return contractEndDate;
	}


	public void setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;
	}


	public String getContractStartDate() {
		return contractStartDate;
	}


	public void setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;
	}


	public String getCancelDate() {
		return cancelDate;
	}


	public void setCancelDate(String cancelDate) {
		this.cancelDate = cancelDate;
	}


	public String getIsLastContract() {
		return isLastContract;
	}


	public void setIsLastContract(String isLastContract) {
		this.isLastContract = isLastContract;
	}


	public String getActivationDate() {
		return activationDate;
	}


	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}


	public String getVip() {
		return vip;
	}


	public void setVip(String vip) {
		this.vip = vip;
	}


	public String getVipGrade() {
		return vipGrade;
	}


	public void setVipGrade(String vipGrade) {
		this.vipGrade = vipGrade;
	}


	public String getArpb() {
		return arpb;
	}


	public void setArpb(String arpb) {
		this.arpb = arpb;
	}

	public String getChurn() {
		return churn;
	}


	public void setChurn(String churn) {
		this.churn = churn;
	}


	public boolean isMvpn() {
		return mvpn;
	}

	public void setMvpn(boolean mvpn) {
		this.mvpn = mvpn;
	}
	
	public boolean isMvpnSplitBill() {
		return mvpnSplitBill;
	}

	public void setMvpnSplitBill(boolean mvpnSplitBill) {
		this.mvpnSplitBill = mvpnSplitBill;
	}
	
	public String getResidenceAddress() {
		return residenceAddress;
	}


	public void setResidenceAddress(String residenceAddress) {
		this.residenceAddress = residenceAddress;
	}
	
	public String getBillingAddress() {
		return billingAddress;
	}


	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}
	
	public boolean isHybrid() {
		return isHybrid;
	}


	public void setHybrid(boolean isHybrid) {
		this.isHybrid = isHybrid;
	}
	
	public String getMobileGenerationCode() {
		return mobileGenerationCode;
	}

	public void setMobileGenerationCode(String mobileGenerationCode) {
		this.mobileGenerationCode = mobileGenerationCode;
	}
	
	public String getCurrentDataRate() {
		return currentDataRate;
	}

	public void setCurrentDataRate(String currentDataRate) {
		this.currentDataRate = currentDataRate;
	}

	public String getCurrentVoiceRate() {
		return currentVoiceRate;
	}

	public void setCurrentVoiceRate(String currentVoiceRate) {
		this.currentVoiceRate = currentVoiceRate;
	}

	public String getCurrentVoiceName() {
		return currentVoiceName;
	}

	public void setCurrentVoiceName(String currentVoiceName) {
		this.currentVoiceName = currentVoiceName;
	}
	
	public Double getCurrentVoicePrice() {
		return currentVoicePrice;
	}

	public void setCurrentVoicePrice(Double currentVoicePrice) {
		this.currentVoicePrice = currentVoicePrice;
	}


	public String getCurrentDataName() {
		return currentDataName;
	}

	public void setCurrentDataName(String currentDataName) {
		this.currentDataName = currentDataName;
	}

	public Double getCurrentDataPrice() {
		return currentDataPrice;
	}

	public void setCurrentDataPrice(Double currentDataPrice) {
		this.currentDataPrice = currentDataPrice;
	}


	public boolean isLyDataOnly() {
		return lyDataOnly;
	}

	public void setLyDataOnly(boolean lyDataOnly) {
		this.lyDataOnly = lyDataOnly;
	}
	
	public String getLoyaltyUpgradeType() {
		return loyaltyUpgradeType;
	}

	public void setLoyaltyUpgradeType(String loyaltyUpgradeType) {
		this.loyaltyUpgradeType = loyaltyUpgradeType;
	}
	
	public boolean isPassVipLoyalty() {
		return passVipLoyalty;
	}

	public void setPassVipLoyalty(boolean passVipLoyalty) {
		this.passVipLoyalty = passVipLoyalty;
	}

	public String getSubscriberGender() {
		return subscriberGender;
	}

	public void setSubscriberGender(String subscriberGender) {
		this.subscriberGender = subscriberGender;
	}

	public String getSubscriberLastName() {
		return subscriberLastName;
	}


	public void setSubscriberLastName(String subscriberLastName) {
		this.subscriberLastName = subscriberLastName;
	}
	
	public String getBillingType() {
		return this.billingType;
		
//		if("1".equals(this.billingType)){
//			return BillingType.BILLING_TYPE_PAPER;
//        }else if("4".equals(this.billingType)){
//        	return BillingType.BILLING_TYPE_EMAIL;
//        }else if(("7").equals(this.billingType)){
//        	return BillingType.BILLING_TYPE_SMS;
//        }else{
//        	return BillingType.BILLING_TYPE_PAPER;
//        	//return billMethod;
//        }
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public String getPaymentConsolidationInd() {
		return paymentConsolidationInd;
	}

	public void setPaymentConsolidationInd(String paymentConsolidationInd) {
		this.paymentConsolidationInd = paymentConsolidationInd;
	}

	public String getHomeTelPrefix() {
		return homeTelPrefix;
	}


	public void setHomeTelPrefix(String homeTelPrefix) {
		this.homeTelPrefix = homeTelPrefix;
	}


	public String getHomeTel() {
		return homeTel;
	}

	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}


	public String getCohOrderId() {
		return cohOrderId;
	}


	public void setCohOrderId(String cohOrderId) {
		this.cohOrderId = cohOrderId;
	}


	public String getSubscriptionItemId() {
		return subscriptionItemId;
	}


	public void setSubscriptionItemId(String subscriptionItemId) {
		this.subscriptionItemId = subscriptionItemId;
	}


	public String getOldSimNo() {
		return oldSimNo;
	}


	public void setOldSimNo(String oldSimNo) {
		this.oldSimNo = oldSimNo;
	}


	public int getTenure() {
		return tenure;
	}


	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	public String getLyMdn(){
		return this.msisdn;
	}
	
	public String getCustomerRocId(){
		return this.subscriberRocID;
	}
	
	public String getCustomerSex(){
		return this.getSubscriberGender();
		
	}
	
	public Double getLyVOfferPrice(){
		return this.getCurrentVoicePrice();
	}
	
	public Double getLyDOfferPrice(){
		return this.getCurrentDataPrice();
	}
	
	public String getLyDOfferName(){
		return this.getCurrentDataName();
	}
	
	public String getLyVOfferName() {
		return this.getCurrentVoiceName();
	}
	
	public void addActiveProductOffering(String itemCode){
		this.activeProductOffering.add(itemCode);
	}

	public List<String> getActiveProductOffering() {
		return activeProductOffering;
	}


	public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getAccountContractComponentId() {
        return accountContractComponentId;
    }

    public void setAccountContractComponentId(String accountContractComponentId) {
        this.accountContractComponentId = accountContractComponentId;
    }

    public String getContractComponentId() {
        return contractComponentId;
    }

    public void setContractComponentId(String contractComponentId) {
        this.contractComponentId = contractComponentId;
    }

    public String getServiceProvider() {
        return serviceProvider;
    }

    public void setServiceProvider(String serviceProvider) {
        this.serviceProvider = serviceProvider;
    }
	
	public String getMvnpCid() {
		return mvnpCid;
	}


	public void setMvnpCid(String mvnpCid) {
		this.mvnpCid = mvnpCid;
	}


	public String getSdpUid() {
		return sdpUid;
	}


	public void setSdpUid(String sdpUid) {
		this.sdpUid = sdpUid;
	}


	public String getSubscriberContractComponentId() {
		return subscriberContractComponentId;
	}


	public void setSubscriberContractComponentId(String subscriberContractComponentId) {
		this.subscriberContractComponentId = subscriberContractComponentId;
	}


	public String getAccountContractId() {
		return accountContractId;
	}


	public void setAccountContractId(String accountContractId) {
		this.accountContractId = accountContractId;
	}


	public String getCustomerContractId() {
		return customerContractId;
	}


	public void setCustomerContractId(String customerContractId) {
		this.customerContractId = customerContractId;
	}


	public String getCustomerContractConpomentId() {
		return customerContractConpomentId;
	}


	public void setCustomerContractConpomentId(String customerContractConpomentId) {
		this.customerContractConpomentId = customerContractConpomentId;
	}


	public Date getVipStartDate() {
		return vipStartDate;
	}


	public void setVipStartDate(Date vipStartDate) {
		this.vipStartDate = vipStartDate;
	}


	public Date getContractExpiryDate() {
		return contractExpiryDate;
	}


	public void setContractExpiryDate(Date contractExpiryDate) {
		this.contractExpiryDate = contractExpiryDate;
	}


	public String getLast3MonthsGprsAverageMB() {
		return last3MonthsGprsAverageMB;
	}


	public void setLast3MonthsGprsAverageMB(String last3MonthsGprsAverageMB) {
		this.last3MonthsGprsAverageMB = last3MonthsGprsAverageMB;
	}


	public String getSmartPhoneIndicator() {
		return smartPhoneIndicator;
	}


	public void setSmartPhoneIndicator(String smartPhoneIndicator) {
		this.smartPhoneIndicator = smartPhoneIndicator;
	}


	public String getHappyGoIdn() {
		return happyGoIdn;
	}


	public void setHappyGoIdn(String happyGoIdn) {
		this.happyGoIdn = happyGoIdn;
	}


	public String getContractComponentValue() {
		return contractComponentValue;
	}


	public void setContractComponentValue(String contractComponentValue) {
		this.contractComponentValue = contractComponentValue;
	}


	public String getPaymentCategoryForGiftRedeem() {
		return paymentCategoryForGiftRedeem;
	}


	public void setPaymentCategoryForGiftRedeem(String paymentCategoryForGiftRedeem) {
		this.paymentCategoryForGiftRedeem = paymentCategoryForGiftRedeem;
	}


	public Integer getNonPrepaymentCount() {
		return nonPrepaymentCount;
	}


	public void setNonPrepaymentCount(Integer nonPrepaymentCount) {
		this.nonPrepaymentCount = nonPrepaymentCount;
	}


	public Integer getsMaxPSArpb() {
		return sMaxPSArpb;
	}


	public void setsMaxPSArpb(Integer sMaxPSArpb) {
		this.sMaxPSArpb = sMaxPSArpb;
	}


	public Integer getsMaxPSTenure() {
		return sMaxPSTenure;
	}


	public void setsMaxPSTenure(Integer sMaxPSTenure) {
		this.sMaxPSTenure = sMaxPSTenure;
	}
	
	public String getLastContractEndDate() {
		return lastContractEndDate;
	}


	public void setLastContractEndDate(String lastContractEndDate) {
		this.lastContractEndDate = lastContractEndDate;
	}

	public String toString(){
		return ReflectionToStringBuilder.toString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public boolean isUpgradePlus() {
		return isUpgradePlus;
	}


	public void setUpgradePlus(boolean isUpgradePlus) {
		this.isUpgradePlus = isUpgradePlus;
	}


	public String getUiInputRocId() {
		return uiInputRocId;
	}


	public void setUiInputRocId(String uiInputRocId) {
		this.uiInputRocId = uiInputRocId;
	}

	public String getCohTx() {
		return cohTx;
	}

	public void setCohTx(String cohTx) {
		this.cohTx = cohTx;
	}

	public boolean isCurrentVDOffer() {
		return currentVDOffer;
	}

	public void setCurrentVDOffer(boolean currentVDOffer) {
		this.currentVDOffer = currentVDOffer;
	}

	public List<CrmPromotionVO> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<CrmPromotionVO> promotions) {
		this.promotions = promotions;
	}

	public String getCurrentHandset() {
		return currentHandset;
	}

	//手機品牌,ex.SAMSUNG
	public void setCurrentHandset(String currentHandset) {
		this.currentHandset = currentHandset;
	}

	public boolean isPrivateAccount() {
		return privateAccount;
	}

	public void setPrivateAccount(boolean privateAccount) {
		this.privateAccount = privateAccount;
	}

	public boolean isLineMobile() {
		return lineMobile;
	}

	public void setLineMobile(boolean lineMobile) {
		this.lineMobile = lineMobile;
	}

}
