package com.fet.estore.core.bean;

import java.io.Serializable;

public class ShipmentVO implements Serializable {

	private static final long serialVersionUID = -6737548195067469221L;
	//訂單編號
	private String cvsid;
	//F + 顧客所選之超商店舖編號
	private String cvsspot;
	//原資料回傳
	private String cvstemp;
	//網站的網域
	private String cvsname;
	//顧客所選之超商店舖名稱
	private String name;
	//顧客所選之超商店舖電話
	private String tel;
	//顧客所選之超商店舖地址
	private String addr;
	//顧客所選之超商店舖路線路順
	private String cvsnum;
	
	public String getCvsid() {
		return cvsid;
	}
	public void setCvsid(String cvsid) {
		this.cvsid = cvsid;
	}
	public String getCvsspot() {
		return cvsspot;
	}
	public void setCvsspot(String cvsspot) {
		this.cvsspot = cvsspot;
	}
	public String getCvstemp() {
		return cvstemp;
	}
	public void setCvstemp(String cvstemp) {
		this.cvstemp = cvstemp;
	}
	public String getCvsname() {
		return cvsname;
	}
	public void setCvsname(String cvsname) {
		this.cvsname = cvsname;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getCvsnum() {
		return cvsnum;
	}
	public void setCvsnum(String cvsnum) {
		this.cvsnum = cvsnum;
	}
	
}
