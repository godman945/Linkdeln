package com.fet.estore.core.bean.bo;

import com.fet.estore.core.bean.vo.UploadFileInfo;

public class UploadCredentialBO {

    private boolean isHealthIdCard;//上傳的是否是健保卡，是的話要同時傳背面
    private UploadFileInfo uploadFileInfo;
    
	public boolean getIsHealthIdCard() {
		return isHealthIdCard;
	}
	public void setIsHealthIdCard(boolean isHealthIdCard) {
		this.isHealthIdCard = isHealthIdCard;
	}
	public UploadFileInfo getUploadFileInfo() {
		return uploadFileInfo;
	}
	public void setUploadFileInfo(UploadFileInfo uploadFileInfo) {
		this.uploadFileInfo = uploadFileInfo;
	}
}
