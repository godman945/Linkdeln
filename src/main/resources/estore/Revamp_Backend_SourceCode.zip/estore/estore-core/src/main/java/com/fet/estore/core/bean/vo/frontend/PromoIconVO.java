package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

public class PromoIconVO implements Serializable{

	private static final long serialVersionUID = 1L;
	/** productId */
	private String productId;
	/** id */
	private String id;
	/** name */
	private String name;
	/** pic */
	private String pic;
	/** seq */
	private Long seq;
	/** type */
	private String type;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public Long getSeq() {
		return seq;
	}
	public void setSeq(Long seq) {
		this.seq = seq;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}

