package com.fet.estore.core.bean;

import java.io.Serializable;

public class ProductTag implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 商品標籤類型 */
    private String type;
    /** 商品標籤名稱 */
    private String name;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
