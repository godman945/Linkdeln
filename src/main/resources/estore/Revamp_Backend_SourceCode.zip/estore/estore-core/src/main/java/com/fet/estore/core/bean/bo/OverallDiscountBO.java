package com.fet.estore.core.bean.bo;

public class OverallDiscountBO {

	private String type;	
	private Long id;
	private String discountCode;
	private Double discountRatio;
	private Long costCenterId;
	private String discountName;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public Double getDiscountRatio() {
		return discountRatio;
	}
	public void setDiscountRatio(Double discountRatio) {
		this.discountRatio = discountRatio;
	}
	public Long getCostCenterId() {
		return costCenterId;
	}
	public void setCostCenterId(Long costCenterId) {
		this.costCenterId = costCenterId;
	}
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}
}
