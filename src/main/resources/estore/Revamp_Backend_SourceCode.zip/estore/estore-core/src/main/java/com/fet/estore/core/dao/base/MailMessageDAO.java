package com.fet.estore.core.dao.base;

import com.fet.estore.core.model.MailMessage;

import java.util.List;
public interface MailMessageDAO extends BaseDAO<MailMessage, Long> {
	/**
	 * 取出未發送之信件之ID
	 * @return
	 */
	List<MailMessage> findUnSentMail(long startId, Integer size);
	
}
