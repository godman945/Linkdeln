package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.util.List;

public class MenuVo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4877278372978674510L;
	
	private String navigationId;
	private String name;
	private String displayName;
	private String linkUrl;
	private String linkMethod;
	private Boolean isHighlight;
	private Boolean isSystemDefault;
	private List<MenuVo> childMenuVoList;
	private MenuVo parentMenuVo;
	private String multiprodActId;
	
	public String getNavigationId() {
		return navigationId;
	}
	public void setNavigationId(String navigationId) {
		this.navigationId = navigationId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getLinkUrl() {
		return linkUrl;
	}
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}
	public String getLinkMethod() {
		return linkMethod;
	}
	public void setLinkMethod(String linkMethod) {
		this.linkMethod = linkMethod;
	}
	public Boolean getIsSystemDefault() {
		return isSystemDefault;
	}
	public void setIsSystemDefault(Boolean isSystemDefault) {
		this.isSystemDefault = isSystemDefault;
	}
	public List<MenuVo> getChildMenuVoList() {
		return childMenuVoList;
	}
	public void setChildMenuVoList(List<MenuVo> childMenuVoList) {
		this.childMenuVoList = childMenuVoList;
	}
	public Boolean getIsHighlight() {
		return isHighlight;
	}
	public void setIsHighlight(Boolean isHighlight) {
		this.isHighlight = isHighlight;
	}
	/**
	 * 取得parentMenuVo。
	 *
	 * @return the parentMenuVo
	 */
	public MenuVo getParentMenuVo() {
		return parentMenuVo;
	}
	/**
	 * 設定parentMenuVo。
	 *
	 * @param parentMenuVo 欲設定的parentMenuVo。
	 */
	public void setParentMenuVo(MenuVo parentMenuVo) {
		this.parentMenuVo = parentMenuVo;
	}
	public String getMultiprodActId() {
		return multiprodActId;
	}
	public void setMultiprodActId(String multiprodActId) {
		this.multiprodActId = multiprodActId;
	}
}
