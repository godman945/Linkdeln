package com.fet.estore.core.bean;

import java.io.Serializable;

public class ReservationOrderReturn implements Serializable {

	private static final long serialVersionUID = -6723020029313069804L;
	private String rtnCode;
	private String errorMsg;
	private String orderType;
	private String msisdn;
	private CrmData crmData;
	
	public String getRtnCode() {
		return rtnCode;
	}
	public void setRtnCode(String rtnCode) {
		this.rtnCode = rtnCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public ReservationOrderReturn() {
		super();
	}
	public ReservationOrderReturn(String rtnCode, String errorMsg) {
		super();
		this.rtnCode = rtnCode;
		this.errorMsg = errorMsg;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public CrmData getCrmData() {
		return crmData;
	}
	public void setCrmData(CrmData crmData) {
		this.crmData = crmData;
	}
	
}
