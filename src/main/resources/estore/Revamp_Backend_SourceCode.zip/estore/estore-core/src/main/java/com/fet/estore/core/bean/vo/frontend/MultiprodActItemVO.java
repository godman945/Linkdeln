package com.fet.estore.core.bean.vo.frontend;

public class MultiprodActItemVO {
    
    private long id;
    private long multiProdActId;
    private String orderType;
    private String title;
    private Boolean isNh;
    private Boolean isLh;
    private Boolean isNp;
   
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public long getMultiProdActId() {
        return multiProdActId;
    }
    
    public void setMultiProdActId(long multiProdActId) {
        this.multiProdActId = multiProdActId;
    }
    
    public String getOrderType() {
        return orderType;
    }
    
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }

    public Boolean getIsNh() {
        return isNh;
    }

    public void setIsNh(Boolean isNh) {
        this.isNh = isNh;
    }

    public Boolean getIsLh() {
        return isLh;
    }

    public void setIsLh(Boolean isLh) {
        this.isLh = isLh;
    }

    public Boolean getIsNp() {
        return isNp;
    }

    public void setIsNp(Boolean isNp) {
        this.isNp = isNp;
    }
    
}