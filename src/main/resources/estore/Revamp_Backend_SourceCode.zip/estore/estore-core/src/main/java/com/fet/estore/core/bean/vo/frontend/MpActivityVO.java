package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.bean.vo.IDiscountItem;

/**
 * 組合折扣活動VO
 * @author Max Chen
 *
 */
public class MpActivityVO implements IDiscountItem {

	private String activityName;
	private String discountType;
	private Integer discountAmount;
	private String groupTitle1;
	private String groupTitle2;
	private String activityType;
	private Integer minChoice;
	private Double discountRatio;
	private String discountCode;
	private Integer plusAmount;
	
	private Long costCenterMasterId;
	
	private String discountName;
	
	public String getDiscountType() {
		return discountType;
	}
	public void setDiscountType(String discountType) {
		this.discountType = discountType;
	}
	public Integer getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(Integer discountAmount) {
		this.discountAmount = discountAmount;
	}
	public String getGroupTitle1() {
		return groupTitle1;
	}
	public void setGroupTitle1(String groupTitle1) {
		this.groupTitle1 = groupTitle1;
	}
	public String getGroupTitle2() {
		return groupTitle2;
	}
	public void setGroupTitle2(String groupTitle2) {
		this.groupTitle2 = groupTitle2;
	}
	public String getActivityType() {
		return activityType;
	}
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
	public Integer getMinChoice() {
		return minChoice;
	}
	public void setMinChoice(Integer minChoice) {
		this.minChoice = minChoice;
	}
	public Double getDiscountRatio() {
		return discountRatio;
	}
	public void setDiscountRatio(Double discountRatio) {
		this.discountRatio = discountRatio;
	}
	public Long getCostCenterMasterId() {
		return costCenterMasterId;
	}
	public void setCostCenterMasterId(Long costCenterMasterId) {
		this.costCenterMasterId = costCenterMasterId;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public Integer getPlusAmount() {
		return plusAmount;
	}
	public void setPlusAmount(Integer plusAmount) {
		this.plusAmount = plusAmount;
	}

	@Override
	public Long getAaiId() {
		return null;
	}
	@Override
	public String getFetNo() {
		return null;
	}
	@Override
	public Long getActivityId() {
		return null;
	}
	@Override
	public Long getCouponId() {
		return null;
	}
	@Override
	public Long getOfferId() {
		return null;
	}
	@Override
	public Long getCostCenterId() {
		return costCenterMasterId;
	}
	@Override
	public Long getActualDiscountAmt() {
		return null;
	}
	@Override
	public String getDisplayGroup() {
		return null;
	}
	@Override
	public String getCode() {
		return discountCode;
	}
	@Override
	public String getName() {
		return activityName;
	}
	@Override
	public Long getAmount() {
		return discountAmount != null ? discountAmount.longValue() : null;
	}
}
