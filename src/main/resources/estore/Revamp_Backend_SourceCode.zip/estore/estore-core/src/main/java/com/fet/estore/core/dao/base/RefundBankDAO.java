package com.fet.estore.core.dao.base;

import org.springframework.stereotype.Repository;

import com.fet.estore.core.model.RefundBank;
@Repository
public interface RefundBankDAO extends BaseDAO<RefundBank, String> {
}
