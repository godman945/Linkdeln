package com.fet.estore.core.bean.vo;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-30
 * @description
 */
public class ProductTagVO {

    private static final long serialVersionUID = 1L;
    private String productId;
    private String type;
    private String name;
    private String tagId;

    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getTagId() {
        return tagId;
    }
    public void setTagId(String tagId) {
        this.tagId = tagId;
    }
}
