package com.fet.estore.core.dao.base;

import java.util.Collection;
import java.util.List;

import com.fet.estore.core.bean.MetaInfo;
import com.fet.estore.core.model.Properties;
import com.fet.estore.core.model.support.Page;
import com.fet.estore.core.bean.vo.PropertiesVO;
/**
 * @version $Id: PropertiesDAO.java,v 1.0, 2017-05-16 11:07:29Z, Evan Tung$
 */
public interface PropertiesDAO extends BaseDAO<Properties, Long> {
	
	/**
	 * 依名稱取得Properties
	 * @param name
	 * @return
	 */
	public Properties findByName(String name);

	/**
	 * 依名稱陣列取得Properties
	 * @param names
	 * @return
	 */
	public List<Properties> findByNames(Collection<String> names);
	
	/**
	 * 查詢館別資料 - 大網
	 * @return
	 */
	public List<PropertiesVO> findMainCategoryList();
	
	/**
	 * SEO Metadata管理 - 依條件分頁查詢 - 大網
	 * @param mainCategory
	 * @param subCategory
	 * @param searchColumn
	 * @param searchKeyword
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Page<PropertiesVO> pageQueryMetadataByCondition(String mainCategory, String subCategory,
			String searchColumn, String queryMetaKeyword, int pageNo, int pageSize);
	
	/**
	 * SEO Metadata管理 - 依條件分頁查詢 - 小網
	 * @param mainCategory
	 * @param searchColumn
	 * @param queryMetaKeyword
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Page<PropertiesVO> pageQueryMetadataByConditionForMobile(String mainCategory, 
			String searchColumn, String queryMetaKeyword, int pageNo, int pageSize);
	
	/**
	 * SEO Metadata管理 - 匯出excel - 大網
	 * @param mainCategory
	 * @param subCategory
	 * @param searchColumn
	 * @param queryMetaKeyword
	 * @return
	 */
	public List<PropertiesVO> findMetadataByCondition(String mainCategory, String subCategory, 
			String searchColumn, String queryMetaKeyword);
	
	/**
	 * SEO Metadata管理 - 匯出excel - 小網
	 * @param mainCategory
	 * @param subCategory
	 * @param searchColumn
	 * @param queryMetaKeyword
	 * @return
	 */
	public List<PropertiesVO> findMetadataByConditionForMobile(String mainCategory,
			String searchColumn, String queryMetaKeyword);
	
	/**
	 * 依館別、次類別查詢「館別+次類別」之名稱組合是否重複
	 * @param mainName
	 * @param subName
	 * @return
	 */
	public boolean isCategoryNameDuplicate(String mainName, String subName);

	/**
	 * @description 判斷是否為一般賣場
	 * @author Dennis.Chen
	 * @param activityId
	 * @return
	 */
	public boolean isNormalAct(Long activityId);

	/**
	 * 用頁面路徑取得Meta Data
	 * @param path
	 * @return
	 * @author Roil.Li
	 * @date 2020-10-19
	 */
	public MetaInfo findPageMetaByPath(String path);

}
