package com.fet.estore.core.bean.vo.frontend;

/**
 * 折扣計算結果 - 折扣VO
 * @author Max Chen
 *
 */
public class DiscountResultDiscountVO {
	
	/** 折扣類型 - 全館設備折扣 */
	public static final String TYPE_OVERALL_HG  = "OVERALL_HG";
	/** 折扣類型 - 全館配件折扣 */
	public static final String TYPE_OVERALL_ACC = "OVERALL_ACC";
	/** 折扣類型 - 配件活動折扣 */
	public static final String TYPE_ACC_ACT     = "ACC_ACT";
	/** 折扣類型 - 活動折扣 */
	public static final String TYPE_ACT         = "ACT";
	
	/** 折扣類型 - HappyGO折扣 */
	public static final String TYPE_HG          = "HG";
	/** 折扣類型 - Coupon折扣 */
	public static final String TYPE_COUPON      = "COUPON";

	/** 折扣類型 - 加價購折扣(固定) */
	public static final String TYPE_MP_DISC_FIXED  = "MP_DISC_FIXED";
	/** 折扣類型 - 加價購折扣(組合) */
	public static final String TYPE_MP_DISC_MARKUP = "MP_DISC_MARKUP";
	/** 折扣類型 - 加價購折扣(比例) */
	public static final String TYPE_MP_DISC_RATIO  = "MP_DISC_RATIO";
	
	/** 折扣類型 - NDS加價購折扣 */
	public static final String TYPE_EB  = "EB";
	
	/** 折扣類型 - NDS專屬優惠折扣 */
	public static final String TYPE_PREMIUM  = "PREMIUM";
	
	/** 折扣類型 - 組合折扣(固定) */
	public static final String TYPE_MP_ACT_FIXED  = "MP_ACT_FIXED";
	/** 折扣類型 - 組合折扣(組合) */
	public static final String TYPE_MP_ACT_MARKUP = "MP_ACT_MARKUP";
	/** 折扣類型 - 組合折扣(比例) */
	public static final String TYPE_MP_ACT_RATIO  = "MP_ACT_RATIO";
	/** 折扣類型 - 組合折扣(加價) */
	public static final String TYPE_MP_ACT_PLUS   = "MP_ACT_PLUS";

	private String type;
	private String discountCode;
	private Long discountAmt;
	private Long actualDiscountAmt;
	private Double discountRatio;
	private String discountName;
	
	private Long actId;
	private Long accActId;
	private Long overallDiscountId;
	private Long mpActId;
	private Long mpDiscId;
	
	private Long couponId;
	private String couponSn;
	
	private Long hgPoints;
	
	private Long hgActPoints;
	
	private String[] discountMemo = new String[0];
		
	/** 成本中心ID */
	private Long costCenterId;
	
	/** NDS加價購 - 合併顯示群組 */
	private String ebDisplayGroup;
	
	
	/**
	 * 記錄折扣數量
	 * @param priceBefore
	 * @param priceAfter
	 */
	public void loggingDiscount(Long priceBefore, Long priceAfter) {
		if(priceBefore == null || priceAfter == null) return;
		
		discountMemo = new String[1];
		
		long discAmt = priceAfter - priceBefore; 
		discountMemo[0] = String.format("%s -> %s (%s)", priceBefore, priceAfter, discAmt);
	}
	
	/**
	 * 記錄折扣數量
	 * @param priceBefore
	 * @param priceAfter
	 */
	public void loggingDiscount(Long priceBefore, Long priceAfter, Long mpSetErpPrice, Long mpProdErpPrice, Long mpSetDiscAmt, Boolean mpSetLast, Double ratio) {
		if(priceBefore == null || priceAfter == null) return;
		
		boolean isRatio = ratio != null;
		discountMemo = isRatio ? new String[2] : new String[4];
		
		long discAmt = priceAfter - priceBefore; 
		discountMemo[0] = String.format("%s -> %s (%s)", priceBefore, priceAfter, discAmt);
		
		if(mpSetErpPrice != null && mpProdErpPrice != null && mpSetDiscAmt != null && mpSetLast != null) {
			if(isRatio) {
				long shareAmt = priceBefore - new Double(Math.floor(priceBefore * ratio)).longValue();				
				discountMemo[1] = String.format("%6d * %3.2f = %d %s ", priceBefore, ratio, shareAmt, mpSetLast ? ", last" : "");
			} else {
				long shareAmt = new Double(((double)mpSetDiscAmt * (double) mpProdErpPrice / (double)mpSetErpPrice)).longValue();
				discountMemo[1] = String.format("            %6d          ", mpProdErpPrice);
				discountMemo[2] = String.format("%6d * ---------- = %d %s ", mpSetDiscAmt   , shareAmt, mpSetLast ? ", last" : "");
				discountMemo[3] = String.format("            %6d          ", mpSetErpPrice  );				
			}
		}
	}	
	
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getDiscountAmt() {
		return discountAmt;
	}
	public void setDiscountAmt(Long discountAmt) {
		this.discountAmt = discountAmt;
	}
	public Double getDiscountRatio() {
		return discountRatio;
	}
	public void setDiscountRatio(Double discountRatio) {
		this.discountRatio = discountRatio;
	}
	public Long getOverallDiscountId() {
		return overallDiscountId;
	}
	public void setOverallDiscountId(Long overallDiscountId) {
		this.overallDiscountId = overallDiscountId;
	}
	public Long getActualDiscountAmt() {
		return actualDiscountAmt;
	}
	public void setActualDiscountAmt(Long actualDiscountAmt) {
		this.actualDiscountAmt = actualDiscountAmt;
	}

	public Long getCostCenterId() {
		return costCenterId;
	}
	public void setCostCenterId(Long costCenterId) {
		this.costCenterId = costCenterId;
	}
	public Long getActId() {
		return actId;
	}
	public void setActId(Long actId) {
		this.actId = actId;
	}
	public Long getAccActId() {
		return accActId;
	}
	public void setAccActId(Long accActId) {
		this.accActId = accActId;
	}
	public Long getMpDiscId() {
		return mpDiscId;
	}
	public void setMpDiscId(Long mpDiscId) {
		this.mpDiscId = mpDiscId;
	}
	public Long getMpActId() {
		return mpActId;
	}
	public void setMpActId(Long mpActId) {
		this.mpActId = mpActId;
	}
	public Long getCouponId() {
		return couponId;
	}
	public void setCouponId(Long couponId) {
		this.couponId = couponId;
	}
	public String getCouponSn() {
		return couponSn;
	}
	public void setCouponSn(String couponSn) {
		this.couponSn = couponSn;
	}
	public Long getHgPoints() {
		return hgPoints;
	}
	public void setHgPoints(Long hgPoints) {
		this.hgPoints = hgPoints;
	}
	public String[] getDiscountMemo() {
		return discountMemo;
	}
	public void setDiscountMemo(String discountMemo[]) {
		this.discountMemo = discountMemo;
	}

	public String getDiscountName() {
		return discountName;
	}

	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}

	public Long getHgActPoints() {
		return hgActPoints;
	}

	public void setHgActPoints(Long hgActPoints) {
		this.hgActPoints = hgActPoints;
	}

	public String getEbDisplayGroup() {
		return ebDisplayGroup;
	}

	public void setEbDisplayGroup(String ebDisplayGroup) {
		this.ebDisplayGroup = ebDisplayGroup;
	}
}
