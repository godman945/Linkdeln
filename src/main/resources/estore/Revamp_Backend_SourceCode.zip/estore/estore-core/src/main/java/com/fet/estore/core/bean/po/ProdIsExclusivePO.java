package com.fet.estore.core.bean.po;

/**
 * @author Dennis.Chen
 * @Date 2020-10-13
 */
public class ProdIsExclusivePO {

    String fetNo;
    Integer inventory;
    Boolean isExclusive;
    Boolean isPreSubscribe;

    public String getFetNo() {
        return fetNo;
    }

    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }

    public Integer getInventory() {
        return inventory;
    }

    public void setInventory(Integer inventory) {
        this.inventory = inventory;
    }

    public Boolean getExclusive() {
        return isExclusive;
    }

    public void setExclusive(Boolean exclusive) {
        isExclusive = exclusive;
    }

    public Boolean getPreSubscribe() {
        return isPreSubscribe;
    }

    public void setPreSubscribe(Boolean preSubscribe) {
        isPreSubscribe = preSubscribe;
    }
}
