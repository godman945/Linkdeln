package com.fet.estore.core.bean;

import java.io.Serializable;

public class ExtraBuy implements Serializable {

	private static final long serialVersionUID = -6220571477197061673L;
	private String type;
	private String fetno;
	private String quantity;
	private String extraBuyId;
	private String extraBuyItemId;

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getFetno() {
		return fetno;
	}
	public void setFetno(String fetno) {
		this.fetno = fetno;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getExtraBuyId() {
		return extraBuyId;
	}
	public void setExtraBuyId(String extraBuyId) {
		this.extraBuyId = extraBuyId;
	}
	public String getExtraBuyItemId() {
		return extraBuyItemId;
	}
	public void setExtraBuyItemId(String extraBuyItemId) {
		this.extraBuyItemId = extraBuyItemId;
	}
}
