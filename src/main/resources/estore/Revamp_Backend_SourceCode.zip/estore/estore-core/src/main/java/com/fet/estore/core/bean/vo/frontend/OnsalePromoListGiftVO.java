package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.List;

/**
 * 促案贈品VO
 * @author Max Chen
 *
 */
public class OnsalePromoListGiftVO {
	/** 活動ID */
	private Long id;
	/** 活動抬頭 */
	private String title;
	/** 開始時間 */
	private String onsaleDateStr;
	/** 結束時間 */
	private String offDateStr;
	/** 描述 */
	private String description;
	/** 圖檔 */
	private String imagePath;	
	
	/** 設備贈品 - 是否為設備贈品 */
	private boolean isHandsetGift;
	/** 設備贈品 - 贈品名稱 */
	private String handsetGiftName;
	
	/** 折價卷 - 是否有折價卷 */
	private boolean hasCoupon;
	/** 折價卷 - ID */
	private Long   couponId;
	/** 折價卷 - 使用方式 */
	private String couponInstructions;
	/** 折價卷 - 折抵金額 */
	private String couponDiscountAmount;
	
	/** 帳單折扣 - 是否有帳單折扣 */
	private boolean hasOffer;
	/** 帳單折扣 - ID清單(與名稱順序相同) */
	private List<Long>   offerIds = new ArrayList<Long>();
	/** 帳單折扣 - 帳單折扣名稱 */
	private List<String> offerNames = new ArrayList<String>();
	
	/** 贈品 - 是否有贈品 */
	private boolean hasGift;
	/** 贈品 - ID清單(與名稱順序相同) */
	private List<String> giftIds = new ArrayList<String>();	
	/** 贈品 - 贈品名稱 */
	private List<String> giftNames = new ArrayList<String>();
	
	/** 看更多URL */
	private String giftDetailLink; 

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	public boolean isHasCoupon() {
		return hasCoupon;
	}
	public void setHasCoupon(boolean hasCoupon) {
		this.hasCoupon = hasCoupon;
	}
	public String getCouponInstructions() {
		return couponInstructions;
	}
	public void setCouponInstructions(String couponInstructions) {
		this.couponInstructions = couponInstructions;
	}
	public String getCouponDiscountAmount() {
		return couponDiscountAmount;
	}
	public void setCouponDiscountAmount(String couponDiscountAmount) {
		this.couponDiscountAmount = couponDiscountAmount;
	}
	public boolean isHasOffer() {
		return hasOffer;
	}
	public void setHasOffer(boolean hasOffer) {
		this.hasOffer = hasOffer;
	}
	public boolean isHasGift() {
		return hasGift;
	}
	public void setHasGift(boolean hasGift) {
		this.hasGift = hasGift;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCouponId() {
		return couponId;
	}
	public void setCouponId(Long couponId) {
		this.couponId = couponId;
	}
	public List<Long> getOfferIds() {
		return offerIds;
	}
	public void setOfferIds(List<Long> offerIds) {
		this.offerIds = offerIds;
	}
	public List<String> getOfferNames() {
		return offerNames;
	}
	public void setOfferNames(List<String> offerNames) {
		this.offerNames = offerNames;
	}
	public List<String> getGiftIds() {
		return giftIds;
	}
	public void setGiftIds(List<String> giftIds) {
		this.giftIds = giftIds;
	}
	public List<String> getGiftNames() {
		return giftNames;
	}
	public void setGiftNames(List<String> giftNames) {
		this.giftNames = giftNames;
	}
	public String getOnsaleDateStr() {
		return onsaleDateStr;
	}
	public void setOnsaleDateStr(String onsaleDateStr) {
		this.onsaleDateStr = onsaleDateStr;
	}
	public String getOffDateStr() {
		return offDateStr;
	}
	public void setOffDateStr(String offDateStr) {
		this.offDateStr = offDateStr;
	}
	public boolean isHandsetGift() {
		return isHandsetGift;
	}
	public void setHandsetGift(boolean isHandsetGift) {
		this.isHandsetGift = isHandsetGift;
	}
	public String getHandsetGiftName() {
		return handsetGiftName;
	}
	public void setHandsetGiftName(String handsetGiftName) {
		this.handsetGiftName = handsetGiftName;
	}
	public String getGiftDetailLink() {
	    return giftDetailLink;
	}
	public void setGiftDetailLink(String giftDetailLink) {
	    this.giftDetailLink = giftDetailLink;
	}

}
