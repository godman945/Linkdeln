package com.fet.estore.core.bean.vo.frontend.mobile;

/**
 * 購買清單項目VO
 * @author Max Chen
 *
 */
public class ShoppingGuideItemVO {
	
	/** 購買清單資訊 - 小計 */
	private Long guidePrice;
	/** 購買清單資訊 - 是否新申辦 */
	private boolean guideIsGa;
	/** 購買清單資訊 - 是否攜碼 */
	private boolean guideIsNp;
	/** 購買清單資訊 - 是否續約 */
	private boolean guideIsLy;
	/** 購買清單資訊 - 是否單買 */
	private boolean guideIsDa;
	/** 購買清單資訊 - 是否搭設備or單買 */
	private boolean guideIsDev;
	/** 購買清單資訊 - 重導路徑 */
	private String guideActNm;
	/** 購買清單資訊 - 可折抵金額 */
	private Long guideCanDiscPrice;
	/** 購買清單資訊 - 預繳金額 */
	private long guidePrepaidPrice;	
	/** 購買清單資訊 - 運費 */
	private long guideShipmentPrice;
	
	/** 門號觀察 - 門號ID */
	private String mdnObProductId;
	/** 門號觀察 - 顯示門號 */
	private String mdnObDisplayMsisdn;
	/** 門號觀察 - 選號費 */
	private Long   mdnObFee;
	
	/** 紅配綠商品 - 群組標題 */
	private String prodGroupTitle;
	
	/** 主商品 - 名稱 */
	private String prodName;
	/** 主商品 - 數量 */
	private Integer prodAmt;
	/** 主商品 - 小計 */
	private Long   prodPrice;
	/** 主商品 - 最大數量 */
	private Integer prodMaxAmt;
	/** 主商品 - 料號 */
	private String prodFetNo;
	
	/** 資費 - 名稱 */
	private String promoName;
	/** 資費 - 促銷描述 */
	private String promoRecommendName;
	
	/** 加值服務 - 名稱 */
	private String vaServName;
	
	/** 加購服務 - 名稱 */
	private String addServName;
	
	/** 門號 - 新申辦/續約/攜碼門號 */
	private String mdnMsisdn;
	/** 門號 - 顯示用 */
	private String mdnDisplayMsisdn;
	
	/** 競標門號 - 門號 */
	private String aucMsisdn;
	/** 競標門號 - 顯示門號 */
	private String aucDisplayMsisdn;
	/** 競標門號 - 得標價 */
	private Integer aucPrice;
	
	/** 門號 - 續約資料是否存在 */
	private boolean mdnLyData;
	/** 門號 - 續約門號使用者之姓 */
	private String mdnLyLastName;
	/** 門號 - 續約門號使用者稱呼(先生/小姐) */
	private String mdnLySex;
	/** 門號 - 續約門號使用者費率 */
	private String mdnLyRate;
	
	/** 配件 - 名稱 */
	private String accName;
	/** 配件 - 數量 */
	private Integer accAmt;
	/** 配件 - 最大數量 */
	private Integer accMaxAmt;
	/** 配件 - 小計 */
	private Long accPrice;
	/** 配件 - 料號 */
	private String accFetNo;
	
	/** 贈品 - 名稱 */
	private String giftName;
	
	/** 優惠券贈送 - 名稱 */
	private String coupongiftName;
	
	/** 帳單優惠 - 名稱 */
	private String offerName;
	/** 帳單優惠 - 回饋金額 */
	private Long offerPrice;
	
	/** 折扣 - 名稱 */
	private String discountName;
	/** 折扣 - 折扣金額 */
	private Long discountPrice;
	
	/** 優惠卷 - 名稱 */
	private String couponName;
	/** 優惠卷 - 折扣金額 */
	private Long couponPrice;
	
	/** HappyGo - 折扣金額 */
	private Long hgPrice;
	/** HappyGo - 折扣點數 */
	private Long hgPoint;
	
	/** 運費 - 金額 */
	private Long shipmentFee;

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public Integer getProdAmt() {
		return prodAmt;
	}

	public void setProdAmt(Integer prodAmt) {
		this.prodAmt = prodAmt;
	}

	public Long getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(Long prodPrice) {
		this.prodPrice = prodPrice;
	}

	public String getPromoName() {
		return promoName;
	}

	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}

	public String getVaServName() {
		return vaServName;
	}

	public void setVaServName(String vaServName) {
		this.vaServName = vaServName;
	}

	public String getAddServName() {
		return addServName;
	}

	public void setAddServName(String addServName) {
		this.addServName = addServName;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public Integer getAccAmt() {
		return accAmt;
	}

	public void setAccAmt(Integer accAmt) {
		this.accAmt = accAmt;
	}

	public Long getAccPrice() {
		return accPrice;
	}

	public void setAccPrice(Long accPrice) {
		this.accPrice = accPrice;
	}

	public String getGiftName() {
		return giftName;
	}

	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}

	public String getDiscountName() {
		return discountName;
	}

	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}

	public Long getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(Long discountPrice) {
		this.discountPrice = discountPrice;
	}

	public String getOfferName() {
		return offerName;
	}

	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	public Long getOfferPrice() {
		return offerPrice;
	}

	public void setOfferPrice(Long offerPrice) {
		this.offerPrice = offerPrice;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}

	public Long getCouponPrice() {
		return couponPrice;
	}

	public void setCouponPrice(Long couponPrice) {
		this.couponPrice = couponPrice;
	}

	public Long getHgPrice() {
		return hgPrice;
	}

	public void setHgPrice(Long hgPrice) {
		this.hgPrice = hgPrice;
	}

	public Integer getAccMaxAmt() {
		return accMaxAmt;
	}

	public void setAccMaxAmt(Integer accMaxAmt) {
		this.accMaxAmt = accMaxAmt;
	}

	public Long getGuidePrice() {
		return guidePrice;
	}

	public void setGuidePrice(Long guidePrice) {
		this.guidePrice = guidePrice;
	}

	public String getPromoRecommendName() {
		return promoRecommendName;
	}

	public void setPromoRecommendName(String promoRecommendName) {
		this.promoRecommendName = promoRecommendName;
	}

	public String getMdnMsisdn() {
		return mdnMsisdn;
	}

	public void setMdnMsisdn(String mdnMsisdn) {
		this.mdnMsisdn = mdnMsisdn;
	}

	public String getMdnDisplayMsisdn() {
		return mdnDisplayMsisdn;
	}

	public void setMdnDisplayMsisdn(String mdnDisplayMsisdn) {
		this.mdnDisplayMsisdn = mdnDisplayMsisdn;
	}

	public Long getShipmentFee() {
		return shipmentFee;
	}

	public void setShipmentFee(Long shipmentFee) {
		this.shipmentFee = shipmentFee;
	}

	public String getCoupongiftName() {
		return coupongiftName;
	}

	public void setCoupongiftName(String coupongiftName) {
		this.coupongiftName = coupongiftName;
	}

	public boolean isGuideIsGa() {
		return guideIsGa;
	}

	public void setGuideIsGa(boolean guideIsGa) {
		this.guideIsGa = guideIsGa;
	}

	public boolean isGuideIsNp() {
		return guideIsNp;
	}

	public void setGuideIsNp(boolean guideIsNp) {
		this.guideIsNp = guideIsNp;
	}

	public boolean isGuideIsLy() {
		return guideIsLy;
	}

	public void setGuideIsLy(boolean guideIsLy) {
		this.guideIsLy = guideIsLy;
	}

	public boolean isGuideIsDa() {
		return guideIsDa;
	}

	public void setGuideIsDa(boolean guideIsDa) {
		this.guideIsDa = guideIsDa;
	}

	public String getGuideActNm() {
		return guideActNm;
	}

	public void setGuideActNm(String guideActNm) {
		this.guideActNm = guideActNm;
	}

	public Long getGuideCanDiscPrice() {
		return guideCanDiscPrice;
	}

	public void setGuideCanDiscPrice(Long guideCanDiscPrice) {
		this.guideCanDiscPrice = guideCanDiscPrice;
	}

	public boolean isGuideIsDev() {
		return guideIsDev;
	}

	public void setGuideIsDev(boolean guideIsDev) {
		this.guideIsDev = guideIsDev;
	}

	public Long getHgPoint() {
		return hgPoint;
	}

	public void setHgPoint(Long hgPoint) {
		this.hgPoint = hgPoint;
	}

	public String getAccFetNo() {
		return accFetNo;
	}

	public void setAccFetNo(String accFetNo) {
		this.accFetNo = accFetNo;
	}

	public long getGuidePrepaidPrice() {
		return guidePrepaidPrice;
	}

	public void setGuidePrepaidPrice(long guidePrepaidPrice) {
		this.guidePrepaidPrice = guidePrepaidPrice;
	}

	public boolean isMdnLyData() {
		return mdnLyData;
	}

	public void setMdnLyData(boolean mdnLyData) {
		this.mdnLyData = mdnLyData;
	}

	public String getMdnLyLastName() {
		return mdnLyLastName;
	}

	public void setMdnLyLastName(String mdnLyLastName) {
		this.mdnLyLastName = mdnLyLastName;
	}

	public String getMdnLySex() {
		return mdnLySex;
	}

	public void setMdnLySex(String mdnLySex) {
		this.mdnLySex = mdnLySex;
	}

	public String getMdnLyRate() {
		return mdnLyRate;
	}

	public void setMdnLyRate(String mdnLyRate) {
		this.mdnLyRate = mdnLyRate;
	}

	public long getGuideShipmentPrice() {
		return guideShipmentPrice;
	}

	public void setGuideShipmentPrice(long guideShipmentPrice) {
		this.guideShipmentPrice = guideShipmentPrice;
	}

	public Integer getProdMaxAmt() {
		return prodMaxAmt;
	}

	public void setProdMaxAmt(Integer prodMaxAmt) {
		this.prodMaxAmt = prodMaxAmt;
	}

	public String getProdFetNo() {
		return prodFetNo;
	}

	public void setProdFetNo(String prodFetNo) {
		this.prodFetNo = prodFetNo;
	}

	public String getMdnObProductId() {
		return mdnObProductId;
	}

	public void setMdnObProductId(String mdnObProductId) {
		this.mdnObProductId = mdnObProductId;
	}

	public String getMdnObDisplayMsisdn() {
		return mdnObDisplayMsisdn;
	}

	public void setMdnObDisplayMsisdn(String mdnObDisplayMsisdn) {
		this.mdnObDisplayMsisdn = mdnObDisplayMsisdn;
	}

	public Long getMdnObFee() {
		return mdnObFee;
	}

	public void setMdnObFee(Long mdnObFee) {
		this.mdnObFee = mdnObFee;
	}

	public String getProdGroupTitle() {
		return prodGroupTitle;
	}

	public void setProdGroupTitle(String prodGroupTitle) {
		this.prodGroupTitle = prodGroupTitle;
	}

	public String getAucMsisdn() {
		return aucMsisdn;
	}

	public void setAucMsisdn(String aucMsisdn) {
		this.aucMsisdn = aucMsisdn;
	}

	public String getAucDisplayMsisdn() {
		return aucDisplayMsisdn;
	}

	public void setAucDisplayMsisdn(String aucDisplayMsisdn) {
		this.aucDisplayMsisdn = aucDisplayMsisdn;
	}

	public Integer getAucPrice() {
		return aucPrice;
	}

	public void setAucPrice(Integer aucPrice) {
		this.aucPrice = aucPrice;
	}
}
