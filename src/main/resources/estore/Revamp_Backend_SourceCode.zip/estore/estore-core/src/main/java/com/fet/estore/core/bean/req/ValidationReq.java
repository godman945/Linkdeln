package com.fet.estore.core.bean.req;

import java.io.Serializable;

public class ValidationReq implements Serializable {

	private static final long serialVersionUID = -3732089501775349151L;
	private String rocId;
	private String msisdn;

	public String getRocId() {
		return rocId;
	}
	public void setRocId(String rocId) {
		this.rocId = rocId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
}
