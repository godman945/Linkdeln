package com.fet.estore.core.dao.newstore;

import java.util.Date;
import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CallingCardDetail;

/**
 * CallCardDetailDAO 介面 
 *  @version     $Id: NCallingCardDetailDAO.java,v 1.0, 2017-05-16 11:04:26Z, Evan Tung$
 */
public interface NCallingCardDetailDAO extends BaseDAO<CallingCardDetail, Long> {

}
