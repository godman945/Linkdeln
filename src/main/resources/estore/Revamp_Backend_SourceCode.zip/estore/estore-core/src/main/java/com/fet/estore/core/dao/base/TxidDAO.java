package com.fet.estore.core.dao.base;

import java.util.List;

import org.hibernate.Query;

import com.fet.estore.core.model.Txid;

public interface TxidDAO extends BaseDAO<Txid, String> {
	public Txid findByTxid(String txid);
	
	/**
	 * 取回TXID狀態
	 * @return
	 */
	public List<Txid> findUnhandleTxid();
	
	
	/**
	 * 當退款狀態未達D（退款成功）或F（退款失敗）時，持續向ipay問狀態。I:退款受理中
	 * @return
	 */
	public List<Txid> findUnhandleRefundTxid();

}
