package com.fet.estore.core.bean.vo.frontend;

import java.util.Date;

public class HSActivityVO {
	/** ID */
	private String productId;
	/** 名稱 */
	private String name;
	/** 圖片路徑 */
	private String imgPath;
	/** 商品原價。 */
	private Long erpPrice;
	/** 上架日期。 */
	private Date onsaleDate;
	/** 下架日期。 */
	private Date offDate;
	/**PK**/
	private String fetNo;
	/**庫存**/
	private Long inventory;
	/** 是否為獨家商品 */
	private Boolean isExclusive;
	/**PROMO_ICON.pic**/
	private String pic;
	/** 單機優惠價 */
	private Long daDiscPrice;
	
	private String defaultImage;
	/**是否宅配**/
	private boolean isHomeDeliverable;
	/**是否門市取貨**/
	private boolean isStoreDeliverable;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImgPath() {
		return imgPath;
	}
	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	public Date getOnsaleDate() {
		return onsaleDate;
	}
	public void setOnsaleDate(Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}
	public Date getOffDate() {
		return offDate;
	}
	public void setOffDate(Date offDate) {
		this.offDate = offDate;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public Long getInventory() {
		return inventory;
	}
	public void setInventory(Long inventory) {
		this.inventory = inventory;
	}
	public Boolean getIsExclusive() {
		return isExclusive;
	}
	public void setIsExclusive(Boolean isExclusive) {
		this.isExclusive = isExclusive;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public Long getDaDiscPrice() {
		return daDiscPrice;
	}
	public void setDaDiscPrice(Long daDiscPrice) {
		this.daDiscPrice = daDiscPrice;
	}
	public String getDefaultImage() {
		return defaultImage;
	}
	public void setDefaultImage(String defaultImage) {
		this.defaultImage = defaultImage;
	}
	public boolean isHomeDeliverable() {
		return isHomeDeliverable;
	}
	public void setHomeDeliverable(boolean isHomeDeliverable) {
		this.isHomeDeliverable = isHomeDeliverable;
	}
	public boolean isStoreDeliverable() {
		return isStoreDeliverable;
	}
	public void setStoreDeliverable(boolean isStoreDeliverable) {
		this.isStoreDeliverable = isStoreDeliverable;
	}	
}
