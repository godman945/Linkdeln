package com.fet.estore.core.dao.base.impl;

import com.fet.estore.core.dao.base.AccessoryGroupDAO;
import com.fet.estore.core.model.AccessoryGroup;
import com.fet.estore.core.util.LogUtil;
import org.apache.commons.codec.binary.StringUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AccessoryGroupDAOImpl extends AbstractBaseDAO<AccessoryGroup, String> implements AccessoryGroupDAO {
	
	@Override
	public void processActivationDateAccessorySort(String act) {
		LogUtil.info("=============AccessoryGroupDAOImpl.processActivationDateAccessorySort is start=====act = "+act);
		StringBuffer sql = new StringBuffer();
		sql.append(" DELETE FROM ACCESSORY_SORTING where ");
		if(StringUtils.equals(act, "BRAND")) {
			sql.append(" CATEGORY is null ");
		}else if(StringUtils.equals(act, "CATEGORY")) {
			sql.append(" CATEGORY is not null ");
		}
		SQLQuery delQry = this.getSessionFactory().getCurrentSession().createSQLQuery(sql.toString());
		delQry.executeUpdate();
		
		StringBuffer sb = new StringBuffer();
		if(StringUtils.equals(act, "BRAND")) {
			sb.append("		  insert into ACCESSORY_SORTING (TOTAL, PRODUCT_ID, BRAND, NAME, SORT) ");
		}else if(StringUtils.equals(act, "CATEGORY")) {
			sb.append("		  insert into ACCESSORY_SORTING (TOTAL, PRODUCT_ID, CATEGORY, NAME, SORT) ");
		}
		sb.append("  	  SELECT COUNT (1) AS total,                                                     ");
		sb.append("           product_1.product_id,                                                      ");		
		if(StringUtils.equals(act, "BRAND")) {
			sb.append("           ACC_BRAND.BRAND,                                                       ");
		}else if(StringUtils.equals(act, "CATEGORY")) {
			sb.append("           ACCESSORY_CATEGORY.NAME as CATEGORY,    								 ");
		}
		sb.append("           ACCESSORY_GROUP.name,                                                  	 ");
		sb.append("           ROW_NUMBER ()                                                              ");
		if(StringUtils.equals(act, "BRAND")) {
			sb.append("              OVER (PARTITION BY ACC_BRAND.BRAND ORDER BY COUNT (1) DESC)         ");
		}else if(StringUtils.equals(act, "CATEGORY")) {
			sb.append("              OVER (PARTITION BY ACCESSORY_CATEGORY.NAME ORDER BY COUNT (1) DESC) ");
		}
		sb.append("              AS sort                                                                 ");
		sb.append("      FROM       ACCESSORY_GROUP                                                      ");
		sb.append("              LEFT JOIN                                                               ");
		sb.append("                 ACC_BRAND                                                            ");
		sb.append("              ON ACC_BRAND.ID = ACCESSORY_GROUP.BRAND                                 ");
		sb.append("           LEFT JOIN                                                                  ");
		sb.append("                 ACCESSORY_CATEGORY_MAPPING                                           ");
		sb.append("              INNER JOIN                                                              ");
		sb.append("                 ACCESSORY_CATEGORY                                                   ");
		sb.append("              ON ACCESSORY_CATEGORY.ID =                                              ");
		sb.append("                    ACCESSORY_CATEGORY_MAPPING.ACCESSORY_CATEGORY_ID                  ");
		sb.append("           ON ACCESSORY_GROUP.PRODUCT_ID = ACCESSORY_CATEGORY_MAPPING.PRODUCT_ID,     ");
		//co_master 取得配件資料
		sb.append("           (SELECT product.*                                                          ");
		sb.append("              FROM co_master, co_detail, product                                      ");
		sb.append("             WHERE     1 = 1                                                          ");
		sb.append("                   AND co_master.ia_status = 'D'                                      ");
		sb.append("                   AND co_master.ACTIVATION_DATE >=                                   ");
		sb.append("                          TRUNC (  SYSDATE                                            ");
		sb.append("                                 - (SELECT content                                    ");
		sb.append("                                      FROM properties                                 ");
		sb.append("                                     WHERE name = 'ACTIVATION_DATE_PERIOD'))          ");
		sb.append("                   AND co_detail.CONO = co_master.cono                                ");
		sb.append("                   AND co_detail.PRODTYPENO = '2'                                     ");
		sb.append("                   AND co_master.co_type IN ('NH', 'PH', 'LH', 'DA')                  ");
		sb.append("                   AND product.fet_no = co_detail.fet_no) product_1                   ");
		sb.append("     WHERE ACCESSORY_GROUP.PRODUCT_ID = product_1.PRODUCT_ID                          ");
		sb.append("  GROUP BY product_1.product_id,                                                      ");
		if(StringUtils.equals(act, "BRAND")) {
			sb.append("           ACC_BRAND.brand,                                                       ");
		}else if(StringUtils.equals(act, "CATEGORY")) {
			sb.append("           ACCESSORY_CATEGORY.NAME,                                               ");
		}
		sb.append("           ACCESSORY_GROUP.name                                                       ");
		SQLQuery qry = this.getSessionFactory().getCurrentSession().createSQLQuery(sb.toString());
		qry.executeUpdate();
		LogUtil.info("=============AccessoryGroupDAOImpl.processActivationDateAccessorySort is end======");
	}
	
	public List<AccessoryGroup> findOnsaleAccessory(){
		Query query = this.getSessionFactory().getCurrentSession().createQuery("from AccessoryGroup a where a.onsaleDate < sysdate and a.offDate > sysdate and a.sign4onsale = 'Y' and a.onsale = 'Y'");
		return query.list();
	}

}
