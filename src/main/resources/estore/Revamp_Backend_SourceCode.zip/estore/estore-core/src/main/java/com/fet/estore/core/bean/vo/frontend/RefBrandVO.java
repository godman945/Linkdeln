package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

import org.hibernate.Hibernate;

public class RefBrandVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** id */
	private String id;
	
	private String brand;
	
	private Long erpPrice;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public Long getErpPrice() {
		return erpPrice;
	}

	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	
	
	
}
