package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * 為了BeanUtil copy可以複製所有properties
 */
public interface IShoppingResultParam extends Serializable {

	String getRedeemCouponSerial();
		
	String getOrderType();	
		
	String getOnsalePromoListId();	
		
	String getDeliveryType();	
		
	Long getHgRedeemPoint();
		
	Long getHgRedeemPrice();
		
	String getAuctionMsisdn();	
		
	Integer getAuctionActivityId();	
		
	String getAuctionRocId();	
		
	Integer getAuctionPrice();	
		
	Long getActivityId();	
		
	String getChannel();	

}
