package com.fet.estore.core.bean.vo.frontend.mobile;

public class ShoppingGuideProductVO {
	private String  productId     ;
	private String  fetNo         ;
	private Long    erpPrice      ;
	private String  pName         ;
	private String  pColor        ;
	private String  hgBrand       ;
	private String  hgModel       ;
	private String  agBrand       ;
	private String  agName        ;
	private Integer hgMaxInventory;
	private Integer agMaxInventory;
	private Long    posPrice;
	
	public String getProductId() {
		return productId;
	}
	
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public String getFetNo() {
		return fetNo;
	}
	
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	
	public Long getErpPrice() {
		return erpPrice;
	}
	
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	
	public String getpName() {
		return pName;
	}
	
	public void setpName(String pName) {
		this.pName = pName;
	}
	
	public String getHgBrand() {
		return hgBrand;
	}
	
	public void setHgBrand(String hgBrand) {
		this.hgBrand = hgBrand;
	}
	
	public String getHgModel() {
		return hgModel;
	}
	
	public void setHgModel(String hgModel) {
		this.hgModel = hgModel;
	}
	
	public String getAgBrand() {
		return agBrand;
	}
	
	public void setAgBrand(String agBrand) {
		this.agBrand = agBrand;
	}
	
	public String getAgName() {
		return agName;
	}
	
	public void setAgName(String agName) {
		this.agName = agName;
	}
	
	public Integer getHgMaxInventory() {
		return hgMaxInventory;
	}
	
	public void setHgMaxInventory(Integer hgMaxInventory) {
		this.hgMaxInventory = hgMaxInventory;
	}
	
	public Integer getAgMaxInventory() {
		return agMaxInventory;
	}
	
	public void setAgMaxInventory(Integer agMaxInventory) {
		this.agMaxInventory = agMaxInventory;
	}

	public String getpColor() {
		return pColor;
	}

	public void setpColor(String pColor) {
		this.pColor = pColor;
	}

	public Long getPosPrice() {
		return posPrice;
	}

	public void setPosPrice(Long posPrice) {
		this.posPrice = posPrice;
	}
}
