package com.fet.estore.core.bean.req;

import java.io.Serializable;

public class ReservationOrderReq implements Serializable {

	private static final long serialVersionUID = -3732089501775349150L;
	private String seq;
	private String rocId;
	private String fetNo;
	private String productId;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getRocId() {
		return rocId;
	}
	public void setRocId(String rocId) {
		this.rocId = rocId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
}
