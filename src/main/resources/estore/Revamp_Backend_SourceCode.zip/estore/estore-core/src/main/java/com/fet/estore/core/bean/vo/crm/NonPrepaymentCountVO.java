package com.fet.estore.core.bean.vo.crm;

public class NonPrepaymentCountVO {
	private Integer nonPrepaymentCount;
	private Integer sMaxPSArpb;
	private Integer sMaxPSTenure;
	
	public Integer getNonPrepaymentCount() {
		return nonPrepaymentCount;
	}
	public void setNonPrepaymentCount(Integer nonPrepaymentCount) {
		this.nonPrepaymentCount = nonPrepaymentCount;
	}
	public Integer getsMaxPSArpb() {
		return sMaxPSArpb;
	}
	public void setsMaxPSArpb(Integer sMaxPSArpb) {
		this.sMaxPSArpb = sMaxPSArpb;
	}
	public Integer getsMaxPSTenure() {
		return sMaxPSTenure;
	}
	public void setsMaxPSTenure(Integer sMaxPSTenure) {
		this.sMaxPSTenure = sMaxPSTenure;
	}
	
	
	
	

}
