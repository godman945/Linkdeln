package com.fet.estore.core.bean.vo.common;

import java.io.Serializable;

/**
 * @description Banner圖文分離Image資料結構
 * @autor Dennis.Chen
 * @date 2020-07-14
 */
public class BannerImageVO implements Serializable{

	private static final long serialVersionUID = -1653482295308095789L;
	String md; //大圖
	String sm; //小圖
	
	public BannerImageVO() {
	}

	public BannerImageVO(String md, String sm) {
		super();
		this.md = md;
		this.sm = sm;
	}
	
	public String getMd() {
		return md;
	}
	public void setMd(String md) {
		this.md = md;
	}
	public String getSm() {
		return sm;
	}
	public void setSm(String sm) {
		this.sm = sm;
	}

}
