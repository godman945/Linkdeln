package com.fet.estore.core.bean.vo.crm;

import java.util.ArrayList;
import java.util.List;

import com.fet.estore.core.constant.Result;


public class ValidationResultList {

	//public static final String RESULT_CHECK_BLACKLIST = "16";
	//public static final String RESULT_CHECK_MULTI_ID = "3";
	//public static final String RESULT_CHECK_NP_IN_PROCESS = "66";
	
	
	//private Map<String, ValidationResult> results = new HashMap<String, ValidationResult>();
	
	
	private List<ValidationResult> results = new ArrayList<ValidationResult>();
	
	public void addResult(ValidationResult result){
		this.results.add(result);
	}
	
//	public boolean isPassBlacklist(){
//		for(ValidationResult result : this.results){
//			if(Result.CHECK_BLACK_LIST.equals(result.getValidationType())){
//				return result.isPass();
//			}
//		}
//		throw new RuntimeException("No CHECK_BLACK_LIST result found!");
//	}
//	
//	public boolean isPassMultiId(){
//		for(ValidationResult result : this.results){
//			if(Result.CHECK_MULTI_ID.equals(result.getValidationType())){
//				return result.isPass();
//			}
//		}
//		throw new RuntimeException("No CHECK_MULTI_ID result found!");
//	}
//	
//	public boolean isPassNpInProcess(){
//		for(ValidationResult result : this.results){
//			if(Result.CHECK_MSISDN_MNP_OUT.equals(result.getValidationType())){
//				return result.isPass();
//			}
//		}
//		throw new RuntimeException("No CHECK_MSISDN_MNP_OUT result found!");
//	}
//	
//
//	//排除VIP LOYALTY
	public boolean isPassAllCheck(){
		for(ValidationResult result : this.results){
			if(!Result.CHECK_VIP_LOYALTY.equals(result.getValidationType()) && !result.isPass()){
				return false;
			}
		}
		return true;
	}
	
	public boolean isPassAllCheckExceptEmployCheck(){
		for(ValidationResult result : this.results){
			if(!(Result.CHECK_VIP_LOYALTY.equals(result.getValidationType()) || Result.CHECK_EMPLOYEE_APPLY_LOYALTY_WAY.equals(result.getValidationType())) 
					&& !result.isPass()){
				return false;
			}
		}
		return true;
	}
	
	
	public ValidationResult getResult(String validationType){
		for(ValidationResult result : this.results){
			if(validationType.equals(result.getValidationType())){
				return result;
			}
		}
		return null;
	}
	
	public ValidationResult getFirstErrorResult(){
		for(ValidationResult result : this.results){
			if(!result.isPass()){
				return result;
			}
		}
		return null;
	}
	
	public List<ValidationResult> getAllResult(){
		return this.results;
	}
	
	public boolean hasCBP29(){
		for(ValidationResult result : this.results){
			if("CBP29".equals(result.getAlertCode())){
				return true;
			}
		}
		return false;
	}
	
	public String getCBP29AlertMessage(){
		for(ValidationResult result : this.results){
			if("CBP29".equals(result.getAlertCode())){
				return result.getAlertMessage();
			}
		}
		return null;
	}
	
//	public boolean isPassVipLoyalty() {
//		for(ValidationResult result : this.results) {
//			if(!Result.CHECK_VIP_LOYALTY.equals(result.getValidationType())) continue;
//			return result.isPass();
//		}
//		return false;
//	}
	
	public ValidationResult getResult(int i){
		
		if(i > this.results.size() -1){
			throw new RuntimeException("Out of bound index!");
		}
		
		return this.results.get(i);
		
	}
	
	
	public boolean isPassSecondaryCheck(){
		List<String> checkRules = new ArrayList<String>();
		checkRules.add(Result.CHECK_REPLACE);
		checkRules.add(Result.CHECK_MSISDN_STATUS);
		checkRules.add(Result.CHECK_MSISDN_ROCID);
		checkRules.add(Result.CHECK_LOYALTY_QUALIFY);
		checkRules.add(Result.CHECK_LOY_CUST_DATA);
		checkRules.add(Result.CHECK_MSISDN_MNP_OUT);
		checkRules.add(Result.CHECK_BASE_STATION);
		checkRules.add(Result.CHECK_LOY_APPLY_DATE);
		checkRules.add(Result.CHECK_EMPLOYEE_APPLY_LOYALTY_WAY);
		checkRules.add(Result.CHECK_CORP_CUSTOMER);
		
		for(ValidationResult result : this.results){
			if(checkRules.contains(result.getValidationType()) && !result.isPass()){
				return false;
			}
		}
		return true;
	}
}
