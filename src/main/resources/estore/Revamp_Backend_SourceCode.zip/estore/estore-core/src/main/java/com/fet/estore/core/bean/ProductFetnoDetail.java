package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.Map;

/**
 * 商品明細頁 - 料號明細，含商品庫存狀態、顏色和對應顏色的圖片
 *
 * @description
 * @author Ted.Hsieh
 * @date 2020-08-11
 */

public class ProductFetnoDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    /** ATR庫存狀態 - 正常供貨 */
    public static final String ATR_STATUS_NORMAL      = "NORMAL";
    /** ATR庫存狀態 - 缺貨 */
    public static final String ATR_STATUS_UNAVAILABLE = "UNAVAILABLE";
    /** ATR庫存狀態 - 預約單取貨 */
    public static final String ATR_STATUS_ALLOW       = "ALLOW";

    /** 商品顏色中文名稱(配合前端有兩個欄位) */
    private String label;
    /** 商品顏色中文名稱(配合前端有兩個欄位) */
    private String value;
    /** 商品顏色色碼 */
    private String color;
    /** 商品料號 */
    private String fetNo;
    /** 商品料號缺貨狀態 */
    private String atrStatus;
    /** 商品料號手動缺貨(貨到通知我 & 預約單取貨)按鈕狀態 */
    private Map<String, String> buttonStatus;
    /** 商品料號是否為可預購狀態 */
    private boolean applyUnavailabel;
    /** 商品料號對應庫存 */
    private Long inventory;
    /** 商品上蓋量檢查後的缺貨狀態 */
    private Boolean outOfStock;
    /** 商品原價 */
    private Long originPrice;
    /** 商品優惠價 */
    private Long salePrice;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getFetNo() {
        return fetNo;
    }

    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }

    public String getAtrStatus() {
        return atrStatus;
    }

    public void setAtrStatus(String atrStatus) {
        this.atrStatus = atrStatus;
    }

    public Map<String, String> getButtonStatus() {
        return buttonStatus;
    }

    public void setButtonStatus(Map<String, String> buttonStatus) {
        this.buttonStatus = buttonStatus;
    }

    public boolean isApplyUnavailabel() {
        return applyUnavailabel;
    }

    public void setApplyUnavailabel(boolean applyUnavailabel) {
        this.applyUnavailabel = applyUnavailabel;
    }

    public Long getInventory() {
        return inventory;
    }

    public void setInventory(Long inventory) {
        this.inventory = inventory;
    }

    public Boolean isOutOfStock() {
        return outOfStock;
    }

    public void setOutOfStock(Boolean outOfStock) {
        this.outOfStock = outOfStock;
    }

    public Long getOriginPrice() {
        return originPrice;
    }

    public void setOriginPrice(Long originPrice) {
        this.originPrice = originPrice;
    }

    public Long getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Long salePrice) {
        this.salePrice = salePrice;
    }
}
