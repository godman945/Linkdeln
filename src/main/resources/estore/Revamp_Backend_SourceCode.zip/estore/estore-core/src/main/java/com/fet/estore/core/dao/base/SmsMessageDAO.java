package com.fet.estore.core.dao.base;

import com.fet.estore.core.model.SmsMessage;

public interface SmsMessageDAO extends BaseDAO<SmsMessage, Long> {

}
