package com.fet.estore.core.bean;

import java.io.Serializable;

public class FaqItem implements Serializable{
	
	private static final long serialVersionUID = 3166589614135746974L;
	private Integer id;
	private String page;
	private String tagName;
	private String faqId;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getTagName() {
		return tagName;
	}
	public void setTagName(String tabName) {
		this.tagName = tabName;
	}
	public String getFaqId() {
		return faqId;
	}
	public void setFaqId(String faqId) {
		this.faqId = faqId;
	}
}
