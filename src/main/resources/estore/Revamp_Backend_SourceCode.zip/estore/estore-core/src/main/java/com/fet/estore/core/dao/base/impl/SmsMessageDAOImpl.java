package com.fet.estore.core.dao.base.impl;

import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.SmsMessageDAO;
import com.fet.estore.core.model.SmsMessage;
@Repository
public class SmsMessageDAOImpl extends AbstractBaseDAO<SmsMessage, Long> implements SmsMessageDAO {

}
