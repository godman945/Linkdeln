package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.util.Date;

public class RecommendSourceVO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 197918648046522552L;
	// Fields
    /** 系統序號。 */
    private String id;
    /** 推薦管道名稱 */
    private String displayName;
    /** 後台是否顯示DESC欄 */
    private Boolean isShowDescription;
    /** 前台輸入框提示文字 */
    private String description;
    /** 是否刪除 */
    private Boolean isDelete;
    /** 是否為系統定義 */
    private Boolean isSystemDefined;
    /** 是否上架 */
    private Boolean onSale;
    /** 上架起始時間 */
    private Date onSaleDate;
    /** 上架結束時間 */
    private Date offDate;
    /** 是否需要門市人員檢核 */
    private Boolean employeeCheck;
	/** 排列順序 */
	private Integer displayOrder;
    
	/** 上架時。 */
	private String onsaleHour;
	/** 下架時。 */
	private String offHour;
	
	private String startDate;
	
	private String endDate;
    
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDisplayName() {
        return displayName;
    }
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    public Boolean getIsShowDescription() {
        return isShowDescription;
    }
    public void setIsShowDescription(Boolean isShowDescription) {
        this.isShowDescription = isShowDescription;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Boolean getIsDelete() {
        return isDelete;
    }
    public void setIsDelete(Boolean isDelete) {
        this.isDelete = isDelete;
    }
    public Boolean getIsSystemDefined() {
        return isSystemDefined;
    }
    public void setIsSystemDefined(Boolean isSystemDefined) {
        this.isSystemDefined = isSystemDefined;
    }
    public Boolean getOnSale() {
        return onSale;
    }
    public void setOnSale(Boolean onSale) {
        this.onSale = onSale;
    }
    public Date getOnSaleDate() {
        return onSaleDate;
    }
    public void setOnSaleDate(Date onSaleDate) {
        this.onSaleDate = onSaleDate;
    }
    public Date getOffDate() {
        return offDate;
    }
    public void setOffDate(Date offDate) {
        this.offDate = offDate;
    }
    public Boolean getEmployeeCheck() {
        return employeeCheck;
    }
    public void setEmployeeCheck(Boolean employeeCheck) {
        this.employeeCheck = employeeCheck;
    }
	public String getOnsaleHour() {
		return onsaleHour;
	}
	public void setOnsaleHour(String onsaleHour) {
		this.onsaleHour = onsaleHour;
	}
	public String getOffHour() {
		return offHour;
	}
	public void setOffHour(String offHour) {
		this.offHour = offHour;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Integer getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}
	
	
}
