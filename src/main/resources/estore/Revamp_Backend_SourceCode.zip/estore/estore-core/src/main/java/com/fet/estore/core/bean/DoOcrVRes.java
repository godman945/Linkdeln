package com.fet.estore.core.bean;

import java.io.Serializable;

public class DoOcrVRes implements Serializable{

	private String ocrErrCode;
	private boolean result;
	private String errMsg;
	private String errCode;
	private String redirectUrl;
	private String secondaryCredentialType;//二證判斷是駕照還是健保卡
	public String getOcrErrCode() {
		return ocrErrCode;
	}
	public void setOcrErrCode(String ocrErrCode) {
		this.ocrErrCode = ocrErrCode;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getRedirectUrl() {
		return redirectUrl;
	}
	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getSecondaryCredentialType() {
		return secondaryCredentialType;
	}
	public void setSecondaryCredentialType(String secondaryCredentialType) {
		this.secondaryCredentialType = secondaryCredentialType;
	}
}
