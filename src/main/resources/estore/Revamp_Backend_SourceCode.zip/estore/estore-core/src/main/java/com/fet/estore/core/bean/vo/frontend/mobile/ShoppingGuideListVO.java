package com.fet.estore.core.bean.vo.frontend.mobile;

import java.util.List;
import java.util.Map;

/**
 * 購買清單列表VO
 * @author Max Chen
 *
 */
public class ShoppingGuideListVO {
	
	/** 填寫資料頁 - 顯示coupon */
	private boolean subShowCoupon;
	/** 填寫資料頁 - 顯示hg */
	private boolean subShowHg;
	/** 填寫資料頁 - 顯示發票 */
	private boolean subShowVat;
	
	/** 購買清單資訊 */
	private ShoppingGuideItemVO       guide;
	
	/** 門號觀察 */
	private List<ShoppingGuideItemVO> msisdnObList;
	
	/** 紅配綠商品 */
	private Map<String, List<ShoppingGuideItemVO>> mpProds; 
	
	/** 主商品 */
	private List<ShoppingGuideItemVO> prodList;
	
	/** 資費 */
	private ShoppingGuideItemVO       promo;
	
	/** 加購服務 */
	private List<ShoppingGuideItemVO> addServList;
	
	/** 加值服務 */
	private List<ShoppingGuideItemVO> vaServList;
	
	/** 門號 */
	private ShoppingGuideItemVO       msisdn;
	
	/** 競標門號 - 門號 */
	private ShoppingGuideItemVO       aucMsisdn;
	
	/** 競標門號 - 得標金 */
	private ShoppingGuideItemVO       aucPrice;
	
	/** 配件 */
	private List<ShoppingGuideItemVO> accList;
	
	/** 贈品 */
	private List<ShoppingGuideItemVO> giftList;
	
	/** 折扣 */
	private List<ShoppingGuideItemVO> discountList;
	
	/** 帳單優惠 */
	private List<ShoppingGuideItemVO> offerList;
	
	/** 優惠卷贈送 */
	private List<ShoppingGuideItemVO> coupongiftList;
	
	/** 優惠卷 */
	private ShoppingGuideItemVO       coupon;
	
	/** HappyGo */
	private ShoppingGuideItemVO       hg;

	/** 運費 */
	private ShoppingGuideItemVO       shipment;
	
	
	public ShoppingGuideItemVO getGuide() {
		return guide;
	}

	public void setGuide(ShoppingGuideItemVO guide) {
		this.guide = guide;
	}

	public List<ShoppingGuideItemVO> getProdList() {
		return prodList;
	}

	public void setProdList(List<ShoppingGuideItemVO> prodList) {
		this.prodList = prodList;
	}

	public ShoppingGuideItemVO getPromo() {
		return promo;
	}

	public void setPromo(ShoppingGuideItemVO promo) {
		this.promo = promo;
	}

	public List<ShoppingGuideItemVO> getAddServList() {
		return addServList;
	}

	public void setAddServList(List<ShoppingGuideItemVO> addServList) {
		this.addServList = addServList;
	}

	public List<ShoppingGuideItemVO> getVaServList() {
		return vaServList;
	}

	public void setVaServList(List<ShoppingGuideItemVO> vaServList) {
		this.vaServList = vaServList;
	}

	public ShoppingGuideItemVO getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(ShoppingGuideItemVO msisdn) {
		this.msisdn = msisdn;
	}

	public List<ShoppingGuideItemVO> getAccList() {
		return accList;
	}

	public void setAccList(List<ShoppingGuideItemVO> accList) {
		this.accList = accList;
	}

	public List<ShoppingGuideItemVO> getGiftList() {
		return giftList;
	}

	public void setGiftList(List<ShoppingGuideItemVO> giftList) {
		this.giftList = giftList;
	}

	public List<ShoppingGuideItemVO> getDiscountList() {
		return discountList;
	}

	public void setDiscountList(List<ShoppingGuideItemVO> discountList) {
		this.discountList = discountList;
	}

	public List<ShoppingGuideItemVO> getOfferList() {
		return offerList;
	}

	public void setOfferList(List<ShoppingGuideItemVO> offerList) {
		this.offerList = offerList;
	}

	public ShoppingGuideItemVO getCoupon() {
		return coupon;
	}

	public void setCoupon(ShoppingGuideItemVO coupon) {
		this.coupon = coupon;
	}

	public ShoppingGuideItemVO getHg() {
		return hg;
	}

	public void setHg(ShoppingGuideItemVO hg) {
		this.hg = hg;
	}

	public ShoppingGuideItemVO getShipment() {
		return shipment;
	}

	public void setShipment(ShoppingGuideItemVO shipment) {
		this.shipment = shipment;
	}

	public List<ShoppingGuideItemVO> getCoupongiftList() {
		return coupongiftList;
	}

	public void setCoupongiftList(List<ShoppingGuideItemVO> coupongiftList) {
		this.coupongiftList = coupongiftList;
	}

	public boolean isSubShowCoupon() {
		return subShowCoupon;
	}

	public void setSubShowCoupon(boolean subShowCoupon) {
		this.subShowCoupon = subShowCoupon;
	}

	public boolean isSubShowHg() {
		return subShowHg;
	}

	public void setSubShowHg(boolean subShowHg) {
		this.subShowHg = subShowHg;
	}

	public boolean isSubShowVat() {
		return subShowVat;
	}

	public void setSubShowVat(boolean subShowVat) {
		this.subShowVat = subShowVat;
	}

	public List<ShoppingGuideItemVO> getMsisdnObList() {
		return msisdnObList;
	}

	public void setMsisdnObList(List<ShoppingGuideItemVO> msisdnObList) {
		this.msisdnObList = msisdnObList;
	}

	public Map<String, List<ShoppingGuideItemVO>> getMpProds() {
		return mpProds;
	}

	public void setMpProds(Map<String, List<ShoppingGuideItemVO>> mpProds) {
		this.mpProds = mpProds;
	}

	public ShoppingGuideItemVO getAucMsisdn() {
		return aucMsisdn;
	}

	public void setAucMsisdn(ShoppingGuideItemVO aucMsisdn) {
		this.aucMsisdn = aucMsisdn;
	}

	public ShoppingGuideItemVO getAucPrice() {
		return aucPrice;
	}

	public void setAucPrice(ShoppingGuideItemVO aucPrice) {
		this.aucPrice = aucPrice;
	}
}
