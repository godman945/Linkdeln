package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

/**
 * 商品預設圖VO
 * @author Max Chen
 *
 */
public class ProductDefaultImageVO implements Serializable{

	private static final long serialVersionUID = 123883828999L;
	
	/** 商品編號 */
	private String fetNo;
	
	/** 圖檔路徑 */
	private String imagePath;
	
	/** 預設圖檔編號(e.g. 1 2 3 ... ) */
	private String defaultImage;

	/** 預設圖檔 */
	private String defaultImagePath;

	
	public String getFetNo() {
		return fetNo;
	}

	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getDefaultImagePath() {
		return defaultImagePath;
	}

	public void setDefaultImagePath(String defaultImagePath) {
		this.defaultImagePath = defaultImagePath;
	}

	public String getDefaultImage() {
		return defaultImage;
	}

	public void setDefaultImage(String defaultImage) {
		this.defaultImage = defaultImage;
	}
	
}
