package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CoMasterTwid;

/**
 * 訂單身分識別資料DAO
 * @author
 *
 */
public interface NCoMasterTwidDAO extends BaseDAO<CoMasterTwid, Long> {

    /**
     * 根據訂單編號取得最新的身分識別資料
     * @param cono
     * @return CoMasterTwid
     */
    public CoMasterTwid findLatestByCono(String cono);
}
