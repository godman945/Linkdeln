package com.fet.estore.core.bean.vo.frontend;

public class ProductVO {
	private String productId;
	private String prodTypeNo;
	private String clickurl;
	private String imagePath;
	private String aliasUrl;
	private String modelName;
	private String brand;
	private Long erpPrice;
	private String layoutId;
    private String fetNo;
    private Long discountPrice;
    private String imagePath2;
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProdTypeNo() {
		return prodTypeNo;
	}
	public void setProdTypeNo(String prodTypeNo) {
		this.prodTypeNo = prodTypeNo;
	}
	public String getClickurl() {
		return clickurl;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setClickurl(String clickurl) {
		this.clickurl = clickurl;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getAliasUrl() {
		return aliasUrl;
	}
	public void setAliasUrl(String aliasUrl) {
		this.aliasUrl = aliasUrl;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getBrand() {
		return brand;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	public String getLayoutId() {
		return layoutId;
	}
	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
    }
    public String getFetNo() {
        return fetNo;
    }
    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }
    public Long getDiscountPrice() {
        return discountPrice;
    }
    public void setDiscountPrice(Long discountPrice) {
        this.discountPrice = discountPrice;
	}
	public String getImagePath2() {
		return imagePath2;
	}
	public void setImagePath2(String imagePath2) {
		this.imagePath2 = imagePath2;
	}    
}
