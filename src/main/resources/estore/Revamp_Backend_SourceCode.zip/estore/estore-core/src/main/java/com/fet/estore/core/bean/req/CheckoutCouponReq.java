package com.fet.estore.core.bean.req;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-29
 * @description
 */
public class CheckoutCouponReq {

    private String couponSn;

    private String couponPwd;

    public String getCouponSn() {
        return couponSn;
    }
    public void setCouponSn(String couponSn) {
        this.couponSn = couponSn;
    }
    public String getCouponPwd() {
        return couponPwd;
    }
    public void setCouponPwd(String couponPwd) {
        this.couponPwd = couponPwd;
    }
}
