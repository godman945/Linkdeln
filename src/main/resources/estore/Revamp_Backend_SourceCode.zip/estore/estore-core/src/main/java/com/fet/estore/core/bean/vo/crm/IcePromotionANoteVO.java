package com.fet.estore.core.bean.vo.crm;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class IcePromotionANoteVO implements Serializable {
	
	private List<IcePromotionANote> icePromotionANotes = new ArrayList<IcePromotionANote>();
	
	private String masterPromoId;
	
	private String rcPromoId;
	
	private String rpPromoId;
	
	public void addIcePromotionANote(String masterPromotionId, String subPromotionId, String masterPromoitonANote,
			String masterPromotionActiANote, String subPromotionANote, String sbuPromotionActiAnote){
		IcePromotionANote icePromotionANote = new IcePromotionANote(masterPromotionId, subPromotionId, masterPromoitonANote,
				masterPromotionActiANote, subPromotionANote, sbuPromotionActiAnote);
		this.icePromotionANotes.add(icePromotionANote);
	}
	
	
	public String getANote(String promotionId){
		StringBuilder sb = new StringBuilder();
		boolean masterANoteRetrieved = false;
		for(IcePromotionANote icePromotionANote : this.icePromotionANotes){
			if(StringUtils.equals(promotionId, icePromotionANote.getMasterPromotionId()) && !masterANoteRetrieved){
				if(icePromotionANote.getMasterPromoitonANote() != null){
					sb.append(icePromotionANote.getMasterPromoitonANote());
				}
				
				if(icePromotionANote.getMasterPromotionActiANote() != null){
					if(sb.length() > 0){
						sb.append("\r\n");
					}
					sb.append(icePromotionANote.getMasterPromotionActiANote());
				}
				
				if(sb.length() > 0){
					masterANoteRetrieved = true;
				}
			}else if(StringUtils.equals(promotionId, icePromotionANote.getSubPromotionId())){
				if(icePromotionANote.getSubPromotionANote() != null){
					sb.append(icePromotionANote.getSubPromotionANote());
				}
				
				if(icePromotionANote.getSubPromotionActiAnote() != null){
					if(sb.length() > 0){
						sb.append("\r\n");
					}
					sb.append(icePromotionANote.getSubPromotionActiAnote());
				}
			}
		}
		
		if(sb.length() > 0){
			return sb.toString();
		}
		return null;
	}
	
	public Map<String, String> getAllANote(){
		Map<String, String> aNoteMap = new HashMap<String, String>();
		boolean masterANoteRetrieved = false;
		for(IcePromotionANote icePromotionANote : this.icePromotionANotes){
			String masterPromotionId = icePromotionANote.getMasterPromotionId();
			String subPromotionId = icePromotionANote.getSubPromotionId();
			
			
			if(!aNoteMap.containsKey(masterPromotionId) && !masterANoteRetrieved){
				aNoteMap.put(masterPromotionId, this.getANote(masterPromotionId));
				masterANoteRetrieved = true;
			}
			
			if(!aNoteMap.containsKey(subPromotionId)){
				aNoteMap.put(subPromotionId, this.getANote(subPromotionId));
			}
		}
		
		return aNoteMap;
	}
	
	
	
	
	public String getMasterPromoId() {
		return masterPromoId;
	}


	public void setMasterPromoId(String masterPromoId) {
		this.masterPromoId = masterPromoId;
	}


	public String getRcPromoId() {
		return rcPromoId;
	}


	public void setRcPromoId(String rcPromoId) {
		this.rcPromoId = rcPromoId;
	}


	public String getRpPromoId() {
		return rpPromoId;
	}


	public void setRpPromoId(String rpPromoId) {
		this.rpPromoId = rpPromoId;
	}




	class IcePromotionANote implements Serializable{
	
		public IcePromotionANote(String masterPromotionId, String subPromotionId, String masterPromoitonANote,
				String masterPromotionActiANote, String subPromotionANote, String subPromotionActiAnote) {
			super();
			this.masterPromotionId = masterPromotionId;
			this.subPromotionId = subPromotionId;
			this.masterPromoitonANote = masterPromoitonANote;
			this.masterPromotionActiANote = masterPromotionActiANote;
			this.subPromotionANote = subPromotionANote;
			this.subPromotionActiAnote = subPromotionActiAnote;
		}
		
		String masterPromotionId;
		String subPromotionId;
		String masterPromoitonANote;
		String masterPromotionActiANote;
		String subPromotionANote;
		String subPromotionActiAnote;
		
		public String getMasterPromotionId() {
			return masterPromotionId;
		}
		public void setMasterPromotionId(String masterPromotionId) {
			this.masterPromotionId = masterPromotionId;
		}
		public String getSubPromotionId() {
			return subPromotionId;
		}
		public void setSubPromotionId(String subPromotionId) {
			this.subPromotionId = subPromotionId;
		}
		public String getMasterPromoitonANote() {
			return masterPromoitonANote;
		}
		public void setMasterPromoitonANote(String masterPromoitonANote) {
			this.masterPromoitonANote = masterPromoitonANote;
		}
		public String getMasterPromotionActiANote() {
			return masterPromotionActiANote;
		}
		public void setMasterPromotionActiANote(String masterPromotionActiANote) {
			this.masterPromotionActiANote = masterPromotionActiANote;
		}
		public String getSubPromotionANote() {
			return subPromotionANote;
		}
		public void setSubPromotionANote(String subPromotionANote) {
			this.subPromotionANote = subPromotionANote;
		}
		public String getSubPromotionActiAnote() {
			return subPromotionActiAnote;
		}
		public void setSubPromotionActiAnote(String subPromotionActiAnote) {
			this.subPromotionActiAnote = subPromotionActiAnote;
		}
	}

	
}
