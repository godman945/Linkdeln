package com.fet.estore.core.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fet.estore.core.bean.bo.ActivityPromoBO;
import com.fet.estore.core.bean.bo.FindProductBO;
import com.fet.estore.core.bean.bo.LyPromoBO;
import com.fet.estore.core.bean.po.PromotionPO;
import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.enums.OrderTypeEnum;
import com.fet.estore.core.model.OnsalePromoList;

/**
 * @author Dennis.Chen
 * @Date 2020-08-19
 */
public interface IOnsalePromotListDao extends BaseDAO<OnsalePromoList, String> {

    /**
     * @description 取得搭配商品促案
     * 1. 檢查該促案是否上架 OPL.ONSALE=Y，是否簽核通過OPL.SIGN4ONSALE=Y
     * 2. 不可為多主商品促案 OPL.IS_MULTIPROD=N or null
     * 3. 須為User設定的上架時間區間內 OPL.ONSALE_DATE、OPL.OFF_DATE
     * 4. 須為ICE設定的上架時間區間內 PL.BEGINDATE、PL.ENDDATE
     * 5. 販售類型 SALE_TYPE 須符合設定，參考OrderTypeEnum.SaleType
     * 6. OPL.V_VOICEGROUP(語音群組)不得為空
     * 7. GA、NP時, 語音不得為空
     * 8. 依據GA、NP流程判斷PL的設定(EX. GA時 -> PL.IS_POS4G=Y OR PL.IS_POS5G=Y)
     * 9. 判斷可遞送產品的方式 OPL.IS_HOME_DELIVERABLE、OPL.IS_STORE_DELIVERABLE
     * 10. 方案期數 PL.LIMIT、PL.DATA_LIMIT兩者取最大值
     * 11. 推薦資費Flag 需 IS_RECOMMEND == 1 且 在推薦期間內
     * 12. RECOMMEND_SORT 需 IS_RECOMMEND == 1 且 在推薦期間內，否則為null
     * @param orderType 訂單流程(NC、NH、PC、PH)
     * @param fetNo 產品料號
     * @param deliveryType 遞送方式
     * @param LyPromo 續約情境下撈促案所需資料
     * @param activityPromoBO 活動相關設定(是否為一般賣場、是否為EBU賣場、活動賣場可申辦之促案清單)
     * @return List<PromotionPO>
     * @author Dennis.Chen
     * @Date 2020-08-19
     */
    public List<PromotionPO> getProductPromo(OrderTypeEnum orderType, String fetNo, Map<String, Boolean> deliveryType, LyPromoBO LyPromo, ActivityPromoBO activityPromoBO);

    /**
     * @description 取得單門號促案
     * @author Roil.Li
     * @Date 2020-09-10
     */
    public List<PromotionPO> getPromotions(OrderTypeEnum orderType, LyPromoBO LyPromo, ActivityPromoBO activityPromoBO);
    
    /**
     *  取得 OnsalePromList Table 中的 資料
     * 
     * @description
     * @author Phil.lin
     * @date 2020-10-21
     * @param pcode
     * @param outputColumns
     * @return
     */
	public Map<String, String> getOnsalePromoListDataByPcode(String pcode, List<String> outputColumns);

    /**
     * 取得促案限定料號
     * @param oplIds
     * @return
     */
    public Map<String, Set<String>> findPromoProdMap(List<String> oplIds);

    /**
     * 取得商品關聯促案(可查多個商品)
     * @param fetNos
     * @param findProductBO
     * @return
     */
    public List<PromotionPO> getProductsRelatedPromo(List<String> fetNos, FindProductBO findProductBO, ActivityPromoBO activityPromoBO);
    
}
