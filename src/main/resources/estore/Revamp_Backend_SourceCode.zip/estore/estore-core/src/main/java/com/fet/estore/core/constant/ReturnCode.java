package com.fet.estore.core.constant;

/**
 * @description API Return Code
 * @author Dennis.Chen
 * @date 20200831
 */
public class ReturnCode {

    public static final String RTN_CODE_SUCCESS = "00000";
    public static final String RTN_CODE_MANDATORY_FIELD = "10001";
    public static final String RTN_CODE_DATA_NOT_FOUND = "10002";
    public static final String RTN_CODE_CAN_NOT_FOUND_PAY_TYPE = "10003";
    public static final String RTN_CODE_UNEXPECT_ERROR = "20001";
    public static final String RTN_CODE_FLOW_VALIDATE_FAIL = "20002";
    public static final String RTN_CODE_ORDER_UUID_MISMATCH = "20003";


    public static final String RTN_MSG_SUCCESS = "SUCCESS";
    public static final String RTN_MSG_MANDATORY_FIELD = "Mandatory Field";
    public static final String RTN_MSG_DATA_NOT_FOUND = "Data Not Found";
    public static final String RTN_MSG_CAN_NOT_FOUND_PAY_TYPE = "很抱歉! 目前無法提供您所選擇的取貨方式! 請重新選擇或電洽客服, 謝謝";
    public static final String RTN_MSG_UNEXPECT_ERROR = "非預期錯誤";
    public static final String RTN_MSG_ORDER_UUID_MISMATCH = "訂單資訊已變更, 為確保購物安全, 請您回首頁重新選購, 謝謝!";
}
