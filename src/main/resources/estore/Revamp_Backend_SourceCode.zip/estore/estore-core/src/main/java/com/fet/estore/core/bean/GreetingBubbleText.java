package com.fet.estore.core.bean;

import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-16
 * @description
 */
public class GreetingBubbleText {

    private Greeting.Type type;

    private String text;

    public Greeting.Type getType() {
        return type;
    }

    public void setType(Greeting.Type type) {
        this.type = type;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
