package com.fet.estore.core.bean.vo.frontend;

import java.util.List;

public class AAEcommerceVO {
    /** Adobe Analytics 需求使用的物件 -- 結帳頁面和結帳完成頁面用 */

    /** 訂單編號 */
    private String transactionID;

    /** 商店別 */
    private String store;

    /** 申辦流程 */
    private String orderType;

    /** 申辦流程 */
    private String deliveryMethod;

    /** 付款方式 */
    private String payMethod;

    /** 商品項目資料 */
    private List<AAProductVO> product;

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getPayMethod() {
        return payMethod;
    }

    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }

    public List<AAProductVO> getProduct() {
        return product;
    }

    public void setProduct(List<AAProductVO> product) {
        this.product = product;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    @Override
    public String toString() {
        return "AAEcommerceVO{" +
                "transactionID='" + transactionID + '\'' +
                ", store='" + store + '\'' +
                ", orderType='" + orderType + '\'' +
                ", deliveryMethod='" + deliveryMethod + '\'' +
                ", payMethod='" + payMethod + '\'' +
                ", product=" + product +
                '}';
    }
}
