package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.List;

public class PlusGiftVO {
	
	private String name;
	private String imagePath;
	private String meta;
	private String erpPrice;
	private String discountPrice;
	private String fetno;
	private String apId;
	private String maxAmount;
	private String productId;
	private List<String> descList = new ArrayList<>();
	private String prodTypeNo;
	private String defaultImage;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(String erpPrice) {
		this.erpPrice = erpPrice;
	}
	public String getDiscountPrice() {
		return discountPrice;
	}
	public void setDiscountPrice(String discountPrice) {
		this.discountPrice = discountPrice;
	}
	public String getFetno() {
		return fetno;
	}
	public void setFetno(String fetno) {
		this.fetno = fetno;
	}
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public List<String> getDescList() {
		return descList;
	}
	public void setDescList(List<String> descList) {
		this.descList = descList;
	}
	public String getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(String maxAmount) {
		this.maxAmount = maxAmount;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getMeta() {
		return meta;
	}
	public void setMeta(String meta) {
		this.meta = meta;
	}
	public String getProdTypeNo() {
		return prodTypeNo;
	}
	public void setProdTypeNo(String prodTypeNo) {
		this.prodTypeNo = prodTypeNo;
	}
	public String getDefaultImage() {
		return defaultImage;
	}
	public void setDefaultImage(String defaultImage) {
		this.defaultImage = defaultImage;
	}
	
}
