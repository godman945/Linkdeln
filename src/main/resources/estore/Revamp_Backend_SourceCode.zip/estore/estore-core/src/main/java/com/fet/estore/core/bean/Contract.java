package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class Contract implements Serializable  {

    private static final long serialVersionUID = 1L;

    /** 結帳頁 -- 合約標題 */
    private String title;
    /** 結帳頁 -- 合約內容 */
    private List<String> content;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getContent() {
        return content;
    }

    public void setContent(List<String> content) {
        this.content = content;
    }
}
