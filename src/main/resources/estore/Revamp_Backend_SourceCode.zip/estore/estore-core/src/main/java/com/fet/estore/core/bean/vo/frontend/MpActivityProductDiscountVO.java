package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.bean.vo.IDiscountItem;

/**
 * 加價購活動折扣VO
 * @author Max Chen
 *
 */
public class MpActivityProductDiscountVO implements IDiscountItem {
	private Long id;
	private Long actId;
	private String discountType;
	private Long discountAmount;
	private String discountCode;
	private Double discountRatio;
	private Long costCenterId;
	private String discountName;
	private Long markupAmount;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDiscountType() {
		return discountType;
	}
	public void setDiscountType(String discountType) {
		this.discountType = discountType;
	}
	public Long getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(Long discountAmount) {
		this.discountAmount = discountAmount;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public Double getDiscountRatio() {
		return discountRatio;
	}
	public void setDiscountRatio(Double discountRatio) {
		this.discountRatio = discountRatio;
	}
	public Long getCostCenterId() {
		return costCenterId;
	}
	public void setCostCenterId(Long costCenterId) {
		this.costCenterId = costCenterId;
	}
	public Long getActId() {
		return actId;
	}
	public void setActId(Long actId) {
		this.actId = actId;
	}
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}
	public Long getMarkupAmount() {
		return markupAmount;
	}
	public void setMarkupAmount(Long markupAmount) {
		this.markupAmount = markupAmount;
	}

	@Override
	public Long getAaiId() {
		return null;
	}
	@Override
	public String getCode() {
		return discountCode;
	}
	@Override
	public String getFetNo() {
		return null;
	}
	@Override
	public Long getActivityId() {
		return actId;
	}
	@Override
	public String getName() {
		return discountName;
	}
	@Override
	public Long getAmount() {
		return discountAmount;
	}
	@Override
	public Long getCouponId() {
		return null;
	}
	@Override
	public Long getOfferId() {
		return null;
	}
	@Override
	public Long getActualDiscountAmt() {
		return null;
	}
	@Override
	public String getDisplayGroup() {
		return null;
	}
}
