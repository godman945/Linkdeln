package com.fet.estore.core.bean.vo;

import java.io.Serializable;

public class CheckCustomerDataInput implements Serializable{
	
	private static final long serialVersionUID = 1244337096830492553L;
	private String rocId;
	private String msisdn;
	private String accountId;
	private String subcriberId;
	private String promotionType;
	private String functionId;
	private String promoType;
	private String voicePromotionId;
	private String dataPromotionId;
	public String getRocId() {
		return rocId;
	}
	public void setRocId(String rocId) {
		this.rocId = rocId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getSubcriberId() {
		return subcriberId;
	}
	public void setSubcriberId(String subcriberId) {
		this.subcriberId = subcriberId;
	}
	public String getPromotionType() {
		return promotionType;
	}
	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}
	public String getFunctionId() {
		return functionId;
	}
	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}
	public String getPromoType() {
		return promoType;
	}
	public void setPromoType(String promoType) {
		this.promoType = promoType;
	}
	public String getVoicePromotionId() {
		return voicePromotionId;
	}
	public void setVoicePromotionId(String voicePromotionId) {
		this.voicePromotionId = voicePromotionId;
	}
	public String getDataPromotionId() {
		return dataPromotionId;
	}
	public void setDataPromotionId(String dataPromotionId) {
		this.dataPromotionId = dataPromotionId;
	}

}
