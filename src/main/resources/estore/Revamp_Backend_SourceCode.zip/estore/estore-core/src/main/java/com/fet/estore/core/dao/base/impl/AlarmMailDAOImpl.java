package com.fet.estore.core.dao.base.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.AlarmMailDAO;
import com.fet.estore.core.model.AlarmMail;

@Repository
public class AlarmMailDAOImpl extends AbstractBaseDAO<AlarmMail, Long> implements AlarmMailDAO {
	
	public AlarmMail findAlarmMailByName(String name){
		
		Query query = this.getSessionFactory().getCurrentSession().createQuery("from AlarmMail a where a.alarmName = :alarmName");
		query.setParameter("alarmName", name);
		List<AlarmMail> alarmMails = query.list();
		if(alarmMails.size() > 0 ) {
			return alarmMails.get(0);
		}
		
		return null;
	}

}
