package com.fet.estore.core.bean.po;

/**
 * @author Dennis.Chen
 * @Date 2020-10-22
 */
public class ActivityTargetPromoPO {

    String targetId;
    Long displayOrder;

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public Long getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder;
    }
}
