package com.fet.estore.core.dao;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.LogOtp;

public interface ILogOtpDAO extends BaseDAO<LogOtp, String> {

}
