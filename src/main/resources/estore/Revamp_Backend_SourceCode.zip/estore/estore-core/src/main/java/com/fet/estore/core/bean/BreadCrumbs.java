package com.fet.estore.core.bean;

import java.io.Serializable;

public class BreadCrumbs implements Serializable{
	
	private static final long serialVersionUID = 3166589614135746974L;
	String text;
	String link;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
	
}
