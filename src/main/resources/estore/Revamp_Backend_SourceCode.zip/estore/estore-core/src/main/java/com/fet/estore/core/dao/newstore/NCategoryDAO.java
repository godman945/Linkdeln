package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AccessoryCategory;
import com.fet.estore.core.model.Category;
import com.fet.estore.core.model.CategoryHandset;

public interface NCategoryDAO extends BaseDAO<Category, Long> {

	/**
	 * 查詢配件商品分類.
	 * @return List<AccessoryCategory>
	 */	
	public List<AccessoryCategory> findProductCategoryList4Accessory();

	/**
	 * 取得對應的Category mapping
	 * @return
	 */
	public List<CategoryHandset> findCategoryForProductIds(String[] fetNos);
}
