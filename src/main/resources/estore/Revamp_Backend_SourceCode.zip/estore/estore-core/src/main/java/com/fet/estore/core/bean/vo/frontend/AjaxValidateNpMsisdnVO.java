package com.fet.estore.core.bean.vo.frontend;

public class AjaxValidateNpMsisdnVO {
    private String mdnErrMsg;
    private String couponErrMsg;
    private String captchaErrMsg;

    public String getCouponErrMsg()                      { return couponErrMsg; }
    public void   setCouponErrMsg(String couponErrMsg)   { this.couponErrMsg = couponErrMsg; }
    public String getCaptchaErrMsg()                     { return captchaErrMsg; }
    public void   setCaptchaErrMsg(String captchaErrMsg) { this.captchaErrMsg = captchaErrMsg; }
    public String getMdnErrMsg()                         { return mdnErrMsg; }
    public void   setMdnErrMsg(String mdnErrMsg)         { this.mdnErrMsg = mdnErrMsg; }
}
