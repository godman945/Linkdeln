package com.fet.estore.core.dao.base.impl;

import java.util.Calendar;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.TxidDAO;
import com.fet.estore.core.model.Txid;
@Repository
public class TxidDAOImpl extends AbstractBaseDAO<Txid, String> implements TxidDAO {

	public Txid findByTxid(String txid){
		
		Query query = this.getSessionFactory().getCurrentSession().createQuery("from Txid t where t.txid = :txid");
		query.setParameter("txid", txid);
		
		List<Txid> results = query.list();
		if(results.size() > 0)
			return results.get(0);
		
		return null;
	}
	
	
	public List<Txid> findUnhandleTxid(){
		String hql = "from Txid t where t.txid is not null and  ((t.status = 'I' and t.createTime + (1/24) > t.modifyTime) or (t.status is null)) and t.createTime > :createTime";
		Query query = this.getSessionFactory().getCurrentSession().createQuery(hql);
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 2018);
		calendar.set(Calendar.MONTH, 11);
		calendar.set(Calendar.DATE, 4);
		query.setParameter("createTime", calendar.getTime());
		return query.list();
	}
	
	
	/**
	 * 當退款狀態未達D（退款成功）或F（退款失敗）時，持續向ipay問狀態。I:退款受理中
	 * @return
	 */
	public List<Txid> findUnhandleRefundTxid(){
		String hql = "from Txid t where t.refund = :refund and (t.refundStatus is null or t.refundStatus = 'I') and t.createTime > :createTime";
		Query query = this.getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter("refund", Boolean.TRUE);
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 2018);
		calendar.set(Calendar.MONTH, 11);
		calendar.set(Calendar.DATE, 4);
		query.setParameter("createTime", calendar.getTime());
		return query.list();
	}

}
