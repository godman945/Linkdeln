package com.fet.estore.core.dao.base.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.OcrRecordDAO;
import com.fet.estore.core.model.OcrRecord;

@Repository
public class OcrRecordDAOImpl extends AbstractBaseDAO<OcrRecord, Long> implements OcrRecordDAO {
	
	public List<OcrRecord> findByOcrSn(String ocrSn){
		
		Query query = this.getSessionFactory().getCurrentSession().createQuery("from OcrRecord where ocrSn = :ocrSn ");
		query.setParameter("ocrSn", ocrSn);
		List<OcrRecord> ocrRecords = query.list();
		
		return ocrRecords;
	}

}
