package com.fet.estore.core.dao.base.impl;

import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.OcrFailDAO;
import com.fet.estore.core.model.OcrFail;

@Repository
public class OcrFailDAOImpl extends AbstractBaseDAO<OcrFail, Long> implements OcrFailDAO {

}
