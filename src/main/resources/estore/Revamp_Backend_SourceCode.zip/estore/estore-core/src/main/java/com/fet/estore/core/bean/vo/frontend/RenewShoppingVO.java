package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fet.estore.core.model.ContentOffer;
import com.fet.estore.core.model.RefBrand;
import com.fet.estore.core.model.support.Page;

public class RenewShoppingVO {
	
	public static class SearchVO extends RenewShoppingBaseVO {
		private Map<String, String> cats = new LinkedHashMap<>();
		private Map<String, String> ranges = new LinkedHashMap<>();
		private Map<String, String> brands = new LinkedHashMap<>();
		private List<RefBrand> refBrands;
		private Map<String, String> prodSorts = new LinkedHashMap<>();
		
		private Map<String, String> promos     = new LinkedHashMap<>();
		private Map<String, String> insts      = new LinkedHashMap<>();
		private Map<String, String> promoTypes = new LinkedHashMap<>();
		private Map<String, String> promoSorts = new LinkedHashMap<>();
		
		public void addCat(String k, String v) { cats.put(k, v); }
		public void addRange(String k, String v) { ranges.put(k, v); }
		public void addBrand(String k, String v) { brands.put(k, v); }
		public void setBrand(List<RefBrand> brands) { refBrands = brands; }
		public void addProdSort(String k, String v) { prodSorts.put(k, v); }
		
		public void addPromo(String k, String v) { promos.put(k, v); }
		public void addInst(String k, String v) { insts.put(k, v); }
		public void addPromoType(String k, String v) { promoTypes.put(k, v); }		
		public void addPromoSort(String k, String v) { promoSorts.put(k, v); }
		
		public Map<String, String> getCats() {
			return cats;
		}
		public void setCats(Map<String, String> cats) {
			this.cats = cats;
		}
		public Map<String, String> getRanges() {
			return ranges;
		}
		public void setRanges(Map<String, String> ranges) {
			this.ranges = ranges;
		}
		public Map<String, String> getBrands() {
			return brands;
		}
		public void setBrands(Map<String, String> brands) {
			this.brands = brands;
		}
		public Map<String, String> getInsts() {
			return insts;
		}
		public void setInsts(Map<String, String> insts) {
			this.insts = insts;
		}
		public Map<String, String> getPromos() {
			return promos;
		}
		public void setPromos(Map<String, String> promos) {
			this.promos = promos;
		}
		public Map<String, String> getPromoTypes() {
			return promoTypes;
		}
		public void setPromoTypes(Map<String, String> promoTypes) {
			this.promoTypes = promoTypes;
		}
		public Map<String, String> getPromoSorts() {
			return promoSorts;
		}
		public void setPromoSorts(Map<String, String> promoSorts) {
			this.promoSorts = promoSorts;
		}
		public Map<String, String> getProdSorts() {
			return prodSorts;
		}
		public void setProdSorts(Map<String, String> prodSorts) {
			this.prodSorts = prodSorts;
		}
		public List<RefBrand> getRefBrands() {
			return refBrands;
		}
		public void setRefBrands(List<RefBrand> refBrands) {
			this.refBrands = refBrands;
		}
	}
	
	public static class ProductsVO extends RenewShoppingBaseVO {
		private Page<ProductVO> page = new Page<>();
		
		public void setResult(List<ProductVO> result) { page.setResult(result); }
		public void setTotalCount(Long totalCount) { page.setTotalCount(totalCount); }
		public void setPageSize(Integer pageSize) { page.setPageSize(pageSize); }
		public void setCurrentIndex(Long currentIndex) { page.setCurrentIndex(currentIndex); }
		public Page<ProductVO> getPage() {
			return page;
		}
	}
	
	public static class ProductVO {
		private String name;
		private String productId;
		private Long origPrice;
		private Long discPrice;
		private String image;
		private List<String> viewDescs = new ArrayList<>();
		private List<String> images = new ArrayList<>();
		private List<String> icons = new ArrayList<>();
		
		public void addImage(String image) { images.add(image); }
		public void addIcon(String icon) { icons.add(icon); }
		public void addViewDesc(String viewDesc) { viewDescs.add(viewDesc); }

		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Long getOrigPrice() {
			return origPrice;
		}
		public void setOrigPrice(Long origPrice) {
			this.origPrice = origPrice;
		}
		public Long getDiscPrice() {
			return discPrice;
		}
		public void setDiscPrice(Long discPrice) {
			this.discPrice = discPrice;
		}
		public List<String> getViewDescs() {
			return viewDescs;
		}
		public void setViewDescs(List<String> viewDescs) {
			this.viewDescs = viewDescs;
		}
		public List<String> getImages() {
			return images;
		}
		public void setImages(List<String> images) {
			this.images = images;
		}
		public List<String> getIcons() {
			return icons;
		}
		public void setIcons(List<String> icons) {
			this.icons = icons;
		}
		public String getProductId() {
			return productId;
		}
		public void setProductId(String productId) {
			this.productId = productId;
		}
	}
	
	public static class PromosVO extends RenewShoppingBaseVO {
		private int showIdx = -1;
		private boolean hasMore = false;
		private boolean fixShowIdx = false;
		private List<PromoVO> list = new ArrayList<>();

		public void addPromo(PromoVO vo) { list.add(vo); }
		
		public int getShowIdx() {
			return showIdx;
		}
		public void setShowIdx(int showIdx) {
			this.showIdx = showIdx;
		}
		public List<PromoVO> getList() {
			return list;
		}
		public void setList(List<PromoVO> list) {
			this.list = list;
		}
		public boolean isHasMore() {
			return hasMore;
		}
		public void setHasMore(boolean hasMore) {
			this.hasMore = hasMore;
		}

		public boolean isFixShowIdx() {
			return fixShowIdx;
		}

		public void setFixShowIdx(boolean fixShowIdx) {
			this.fixShowIdx = fixShowIdx;
		}
		
		
	}
	
	public static class PromoVO {
		private String  onsalePromoListId;
		private boolean isRecommend      ;
		private String  recommendDesc    ;
		private Integer limit            ;
		private Long    monthPrice       ;
		private Long    prepaidPrice     ;
		private String  dataUsageAmount  ;
		private String  speedDesc        ;
		private String  voicePremium     ;//語音優惠(= voicePremium1 + voicePremium2 + voicePremium3 + voicePremium4)
	    private String  voicePremium1    ;//網內語音優惠
	    private String  voicePremium2    ;//網外語音優惠
	    private String  voicePremium3    ;//市話語音優惠
	    private String  voicePremium4    ;//空白
		private String  otherPremium     ;
		private Date    onsaleDate       ;
		private String  promotionListId  ;
		private Long    posPrice         ;
		private Long    discPrice        ;
		private String  upgradeType      ;
		private Boolean noLimit			 ;//是否吃到飽
		private String  otherDesc        ;//其它說明
		private Integer prepaymentPrice  ;//Omin後,新申和續約用這個金額
		private Boolean exclusive		 ;//是否獨家
		private String  bubbleText       ;
		private Boolean isCheckOnceContract9M;//是否要驗證九個月一證一號
		private List<ContentOffer> contentOffers; // C約清單 added by Roil.Li 2020/03/30

		public String getOnsalePromoListId() {
			return onsalePromoListId;
		}
		public void setOnsalePromoListId(String onsalePromoListId) {
			this.onsalePromoListId = onsalePromoListId;
		}
		public boolean isRecommend() {
			return isRecommend;
		}
		public void setRecommend(boolean isRecommend) {
			this.isRecommend = isRecommend;
		}
		public String getRecommendDesc() {
			return recommendDesc;
		}
		public void setRecommendDesc(String recommendDesc) {
			this.recommendDesc = recommendDesc;
		}
		public Integer getLimit() {
			return limit;
		}
		public void setLimit(Integer limit) {
			this.limit = limit;
		}
		public Long getMonthPrice() {
			return monthPrice;
		}
		public void setMonthPrice(Long monthPrice) {
			this.monthPrice = monthPrice;
		}
		public Long getPrepaidPrice() {
			return prepaidPrice;
		}
		public void setPrepaidPrice(Long prepaidPrice) {
			this.prepaidPrice = prepaidPrice;
		}
		public String getDataUsageAmount() {
			return dataUsageAmount;
		}
		public void setDataUsageAmount(String dataUsageAmount) {
			this.dataUsageAmount = dataUsageAmount;
		}
		public String getSpeedDesc() {
			return speedDesc;
		}
		public void setSpeedDesc(String speedDesc) {
			this.speedDesc = speedDesc;
		}
		public String getVoicePremium() {
			return voicePremium;
		}
		public void setVoicePremium(String voicePremium) {
			this.voicePremium = voicePremium;
		}
		public String getOtherPremium() {
			return otherPremium;
		}
		public void setOtherPremium(String otherPremium) {
			this.otherPremium = otherPremium;
		}
		public Date getOnsaleDate() {
			return onsaleDate;
		}
		public void setOnsaleDate(Date onsaleDate) {
			this.onsaleDate = onsaleDate;
		}
		public String getPromotionListId() {
			return promotionListId;
		}
		public void setPromotionListId(String promotionListId) {
			this.promotionListId = promotionListId;
		}
		public Long getPosPrice() {
			return posPrice;
		}
		public void setPosPrice(Long posPrice) {
			this.posPrice = posPrice;
		}
		public String getUpgradeType() {
			return upgradeType;
		}
		public void setUpgradeType(String upgradeType) {
			this.upgradeType = upgradeType;
		}
		public Long getDiscPrice() {
			return discPrice;
		}
		public void setDiscPrice(Long discPrice) {
			this.discPrice = discPrice;
		}
		public Boolean getNoLimit() {
			return noLimit;
		}
		public void setNoLimit(Boolean noLimit) {
			this.noLimit = noLimit;
		}
		public String getOtherDesc() {
			return otherDesc;
		}
		public void setOtherDesc(String otherDesc) {
			this.otherDesc = otherDesc;
		}
		public Integer getPrepaymentPrice() {
			return prepaymentPrice;
		}
		public void setPrepaymentPrice(Integer prepaymentPrice) {
			this.prepaymentPrice = prepaymentPrice;
		}
		public Boolean getExclusive() {
			return exclusive;
		}
		public void setExclusive(Boolean exclusive) {
			this.exclusive = exclusive;
		}
		public String getVoicePremium1() {
			return voicePremium1;
		}
		public void setVoicePremium1(String voicePremium1) {
			this.voicePremium1 = voicePremium1;
		}
		public String getVoicePremium2() {
			return voicePremium2;
		}
		public void setVoicePremium2(String voicePremium2) {
			this.voicePremium2 = voicePremium2;
		}
		public String getVoicePremium3() {
			return voicePremium3;
		}
		public void setVoicePremium3(String voicePremium3) {
			this.voicePremium3 = voicePremium3;
		}
		public String getVoicePremium4() {
			return voicePremium4;
		}
		public void setVoicePremium4(String voicePremium4) {
			this.voicePremium4 = voicePremium4;
		}
		public String getBubbleText() {
			return bubbleText;
		}
		public void setBubbleText(String bubbleText) {
			this.bubbleText = bubbleText;
		}
		public Boolean getIsCheckOnceContract9M() {
			return isCheckOnceContract9M;
		}
		public void setIsCheckOnceContract9M(Boolean isCheckOnceContract9M) {
			this.isCheckOnceContract9M = isCheckOnceContract9M;
		}
		public List<ContentOffer> getContentOffers() {
			return contentOffers;
		}
		public void setContentOffers(List<ContentOffer> contentOffers) {
			this.contentOffers = contentOffers;
		}
	}
	
	public static class PromoWithContractComparator implements Comparator<PromoVO> {
		private long currentPromoPrice;
		
		public PromoWithContractComparator(long currentPromoPrice) {
			this.currentPromoPrice = currentPromoPrice;
		}

		@Override
		public int compare(PromoVO p1, PromoVO p2) {
			boolean rec1 = false;
			boolean rec2 = false;
			Long prc1 = null;
			Long prc2 = null;
			
			if(p1 != null) { rec1 = Boolean.TRUE.equals(p1.isRecommend()); prc1 = p1.getMonthPrice() != null ? p1.getMonthPrice() : 0L; }
			if(p2 != null) { rec2 = Boolean.TRUE.equals(p2.isRecommend()); prc2 = p2.getMonthPrice() != null ? p2.getMonthPrice() : 0L; }
			
			String r1 = String.format("%s%s%06d", rec1 ? "a" : "b", prc1 != null && prc1.equals(currentPromoPrice) ? "a" : "b", prc1);
			String r2 = String.format("%s%s%06d", rec2 ? "a" : "b", prc1 != null && prc1.equals(currentPromoPrice) ? "a" : "b", prc2);

			//System.out.println(String.format("%s -> %s", r1, r2));
			return r1.compareTo(r2);
		}
		
	}
	
	public static class PromoWithoutContractComparator implements Comparator<PromoVO> {
		@Override
		public int compare(PromoVO p1, PromoVO p2) {
			boolean rec1 = false;
			boolean rec2 = false;
			boolean exclusiveP1 = false;
			boolean exclusiveP2 = false;
			Long prc1 = null;
			Long prc2 = null;
			
			if(p1 != null) { rec1 = Boolean.TRUE.equals(p1.isRecommend()); exclusiveP1 = Boolean.TRUE.equals(p1.getExclusive()); prc1 = p1.getMonthPrice() != null ? p1.getMonthPrice() : 0L; }
			if(p2 != null) { rec2 = Boolean.TRUE.equals(p2.isRecommend()); exclusiveP2 = Boolean.TRUE.equals(p2.getExclusive()); prc2 = p2.getMonthPrice() != null ? p2.getMonthPrice() : 0L; }
			
			//推薦aap1,aap2,aap3......
			//非推薦,獨家bap1,bap2,bap3......
			//非獨家,非推薦bb1,bb2,bb3......
			String r1 = String.format("%s%06d", rec1 ? "aa" : (exclusiveP1 ? "ba" : "bb") , prc1);
			String r2 = String.format("%s%06d", rec2 ? "aa" : (exclusiveP2 ? "ba" : "bb"), prc2);

			//System.out.println(String.format("%s -> %s", r1, r2));
			return r1.compareTo(r2);
		}
		
	}
	

	private String tab;
	private Map<String, String> tabs = new LinkedHashMap<>();
	private Page<ProductVO> prods = new Page<>();
	
	public String getTab() {
		return tab;
	}
	public void setTab(String tab) {
		this.tab = tab;
	}
	public Map<String, String> getTabs() {
		return tabs;
	}
	public void setTabs(Map<String, String> tabs) {
		this.tabs = tabs;
	}
	public Page<ProductVO> getProds() {
		return prods;
	}
	public void setProds(Page<ProductVO> prods) {
		this.prods = prods;
	}
}
