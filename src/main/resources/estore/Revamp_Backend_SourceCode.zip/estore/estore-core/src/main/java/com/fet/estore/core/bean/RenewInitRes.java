package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class RenewInitRes implements Serializable {

	private static final long serialVersionUID = -9171181503672888076L;

	/** 廠牌下拉選單 */
	private BrandList brandList;
	/** 麵包屑資訊 */
	private List<BreadCrumbs> breadcrumbs;
	/** 續約館基本資料 */
	private CurrentPlan currentPlan;
	/** 原門號手機世代 */
	private String lyMobileGeneration;
	
	public BrandList getBrandList() {
		return brandList;
	}

	public void setBrandList(BrandList brandList) {
		this.brandList = brandList;
	}

	public List<BreadCrumbs> getBreadcrumbs() {
		return breadcrumbs;
	}

	public void setBreadcrumbs(List<BreadCrumbs> breadcrumbs) {
		this.breadcrumbs = breadcrumbs;
	}

	public CurrentPlan getCurrentPlan() {
		return currentPlan;
	}

	public void setCurrentPlan(CurrentPlan currentPlan) {
		this.currentPlan = currentPlan;
	}

	public String getLyMobileGeneration() {
		return lyMobileGeneration;
	}

	public void setLyMobileGeneration(String lyMobileGeneration) {
		this.lyMobileGeneration = lyMobileGeneration;
	}
	
}
