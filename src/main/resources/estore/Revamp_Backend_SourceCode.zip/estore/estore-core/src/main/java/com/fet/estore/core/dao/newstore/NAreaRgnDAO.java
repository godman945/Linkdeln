package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AreaRgn;
import com.fet.estore.core.bean.vo.frontend.mobile.AreaRgnVO;

/**
 * 鄉鎮市區DAO
 * @author Max Chen
 *
 */
public interface NAreaRgnDAO extends BaseDAO<AreaRgn, String>  {

	/**
	 * 依郵遞區號取得鄉鎮市區(3碼; 但新竹市/台南市為5碼)
	 * @return
	 */
	public AreaRgn findTownByCode(String rgnCode);

}
