package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

/**
 * 商品明細頁 - 提醒資訊內容
 *
 * @description
 * @author Ted.Hsieh
 * @date 2020-08-14
 */

public class NoticeContent implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 提醒資訊Modal標題 */
    private String title;
    /** 提醒資訊Modal內容 */
    private List<String> content;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getContent() {
        return content;
    }

    public void setContent(List<String> content) {
        this.content = content;
    }
}
