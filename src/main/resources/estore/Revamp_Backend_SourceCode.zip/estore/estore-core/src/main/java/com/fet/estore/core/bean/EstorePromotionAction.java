package com.fet.estore.core.bean;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-15
 * @description
 */
public class EstorePromotionAction {

    private String text;

    private String link;

    private String target;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }
}
