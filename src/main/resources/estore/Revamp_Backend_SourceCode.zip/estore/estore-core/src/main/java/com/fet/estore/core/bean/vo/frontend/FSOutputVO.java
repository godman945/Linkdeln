package com.fet.estore.core.bean.vo.frontend;

public class FSOutputVO {
	private String returnCode;
	private String returnMessage;
	private byte[] returnValue;
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	public byte[] getReturnValue() {
		return returnValue;
	}
	public void setReturnValue(byte[] returnValue) {
		this.returnValue = returnValue;
	}
}
