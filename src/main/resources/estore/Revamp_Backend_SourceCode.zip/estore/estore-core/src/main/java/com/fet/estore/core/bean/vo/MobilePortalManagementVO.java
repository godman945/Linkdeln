package com.fet.estore.core.bean.vo;

import java.io.Serializable;

import com.fet.estore.core.model.Activity;

public class MobilePortalManagementVO implements Serializable{
    private static final long serialVersionUID = 3361872632576521773L;
    
    /**
     * 活動ID
     */
    private Long activityId;
    private Activity activity;
    
    /**
     * MobilePortalActivity 的ID
     */
    private Long mpaId;
    /**
     * 活動標題
     */
    private String title;
    /**
     * 活動期間 start
     */
    private String startDate;
    /**
     * 活動期間 end
     */
    private String endDate;
    /**
     * 露出
     */
    private boolean exposure;
    /**
     * 置頂
     */
    private boolean top;
    
    public Activity getActivity() {
        return activity;
    }
    public void setActivity(Activity activity) {
        this.activity = activity;
    }
    public Long getActivityId() {
        return activityId;
    }
    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    public boolean isExposure() {
        return exposure;
    }
    public void setExposure(boolean exposure) {
        this.exposure = exposure;
    }
    public boolean isTop() {
        return top;
    }
    public void setTop(boolean top) {
        this.top = top;
    }
    public Long getMpaId() {
        return mpaId;
    }
    public void setMpaId(Long mpaId) {
        this.mpaId = mpaId;
    }
    @Override
    public String toString() {
        return "MobilePortalManagementVO [activityId=" + activityId + ", activity=" + activity + ", mpaId=" + mpaId + ", title=" + title + ", startDate=" + startDate + ", endDate=" + endDate
                + ", exposure=" + exposure + ", top=" + top + "]";
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((activityId == null) ? 0 : activityId.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MobilePortalManagementVO other = (MobilePortalManagementVO) obj;
        if (activityId == null) {
            if (other.activityId != null)
                return false;
        } else if (!activityId.equals(other.activityId))
            return false;
        return true;
    }
}
