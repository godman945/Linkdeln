package com.fet.estore.core.bean.vo.crm;

public class ValidationResult {
	
	private String validationType;
	
	private boolean pass;
	
	private String errorCode;
	
	private String errorMessage;
	
	private Integer voiceMasterReduceAmoun;
	
	private Integer dataMasterReduceAmoun;
	
	private String alertCode;
	
	private String alertMessage;
	
	private boolean vdOffer;

	private String description;
	

	public boolean isVdOffer() {
		return vdOffer;
	}

	public void setVdOffer(boolean vdOffer) {
		this.vdOffer = vdOffer;
	}

	public String getAlertCode() {
		return alertCode;
	}

	public void setAlertCode(String alertCode) {
		this.alertCode = alertCode;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public ValidationResult(){
		
	}

	public ValidationResult(String validationType, boolean pass) {
		this.validationType = validationType;
		this.pass = pass;
	}

	public ValidationResult(String validationType, boolean pass, String errorCode, String errorMessage) {
		super();
		this.validationType = validationType;
		this.pass = pass;
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean isPass() {
		return pass;
	}

	public void setPass(boolean pass) {
		this.pass = pass;
	}

	public String getValidationType() {
		return validationType;
	}

	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	public Integer getDataMasterReduceAmoun() {
		return dataMasterReduceAmoun;
	}

	public void setDataMasterReduceAmoun(Integer dataMasterReduceAmoun) {
		this.dataMasterReduceAmoun = dataMasterReduceAmoun;
	}

	public Integer getVoiceMasterReduceAmoun() {
		return voiceMasterReduceAmoun;
	}

	public void setVoiceMasterReduceAmoun(Integer voiceMasterReduceAmoun) {
		this.voiceMasterReduceAmoun = voiceMasterReduceAmoun;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "ValidationResult [validationType=" + validationType + ", pass=" + pass + ", errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage + ", voiceMasterReduceAmoun=" + voiceMasterReduceAmoun
				+ ", dataMasterReduceAmoun=" + dataMasterReduceAmoun + ", alertCode=" + alertCode + ", alertMessage="
				+ alertMessage + ", vdOffer=" + vdOffer + ", description=" + description + "]";
	}
	
}
