package com.fet.estore.core.bean.vo;

/**
 * C約內容
 * @author Dennis.Chen
 * @Date 2020-08-20
 */
public class ContentOfferVO {

    String contentOfferId;
    String contentOfferName;

    public String getContentOfferId() {
        return contentOfferId;
    }

    public void setContentOfferId(String contentOfferId) {
        this.contentOfferId = contentOfferId;
    }

    public String getContentOfferName() {
        return contentOfferName;
    }

    public void setContentOfferName(String contentOfferName) {
        this.contentOfferName = contentOfferName;
    }
}
