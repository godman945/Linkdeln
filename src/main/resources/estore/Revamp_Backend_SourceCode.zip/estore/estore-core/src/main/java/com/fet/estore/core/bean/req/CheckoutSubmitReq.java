package com.fet.estore.core.bean.req;

import java.io.Serializable;

/**
 * @description 結帳Submit物件
 * @author Dennis.Chen
 * @Date 2020-09-05
 */
public class CheckoutSubmitReq implements Serializable {

    private static final long serialVersionUID = -2469892514427399747L;

    CheckoutCouponReq coupon; //Coupon資訊
    String happygo; //HappyGo資訊
    String payment; //繳款方式 1:貨到付款, 2: 信用卡一次付清, 3: 信用卡分期付款
    String deliveryType; //取貨方式 1:全家超商取貨, 2:宅配, 3:門市取貨, 4:門市取貨及付款
    String receiptType; //發票格式 1:遠傳電信會員載具, 2:電子發票-自然人憑證, 3:電子發票-手機條碼, 4:電子發票-捐贈, 5:紙本發票-三聯式
    String receiptDonateUnit; //捐贈單位
    String receiptDonateNumber; //捐贈碼
    String bank; //刷卡銀行
    String installment; //分期
    String creditNumber1; //信用卡卡號區段1
    String creditNumber2; //信用卡卡號區段2
    String creditNumber3; //信用卡卡號區段3
    String creditNumber4; //信用卡卡號區段4
    String creditYear; //信用卡有效年份
    String creditMonth; //信用卡有效月份
    String creditCode; //驗證碼
    String storeCity; //門市 縣/市
    String storeArea; //門市 區域
    String storeRoad; //門市 路
    String storeName; //門市 店名
    String storeNo; //門市 編號
    String csStoreNo; //超商(Convenience Store) 編號
    String csStoreName; //超商店名
    String csStoreTel; //超商電話
    String csStoreAddress; //超商地址
    String csStoreCvsId; //超商地圖CVS系統 - 店家ID
    String csStoreCvsName; //超商地圖CVS系統 - 店名
    String deliveryCity; //送貨 縣/市
    String deliveryArea; //送貨 區域
    String deliveryAddress; //送貨 地址
    String receiptCertificate; //自然人憑證號碼
    String taxIdNumber; //統一編碼
    String taxIdTitle; //統編抬頭
    String domicileCity; //發票寄送地址 縣/市
    String domicileArea; //發票寄送地址 區
    String domicileAddress; //發票寄送地址 地址
    Boolean sameAsBillAddress; //宅配-同帳單地址flag
    Boolean domicileSameAsBillAddress; //三聯式發票-同帳單地址flag

    public CheckoutCouponReq getCoupon() {
        return coupon;
    }

    public void setCoupon(CheckoutCouponReq coupon) {
        this.coupon = coupon;
    }

    public String getHappygo() {
        return happygo;
    }

    public void setHappygo(String happygo) {
        this.happygo = happygo;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }

    public String getReceiptType() {
        return receiptType;
    }

    public void setReceiptType(String receiptType) {
        this.receiptType = receiptType;
    }

    public String getReceiptDonateUnit() {
        return receiptDonateUnit;
    }

    public void setReceiptDonateUnit(String receiptDonateUnit) {
        this.receiptDonateUnit = receiptDonateUnit;
    }

    public String getReceiptDonateNumber() {
        return receiptDonateNumber;
    }

    public void setReceiptDonateNumber(String receiptDonateNumber) {
        this.receiptDonateNumber = receiptDonateNumber;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getInstallment() {
        return installment;
    }

    public void setInstallment(String installment) {
        this.installment = installment;
    }

    public String getCreditNumber1() {
        return creditNumber1;
    }

    public void setCreditNumber1(String creditNumber1) {
        this.creditNumber1 = creditNumber1;
    }

    public String getCreditNumber2() {
        return creditNumber2;
    }

    public void setCreditNumber2(String creditNumber2) {
        this.creditNumber2 = creditNumber2;
    }

    public String getCreditNumber3() {
        return creditNumber3;
    }

    public void setCreditNumber3(String creditNumber3) {
        this.creditNumber3 = creditNumber3;
    }

    public String getCreditNumber4() {
        return creditNumber4;
    }

    public void setCreditNumber4(String creditNumber4) {
        this.creditNumber4 = creditNumber4;
    }

    public String getCreditYear() {
        return creditYear;
    }

    public void setCreditYear(String creditYear) {
        this.creditYear = creditYear;
    }

    public String getCreditMonth() {
        return creditMonth;
    }

    public void setCreditMonth(String creditMonth) {
        this.creditMonth = creditMonth;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getStoreCity() {
        return storeCity;
    }

    public void setStoreCity(String storeCity) {
        this.storeCity = storeCity;
    }

    public String getStoreArea() {
        return storeArea;
    }

    public void setStoreArea(String storeArea) {
        this.storeArea = storeArea;
    }

    public String getStoreRoad() {
        return storeRoad;
    }

    public void setStoreRoad(String storeRoad) {
        this.storeRoad = storeRoad;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreNo() {
        return storeNo;
    }

    public void setStoreNo(String storeNo) {
        this.storeNo = storeNo;
    }

    public String getCsStoreNo() {
        return csStoreNo;
    }

    public void setCsStoreNo(String csStoreNo) {
        this.csStoreNo = csStoreNo;
    }

    public String getCsStoreName() {
        return csStoreName;
    }

    public void setCsStoreName(String csStoreName) {
        this.csStoreName = csStoreName;
    }

    public String getCsStoreTel() {
        return csStoreTel;
    }

    public void setCsStoreTel(String csStoreTel) {
        this.csStoreTel = csStoreTel;
    }

    public String getCsStoreAddress() {
        return csStoreAddress;
    }

    public void setCsStoreAddress(String csStoreAddress) {
        this.csStoreAddress = csStoreAddress;
    }

    public String getCsStoreCvsId() {
        return csStoreCvsId;
    }

    public void setCsStoreCvsId(String csStoreCvsId) {
        this.csStoreCvsId = csStoreCvsId;
    }

    public String getCsStoreCvsName() {
        return csStoreCvsName;
    }

    public void setCsStoreCvsName(String csStoreCvsName) {
        this.csStoreCvsName = csStoreCvsName;
    }

    public String getDeliveryCity() {
        return deliveryCity;
    }

    public void setDeliveryCity(String deliveryCity) {
        this.deliveryCity = deliveryCity;
    }

    public String getDeliveryArea() {
        return deliveryArea;
    }

    public void setDeliveryArea(String deliveryArea) {
        this.deliveryArea = deliveryArea;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public String getReceiptCertificate() {
        return receiptCertificate;
    }

    public void setReceiptCertificate(String receiptCertificate) {
        this.receiptCertificate = receiptCertificate;
    }

    public String getTaxIdNumber() {
        return taxIdNumber;
    }

    public void setTaxIdNumber(String taxIdNumber) {
        this.taxIdNumber = taxIdNumber;
    }

    public String getTaxIdTitle() {
        return taxIdTitle;
    }

    public void setTaxIdTitle(String taxIdTitle) {
        this.taxIdTitle = taxIdTitle;
    }

    public String getDomicileCity() {
        return domicileCity;
    }

    public void setDomicileCity(String domicileCity) {
        this.domicileCity = domicileCity;
    }

    public String getDomicileArea() {
        return domicileArea;
    }

    public void setDomicileArea(String domicileArea) {
        this.domicileArea = domicileArea;
    }

    public String getDomicileAddress() {
        return domicileAddress;
    }

    public void setDomicileAddress(String domicileAddress) {
        this.domicileAddress = domicileAddress;
    }

    public Boolean getSameAsBillAddress() {
        return sameAsBillAddress;
    }

    public void setSameAsBillAddress(Boolean sameAsBillAddress) {
        this.sameAsBillAddress = sameAsBillAddress;
    }

    public Boolean getDomicileSameAsBillAddress() {
        return domicileSameAsBillAddress;
    }

    public void setDomicileSameAsBillAddress(Boolean domicileSameAsBillAddress) {
        this.domicileSameAsBillAddress = domicileSameAsBillAddress;
    }
}
