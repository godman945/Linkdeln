package com.fet.estore.core.bean.bo;

import java.util.ArrayList;
import java.util.List;

/**
 * 折扣計算結果 - 組合商品VO
 * @author Max Chen
 *
 */
public class ShoppingResultMultiSetBO {
	
	/** 商品清單 */
	private List<ShoppingResultProductBO> products = new ArrayList<ShoppingResultProductBO>();
	/** 組合折扣 */
	private List<ShoppingResultDiscountBO> discounts = new ArrayList<ShoppingResultDiscountBO>();

	public List<ShoppingResultProductBO> getProducts() {
		return products;
	}

	public void setProducts(List<ShoppingResultProductBO> products) {
		this.products = products;
	}

	public Long getDiscPrice() {
		long price = 0L;
		for(ShoppingResultProductBO prod : products) {
			Long discPrice = prod.getDiscPrice();
			if(discPrice == null) continue;
			price += discPrice;
		}
		return price;
	}

	public Long getDiscAmount() {
		long amount = 0L;
		for(ShoppingResultProductBO prod : products) {
			Long discAmount = prod.getDiscAmount();
			if(discAmount == null) continue;
			amount += discAmount;
		}
		return amount;
	}

	public List<ShoppingResultDiscountBO> getDiscounts() {
		return discounts;
	}

	public void setDiscounts(List<ShoppingResultDiscountBO> discounts) {
		this.discounts = discounts;
	}	
}

