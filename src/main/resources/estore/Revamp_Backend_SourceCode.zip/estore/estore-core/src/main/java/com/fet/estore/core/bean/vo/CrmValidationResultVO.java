package com.fet.estore.core.bean.vo;

import java.io.Serializable;

import com.fet.estore.core.bean.CrmData;
import com.fet.estore.core.enums.ValidationResultEnum;

public class CrmValidationResultVO implements Serializable {

	private static final long serialVersionUID = 8447660362561228448L;
	
	/** 回傳碼 */
	private String returnCode;
	/** 回傳訊息 */
	private String returnMsg;
	/** 結果狀態 Enum */
	private ValidationResultEnum resultEnum;
	/** CRM Data */
	private CrmData crmData;
	/** 是否可續約 */
	private boolean checkLy;
	/** 是否為換約 */
	private boolean checkChange;
	/** 是否是遠傳員工 */
	private boolean isFetEmp;
	/** 是否顯示續約通知按鈕 */
	private boolean showNotifyButton;
	/** 使用者原約的G數 2,3,4,5 */
	private String mobileGenerationCode;
	/** 是否顯示前往繳款按鈕 */
	private boolean showToPay;
	/** 是否顯示原約升級為5G按鈕 */
	private boolean showUpgrade5G;
	/** 是否要進行OTP驗證 */
	private boolean needOtp;
	/** 續約記錄用結構 */
	private String loyaltyRecordId;
	/** 驗證未通過時給前端對話框的資訊 */
	private LyLoginCheckFailMsgboxVO msgboxInfo;
	/** 名單式賣場的連結 */
	private String nameListUrl;
	/** 名單式賣場的活動Id */
	private Long nameListActivityId;
	/** 驗證後從 Session 中取出的門號，給 AA 用 */
	private String msisdn;
	

	private boolean guestUseEmployeeAct;

	public CrmValidationResultVO() {
		
	}
	
	public CrmValidationResultVO(ValidationResultEnum resultEnum) {
		this.resultEnum = resultEnum;
		this.returnCode = resultEnum.getCode();
		this.returnMsg = resultEnum.getDescription();
	}
	
	public CrmValidationResultVO(ValidationResultEnum resultEnum, CrmData crmData ,String loyaltyRecordId) {
		this.resultEnum = resultEnum;
		this.returnCode = resultEnum.getCode();
		this.returnMsg = resultEnum.getDescription();
		this.crmData = crmData;
		this.loyaltyRecordId = loyaltyRecordId;
	}
	
	public CrmValidationResultVO(ValidationResultEnum resultEnum, String nameListUrl, Long nameListActivityId) {
		this.resultEnum = resultEnum;
		this.returnCode = resultEnum.getCode();
		this.returnMsg = resultEnum.getDescription();
		this.nameListUrl = nameListUrl;
		this.nameListActivityId = nameListActivityId;
	}
	
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMsg() {
		return returnMsg;
	}
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
	public ValidationResultEnum getResultEnum() {
		return resultEnum;
	}
	public void setResultEnum(ValidationResultEnum resultEnum) {
		this.resultEnum = resultEnum;
	}
	public CrmData getCrmData() {
		return crmData;
	}
	public void setCrmData(CrmData crmData) {
		this.crmData = crmData;
	}

	public boolean isCheckLy() {
		return checkLy;
	}

	public void setCheckLy(boolean checkLy) {
		this.checkLy = checkLy;
	}

	public boolean isCheckChange() {
		return checkChange;
	}

	public void setCheckChange(boolean checkChange) {
		this.checkChange = checkChange;
	}

	public boolean isShowNotifyButton() {
		return showNotifyButton;
	}

	public void setShowNotifyButton(boolean showNotifyButton) {
		this.showNotifyButton = showNotifyButton;
	}

	public boolean isShowToPay() {
		return showToPay;
	}

	public void setShowToPay(boolean showToPay) {
		this.showToPay = showToPay;
	}

	public String getLoyaltyRecordId() {
		return loyaltyRecordId;
	}

	public void setLoyaltyRecordId(String loyaltyRecordId) {
		this.loyaltyRecordId = loyaltyRecordId;
	}

	public boolean isShowUpgrade5G() {
		return showUpgrade5G;
	}

	public void setShowUpgrade5G(boolean showUpgrade5G) {
		this.showUpgrade5G = showUpgrade5G;
	}

	public boolean isNeedOtp() {
		return needOtp;
	}

	public void setNeedOtp(boolean needOtp) {
		this.needOtp = needOtp;
	}

	public LyLoginCheckFailMsgboxVO getMsgboxInfo() {
		return msgboxInfo;
	}

	public void setMsgboxInfo(LyLoginCheckFailMsgboxVO msgboxInfo) {
		this.msgboxInfo = msgboxInfo;

	}
	
	public String getMobileGenerationCode() {
		return mobileGenerationCode;
	}

	public void setMobileGenerationCode(String mobileGenerationCode) {
		this.mobileGenerationCode = mobileGenerationCode;
	}

	public String getNameListUrl() {
		return nameListUrl;
	}

	public void setNameListUrl(String nameListUrl) {
		this.nameListUrl = nameListUrl;
	}

	public Long getNameListActivityId() {
		return nameListActivityId;
	}

	public void setNameListActivityId(Long nameListActivityId) {
		this.nameListActivityId = nameListActivityId;
	}

	public boolean getIsFetEmp() {
		return isFetEmp;
	}

	public void setIsFetEmp(boolean isFetEmp) {
		this.isFetEmp = isFetEmp;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}	
	

	public boolean isGuestUseEmployeeAct() {
		return guestUseEmployeeAct;
	}

	public void setGuestUseEmployeeAct(boolean guestUseEmployeeAct) {
		this.guestUseEmployeeAct = guestUseEmployeeAct;
	}
}
