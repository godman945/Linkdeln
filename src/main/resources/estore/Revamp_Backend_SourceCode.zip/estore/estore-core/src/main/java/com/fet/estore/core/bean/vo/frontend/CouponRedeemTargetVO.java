package com.fet.estore.core.bean.vo.frontend;

/**
 * 折扣卷限制條件VO
 * @author Max Chen
 *
 */
public class CouponRedeemTargetVO {
	private String targetId;
	private String type;
	
	public String getTargetId() {
		return targetId;
	}
	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
