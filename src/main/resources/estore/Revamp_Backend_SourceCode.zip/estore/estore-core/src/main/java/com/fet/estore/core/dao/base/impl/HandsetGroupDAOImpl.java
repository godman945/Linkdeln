package com.fet.estore.core.dao.base.impl;

import com.fet.estore.core.dao.base.HandsetGroupDAO;
import com.fet.estore.core.model.HandsetGroup;
import com.fet.estore.core.util.LogUtil;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class HandsetGroupDAOImpl extends AbstractBaseDAO<HandsetGroup, String> implements HandsetGroupDAO {
	
	@Override	
	public void processActivationDateHandsetSort(String category) {
		LogUtil.info("=============HandsetGroupDAOImpl.processActivationDateHandsetSort is start=====category = "+category);
		String sql = String.format("DELETE FROM HANDSET_SORTING where CATEGORY =  '%s' ", category);
		SQLQuery delQry = this.getSessionFactory().getCurrentSession().createSQLQuery(sql.toString());
		delQry.executeUpdate();
		
		StringBuffer sb = new StringBuffer();
		sb.append("		  insert into HANDSET_SORTING (TOTAL, PRODUCT_ID, BRAND, MODEL_NAME, SORT, CATEGORY) ");
		sb.append("		  SELECT COUNT (1) as total,                                              ");
		sb.append("	         product_1.PRODUCT_ID,                                                ");
		sb.append("	         ref_brand.brand,                                                     ");
		sb.append("	         HANDSET_GROUP.MODEL_NAME,                                            ");
		//分類排序
		sb.append("	         ROW_NUMBER ()                                                        ");
		sb.append("	         OVER (PARTITION BY ref_brand.brand ORDER BY COUNT (1) DESC) as sort, ");
		sb.append("	         '").append(category).append("' as CATEGORY							  ");	
		sb.append("	    FROM handset_group,                                                       ");
		sb.append("	         ref_brand,                                                           ");
		//根據co_master的啟用日,取得product 的內容
		sb.append("	         (SELECT product.*                                                    ");
		sb.append("	            FROM co_master, co_detail, product                                ");
		sb.append("	           WHERE     1 = 1                                                    ");
		sb.append("	                 AND co_master.ia_status = 'D'                                ");
		sb.append("	                 AND co_master.ACTIVATION_DATE >=                             ");
		//properties table 找啟用日的區間日期預設90天
		sb.append("	                        TRUNC (  SYSDATE                                      ");
		sb.append("	                               - (SELECT content                              ");
		sb.append("	                                    FROM properties                           ");
		sb.append("	                                   WHERE name = 'ACTIVATION_DATE_PERIOD'))    ");
		sb.append("	                 AND co_detail.CONO = co_master.cono                          ");
		sb.append("	                 AND co_detail.PRODTYPENO = '1'                               ");
		sb.append("	                 AND co_master.co_type IN ('NH', 'PH', 'LH', 'DA')            ");
		sb.append("	                 AND product.fet_no = co_detail.fet_no) product_1             ");
		sb.append("	   WHERE     1 = 1                                                            ");
		sb.append("	         AND product_1.product_id = handset_group.product_id                  ");
		sb.append("	         AND HANDSET_GROUP.BRAND = ref_brand.id                               ");
		//符合NEWSTORE_HANDSET的設備
		sb.append("	         AND product_1.PRODUCT_ID IN                                          ");
		sb.append("	                (SELECT DISTINCT categoryHandset.HANDSET_ID                   ");
		sb.append("	                   FROM CATEGORY_HANDSET categoryHandset,                     ");
		sb.append("	                        CATEGORY category,                                    ");
		sb.append("	                        CATEGORY_GROUP categoryGroup                          ");
		sb.append("	                  WHERE     1 = 1                                             ");
		sb.append("	                        AND categoryHandset.CATEGORY_ID = category.ID         ");
		sb.append("	                        AND category.CATEGORY_GROUP_ID = categoryGroup.ID     ");
		if(StringUtils.equals("HANDSET", category)) {
			sb.append("	                        AND categoryGroup.NAME = 'NEWSTORE_HANDSET')          ");
		}else if(StringUtils.equals("TABLET", category)) {
			sb.append("	                        AND categoryGroup.NAME = 'NEWSTORE_TABLET')          ");
		}		
		sb.append("	GROUP BY product_1.product_id, ref_brand.brand, HANDSET_GROUP.MODEL_NAME      ");	
		SQLQuery qry = this.getSessionFactory().getCurrentSession().createSQLQuery(sb.toString());
		qry.executeUpdate();
		LogUtil.info("=============HandsetGroupDAOImpl.processActivationDateHandsetSort is end=====");
	}
	
	public List<HandsetGroup> findOnsaleHandset(){
		Query query = this.getSessionFactory().getCurrentSession().createQuery("from HandsetGroup h where h.onsaleDate < sysdate and h.offDate > sysdate and h.sign4onsale = 'Y' and h.onsale = 'Y'");
		return query.list();
	}

}
