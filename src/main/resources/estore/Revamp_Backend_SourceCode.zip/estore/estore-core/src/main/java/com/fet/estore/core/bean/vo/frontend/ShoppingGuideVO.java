package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.List;

import com.fet.estore.core.model.Coupon;
import com.fet.estore.core.model.OnsalePromoList;
import com.fet.estore.core.model.Product;
import com.fet.estore.core.model.VaService;

public class ShoppingGuideVO {
	
	List<ShoppingGuideDetailVO> handsetGroupList = new ArrayList<ShoppingGuideDetailVO>();
	List<ShoppingGuideDetailVO> accessoryList = new ArrayList<ShoppingGuideDetailVO>();
	List<Product> addtionList = new ArrayList<Product>();
	List<VaService> vaServiceList = new ArrayList<VaService>();
//	List<Product> giftList = new ArrayList<Product>();
	OnsalePromoList onsalePromoList;
	String orderType;
	Integer totalPrice;
	Long price = 0L;
	Long prepaidPrice = 0L;
	//新約選擇的門號ID 
	String msisdnId;
	//門號可攜或續約原有門號或新申辦門號
	String msisdn;
	Coupon coupon;
	String couponSn;
	boolean inFillData;
	String delivery;
//	DiscountVO discountVO;
	Long happyGoPrice;
	Long happyGoPoint;
	boolean error;
	boolean onlyS;
//	boolean showDeliveryPrice;
	Long deliveryPrice = 0L;
	
	boolean hasAccessory;
	boolean hasAddationlist;
	boolean hasVaservicelist;
	boolean hasShowAccessory;
	
	Long couponDiscountPrice;
	String uuid;
	String fetNo;
	
//	private List<DiscountItemVO> giftDiscount = new ArrayList<DiscountItemVO>();
//	private List<DiscountItemVO> couponDiscount = new ArrayList<DiscountItemVO>();
//	private List<DiscountItemVO> offerDiscount = new ArrayList<DiscountItemVO>();
	
	private List<DiscountResultAwardVO> awards = new ArrayList<DiscountResultAwardVO>();
	
	private List<DiscountResultDiscountVO> discounts = new ArrayList<DiscountResultDiscountVO>();
	
	private Long preSelectedActivityId;
//	ShoppingGuidePriceVO shoppingGuidePriceVO;
	
	List<MarkupProductVO> markProductVOList;
	
	private boolean isCouponDeliveryTypeError;
	private List<String> couponErrorList = new ArrayList<String>();
	
	private String auctionMsisdn;
	private Integer auctionMsisdnPrice;
	/**是否為多主商品**/
	private boolean isMultiprod;
	/**omni 預繳金**/
	private Long prepayment;
	/**omni 設備 light box **/
	private List<DiscountResultProductVO> handsets;
	/**omni 配件 light box **/
	private List<DiscountResultProductVO> accessorys;
	/**omni 折扣 light box **/
	private Long totalDiscountPrice;
	/**omni 顯示 light box **/
	private boolean showPrepayment;
	
	public Long getCouponDiscountPrice() {
		return couponDiscountPrice;
	}
	public void setCouponDiscountPrice(Long couponDiscountPrice) {
		this.couponDiscountPrice = couponDiscountPrice;
	}
	public List<ShoppingGuideDetailVO> getHandsetGroupList() {
		return handsetGroupList;
	}
	public void setHandsetGroupList(List<ShoppingGuideDetailVO> handsetGroupList) {
		this.handsetGroupList = handsetGroupList;
	}
	public List<ShoppingGuideDetailVO> getAccessoryList() {
		return accessoryList;
	}
	public void setAccessoryList(List<ShoppingGuideDetailVO> accessoryList) {
		this.accessoryList = accessoryList;
	}
	public List<Product> getAddtionList() {
		return addtionList;
	}
	public void setAddtionList(List<Product> addtionList) {
		this.addtionList = addtionList;
	}
	public List<VaService> getVaServiceList() {
		return vaServiceList;
	}
	public void setVaServiceList(List<VaService> vaServiceList) {
		this.vaServiceList = vaServiceList;
	}
	public OnsalePromoList getOnsalePromoList() {
		return onsalePromoList;
	}
	public void setOnsalePromoList(OnsalePromoList onsalePromoList) {
		this.onsalePromoList = onsalePromoList;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public Integer getTotalPrice() {
		int p = price.intValue() + deliveryPrice.intValue();
		if(p>0){
			p += prepaidPrice.intValue();
		}else{
			p = prepaidPrice.intValue();
		}
		
		// 競標門號
		if(auctionMsisdnPrice != null) p += auctionMsisdnPrice.intValue();
		
		return p;
	}
	public String getMsisdnId() {
		return msisdnId;
	}
	public void setMsisdnId(String msisdnId) {
		this.msisdnId = msisdnId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public Coupon getCoupon() {
		return coupon;
	}
	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}
	public boolean isInFillData() {
		return inFillData;
	}
	public void setInFillData(boolean inFillData) {
		this.inFillData = inFillData;
	}
	public String getDelivery() {
		return delivery;
	}
	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}
//	public DiscountVO getDiscountVO() {
//		return discountVO;
//	}
//	public void setDiscountVO(DiscountVO discountVO) {
//		this.discountVO = discountVO;
//	}
	public Long getHappyGoPrice() {
		return happyGoPrice;
	}
	public void setHappyGoPrice(Long happyGoPrice) {
		this.happyGoPrice = happyGoPrice;
	}
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public boolean isOnlyS() {
		return onlyS;
	}
	public void setOnlyS(boolean onlyS) {
		this.onlyS = onlyS;
	}
	public Long getHappyGoPoint() {
		return happyGoPoint;
	}
	public void setHappyGoPoint(Long happyGoPoint) {
		this.happyGoPoint = happyGoPoint;
	}
	public String getCouponSn() {
		return couponSn;
	}
	public void setCouponSn(String couponSn) {
		this.couponSn = couponSn;
	}
	public Long getDeliveryPrice() {
		return deliveryPrice;
	}
	public void setDeliveryPrice(Long deliveryPrice) {
		this.deliveryPrice = deliveryPrice;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public Long getPrepaidPrice() {
		return prepaidPrice;
	}
	public void setPrepaidPrice(Long prepaidPrice) {
		this.prepaidPrice = prepaidPrice;
	}
	public boolean isHasAccessory() {
		return hasAccessory;
	}
	public void setHasAccessory(boolean hasAccessory) {
		this.hasAccessory = hasAccessory;
	}
	public boolean isHasAddationlist() {
		return hasAddationlist;
	}
	public void setHasAddationlist(boolean hasAddationlist) {
		this.hasAddationlist = hasAddationlist;
	}
	public boolean isHasVaservicelist() {
		return hasVaservicelist;
	}
	public void setHasVaservicelist(boolean hasVaservicelist) {
		this.hasVaservicelist = hasVaservicelist;
	}
//	public List<Product> getGiftList() {
//		return giftList;
//	}
//	public void setGiftList(List<Product> giftList) {
//		this.giftList = giftList;
//	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public boolean isHasShowAccessory() {
		return hasShowAccessory;
	}
	public void setHasShowAccessory(boolean hasShowAccessory) {
		this.hasShowAccessory = hasShowAccessory;
	}
	public Long getPreSelectedActivityId() {
		return preSelectedActivityId;
	}
	public void setPreSelectedActivityId(Long preSelectedActivityId) {
		this.preSelectedActivityId = preSelectedActivityId;
	}

//	public List<DiscountItemVO> getGiftDiscount() {
//		return giftDiscount;
//	}
//	public void setGiftDiscount(List<DiscountItemVO> giftDiscount) {
//		this.giftDiscount = giftDiscount;
//	}
//	public List<DiscountItemVO> getCouponDiscount() {
//		return couponDiscount;
//	}
//	public void setCouponDiscount(List<DiscountItemVO> couponDiscount) {
//		this.couponDiscount = couponDiscount;
//	}
//	public List<DiscountItemVO> getOfferDiscount() {
//		return offerDiscount;
//	}
//	public void setOfferDiscount(List<DiscountItemVO> offerDiscount) {
//		this.offerDiscount = offerDiscount;
//	}
	public List<MarkupProductVO> getMarkProductVOList() {
		return markProductVOList;
	}
	public void setMarkProductVOList(List<MarkupProductVO> markProductVOList) {
		this.markProductVOList = markProductVOList;
	}
	public boolean isCouponDeliveryTypeError() {
		return isCouponDeliveryTypeError;
	}
	public void setCouponDeliveryTypeError(boolean isCouponDeliveryTypeError) {
		this.isCouponDeliveryTypeError = isCouponDeliveryTypeError;
	}
	public List<String> getCouponErrorList() {
		return couponErrorList;
	}
	public void setCouponErrorList(List<String> couponErrorList) {
		this.couponErrorList = couponErrorList;
	}
	public List<DiscountResultAwardVO> getAwards() {
		return awards;
	}
	public void setAwards(List<DiscountResultAwardVO> awards) {
		this.awards = awards;
	}
	public List<DiscountResultDiscountVO> getDiscounts() {
		return discounts;
	}
	public void setDiscounts(List<DiscountResultDiscountVO> discounts) {
		this.discounts = discounts;
	}
	public String getAuctionMsisdn() {
		return auctionMsisdn;
	}
	public void setAuctionMsisdn(String auctionMsisdn) {
		this.auctionMsisdn = auctionMsisdn;
	}
	public Integer getAuctionMsisdnPrice() {
		return auctionMsisdnPrice;
	}
	public void setAuctionMsisdnPrice(Integer auctionMsisdnPrice) {
		this.auctionMsisdnPrice = auctionMsisdnPrice;
	}
	public boolean isMultiprod() {
		return isMultiprod;
	}
	public void setMultiprod(boolean isMultiprod) {
		this.isMultiprod = isMultiprod;
	}
	public Long getPrepayment() {
		return prepayment;
	}
	public void setPrepayment(Long prepayment) {
		this.prepayment = prepayment;
	}
	public List<DiscountResultProductVO> getHandsets() {
		return handsets;
	}
	public void setHandsets(List<DiscountResultProductVO> handsets) {
		this.handsets = handsets;
	}
	public List<DiscountResultProductVO> getAccessorys() {
		return accessorys;
	}
	public void setAccessorys(List<DiscountResultProductVO> accessorys) {
		this.accessorys = accessorys;
	}
	public Long getTotalDiscountPrice() {
		return totalDiscountPrice;
	}
	public void setTotalDiscountPrice(Long totalDiscountPrice) {
		this.totalDiscountPrice = totalDiscountPrice;
	}
	public boolean isShowPrepayment() {
		return showPrepayment;
	}
	public void setShowPrepayment(boolean showPrepayment) {
		this.showPrepayment = showPrepayment;
	}	
}
