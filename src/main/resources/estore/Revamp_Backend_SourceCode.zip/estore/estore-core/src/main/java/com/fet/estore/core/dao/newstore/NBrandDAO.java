package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.RefBrand;

import java.util.List;

public interface NBrandDAO extends BaseDAO<RefBrand, String> {
	
	/**
	 * 平板筆電館查詢品牌.
	 * @return List<RefBrand>
	 */
	public List<RefBrand> find3CBrandList();

	/**
	 * 其他館查詢品牌.
	 * @return List<RefBrand>
	 */
	public List<RefBrand> findHandsetBrandList();

	/**
	 * 依名稱取得ID
	 * @param name
	 * @param ignoreCase
	 * @return
	 */
	public String findIdByName(String name, boolean ignoreCase);

	public List<RefBrand> findComputerBrandList();
}
