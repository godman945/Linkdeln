/**
 * 
 */
package com.fet.estore.core.bean.vo.frontend;

/**
 * @author Brian
 * 
 */
public class InstallmentPlanVO {

	/** 分期數 */
	private Integer installmentTenor;
	/** 分期顯示名稱 */
	private String representation;
	/** 銀行家數 */
	private Integer bankCount;
	/** 第一間銀行名稱 */
	private String firstBankName;
	/** 分期價格 */
	private Integer installmentPrice;

	public Integer getInstallmentTenor() {
		return installmentTenor;
	}

	public void setInstallmentTenor(Integer installmentTenor) {
		this.installmentTenor = installmentTenor;
	}

	public String getRepresentation() {
		return representation;
	}

	public void setRepresentation(String representation) {
		this.representation = representation;
	}

	public Integer getBankCount() {
		return bankCount;
	}

	public void setBankCount(Integer bankCount) {
		this.bankCount = bankCount;
	}

	public String getFirstBankName() {
		return firstBankName;
	}

	public void setFirstBankName(String firstBankName) {
		this.firstBankName = firstBankName;
	}

	public Integer getInstallmentPrice() {
		return installmentPrice;
	}

	public void setInstallmentPrice(Integer installmentPrice) {
		this.installmentPrice = installmentPrice;
	}

}
