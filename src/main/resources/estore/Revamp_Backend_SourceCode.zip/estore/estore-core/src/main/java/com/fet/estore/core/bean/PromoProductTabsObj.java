package com.fet.estore.core.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-23
 * @description
 */
public class PromoProductTabsObj {

    private String label;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public PromoProductTabsObj(String label) {
        this.label = label;
    }
}
