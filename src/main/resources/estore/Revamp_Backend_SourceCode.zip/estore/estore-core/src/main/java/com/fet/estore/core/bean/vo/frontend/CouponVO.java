package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.bean.vo.IDiscountItem;

import java.util.HashSet;
import java.util.Set;

/**
 * 折扣卷VO
 * @author Max Chen
 *
 */
public class CouponVO implements IDiscountItem {
	private Long id;
	private boolean isDeviceAllow;
	private boolean isAccessoryAllow;
	
	private Integer minTotalPrice;
	private Integer minDevicePrice;
	private Integer minAccessoryPrice;
	
	
	private String discountCode;
	private Long discountAmount;
	
	private Long costCenterMasterId;
	private String discountName;
	
	private String description;
	
	private Set<CouponRedeemTargetVO> couponRedeemTargets = new HashSet<CouponRedeemTargetVO>();
	
	private String couponSerial;
	
	
	public boolean isDeviceAllow() {
		return isDeviceAllow;
	}
	public void setDeviceAllow(boolean isDeviceAllow) {
		this.isDeviceAllow = isDeviceAllow;
	}
	public boolean isAccessoryAllow() {
		return isAccessoryAllow;
	}
	public void setAccessoryAllow(boolean isAccessoryAllow) {
		this.isAccessoryAllow = isAccessoryAllow;
	}
	public Set<CouponRedeemTargetVO> getCouponRedeemTargets() {
		return couponRedeemTargets;
	}
	public void setCouponRedeemTargets(Set<CouponRedeemTargetVO> couponRedeemTargets) {
		this.couponRedeemTargets = couponRedeemTargets;
	}
	public Integer getMinTotalPrice() {
		return minTotalPrice;
	}
	public void setMinTotalPrice(Integer minTotalPrice) {
		this.minTotalPrice = minTotalPrice;
	}
	public Integer getMinDevicePrice() {
		return minDevicePrice;
	}
	public void setMinDevicePrice(Integer minDevicePrice) {
		this.minDevicePrice = minDevicePrice;
	}
	public Integer getMinAccessoryPrice() {
		return minAccessoryPrice;
	}
	public void setMinAccessoryPrice(Integer minAccessoryPrice) {
		this.minAccessoryPrice = minAccessoryPrice;
	}
	public Long getCostCenterMasterId() {
		return costCenterMasterId;
	}
	public void setCostCenterMasterId(Long costCenterMasterId) {
		this.costCenterMasterId = costCenterMasterId;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public Long getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(Long discountAmount) {
		this.discountAmount = discountAmount;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCouponSerial() {
		return couponSerial;
	}
	public void setCouponSerial(String couponSerial) {
		this.couponSerial = couponSerial;
	}

	@Override
	public Long getAaiId() {
		return null;
	}
	@Override
	public String getCode() {
		return discountCode;
	}
	@Override
	public String getFetNo() {
		return null;
	}
	@Override
	public Long getActivityId() {
		return null;
	}
	@Override
	public String getName() {
		return discountName;
	}
	@Override
	public Long getAmount() {
		return discountAmount;
	}
	@Override
	public Long getCouponId() {
		return id;
	}
	@Override
	public Long getOfferId() {
		return null;
	}
	@Override
	public Long getCostCenterId() {
		return costCenterMasterId;
	}
	@Override
	public Double getDiscountRatio() {
		return null;
	}
	@Override
	public Long getActualDiscountAmt() {
		return null;
	}
	@Override
	public String getDisplayGroup() {
		return null;
	}
}
