package com.fet.estore.core.bean.vo;

import java.util.Date;

public class OcrIDrReqVO implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 辨識任務代號，8 碼日期+7 碼流水號 共 15 碼，例： 201702020000001
	 */
	String ocrSN;

	/**
	 * 來源系統代號 於網站組態檔設定值設定管控不同 的來源系統，則必需代入這個值以做 驗証，如同帳號
	 */
	String sysID;

	/**
	 * 來源系統識別值 於網站組態檔設定值設定管控不同 的來源系統，則必需代入這個值以做 驗証，如同密碼
	 */
	String mac;

	public String getOcrSN() {
		return ocrSN;
	}

	public void setOcrSN(String ocrSN) {
		this.ocrSN = ocrSN;
	}

	public String getSysID() {
		return sysID;
	}

	public void setSysID(String sysID) {
		this.sysID = sysID;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}
	
	
}
