package com.fet.estore.core.bean;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fet.estore.core.bean.vo.UploadFileInfo;
import com.fet.estore.core.bean.vo.crm.ANoteVO;
import com.fet.estore.core.bean.vo.frontend.Address;
import com.fet.estore.core.bean.vo.frontend.EntryPointEnum;
import com.fet.estore.core.bean.vo.frontend.IdAndQuantityPairHelper;
import com.fet.estore.core.bean.vo.frontend.ProductHelperVO;
import com.fet.estore.core.util.LogUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class OrderHelper implements Serializable, IShoppingResultParam {

	private static final long serialVersionUID = 1335978496974289547L;

	/** 未知來源的訂單模式 */
	public static final int UNKNOWN_ORDER = 0;
	/** 購物車訂單 */
	public static final int CART_ORDER = 1;
	/** 手機訂單 */
	public static final int PRODUCT_ORDER = 2;
	/** 流程控制器資料 */
	private FlowControlBean flowControlBean;
	/** 訂單模式 */
	private final int orderMode;
	/** 購物車 */
	private Cart cart;
	/** 商品資訊 productId */
	private String productId;
	/** 商品數量 */
	private Integer number;
	/** 商品資訊 fetNo */
	private String fetNo;
	/** 申辦類型 */
	private String orderType;
	/** 門號 */
	private String msisdn;
    /** 門號商品ID、對應後端 MSISDN Table 的 Product Id */
    private String msisdnId;
	/** 資費方案 - 對應 onsalePromoList.seq*/
	private String onsalePromoListId;
	/** 資費方案 - 對應 onsalePromoList.promotionListId*/
	private String promotionListId;
	/** 加值服務 */
	private List<String> extraPlan;
	/** 結帳總金額 */
	private Long total;
	/** 蝦皮訂單時 CROSS_COORPERATION 的 ORDER NO */
	private String crossCooperationOrderNo;
	/** 蝦皮訂單的 CROSS_COORPERATION ，蝦皮訂單有資料，非蝦皮訂單為 null*/
	private CrossCooperationData crossCooperationData;

	//以下為DiscountResultVO在改寫地的時候加入的
	//TODO 多組商品活動ID
	private Long mpActivityId;
	//命名有點怪怪, 檢查再改
	//TODO Coupon券序號
	private String redeemCouponSerial;
	//TODO Coupon券密碼
	private String redeemCouponPassword;
	//TODO  HappyGo點數
	private Long hgRedeemPoint;
	//TODO  HappyGo金額
	private Long hgRedeemPrice;

	/** 門號競標 */
	//TODO  競標門號
	private String auctionMsisdn;
	//TODO  競標門號活動ID
	private Integer auctionActivityId;
	//TODO  競標門號活動申請人身分證字號
	private String auctionRocId;
	//TODO  競標門號活動價格
	private Integer auctionPrice;
	/** 原preSelectedActivityId */
	//TODO  活動ID
	private Long activityId;
	//TODO  來源"ESTORE"或"MOBILE",
	private String channel;
	//TODO  加購ID
	private String[] vasIds;
	//TODO  配送方式: H, S
	private String deliveryType;
	//TODO  以前的 帶刪除
//	private List<ProductHelper> productHelpers;

	/** preselected系列未來不知道會不會有用, 先放著之後有需要再移除*/
	private String preSelctedCouponSerial;
	private Long preSelectedActivityId;
	private String staffType;
    private boolean isEbu;
    private String cono;
    private String ebuSubscriberType;
    /** 勾選稍後上傳證件 */
    private boolean isUploadLater;
    private String credentialFile1No;
    private String credentialFile2No;
    private String credentialFile3No;
    private String credentialFile4No;
    //員工證件
    private String credentialFile5No;
    //員眷
    private List<String> credentialFile6No;
    private List<UploadFileInfo> uploadFileInfoList;
    private String cohTxid;
    private String voiceRateId;
    private String dataRateId;
    private String transType;
    private String cohOrderId;
    /** 證件上傳頁 ocr 的 識別值**/
    private List<String> ocrSn;
    private IdNum1 idNum1;
    private IdNum2 idNum2;
    private IdNum31 idNum31;
    private IdNum41 idNum41;
    private String idNum1ocrSN;
    private Address ocrVailAddr;
    private String lastPaymentMethod;
    /** VIP LOYALTY */
    private boolean isPassVipLoyalty;
    /** 2020/03/12 add 是否要驗證九個月一證一號 */
    private Boolean isCheckOnceContract9M;
    private String transBpid =  java.util.UUID.randomUUID().toString();
    /** 資費升級類型 */
    private String upgradeType;
    /** 2020-04-06 Ted.Hsieh 新增 c約(contentOffer)的ID清單 */
    private List<String> contentOfferIdList;
    /**是否為多主商品**/
    private boolean isMultiprod;
    /** 多主商品群組1, 群組2的fet no**/
    private List<String> fetNos;
    private boolean needOcr;
    private boolean isStudentPromotion;
    private String credentialType;
    private ANoteVO aNoteVO;
    /** 2020/01/03 add 帳單地址是否為外島、離島 */
    private Boolean isOffshoreIsland;
	private Long oldBillingTypeId;
	private Long newBillingTypeId;
    private Boolean cncDeliveryOrder;
    //個資填寫參數
    private String applicantSecondId;//二證號碼
    private String applicantSecondIdType;//二證種類
    private Date applicantBirthday;//生日 GANP前端必填或合併帳單從CrmData拿，LY從CrmData拿
    private boolean isMergeBill;//是否合併帳單 GANP可選，LY無
    private String mergeBillMsisdn;//合併帳單門號
    private String applicantName;//姓名 GANP前端必填或合併帳單從CrmData拿，LY從CrmData拿
    private String applicantRocId;//身分證 GANP前端必填或合併帳單從CrmData拿，LY從CrmData拿
    private String applicantEmail;//email GANP前端必填或合併帳單從CrmData拿，LY從CrmData拿
    private Address registerAddress;//戶籍地址(也是帳單地址)
    private String tel1;//聯絡電話(現在只有手機沒有市話)
    //個資填寫參數

// 以下為來自舊 OrderHelperVO
	private String preSelectedHandsetGroupId;
	private String preSelectedOnsalePromoListId;
	private String preSelectedOrderType;

	private Integer preselectedHandsetGroupAmt;
	private boolean isRegisterActivity;
	
	private String happyGoRocId;

	
	/**
	 * 館別進入點
	 */
	private EntryPointEnum entryPoint;
	/** 館別第二層進入點 */
	private Integer entryNavigationId;

	/**
	 * 使用於活動商品麵包屑版型D跟活動資費麵包屑版型E
	 */
	private String activityStep;


	private int selectionFee;
	private boolean registerDemandActivity;
	private Long activityCouponId;
	private String loyaltyToken;
	private String npCompanyCode;
	

	private String telPrefix1;

	private String telPrefix2;
	private String tel2;
	
	private List<String> extraVaServiceIds = new ArrayList<String>();
	private String deliTime;
	
	private String receiverName;
	private String receiverRocId;
	private String receiverTelPrefix1;
	private String receiverTel1;
	private String receiverTelPrefix2;
	private String receiverTel2;
	
	private String storeReceiverName;
	private String storeReceiverRocId;
	private String storeTelPrefix1;
	private String storeTel1;
	private String storeTelPrefix2;
	private String storeTel2;
	private String cityId;
	private String storeId;
	
	private String gender;
	private boolean isInvoiceDemand;
	private String vatNo;
	private String vatTitle;
	/**
	 *收件人同申辦人
	 */
	private boolean addOnReceiver;
	
	/**
	 * 是否可代收(1:是  2:否)
	 */
	private String deliAlt;

	private Long hgRedeemId;
	
	private boolean happyGoRedeemed;
	
	private String orderNumber;
	
	private boolean clickFinish;
	
	private boolean orderSustained;

	
	private boolean acceptSms;
	
	private String callingcardTicket;
	
	private String exitMsg;
	
	private String packageBrowsingStatisticId;
	
	//用作輔助coupon或其它折抵之用,可知道設備剩多少金額可折抵
	private Long leftPriceToDiscountForDevice = 0L;
	//用作輔助coupon或其它折抵之用,可知道配件剩多少金額可折抵
	private Long leftPriceToDiscountForAccessory = 0L;
	

	/**電子發票載具類別**/
	private String einvoiceDeviceType;
	/**電子發票載具代碼**/
	private String einvoiceDeviceId;
	/**電子發票愛心捐贈碼**/
	private String donateUnitId;
	/**電子發票愛心捐贈單位**/
	private String donateUnitName;
	/**電子發票類別**/
	private String invoiceType;
	
	private String uid;
	
	/** */
	private String preorderNo;
	
	/** 是否為小網 */
	private boolean isMobileWeb;
	
	private boolean webtrendRecorded;
	
	/** 是否為App導購 */
	private boolean appFlow;
	/** 訊息來源 */
    private String recommendSource;
	/** 訊息來源資料 */
    private String recommendDesc;
	/** 企業客戶統編資料 */
    private String mvpnVatNo;
    /** 企業客戶資料 */
    private String mvpnStr;
    
    
    /** 網路涵蓋率 */
    private Boolean netCoverRate;
    
    /**
     * CPS門號
     */
    private String cspMsisdn;
    
    private String appSource;

    private String o2oOrderId;
    
    private String subscriberId;
    /**是否為資費試用**/
    private String trial;
    /**資費試用RocId**/
    private String ncRocId;
    /** 是否同意電信費用及小額付費帳單合併 */
    private String paymentConsolidation;
    /** 取得小額帳單資料錯誤訊息 */
    private String paymentConsolidationError;
    /**指定名單式ID*/
    private Long nameListId;
    /**發證日期*/
    private Date idCardDate;
    /**發證地點*/
    private String idCardCity;
    /**領補換類別*/
    private String idCardType;
    //多主商品
    /**多主商品 id**/
    private String multiprodId;
    /** 多主商品群組1, 群組2的 proudct id**/
    private List<String> productIds;
    /**多主商品指定名單式ID*/
    private Long multiprodNameListId;
     /**版型A,B,C id**/
	private String minisiteActivityId;

    private String mdmAccountId;
    private String mdmSubscriberId;
    private String mdmCustomerId;
    private boolean ly3to4;

    private Long prepaymentPrice;
    
    private boolean addAnoteSuccess = false;
    private boolean addGiftRedeem = false;



	/**markup product begin**/
	Map<String, List<ProductHelperVO>> masterProductMap = new HashMap<String, List<ProductHelperVO>>();
	Map<String, List<ProductHelperVO>> slaveProductMap = new HashMap<String, List<ProductHelperVO>>();

    /**HappyGo - Token*/
    private String hgToken;
	/**HappyGo - 總點數*/
    private String hgTotalPoint;
	/**HappyGo - mpId(不確定是甚麼值，記DB用)*/
    private String mpId;
	/**HappyGo - mpIdCheckSum(不確定是甚麼值，記DB用)*/
    private String mpIdCheckSum;
	/**HappyGo - call HG時間*/
    private Date hgRedeemTime;
	
	//是否3轉4平轉
	private boolean isNba324;
	//3轉4平轉需要simcard no
	private String simcardNo;
	//是否為聯名卡
	private boolean isCobranding;
    // NEIL Project
    /** 是否為NEIL平台訂單 **/
    private boolean neilOrder = false;
    /** NEIL平台訂單編號 **/
    private String neilCono;
    /**是否同意加速退貨辦理**/
    private boolean agreeReturnSpeedup;
    
    private String loyaltyRecordId;
    
    private int installments;
    
    private String creditCardNo;
    
    private String sid;
    
    private String npxCono;
    
    private String npxTxid;
    
    private String dspUserProfileUuid;
    
    
    private String jsonString;
    //phase 2
    private String deliTel;
    private boolean regAsBill;
    private boolean regAsAddr;
    private String vatTp;
    private boolean agreeContract;
    private String backFromUri;
    private String orderChannel;
    

    private String csStoreCvsid;
    private String csStoreCvsname;
    private String csStoreNo;
    private String csStoreName;
    private String csStoreTel;
    private String csStoreAddress;
    private String csStoreAreaCode;
    
    private String extraService;

    /**是否為資費自由選**/
    private boolean isSelfHelpingPromotion = false;

    private String selfHelpingPromotionName;
    /** 資費自由選  D_OFFERID**/
    private String selfHelpingPromotion1;
    /** 資費自由選  ONNET_OFFERID**/
    private String selfHelpingPromotion2;
    /** 資費自由選  OFFNET_OFFERID**/
    private String selfHelpingPromotion3;
    
    private String fridayOrderType;
    
    private String fridayOrderNo;
    
    private boolean isFirday = false;
    
    //驗證碼
    private String captcha;
    
    //CR2019028
    private String rId;
    private String clickId;
    private boolean isFromMarketAmerica;
    
    
    private boolean isInsurance;



    private boolean isPremium;
    
    private String premiumTitle;
    
    private Integer premiumBuyCount;
    
    private Map<Long, Integer> premiumGroup1 = new LinkedHashMap<>();
    private Map<Long, Integer> premiumGroup2 = new LinkedHashMap<>();
    
    //2019/07/30 add EBU證件上傳
    

    

    
    private String ebuVatNo;
    private String ebuVatTitle;
    private String ebuRecomName;
    private String ebuRecomMsisdn;
    
    //app 上傳證照的唯一值
    private String uploadImagePageSidByAPP;
    
    private String host;
    private String xff;
    


    /** 證件上傳頁 是否延遲上傳**/
    private String delayChoose;
    /** 資料填寫頁 簽名方式**/
    private String ApplicantSignType;
    private String forbidMsisdn;//GA流程下連絡電話不可與所選門號相同

	/**
	 * 2020/05/12 add 成單時要寫回上傳頁面當時取的useOcr及credentialType
	 */
	private Map<String, String> ocrAttrMap;

	//20200831 Dennis.Chen 搬回舊的
	private List<Address> addresses = new ArrayList<Address>();
	private Map<String, ProductHelperVO> handsetGroupMap = new LinkedHashMap<String, ProductHelperVO>();
	List<String> addtionPurchaseFetNos = new ArrayList<String>();
	private String lastPaymentMethodAns;
	Map<String, ProductHelperVO> accessoryMap = new LinkedHashMap<String, ProductHelperVO>();
	List<String> vaServices = new ArrayList<String>();

	//20200909 Dennis.Chen 新增CoPayType 付款方式
	private String coPayType;
	private String afterCreditResult;
	private String afterCreditErrMsg;

	/** 20200916 Dennis.Chen - 新增商品明細頁加購物件*/
	private List<PremiumDiscountProd> extraBuyList;
	/** 20200916 Dennis.Chen - 新增商品明細頁好禮物件*/
	private List<PremiumDiscountProd> giftList;

	/** 2020-10-05 Ted.Hsieh 新增 coupon和happyGo折抵總金額(折抵金額紀錄供前端顯示用) */
    private OrderDiscountResult paymentPageDiscount;
    /** 2020-10-08 Ted.Hsieh 新增 判斷預繳金是否已經被anote重新計算過的flag */
	private Boolean anotePrepayCounted;
	/** 2020-11-16 Dennis.Chen - 用戶選擇的送貨方式。因端會把用戶的送貨方式整理，導致無法分聘用戶所選 */
	private String userDeliveryType;

	/**
	 * 未指定訂單類型，理論上不應該用此建構子建立訂單
	 */
	public OrderHelper() {
		LogUtil.warn("Create OrderHelper Data with Unknown mode!! prefer to use 'new OrderHelper(orderMode) to create.'");
		LogUtil.warn("orderMode maybe CART_ORDER or PRODUCT_ORDER");
		this.orderMode = UNKNOWN_ORDER;
	}

	/**
	 * 建立訂單 指定訂單類型
	 *
	 * @param orderMode
	 */
	public OrderHelper(int orderMode) {
		this.orderMode = orderMode;
	}

	public Long getMpActivityId() {
		return mpActivityId;
	}

	public void setMpActivityId(Long mpActivityId) {
		this.mpActivityId = mpActivityId;
	}

//	public List<ProductHelper> getProductHelpers() {
//		return productHelpers;
//	}

//	public void setProductHelpers(List<ProductHelper> productHelpers) {
//		this.productHelpers = productHelpers;
//	}

//	//這個為為了滿足過去的code先加的, 看看可不可以直接使用 getProductHelpers解決
//	public Map<String, List<ProductHelper>> getAccesoryMap() {
//		return productHelpers.stream()
//				.filter(p -> PRODUCT_TYPE_HANDSET.equals(p.getProductType()))
//				.collect(Collectors.groupingBy(ProductHelper::getFetNo));
//	}
//	//這個為為了滿足過去的code先加的, 看看可不可以直接使用 getProductHelpers解決
//	public Map<String, List<ProductHelper>> getHandsetGroupMap() {
//		return productHelpers.stream()
//				.filter(p->PRODUCT_TYPE_ACCESSORY.equals(p.getProductType()))
//				.collect(Collectors.groupingBy(ProductHelper::getFetNo));
//	}

	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getOnsalePromoListId() {
		return onsalePromoListId;
	}
	public void setOnsalePromoListId(String onsalePromoListId) {
		this.onsalePromoListId = onsalePromoListId;
	}
	public List<String> getExtraPlan() {
		return extraPlan;
	}
	public void setExtraPlan(List<String> extraPlan) {
		this.extraPlan = extraPlan;
	}

	public String getRedeemCouponSerial() {
		return redeemCouponSerial;
	}
	public void setRedeemCouponSerial(String redeemCouponSerial) {
		this.redeemCouponSerial = redeemCouponSerial;
	}
	public String getRedeemCouponPassword() {
		return redeemCouponPassword;
	}
	public void setRedeemCouponPassword(String redeemCouponPassword) {
		this.redeemCouponPassword = redeemCouponPassword;
	}
	public Long getHgRedeemPoint() {
		return hgRedeemPoint;
	}
	public void setHgRedeemPoint(Long hgRedeemPoint) {
		this.hgRedeemPoint = hgRedeemPoint;
	}
	public Long getHgRedeemPrice() {
		return hgRedeemPrice;
	}
	public void setHgRedeemPrice(Long hgRedeemPrice) {
		this.hgRedeemPrice = hgRedeemPrice;
	}
	public String getDeliveryType() {
		return deliveryType;
	}
	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}
	public String getAuctionMsisdn() {
		return auctionMsisdn;
	}
	public void setAuctionMsisdn(String auctionMsisdn) {
		this.auctionMsisdn = auctionMsisdn;
	}
	public Integer getAuctionActivityId() {
		return auctionActivityId;
	}
	public void setAuctionActivityId(Integer auctionActivityId) {
		this.auctionActivityId = auctionActivityId;
	}
	public String getAuctionRocId() {
		return auctionRocId;
	}
	public void setAuctionRocId(String auctionRocId) {
		this.auctionRocId = auctionRocId;
	}
	public Integer getAuctionPrice() {
		return auctionPrice;
	}
	public void setAuctionPrice(Integer auctionPrice) {
		this.auctionPrice = auctionPrice;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String[] getVasIds() {
		return vasIds;
	}
	public void setVasIds(String[] vasIds) {
		this.vasIds = vasIds;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getPreSelctedCouponSerial() {
		return preSelctedCouponSerial;
	}
	public void setPreSelctedCouponSerial(String preSelctedCouponSerial) {
		this.preSelctedCouponSerial = preSelctedCouponSerial;
	}
	public Long getPreSelectedActivityId() {
		return preSelectedActivityId;
	}
	public void setPreSelectedActivityId(Long preSelectedActivityId) {
		this.preSelectedActivityId = preSelectedActivityId;
	}

	public int getOrderMode() {
		return orderMode;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public boolean isEbu() {
		return isEbu;
	}

	public void setEbu(boolean isEbu) {
		this.isEbu = isEbu;
	}

	public String getCono() {
		return cono;
	}

	public void setCono(String cono) {
		this.cono = cono;
	}

	public String getEbuSubscriberType() {
		return ebuSubscriberType;
	}

	public void setEbuSubscriberType(String ebuSubscriberType) {
		this.ebuSubscriberType = ebuSubscriberType;
	}

	public boolean isUploadLater() {
		return isUploadLater;
	}

	public void setUploadLater(boolean isUploadLater) {
		this.isUploadLater = isUploadLater;
	}

	public String getApplicantSecondId() {
		return applicantSecondId;
	}

	public void setApplicantSecondId(String applicantSecondId) {
		this.applicantSecondId = applicantSecondId;
	}

	public String getApplicantSecondIdType() {
		return applicantSecondIdType;
	}

	public void setApplicantSecondIdType(String applicantSecondIdType) {
		this.applicantSecondIdType = applicantSecondIdType;
	}

	public String getCredentialFile1No() {
		return credentialFile1No;
	}

	public void setCredentialFile1No(String credentialFile1No) {
		this.credentialFile1No = credentialFile1No;
	}

	public String getCredentialFile2No() {
		return credentialFile2No;
	}

	public void setCredentialFile2No(String credentialFile2No) {
		this.credentialFile2No = credentialFile2No;
	}

	public String getCredentialFile3No() {
		return credentialFile3No;
	}

	public void setCredentialFile3No(String credentialFile3No) {
		this.credentialFile3No = credentialFile3No;
	}

	public String getCredentialFile4No() {
		return credentialFile4No;
	}

	public void setCredentialFile4No(String credentialFile4No) {
		this.credentialFile4No = credentialFile4No;
	}

	public String getCredentialFile5No() {
		return credentialFile5No;
	}

	public void setCredentialFile5No(String credentialFile5No) {
		this.credentialFile5No = credentialFile5No;
	}

	public List<String> getCredentialFile6No() {
		return credentialFile6No;
	}

	public void setCredentialFile6No(List<String> credentialFile6No) {
		this.credentialFile6No = credentialFile6No;
	}

	public String getCohTxid() {
		return cohTxid;
	}

	public void setCohTxid(String cohTxid) {
		this.cohTxid = cohTxid;
	}

	public String getMsisdnId() {
		return msisdnId;
	}

	public void setMsisdnId(String msisdnId) {
		this.msisdnId = msisdnId;
	}

	public String getVoiceRateId() {
		return voiceRateId;
	}

	public void setVoiceRateId(String voiceRateId) {
		this.voiceRateId = voiceRateId;
	}

	public String getDataRateId() {
		return dataRateId;
	}

	public void setDataRateId(String dataRateId) {
		this.dataRateId = dataRateId;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getCohOrderId() {
		return cohOrderId;
	}

	public void setCohOrderId(String cohOrderId) {
		this.cohOrderId = cohOrderId;
	}

	public String getLastPaymentMethod() {
		return lastPaymentMethod;
	}

	public void setLastPaymentMethod(String lastPaymentMethod) {
		this.lastPaymentMethod = lastPaymentMethod;
	}

	public boolean isPassVipLoyalty() {
		return isPassVipLoyalty;
	}

	public void setPassVipLoyalty(boolean isPassVipLoyalty) {
		this.isPassVipLoyalty = isPassVipLoyalty;
	}

	public Boolean getIsCheckOnceContract9M() {
		return isCheckOnceContract9M;
	}

	public void setIsCheckOnceContract9M(Boolean isCheckOnceContract9M) {
		this.isCheckOnceContract9M = isCheckOnceContract9M;
	}

	public String getTransBpid() {
		return transBpid;
	}

	public void setTransBpid(String transBpid) {
		this.transBpid = transBpid;
	}

	public String getUpgradeType() {
		return upgradeType;
	}

	public void setUpgradeType(String upgradeType) {
		this.upgradeType = upgradeType;
	}

	public List<String> getContentOfferIdList() {
		return contentOfferIdList;
	}

	public void setContentOfferIdList(List<String> contentOfferIdList) {
		this.contentOfferIdList = contentOfferIdList;
	}

	public boolean isMultiprod() {
		return isMultiprod;
	}

	public void setMultiprod(boolean isMultiprod) {
		this.isMultiprod = isMultiprod;
	}

	public List<String> getFetNos() {
		return fetNos;
	}

	public void setFetNos(List<String> fetNos) {
		this.fetNos = fetNos;
	}

	public boolean getNeedOcr() {
		return needOcr;
	}

	public void setNeedOcr(boolean needOcr) {
		this.needOcr = needOcr;
	}

	public String getPromotionListId() {
		return promotionListId;
	}

	public void setPromotionListId(String promotionListId) {
		this.promotionListId = promotionListId;
	}

	public String getHgTotalPoint() {
		return hgTotalPoint;
	}

	public void setHgTotalPoint(String hgTotalPoint) {
		this.hgTotalPoint = hgTotalPoint;
	}

	public String getMpId() {
		return mpId;
	}

	public void setMpId(String mpId) {
		this.mpId = mpId;
	}

	public String getMpIdCheckSum() {
		return mpIdCheckSum;
	}

	public void setMpIdCheckSum(String mpIdCheckSum) {
		this.mpIdCheckSum = mpIdCheckSum;
	}

	public FlowControlBean getFlowControlBean() {
		return flowControlBean;
	}

	public void setFlowControlBean(FlowControlBean flowControlBean) {
		this.flowControlBean = flowControlBean;
	}

	public ANoteVO getaNoteVO() {
		return aNoteVO;
	}

	public void setaNoteVO(ANoteVO aNoteVO) {
		this.aNoteVO = aNoteVO;
	}

	public Boolean getIsOffshoreIsland() {
		return isOffshoreIsland;
	}

	public void setIsOffshoreIsland(Boolean isOffshoreIsland) {
		this.isOffshoreIsland = isOffshoreIsland;
	}

	public Long getOldBillingTypeId() {
		return oldBillingTypeId;
	}

	public void setOldBillingTypeId(Long oldBillingTypeId) {
		this.oldBillingTypeId = oldBillingTypeId;
	}

	public Boolean getCncDeliveryOrder() {
		return cncDeliveryOrder;
	}

	public void setCncDeliveryOrder(Boolean cncDeliveryOrder) {
		this.cncDeliveryOrder = cncDeliveryOrder;
	}

	public Date getApplicantBirthday() {
		return applicantBirthday;
	}

	public void setApplicantBirthday(Date applicantBirthday) {
		this.applicantBirthday = applicantBirthday;
	}

	public boolean isMergeBill() {
		return isMergeBill;
	}

	public void setMergeBill(boolean isMergeBill) {
		this.isMergeBill = isMergeBill;
	}

	public String getMergeBillMsisdn() {
		return mergeBillMsisdn;
	}

	public void setMergeBillMsisdn(String mergeBillMsisdn) {
		this.mergeBillMsisdn = mergeBillMsisdn;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getApplicantRocId() {
		return applicantRocId;
	}

	public void setApplicantRocId(String applicantRocId) {
		this.applicantRocId = applicantRocId;
	}

	public String getApplicantEmail() {
		return applicantEmail;
	}

	public void setApplicantEmail(String applicantEmail) {
		this.applicantEmail = applicantEmail;
	}

	public Address getRegisterAddress() {
		return registerAddress;
	}

	public void setRegisterAddress(Address registerAddress) {
		this.registerAddress = registerAddress;
	}

	public String getTel1() {
		return tel1;
	}

	public void setTel1(String tel1) {
		this.tel1 = tel1;
	}

	public String getPreSelectedHandsetGroupId() {
		return preSelectedHandsetGroupId;
	}

	public void setPreSelectedHandsetGroupId(String preSelectedHandsetGroupId) {
		this.preSelectedHandsetGroupId = preSelectedHandsetGroupId;
	}

	public String getPreSelectedOnsalePromoListId() {
		return preSelectedOnsalePromoListId;
	}

	public void setPreSelectedOnsalePromoListId(String preSelectedOnsalePromoListId) {
		this.preSelectedOnsalePromoListId = preSelectedOnsalePromoListId;
	}

	public String getPreSelectedOrderType() {
		return preSelectedOrderType;
	}

	public void setPreSelectedOrderType(String preSelectedOrderType) {
		this.preSelectedOrderType = preSelectedOrderType;
	}

	public Integer getPreselectedHandsetGroupAmt() {
		return preselectedHandsetGroupAmt;
	}

	public void setPreselectedHandsetGroupAmt(Integer preselectedHandsetGroupAmt) {
		this.preselectedHandsetGroupAmt = preselectedHandsetGroupAmt;
	}

	public boolean isRegisterActivity() {
		return isRegisterActivity;
	}

	public void setRegisterActivity(boolean isRegisterActivity) {
		this.isRegisterActivity = isRegisterActivity;
	}

	public String getHappyGoRocId() {
		return happyGoRocId;
	}

	public void setHappyGoRocId(String happyGoRocId) {
		this.happyGoRocId = happyGoRocId;
	}

	public EntryPointEnum getEntryPoint() {
		return entryPoint;
	}

	public void setEntryPoint(EntryPointEnum entryPoint) {
		this.entryPoint = entryPoint;
	}

	public Integer getEntryNavigationId() {
		return entryNavigationId;
	}

	public void setEntryNavigationId(Integer entryNavigationId) {
		this.entryNavigationId = entryNavigationId;
	}

	public String getActivityStep() {
		return activityStep;
	}

	public void setActivityStep(String activityStep) {
		this.activityStep = activityStep;
	}

	public int getSelectionFee() {
		return selectionFee;
	}

	public void setSelectionFee(int selectionFee) {
		this.selectionFee = selectionFee;
	}

	public boolean isRegisterDemandActivity() {
		return registerDemandActivity;
	}

	public void setRegisterDemandActivity(boolean registerDemandActivity) {
		this.registerDemandActivity = registerDemandActivity;
	}

	public Long getActivityCouponId() {
		return activityCouponId;
	}

	public void setActivityCouponId(Long activityCouponId) {
		this.activityCouponId = activityCouponId;
	}

	public String getLoyaltyToken() {
		return loyaltyToken;
	}

	public void setLoyaltyToken(String loyaltyToken) {
		this.loyaltyToken = loyaltyToken;
	}

	public String getNpCompanyCode() {
		return npCompanyCode;
	}

	public void setNpCompanyCode(String npCompanyCode) {
		this.npCompanyCode = npCompanyCode;
	}

	public String getTelPrefix1() {
		return telPrefix1;
	}

	public void setTelPrefix1(String telPrefix1) {
		this.telPrefix1 = telPrefix1;
	}

	public String getTelPrefix2() {
		return telPrefix2;
	}

	public void setTelPrefix2(String telPrefix2) {
		this.telPrefix2 = telPrefix2;
	}

	public String getTel2() {
		return tel2;
	}

	public void setTel2(String tel2) {
		this.tel2 = tel2;
	}

	public List<String> getExtraVaServiceIds() {
		return extraVaServiceIds;
	}

	public void setExtraVaServiceIds(List<String> extraVaServiceIds) {
		this.extraVaServiceIds = extraVaServiceIds;
	}

	public String getDeliTime() {
		return deliTime;
	}

	public void setDeliTime(String deliTime) {
		this.deliTime = deliTime;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getReceiverRocId() {
		return receiverRocId;
	}

	public void setReceiverRocId(String receiverRocId) {
		this.receiverRocId = receiverRocId;
	}

	public String getReceiverTelPrefix1() {
		return receiverTelPrefix1;
	}

	public void setReceiverTelPrefix1(String receiverTelPrefix1) {
		this.receiverTelPrefix1 = receiverTelPrefix1;
	}

	public String getReceiverTel1() {
		return receiverTel1;
	}

	public void setReceiverTel1(String receiverTel1) {
		this.receiverTel1 = receiverTel1;
	}

	public String getReceiverTelPrefix2() {
		return receiverTelPrefix2;
	}

	public void setReceiverTelPrefix2(String receiverTelPrefix2) {
		this.receiverTelPrefix2 = receiverTelPrefix2;
	}

	public String getReceiverTel2() {
		return receiverTel2;
	}

	public void setReceiverTel2(String receiverTel2) {
		this.receiverTel2 = receiverTel2;
	}

	public String getStoreReceiverName() {
		return storeReceiverName;
	}

	public void setStoreReceiverName(String storeReceiverName) {
		this.storeReceiverName = storeReceiverName;
	}

	public String getStoreReceiverRocId() {
		return storeReceiverRocId;
	}

	public void setStoreReceiverRocId(String storeReceiverRocId) {
		this.storeReceiverRocId = storeReceiverRocId;
	}

	public String getStoreTelPrefix1() {
		return storeTelPrefix1;
	}

	public void setStoreTelPrefix1(String storeTelPrefix1) {
		this.storeTelPrefix1 = storeTelPrefix1;
	}

	public String getStoreTel1() {
		return storeTel1;
	}

	public void setStoreTel1(String storeTel1) {
		this.storeTel1 = storeTel1;
	}

	public String getStoreTelPrefix2() {
		return storeTelPrefix2;
	}

	public void setStoreTelPrefix2(String storeTelPrefix2) {
		this.storeTelPrefix2 = storeTelPrefix2;
	}

	public String getStoreTel2() {
		return storeTel2;
	}

	public void setStoreTel2(String storeTel2) {
		this.storeTel2 = storeTel2;
	}

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean isInvoiceDemand() {
		return isInvoiceDemand;
	}

	public void setInvoiceDemand(boolean isInvoiceDemand) {
		this.isInvoiceDemand = isInvoiceDemand;
	}

	public String getVatNo() {
		return vatNo;
	}

	public void setVatNo(String vatNo) {
		this.vatNo = vatNo;
	}

	public String getVatTitle() {
		return vatTitle;
	}

	public void setVatTitle(String vatTitle) {
		this.vatTitle = vatTitle;
	}

	public boolean isAddOnReceiver() {
		return addOnReceiver;
	}

	public void setAddOnReceiver(boolean addOnReceiver) {
		this.addOnReceiver = addOnReceiver;
	}

	public String getDeliAlt() {
		return deliAlt;
	}

	public void setDeliAlt(String deliAlt) {
		this.deliAlt = deliAlt;
	}

	public String getHgToken() {
		return hgToken;
	}

	public void setHgToken(String hgToken) {
		this.hgToken = hgToken;
	}

	public Long getHgRedeemId() {
		return hgRedeemId;
	}

	public void setHgRedeemId(Long hgRedeemId) {
		this.hgRedeemId = hgRedeemId;
	}

	public boolean isHappyGoRedeemed() {
		return happyGoRedeemed;
	}

	public void setHappyGoRedeemed(boolean happyGoRedeemed) {
		this.happyGoRedeemed = happyGoRedeemed;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public boolean isClickFinish() {
		return clickFinish;
	}

	public void setClickFinish(boolean clickFinish) {
		this.clickFinish = clickFinish;
	}

	public boolean isOrderSustained() {
		return orderSustained;
	}

	public void setOrderSustained(boolean orderSustained) {
		this.orderSustained = orderSustained;
	}

	public boolean isAcceptSms() {
		return acceptSms;
	}

	public void setAcceptSms(boolean acceptSms) {
		this.acceptSms = acceptSms;
	}

	public String getCallingcardTicket() {
		return callingcardTicket;
	}

	public void setCallingcardTicket(String callingcardTicket) {
		this.callingcardTicket = callingcardTicket;
	}

	public String getExitMsg() {
		return exitMsg;
	}

	public void setExitMsg(String exitMsg) {
		this.exitMsg = exitMsg;
	}

	public String getPackageBrowsingStatisticId() {
		return packageBrowsingStatisticId;
	}

	public void setPackageBrowsingStatisticId(String packageBrowsingStatisticId) {
		this.packageBrowsingStatisticId = packageBrowsingStatisticId;
	}

	public Long getLeftPriceToDiscountForDevice() {
		return leftPriceToDiscountForDevice;
	}

	public void setLeftPriceToDiscountForDevice(Long leftPriceToDiscountForDevice) {
		this.leftPriceToDiscountForDevice = leftPriceToDiscountForDevice;
	}

	public Long getLeftPriceToDiscountForAccessory() {
		return leftPriceToDiscountForAccessory;
	}

	public void setLeftPriceToDiscountForAccessory(Long leftPriceToDiscountForAccessory) {
		this.leftPriceToDiscountForAccessory = leftPriceToDiscountForAccessory;
	}

	public String getEinvoiceDeviceType() {
		return einvoiceDeviceType;
	}

	public void setEinvoiceDeviceType(String einvoiceDeviceType) {
		this.einvoiceDeviceType = einvoiceDeviceType;
	}

	public String getEinvoiceDeviceId() {
		return einvoiceDeviceId;
	}

	public void setEinvoiceDeviceId(String einvoiceDeviceId) {
		this.einvoiceDeviceId = einvoiceDeviceId;
	}

	public String getDonateUnitId() {
		return donateUnitId;
	}

	public void setDonateUnitId(String donateUnitId) {
		this.donateUnitId = donateUnitId;
	}

	public String getDonateUnitName() {
		return donateUnitName;
	}

	public void setDonateUnitName(String donateUnitName) {
		this.donateUnitName = donateUnitName;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getPreorderNo() {
		return preorderNo;
	}

	public void setPreorderNo(String preorderNo) {
		this.preorderNo = preorderNo;
	}

	public boolean isMobileWeb() {
		return isMobileWeb;
	}

	public void setMobileWeb(boolean isMobileWeb) {
		this.isMobileWeb = isMobileWeb;
	}

	public boolean isWebtrendRecorded() {
		return webtrendRecorded;
	}

	public void setWebtrendRecorded(boolean webtrendRecorded) {
		this.webtrendRecorded = webtrendRecorded;
	}

	public Date getHgRedeemTime() {
		return hgRedeemTime;
	}

	public void setHgRedeemTime(Date hgRedeemTime) {
		this.hgRedeemTime = hgRedeemTime;
	}

	public boolean isAppFlow() {
		return appFlow;
	}

	public void setAppFlow(boolean appFlow) {
		this.appFlow = appFlow;
	}

	public String getRecommendSource() {
		return recommendSource;
	}

	public void setRecommendSource(String recommendSource) {
		this.recommendSource = recommendSource;
	}

	public String getRecommendDesc() {
		return recommendDesc;
	}

	public void setRecommendDesc(String recommendDesc) {
		this.recommendDesc = recommendDesc;
	}

	public String getMvpnVatNo() {
		return mvpnVatNo;
	}

	public void setMvpnVatNo(String mvpnVatNo) {
		this.mvpnVatNo = mvpnVatNo;
	}

	public String getMvpnStr() {
		return mvpnStr;
	}

	public void setMvpnStr(String mvpnStr) {
		this.mvpnStr = mvpnStr;
	}

	public Boolean getNetCoverRate() {
		return netCoverRate;
	}

	public void setNetCoverRate(Boolean netCoverRate) {
		this.netCoverRate = netCoverRate;
	}

	public String getCspMsisdn() {
		return cspMsisdn;
	}

	public void setCspMsisdn(String cspMsisdn) {
		this.cspMsisdn = cspMsisdn;
	}

	public String getAppSource() {
		return appSource;
	}

	public void setAppSource(String appSource) {
		this.appSource = appSource;
	}

	public String getO2oOrderId() {
		return o2oOrderId;
	}

	public void setO2oOrderId(String o2oOrderId) {
		this.o2oOrderId = o2oOrderId;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getTrial() {
		return trial;
	}

	public void setTrial(String trial) {
		this.trial = trial;
	}

	public String getNcRocId() {
		return ncRocId;
	}

	public void setNcRocId(String ncRocId) {
		this.ncRocId = ncRocId;
	}

	public String getPaymentConsolidation() {
		return paymentConsolidation;
	}

	public void setPaymentConsolidation(String paymentConsolidation) {
		this.paymentConsolidation = paymentConsolidation;
	}

	public String getPaymentConsolidationError() {
		return paymentConsolidationError;
	}

	public void setPaymentConsolidationError(String paymentConsolidationError) {
		this.paymentConsolidationError = paymentConsolidationError;
	}

	public Long getNameListId() {
		return nameListId;
	}

	public void setNameListId(Long nameListId) {
		this.nameListId = nameListId;
	}

	public Date getIdCardDate() {
		return idCardDate;
	}

	public void setIdCardDate(Date idCardDate) {
		this.idCardDate = idCardDate;
	}

	public String getIdCardCity() {
		return idCardCity;
	}

	public void setIdCardCity(String idCardCity) {
		this.idCardCity = idCardCity;
	}

	public String getIdCardType() {
		return idCardType;
	}

	public void setIdCardType(String idCardType) {
		this.idCardType = idCardType;
	}

	public String getMultiprodId() {
		return multiprodId;
	}

	public void setMultiprodId(String multiprodId) {
		this.multiprodId = multiprodId;
	}

	public List<String> getProductIds() {
		return productIds;
	}

	public void setProductIds(List<String> productIds) {
		this.productIds = productIds;
	}

	public Long getMultiprodNameListId() {
		return multiprodNameListId;
	}

	public void setMultiprodNameListId(Long multiprodNameListId) {
		this.multiprodNameListId = multiprodNameListId;
	}

	public String getMinisiteActivityId() {
		return minisiteActivityId;
	}

	public void setMinisiteActivityId(String minisiteActivityId) {
		this.minisiteActivityId = minisiteActivityId;
	}

	public String getMdmAccountId() {
		return mdmAccountId;
	}

	public void setMdmAccountId(String mdmAccountId) {
		this.mdmAccountId = mdmAccountId;
	}

	public String getMdmSubscriberId() {
		return mdmSubscriberId;
	}

	public void setMdmSubscriberId(String mdmSubscriberId) {
		this.mdmSubscriberId = mdmSubscriberId;
	}

	public String getMdmCustomerId() {
		return mdmCustomerId;
	}

	public void setMdmCustomerId(String mdmCustomerId) {
		this.mdmCustomerId = mdmCustomerId;
	}

	public boolean isLy3to4() {
		return ly3to4;
	}

	public void setLy3to4(boolean ly3to4) {
		this.ly3to4 = ly3to4;
	}

	public Long getPrepaymentPrice() {
		return prepaymentPrice;
	}

	public void setPrepaymentPrice(Long prepaymentPrice) {
		this.prepaymentPrice = prepaymentPrice;
	}

	public boolean isAddAnoteSuccess() {
		return addAnoteSuccess;
	}

	public void setAddAnoteSuccess(boolean addAnoteSuccess) {
		this.addAnoteSuccess = addAnoteSuccess;
	}

	public boolean isAddGiftRedeem() {
		return addGiftRedeem;
	}

	public void setAddGiftRedeem(boolean addGiftRedeem) {
		this.addGiftRedeem = addGiftRedeem;
	}

	public Map<String, List<ProductHelperVO>> getMasterProductMap() {
		return masterProductMap;
	}

	public void setMasterProductMap(Map<String, List<ProductHelperVO>> masterProductMap) {
		this.masterProductMap = masterProductMap;
	}

	public Map<String, List<ProductHelperVO>> getSlaveProductMap() {
		return slaveProductMap;
	}

	public void setSlaveProductMap(Map<String, List<ProductHelperVO>> slaveProductMap) {
		this.slaveProductMap = slaveProductMap;
	}

	public boolean isNba324() {
		return isNba324;
	}

	public void setNba324(boolean isNba324) {
		this.isNba324 = isNba324;
	}

	public String getSimcardNo() {
		return simcardNo;
	}

	public void setSimcardNo(String simcardNo) {
		this.simcardNo = simcardNo;
	}

	public boolean isCobranding() {
		return isCobranding;
	}

	public void setCobranding(boolean isCobranding) {
		this.isCobranding = isCobranding;
	}

	public boolean isNeilOrder() {
		return neilOrder;
	}

	public void setNeilOrder(boolean neilOrder) {
		this.neilOrder = neilOrder;
	}

	public String getNeilCono() {
		return neilCono;
	}

	public void setNeilCono(String neilCono) {
		this.neilCono = neilCono;
	}

	public boolean isAgreeReturnSpeedup() {
		return agreeReturnSpeedup;
	}

	public void setAgreeReturnSpeedup(boolean agreeReturnSpeedup) {
		this.agreeReturnSpeedup = agreeReturnSpeedup;
	}

	public String getLoyaltyRecordId() {
		return loyaltyRecordId;
	}

	public void setLoyaltyRecordId(String loyaltyRecordId) {
		this.loyaltyRecordId = loyaltyRecordId;
	}

	public int getInstallments() {
		return installments;
	}

	public void setInstallments(int installments) {
		this.installments = installments;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getNpxCono() {
		return npxCono;
	}

	public void setNpxCono(String npxCono) {
		this.npxCono = npxCono;
	}

	public String getNpxTxid() {
		return npxTxid;
	}

	public void setNpxTxid(String npxTxid) {
		this.npxTxid = npxTxid;
	}

	public String getDspUserProfileUuid() {
		return dspUserProfileUuid;
	}

	public void setDspUserProfileUuid(String dspUserProfileUuid) {
		this.dspUserProfileUuid = dspUserProfileUuid;
	}

	public String getJsonString() {
		return jsonString;
	}

	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}

	public String getDeliTel() {
		return deliTel;
	}

	public void setDeliTel(String deliTel) {
		this.deliTel = deliTel;
	}

	public boolean isRegAsBill() {
		return regAsBill;
	}

	public void setRegAsBill(boolean regAsBill) {
		this.regAsBill = regAsBill;
	}

	public boolean isRegAsAddr() {
		return regAsAddr;
	}

	public void setRegAsAddr(boolean regAsAddr) {
		this.regAsAddr = regAsAddr;
	}

	public String getVatTp() {
		return vatTp;
	}

	public void setVatTp(String vatTp) {
		this.vatTp = vatTp;
	}

	public boolean isAgreeContract() {
		return agreeContract;
	}

	public void setAgreeContract(boolean agreeContract) {
		this.agreeContract = agreeContract;
	}

	public String getBackFromUri() {
		return backFromUri;
	}

	public void setBackFromUri(String backFromUri) {
		this.backFromUri = backFromUri;
	}

	public String getOrderChannel() {
		return orderChannel;
	}

	public void setOrderChannel(String orderChannel) {
		this.orderChannel = orderChannel;
	}

	public String getCsStoreCvsid() {
		return csStoreCvsid;
	}

	public void setCsStoreCvsid(String csStoreCvsid) {
		this.csStoreCvsid = csStoreCvsid;
	}

	public String getCsStoreCvsname() {
		return csStoreCvsname;
	}

	public void setCsStoreCvsname(String csStoreCvsname) {
		this.csStoreCvsname = csStoreCvsname;
	}

	public String getCsStoreNo() {
		return csStoreNo;
	}

	public void setCsStoreNo(String csStoreNo) {
		this.csStoreNo = csStoreNo;
	}

	public String getCsStoreName() {
		return csStoreName;
	}

	public void setCsStoreName(String csStoreName) {
		this.csStoreName = csStoreName;
	}

	public String getCsStoreTel() {
		return csStoreTel;
	}

	public void setCsStoreTel(String csStoreTel) {
		this.csStoreTel = csStoreTel;
	}

	public String getCsStoreAddress() {
		return csStoreAddress;
	}

	public void setCsStoreAddress(String csStoreAddress) {
		this.csStoreAddress = csStoreAddress;
	}

	public String getCsStoreAreaCode() {
		return csStoreAreaCode;
	}

	public void setCsStoreAreaCode(String csStoreAreaCode) {
		this.csStoreAreaCode = csStoreAreaCode;
	}

	public String getExtraService() {
		return extraService;
	}

	public void setExtraService(String extraService) {
		this.extraService = extraService;
	}

	public boolean isSelfHelpingPromotion() {
		return isSelfHelpingPromotion;
	}

	public void setSelfHelpingPromotion(boolean isSelfHelpingPromotion) {
		this.isSelfHelpingPromotion = isSelfHelpingPromotion;
	}

	public String getSelfHelpingPromotionName() {
		return selfHelpingPromotionName;
	}

	public void setSelfHelpingPromotionName(String selfHelpingPromotionName) {
		this.selfHelpingPromotionName = selfHelpingPromotionName;
	}

	public String getSelfHelpingPromotion1() {
		return selfHelpingPromotion1;
	}

	public void setSelfHelpingPromotion1(String selfHelpingPromotion1) {
		this.selfHelpingPromotion1 = selfHelpingPromotion1;
	}

	public String getSelfHelpingPromotion2() {
		return selfHelpingPromotion2;
	}

	public void setSelfHelpingPromotion2(String selfHelpingPromotion2) {
		this.selfHelpingPromotion2 = selfHelpingPromotion2;
	}

	public String getSelfHelpingPromotion3() {
		return selfHelpingPromotion3;
	}

	public void setSelfHelpingPromotion3(String selfHelpingPromotion3) {
		this.selfHelpingPromotion3 = selfHelpingPromotion3;
	}

	public String getFridayOrderType() {
		return fridayOrderType;
	}

	public void setFridayOrderType(String fridayOrderType) {
		this.fridayOrderType = fridayOrderType;
	}

	public String getFridayOrderNo() {
		return fridayOrderNo;
	}

	public void setFridayOrderNo(String fridayOrderNo) {
		this.fridayOrderNo = fridayOrderNo;
	}

	public boolean isFirday() {
		return isFirday;
	}

	public void setFirday(boolean isFirday) {
		this.isFirday = isFirday;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public String getrId() {
		return rId;
	}

	public void setrId(String rId) {
		this.rId = rId;
	}

	public String getClickId() {
		return clickId;
	}

	public void setClickId(String clickId) {
		this.clickId = clickId;
	}

	public boolean isFromMarketAmerica() {
		return isFromMarketAmerica;
	}

	public void setFromMarketAmerica(boolean isFromMarketAmerica) {
		this.isFromMarketAmerica = isFromMarketAmerica;
	}

	public boolean isInsurance() {
		return isInsurance;
	}

	public void setInsurance(boolean isInsurance) {
		this.isInsurance = isInsurance;
	}

	public boolean isPremium() {
		return isPremium;
	}

	public void setPremium(boolean isPremium) {
		this.isPremium = isPremium;
	}

	public String getPremiumTitle() {
		return premiumTitle;
	}

	public void setPremiumTitle(String premiumTitle) {
		this.premiumTitle = premiumTitle;
	}

	public Integer getPremiumBuyCount() {
		return premiumBuyCount;
	}

	public void setPremiumBuyCount(Integer premiumBuyCount) {
		this.premiumBuyCount = premiumBuyCount;
	}

	public Map<Long, Integer> getPremiumGroup1() {
		return premiumGroup1;
	}

	public void setPremiumGroup1(Map<Long, Integer> premiumGroup1) {
		this.premiumGroup1 = premiumGroup1;
	}

	public Map<Long, Integer> getPremiumGroup2() {
		return premiumGroup2;
	}

	public void setPremiumGroup2(Map<Long, Integer> premiumGroup2) {
		this.premiumGroup2 = premiumGroup2;
	}

	public String getEbuVatNo() {
		return ebuVatNo;
	}

	public void setEbuVatNo(String ebuVatNo) {
		this.ebuVatNo = ebuVatNo;
	}

	public String getEbuVatTitle() {
		return ebuVatTitle;
	}

	public void setEbuVatTitle(String ebuVatTitle) {
		this.ebuVatTitle = ebuVatTitle;
	}

	public String getEbuRecomName() {
		return ebuRecomName;
	}

	public void setEbuRecomName(String ebuRecomName) {
		this.ebuRecomName = ebuRecomName;
	}

	public String getEbuRecomMsisdn() {
		return ebuRecomMsisdn;
	}

	public void setEbuRecomMsisdn(String ebuRecomMsisdn) {
		this.ebuRecomMsisdn = ebuRecomMsisdn;
	}

	public String getUploadImagePageSidByAPP() {
		return uploadImagePageSidByAPP;
	}

	public void setUploadImagePageSidByAPP(String uploadImagePageSidByAPP) {
		this.uploadImagePageSidByAPP = uploadImagePageSidByAPP;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getXff() {
		return xff;
	}

	public void setXff(String xff) {
		this.xff = xff;
	}

	public String getDelayChoose() {
		return delayChoose;
	}

	public void setDelayChoose(String delayChoose) {
		this.delayChoose = delayChoose;
	}

	public String getApplicantSignType() {
		return ApplicantSignType;
	}

	public void setApplicantSignType(String applicantSignType) {
		ApplicantSignType = applicantSignType;
	}

	public Map<String, String> getOcrAttrMap() {
		return ocrAttrMap;
	}

	public void setOcrAttrMap(Map<String, String> ocrAttrMap) {
		this.ocrAttrMap = ocrAttrMap;
	}
	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	//20200909 Dennis.CHen 新增CoPayType 付款方式
	public String getCoPayType() {
		return coPayType;
	}

	public void setCoPayType(String coPayType) {
		this.coPayType = coPayType;
	}

	//20200831 Dennis.Chen 搬回舊的
	public List<String> getVaServices() {
		return vaServices;
	}

	public void setVaServices(List<String> vaServices) {
		this.vaServices = vaServices;
	}

	public Map<String, ProductHelperVO> getAccessoryMap() {
		
		if (cart == null || cart.getList() == null) {
			return accessoryMap;
		}
		
		return cart.getList().stream().map(o->{
			ProductHelperVO productHelper = new ProductHelperVO();
			productHelper.setFetNo(o.getDefaultFetNo());
			productHelper.setQuantity(o.getNumber());
			productHelper.setUuid(null);
			productHelper.setMarkupProduct(false);
			productHelper.setMpActivityId(null);
			productHelper.setMpActivityProductDiscountId(null);
			productHelper.setGroupNumber(0);

			return productHelper;
		}).collect(Collectors.toMap(o->o.getFetNo(), o->o));
		
//		return accessoryMap;
	}

	public void setAccessoryMap(Map<String, ProductHelperVO> accessoryMap) {
		this.accessoryMap = accessoryMap;
	}

	public String getLastPaymentMethodAns() {
		return lastPaymentMethodAns;
	}

	public void setLastPaymentMethodAns(String lastPaymentMethodAns) {
		this.lastPaymentMethodAns = lastPaymentMethodAns;
	}

	public List<String> getAddtionPurchaseFetNos() {
		return addtionPurchaseFetNos;
	}

	public void setAddtionPurchaseFetNos(List<String> addtionPurchaseFetNos) {
		this.addtionPurchaseFetNos = addtionPurchaseFetNos;
	}

	public Map<String, ProductHelperVO> getHandsetGroupMap() {
		return handsetGroupMap;
	}

	public void setHandsetGroupMap(Map<String, ProductHelperVO> handsetGroupMap) {
		this.handsetGroupMap = handsetGroupMap;
	}

	public void setNewBillingTypeId(Long newBillingTypeId) {
		this.newBillingTypeId = newBillingTypeId;
	}

	public Long getNewBillingTypeId() {
		return newBillingTypeId;
	}

	public JSONArray getExtraBuy() {
		if(this.jsonString == null) {
			return new JSONArray();
		}

		JSONObject jsonObject = JSONObject.fromObject(this.jsonString);


		Object testObject = jsonObject.get("extraBuy");
		if(!(testObject instanceof JSONArray)) {
			return new JSONArray();
		}else {
			return jsonObject.getJSONArray("extraBuy");
		}

	}

	public void setDeliAddress(String cityCode, String areaCode, String textAddress, String sameAs, String sixZipCode){
		for(Address address : this.addresses){
			if(Address.ADDRESS_TYPE_DELIVERY.equals(address.getAddressType())){
				this.addresses.remove(address);
				break;
			}
		}
		Address address = new Address(cityCode, areaCode, textAddress, Address.ADDRESS_TYPE_DELIVERY, sameAs);
		address.setSixZipCode(sixZipCode);
		this.addresses.add(address);
	}

	public Address getDeliAddress(){
		return this.getAddress(Address.ADDRESS_TYPE_DELIVERY);
	}

	public void setBillAddress(String cityCode, String areaCode, String textAddress, String sameAs){
		for(Address address : this.addresses){
			if(Address.ADDRESS_TYPE_BILL.equals(address.getAddressType())){
				this.addresses.remove(address);
				break;
			}
		}
		Address address = new Address(cityCode, areaCode, textAddress, Address.ADDRESS_TYPE_BILL, sameAs);
		this.addresses.add(address);
	}

	public Address getBillAddress(){
		return this.getAddress(Address.ADDRESS_TYPE_BILL);
	}

	public void setVatAddress(String cityCode, String areaCode, String textAddress, String sameAs, String sixZipCode){
		Address address = new Address(cityCode, areaCode, textAddress, Address.ADDRESS_TYPE_VAT, sameAs);
		address.setSixZipCode(sixZipCode);
		this.addresses.add(address);
	}

	public Address getVatAddress(){
		return this.getAddress(Address.ADDRESS_TYPE_VAT);
	}

	private Address getAddress(String addressType){
		for(int i=0; i< addresses.size(); i++){
			if(addresses.get(i).getAddressType().equals(addressType)){
				return this.addresses.get(i);
			}
		}

		return null;
	}

	public List<IdAndQuantityPairHelper> getHandsetGroup() {
		List<IdAndQuantityPairHelper> handsetGroups = new ArrayList<IdAndQuantityPairHelper>();
		
		if(fetNo == null) {
			return handsetGroups;
		}
		
		// TODO : 多主商品時要修正此邏輯
		IdAndQuantityPairHelper pair = new IdAndQuantityPairHelper();
		
		// TODO : 測試用
		pair.setId(fetNo);
		pair.setQuantity(number);
		pair.setUuid(null);
		pair.setMarkupProduct(false);
		pair.setMpActivityId(null);
		pair.setMpActivityProductDiscountId(null);
		pair.setGroupNumber(0);
		
		
		handsetGroups.add(pair);
		
		
//		Set<String> keys = this.handsetGroupMap.keySet();
//		for (String key : keys) {
//			IdAndQuantityPairHelper pair = new IdAndQuantityPairHelper();
//
//			String fetNo = null;
//			if (key.indexOf("_") >= 0) {
//				fetNo = key.substring(0, key.indexOf("_"));
//			} else {
//				fetNo = key;
//			}
//
//			ProductHelperVO vo = this.handsetGroupMap.get(key);
//
//			boolean createNewVO = true;
//			for (IdAndQuantityPairHelper myPair : handsetGroups) {
//				if (myPair.getId().equals(fetNo)) {
//					myPair.setQuantity(myPair.getQuantity() + vo.getQuantity());
//					createNewVO = false;
//					break;
//				}
//			}
//			if (!createNewVO) {
//				break;
//			}
//			pair.setId(fetNo);
//			pair.setQuantity(vo.getQuantity());
//			pair.setUuid(vo.getUuid());
//			pair.setMarkupProduct(vo.isMarkupProduct());
//			pair.setMpActivityId(vo.getMpActivityId());
//			pair.setMpActivityProductDiscountId(vo.getMpActivityProductDiscountId());
//			pair.setGroupNumber(vo.getGroupNumber());
//			handsetGroups.add(pair);
//		}
		
		
		return handsetGroups;
	}
	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}
	
	public List<IdAndQuantityPairHelper> getAccessory(){
		List<IdAndQuantityPairHelper> accessories = new ArrayList<IdAndQuantityPairHelper>();
		if(this.getCart() == null) {
			return accessories;
		}
		for(CartItem cart : this.getCart().getList()) {
			IdAndQuantityPairHelper pair = new IdAndQuantityPairHelper();
			pair.setId(cart.getDefaultFetNo());
			pair.setQuantity(cart.getNumber());
			pair.setUuid(null);
			pair.setMarkupProduct(false);
			pair.setMpActivityId(null);
			pair.setMpActivityProductDiscountId(null);
			pair.setGroupNumber(0);
			accessories.add(pair);
		}

//		Set<String> keys = this.accessoryMap.keySet();
//		for(String key: keys){
//			IdAndQuantityPairHelper pair = new IdAndQuantityPairHelper();
//			
//			String fetNo = null;
//			if(key.indexOf("_") >= 0){
//				fetNo = key.substring(0, key.indexOf("_"));
//			}else{
//				fetNo = key;
//			}
//			ProductHelperVO vo = this.accessoryMap.get(key);
//			
//			boolean createNewPairVO = true;
//			for(IdAndQuantityPairHelper myPair : accessories){
//				if(myPair.getId().equals(fetNo)){
//					myPair.setQuantity(myPair.getQuantity() + vo.getQuantity());
//					createNewPairVO = false;
//					break;
//				}
//			}
//			if(!createNewPairVO){
//				break;
//			}
//			
//			
//			pair.setId(fetNo);
//			pair.setQuantity(vo.getQuantity());
//			pair.setUuid(vo.getUuid());
//			pair.setMarkupProduct(vo.isMarkupProduct());
//			pair.setMpActivityId(vo.getMpActivityId());
//			pair.setMpActivityProductDiscountId(vo.getMpActivityProductDiscountId());
//			pair.setGroupNumber(vo.getGroupNumber());
//			accessories.add(pair);
//		}
		return accessories;
	}

	public String getForbidMsisdn() {
		return forbidMsisdn;
	}

	public void setForbidMsisdn(String forbidMsisdn) {
		this.forbidMsisdn = forbidMsisdn;
	}

	public String getCredentialType() {
		return credentialType;
	}

	public void setCredentialType(String credentialType) {
		this.credentialType = credentialType;
	}

	public String getAfterCreditResult() {
		return afterCreditResult;
	}

	public void setAfterCreditResult(String afterCreditResult) {
		this.afterCreditResult = afterCreditResult;
	}

	public String getAfterCreditErrMsg() {
		return afterCreditErrMsg;
	}

	public void setAfterCreditErrMsg(String afterCreditErrMsg) {
		this.afterCreditErrMsg = afterCreditErrMsg;
	}

	public List<PremiumDiscountProd> getExtraBuyList() {
		return extraBuyList;
	}

	public void setExtraBuyList(List<PremiumDiscountProd> extraBuyList) {
		this.extraBuyList = extraBuyList;
	}

	public List<PremiumDiscountProd> getGiftList() {
		return giftList;
	}

	public void setGiftList(List<PremiumDiscountProd> giftList) {
		this.giftList = giftList;
	}

	public OrderDiscountResult getPaymentPageDiscount() {
		return paymentPageDiscount;
	}

	public void setPaymentPageDiscount(OrderDiscountResult paymentPageDiscount) {
		this.paymentPageDiscount = paymentPageDiscount;
	}

	public Boolean getAnotePrepayCounted() {
		return anotePrepayCounted;
	}

	public void setAnotePrepayCounted(Boolean anotePrepayCounted) {
		this.anotePrepayCounted = anotePrepayCounted;
	}

	public String getCrossCooperationOrderNo() {
		return crossCooperationOrderNo;
	}
	
	public CrossCooperationData getCrossCooperationData() {
		return crossCooperationData;
	}
	
	public void setCrossCooperationData(CrossCooperationData crossCooperationData) {
		this.crossCooperationData = crossCooperationData;
	}

	public void setCrossCooperationOrderNo(String crossCooperationOrderNo) {
		this.crossCooperationOrderNo = crossCooperationOrderNo;
	}

	public boolean getIsStudentPromotion() {
		return isStudentPromotion;
	}

	public void setIsStudentPromotion(boolean isStudentPromotion) {
		this.isStudentPromotion = isStudentPromotion;
	}

	public IdNum1 getIdNum1() {
		return idNum1;
	}

	public void setIdNum1(IdNum1 idNum1) {
		this.idNum1 = idNum1;
	}

	public IdNum2 getIdNum2() {
		return idNum2;
	}

	public void setIdNum2(IdNum2 idNum2) {
		this.idNum2 = idNum2;
	}

	public IdNum31 getIdNum31() {
		return idNum31;
	}

	public void setIdNum31(IdNum31 idNum31) {
		this.idNum31 = idNum31;
	}

	public IdNum41 getIdNum41() {
		return idNum41;
	}

	public void setIdNum41(IdNum41 idNum41) {
		this.idNum41 = idNum41;
	}

	public String getIdNum1ocrSN() {
		return idNum1ocrSN;
	}

	public void setIdNum1ocrSN(String idNum1ocrSN) {
		this.idNum1ocrSN = idNum1ocrSN;
	}

	public Address getOcrVailAddr() {
		return ocrVailAddr;
	}

	public void setOcrVailAddr(Address ocrVailAddr) {
		this.ocrVailAddr = ocrVailAddr;
	}

	public List<String> getOcrSn() {
		return ocrSn;
	}

	public void setOcrSn(List<String> ocrSn) {
		this.ocrSn = ocrSn;
	}

	public List<UploadFileInfo> getUploadFileInfoList() {
		return uploadFileInfoList;
	}

	public void setUploadFileInfoList(List<UploadFileInfo> uploadFileInfoList) {
		this.uploadFileInfoList = uploadFileInfoList;
	}

	public String getStaffType() {
		return staffType;
	}

	public void setStaffType(String staffType) {
		this.staffType = staffType;
	}

	public String getUserDeliveryType() {
		return userDeliveryType;
	}

	public void setUserDeliveryType(String userDeliveryType) {
		this.userDeliveryType = userDeliveryType;
	}
}
