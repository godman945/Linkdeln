package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CoHistory;

public interface NCoHistoryDAO extends BaseDAO<CoHistory, String> {

}
