package com.fet.estore.core.bean;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-15
 * @description
 */
public class EstorePromotion {

    private String title;

    private String subtitle;

    private EstorePromotionAction action;

    private EstorePromotionImage image;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public EstorePromotionAction getAction() {
        return action;
    }

    public void setAction(EstorePromotionAction action) {
        this.action = action;
    }

    public EstorePromotionImage getImage() {
        return image;
    }

    public void setImage(EstorePromotionImage image) {
        this.image = image;
    }
}
