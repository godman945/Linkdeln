package com.fet.estore.core.bean.vo;

import java.util.Date;

public class MayannVO implements java.io.Serializable {
	
	private static final long serialVersionUID = 481040969903160844L;

	String cono;
	String rId;
	String clickId;
	Long activityId;
	String coDate;
	Long monthPrice;
	Long limit;
	Long dataLimit;
	String activationDate;
	String mvpnServiceDate;
	String coType;
	
	public String getCono() {
		return cono;
	}
	public void setCono(String cono) {
		this.cono = cono;
	}
	public String getrId() {
		return rId;
	}
	public void setrId(String rId) {
		this.rId = rId;
	}
	public String getClickId() {
		return clickId;
	}
	public void setClickId(String clickId) {
		this.clickId = clickId;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getCoDate() {
		return coDate;
	}
	public void setCoDate(String coDate) {
		this.coDate = coDate;
	}
	public Long getMonthPrice() {
		return monthPrice;
	}
	public void setMonthPrice(Long monthPrice) {
		this.monthPrice = monthPrice;
	}
	public Long getLimit() {
		return limit;
	}
	public void setLimit(Long limit) {
		this.limit = limit;
	}
	public Long getDataLimit() {
		return dataLimit;
	}
	public void setDataLimit(Long dataLimit) {
		this.dataLimit = dataLimit;
	}
	public String getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}
	public String getMvpnServiceDate() {
		return mvpnServiceDate;
	}
	public void setMvpnServiceDate(String mvpnServiceDate) {
		this.mvpnServiceDate = mvpnServiceDate;
	}
	public String getCoType() {
		return coType;
	}
	public void setCoType(String coType) {
		this.coType = coType;
	}
	
}
