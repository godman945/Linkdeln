package com.fet.estore.core.bean.vo.frontend;

public class ShoppingGuidePriceVO {
	
	
	private Long totalPrice = 0L;
	
	private Long prepaidPrice = 0L;
	
	private Long shipmentFee = 0L;
	
	private Long devicePrice = 0L;
	
	private Long accessoryPrice = 0L;
	
	private Long additionPurchasePrice = 0L;
	
	private Long couponDiscountPrice = 0L;
	
	private Long hgDiscountPrice = 0L;
	
	
	
	boolean passCouponHandsetCheck;
	boolean passCouponAccessoryCheck;
	boolean passCouponPromotionCheck;
	boolean passCouponDeliveryTypeCheck;
	boolean passCouponTotalPriceCheck;
	boolean passCouponHandsetTotalPriceCheck;
	boolean passCouponAccessoryTotalPriceCheck;
	boolean passCouponOrderTypeCheck;
	boolean isCouponApplyToDevice;
	boolean isCouponApplyToAccessory;
	boolean passCouponDeviceTypeCheck;


	public boolean isCouponApplyToAccessory() {
		return isCouponApplyToAccessory;
	}



	public void setCouponApplyToAccessory(boolean isCouponApplyToAccessory) {
		this.isCouponApplyToAccessory = isCouponApplyToAccessory;
	}



	public boolean isCouponApplyToDevice() {
		return isCouponApplyToDevice;
	}



	public void setCouponApplyToDevice(boolean isCouponApplyToDevice) {
		this.isCouponApplyToDevice = isCouponApplyToDevice;
	}



	public boolean isPassCouponAccessoryCheck() {
		return passCouponAccessoryCheck;
	}



	public void setPassCouponAccessoryCheck(boolean passCouponAccessoryCheck) {
		this.passCouponAccessoryCheck = passCouponAccessoryCheck;
	}




	public boolean isPassCouponDeliveryTypeCheck() {
		return passCouponDeliveryTypeCheck;
	}



	public void setPassCouponDeliveryTypeCheck(boolean passCouponDeliveryTypeCheck) {
		this.passCouponDeliveryTypeCheck = passCouponDeliveryTypeCheck;
	}



	public boolean isPassCouponHandsetCheck() {
		return passCouponHandsetCheck;
	}



	public void setPassCouponHandsetCheck(boolean passCouponHandsetCheck) {
		this.passCouponHandsetCheck = passCouponHandsetCheck;
	}

	public boolean isPassCouponOrderTypeCheck() {
		return passCouponOrderTypeCheck;
	}



	public void setPassCouponOrderTypeCheck(boolean passCouponOrderTypeCheck) {
		this.passCouponOrderTypeCheck = passCouponOrderTypeCheck;
	}



	public boolean isPassCouponPromotionCheck() {
		return passCouponPromotionCheck;
	}



	public void setPassCouponPromotionCheck(boolean passCouponPromotionCheck) {
		this.passCouponPromotionCheck = passCouponPromotionCheck;
	}


	public boolean isPassCouponAccessoryTotalPriceCheck() {
		return passCouponAccessoryTotalPriceCheck;
	}



	public void setPassCouponAccessoryTotalPriceCheck(
			boolean passCouponAccessoryTotalPriceCheck) {
		this.passCouponAccessoryTotalPriceCheck = passCouponAccessoryTotalPriceCheck;
	}



	public boolean isPassCouponHandsetTotalPriceCheck() {
		return passCouponHandsetTotalPriceCheck;
	}



	public void setPassCouponHandsetTotalPriceCheck(
			boolean passCouponHandsetTotalPriceCheck) {
		this.passCouponHandsetTotalPriceCheck = passCouponHandsetTotalPriceCheck;
	}



	public boolean isPassCouponTotalPriceCheck() {
		return passCouponTotalPriceCheck;
	}



	public void setPassCouponTotalPriceCheck(boolean passCouponTotalPriceCheck) {
		this.passCouponTotalPriceCheck = passCouponTotalPriceCheck;
	}



	public Long getShipmentFee() {
		return shipmentFee;
	}



	public void setShipmentFee(Long shipmentFee) {
		this.shipmentFee = shipmentFee;
	}



	public ShoppingGuidePriceVO(Long totalPrice, Long prepaidPrice, Long shipmentFee) {
		super();
		this.totalPrice = totalPrice;
		this.prepaidPrice = prepaidPrice;
		this.shipmentFee = shipmentFee;
	}
	
	
	//revamp phase II releas I, 修改,加入其它參數
	public ShoppingGuidePriceVO(Long devicePrice, Long accessoryPrice, Long additionPurchasePrice, Long couponDiscountPrice, Long hgDiscountPrice, Long prepaidPrice, Long shipmentFee){
		//revamp phase I 定義不變
		this(devicePrice + accessoryPrice + additionPurchasePrice - couponDiscountPrice - hgDiscountPrice, prepaidPrice, shipmentFee);
		//revamp phase I 定義不變
		
		this.devicePrice = devicePrice;
		this.accessoryPrice = accessoryPrice;
		this.additionPurchasePrice = additionPurchasePrice;
		this.couponDiscountPrice = couponDiscountPrice;
		this.hgDiscountPrice = hgDiscountPrice;
		
	}
	
	
	



	public Long getPrepaidPrice() {
		return prepaidPrice;
	}



	public void setPrepaidPrice(Long prepaidPrice) {
		this.prepaidPrice = prepaidPrice;
	}



	public Long getTotalPrice() {
		return totalPrice;
	}



	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}



	public Long getAccessoryPrice() {
		return accessoryPrice;
	}



	public void setAccessoryPrice(Long accessoryPrice) {
		this.accessoryPrice = accessoryPrice;
	}



	public Long getAdditionPurchasePrice() {
		return additionPurchasePrice;
	}



	public void setAdditionPurchasePrice(Long additionPurchasePrice) {
		this.additionPurchasePrice = additionPurchasePrice;
	}



	public Long getCouponDiscountPrice() {
		return couponDiscountPrice;
	}



	public void setCouponDiscountPrice(Long couponDiscountPrice) {
		this.couponDiscountPrice = couponDiscountPrice;
	}



	public Long getDevicePrice() {
		return devicePrice;
	}



	public void setDevicePrice(Long devicePrice) {
		this.devicePrice = devicePrice;
	}



	public Long getHgDiscountPrice() {
		return hgDiscountPrice;
	}



	public void setHgDiscountPrice(Long hgDiscountPrice) {
		this.hgDiscountPrice = hgDiscountPrice;
	}



	public boolean isPassCouponDeviceTypeCheck() {
		return passCouponDeviceTypeCheck;
	}



	public void setPassCouponDeviceTypeCheck(boolean passCouponDeviceTypeCheck) {
		this.passCouponDeviceTypeCheck = passCouponDeviceTypeCheck;
	}

	
	
	

}
