package com.fet.estore.core.dao.base;

import java.util.List;

import com.fet.estore.core.model.AccessoryGroup;

public interface AccessoryGroupDAO extends BaseDAO<AccessoryGroup, String> {
	/**
	 * 根據co_master內容,將90天或N天內,IA_STATUS = 'D'已啟用狀態訂單,計算數量並排序
	 * @param category
	 */
	public void processActivationDateAccessorySort(String act);
	
	/**
	 * a.onsaleDate < sysdate and a.offDate > sysdate and a.sign4onsale = 'Y' and a.onsale = 'Y'
	 * @return
	 */
	public List<AccessoryGroup> findOnsaleAccessory();
}
