package com.fet.estore.core.bean;

import java.util.List;

/**
 * 給前端React NewFlow所使用
 * 回給前端是的資料結構List<MsisdnFlow>
 *
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-06
 * @description
 */
public class MsisdnFlow<T> {

    /**
     * 新申辦 標籤清單
     * 可以有兩種型別: Object或是List<String> 分別給不同的id所使用
     */
    private Object tags;
    /** 新申辦 選項內容 */
    private List<T> options;

    public Object getTags() {
        return tags;
    }
    public void setTags(Object tags) {
        this.tags = tags;
    }
    public List<T> getOptions() {
        return options;
    }
    public void setOptions(List<T> options) {
        this.options = options;
    }
}
