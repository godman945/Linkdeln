package com.fet.estore.core.bean;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 月付 ratePlane
 * 商品價 productPrice //只會配合單機
 * 優惠價 preferentialPrice //只會配合單機
 * 專案價 projectPrice // 只會配合促案
 */
public class Product implements Serializable {

	private static final long serialVersionUID = -2042121336834381925L;

	/** 商品編號:'handset.productId' */
	private String productId;
	/** 大分類 */
	private String categoryGroup;
	/** 產品項目類型，商品:'product'、遠遊卡:'wireless'、活動廣告(有圖):'promo-product'、活動廣告(無圖):'promotion' */
	private String type;
	/** 產品連結 */
	private String link;
	/** 行銷標籤 對應方式 CFG_PRODUCT_TAG.TYPE = '1'  */
	private String ribbon;
	/** 產品圖片資料夾 */
	private String image;
	/** 產品圖片預設圖檔 */
	private String defaultImage;
	/** 產品屬性標籤 對應方式 CFG_PRODUCT_TAG.TYPE = '2'  */
	private String tag;
	/** 產品廠牌 */
	private String meta;
	/** 產品名稱 */
	private String title;
	/** 商品價（配件、3c 使用欄位） */
	private String productPrice;
	/** 優惠價 */
	private String preferentialPrice;
	/** 月付（手機、平板 使用欄位） */
	private String ratePlan;
	/** 專案價（手機、平板 使用欄位） */
	private String projectPrice;
	/** 專案優惠價（手機、平板 使用欄位） */
	private String preferentialProjectPrice;
	/** TYPE 為 Promotion 時所需要的資料結構*/
	private PromotionAction action;
	/** 料號 */
	private String fetNo;
	/** 可申辦類型 */
	private String sellType;
	/** 上架日 */
	private Date onsaleDate;
	/** 續約最低價 */
	private Long lyLowestPrice;
	/** 熱銷手機推薦（此欄位不是DB撈出來的是在續約找商品處處理時塞入） */
	private Integer cohotCount;
	/** 主分類Id */
	private List<Integer> categoryGroupId;
	/** 次份類Id */
	private List<Long> categoryId;
	/** 促案Seq */
	private String oplSeq;
	/** 限宅配 */
	private Boolean homeDeliverable;
	/** 限門市 */
	private Boolean storeDeliverable;

	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getCategoryGroup() {
		return categoryGroup;
	}
	public void setCategoryGroup(String categoryGroup) {
		this.categoryGroup = categoryGroup;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getRibbon() {
		return ribbon;
	}
	public void setRibbon(String ribbon) {
		this.ribbon = ribbon;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getMeta() {
		return meta;
	}
	public void setMeta(String meta) {
		this.meta = meta;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public String getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}
	public String getProjectPrice() {
		return projectPrice;
	}
	public void setProjectPrice(String projectPrice) {
		this.projectPrice = projectPrice;
	}
	public String getPreferentialPrice() {
		return preferentialPrice;
	}
	public void setPreferentialPrice(String preferentialPrice) {
		this.preferentialPrice = preferentialPrice;
	}
	public PromotionAction getAction() {
		return action;
	}
	public void setAction(PromotionAction action) {
		this.action = action;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getDefaultImage() {
		return defaultImage;
	}
	public void setDefaultImage(String defaultImage) {
		this.defaultImage = defaultImage;
	}
	public String getSellType() {
		return sellType;
	}
	public void setSellType(String sellType) {
		this.sellType = sellType;
	}
	public void setCohotCount(Integer coHotCount) {
		this.cohotCount = coHotCount;
	}
	public Integer getCohotCount() {
		return cohotCount;
	}
	public Date getOnsaleDate() {
		return onsaleDate;
	}
	public void setOnsaleDate(Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}
	public Long getLyLowestPrice() {
		return lyLowestPrice;
	}
	public void setLyLowestPrice(Long lyLowestPrice) {
		this.lyLowestPrice = lyLowestPrice;
	}
	public List<Long> getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(List<Long> categoryId) {
		this.categoryId = categoryId;
	}
	public List<Integer> getCategoryGroupId() {
		return categoryGroupId;
	}
	public void setCategoryGroupId(List<Integer> categoryGroupId) {
		this.categoryGroupId = categoryGroupId;
	}
	public String getOplSeq() {
		return oplSeq;
	}
	public void setOplSeq(String oplSeq) {
		this.oplSeq = oplSeq;
	}
	public String getPreferentialProjectPrice() {
		return preferentialProjectPrice;
	}
	public void setPreferentialProjectPrice(String preferentialProjectPrice) {
		this.preferentialProjectPrice = preferentialProjectPrice;
	}
	public Boolean getHomeDeliverable() {
		return homeDeliverable;
	}
	public void setHomeDeliverable(Boolean homeDeliverable) {
		this.homeDeliverable = homeDeliverable;
	}
	public Boolean getStoreDeliverable() {
		return storeDeliverable;
	}
	public void setStoreDeliverable(Boolean storeDeliverable) {
		this.storeDeliverable = storeDeliverable;
	}
}
