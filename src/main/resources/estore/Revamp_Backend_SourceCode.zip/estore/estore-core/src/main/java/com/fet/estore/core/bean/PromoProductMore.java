package com.fet.estore.core.bean;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-23
 * @description
 */
public class PromoProductMore {

    private String text;

    private String link;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

}