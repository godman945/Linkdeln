package com.fet.estore.core.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-30
 * @description
 */
public class PromotionalPriceArgs {

    private String categoryGroup;

    private List<String> includeCategories;

    private List<String> excludeCategories;

    private String brand;

    private String category;

    private String keyword;

    private Boolean type;

    public String getCategoryGroup() {
        return categoryGroup;
    }

    public void setCategoryGroup(String categoryGroup) {
        this.categoryGroup = categoryGroup;
    }

    public List<String> getIncludeCategories() {
        return includeCategories;
    }

    public void setIncludeCategories(List<String> includeCategories) {
        this.includeCategories = includeCategories;
    }

    public List<String> getExcludeCategories() {
        return excludeCategories;
    }

    public void setExcludeCategories(List<String> excludeCategories) {
        this.excludeCategories = excludeCategories;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Boolean getType() {
        return type;
    }

    public void setType(boolean type) {
        this.type = type;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public static Builder builder(String categoryGroup) {
        return new Builder(categoryGroup);
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String categoryGroupInner;

        private List<String> includeCategoriesInner = new ArrayList<>();

        private List<String> excludeCategoriesInner = new ArrayList<>();

        private String brandInner;

        private String categoryInner;

        private String keywordInner;

        private Boolean typeInner;

        public Builder() {
        }

        public Builder(String categoryGroup) {
            this.categoryGroupInner = categoryGroup;
        }

        public Builder categoryGroup(String categoryGroup) {
            this.categoryGroupInner = categoryGroup;
            return this;
        }
        public Builder exclude(String exclude){
            excludeCategoriesInner.add(exclude);
            return this;
        }
        public Builder include(String include) {
            includeCategoriesInner.add(include);
            return this;
        }

        public Builder brand(String brand) {
            this.brandInner = brand;
            return this;
        }

        public Builder type(Boolean type) {
            this.typeInner = type;
            return this;
        }

        public Builder keyword(String keyword) {
            this.keywordInner = keyword;
            return this;
        }

        public Builder category(String category) {
            this.categoryInner = category;
            return this;
        }

        public PromotionalPriceArgs build(){
            PromotionalPriceArgs args = new PromotionalPriceArgs();
            args.categoryGroup = this.categoryGroupInner;
            args.includeCategories = this.includeCategoriesInner;
            args.excludeCategories = this.excludeCategoriesInner;
            args.brand = this.brandInner;
            args.keyword = this.keywordInner;
            args.category = this.categoryInner;
            args.type = this.typeInner;
            return args;
        }

    }
}
