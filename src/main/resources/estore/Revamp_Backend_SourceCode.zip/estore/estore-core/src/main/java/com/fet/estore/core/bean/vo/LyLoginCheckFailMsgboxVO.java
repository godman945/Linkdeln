package com.fet.estore.core.bean.vo;

import java.io.Serializable;

public class LyLoginCheckFailMsgboxVO implements Serializable {


	private static final long serialVersionUID = 4255654674320458825L;
	
	/** 對話框標題 */
    private String title;
    /** 對話框內文訊息 */
    private String msg;
    /** 對話框按鈕 */
    private String btnText;
    /** 對話框按鈕超連結 */
    private String btnUrl;
    
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getBtnText() {
		return btnText;
	}
	public void setBtnText(String btnText) {
		this.btnText = btnText;
	}
	public String getBtnUrl() {
		return btnUrl;
	}
	public void setBtnUrl(String btnUrl) {
		this.btnUrl = btnUrl;
	}

}
