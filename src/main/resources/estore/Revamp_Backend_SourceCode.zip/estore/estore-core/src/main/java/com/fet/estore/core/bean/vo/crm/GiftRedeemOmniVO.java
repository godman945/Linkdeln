package com.fet.estore.core.bean.vo.crm;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GiftRedeemOmniVO implements Serializable {
	private List<GiftRedeemItemOmni> giftRedeemItemsOmni;
	
	public GiftRedeemOmniVO(List<GiftRedeemItemOmni> giftRedeemItemsOmni){
		this.giftRedeemItemsOmni = giftRedeemItemsOmni;
	}
	
	public String getPrepaymentCode(){
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_PREPAYMENT.equals(giftRedeemItemOmni.getGiftType())){
				return giftRedeemItemOmni.getGiftCode();
			}
		}
		return null;
	}
	
	public Long getPrepaymentPrice(){
		Long myPrepaymentPrice = null;
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_PREPAYMENT.equals(giftRedeemItemOmni.getGiftType())){
				if(myPrepaymentPrice == null){
					myPrepaymentPrice = 0L;
				}
				myPrepaymentPrice += giftRedeemItemOmni.getPrice();
				//return giftRedeemItemOmni.getPrice();
			}
		}
		return myPrepaymentPrice;
	}
	
	public String getPrepaymentFetno(){
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_PREPAYMENT.equals(giftRedeemItemOmni.getGiftType())){
				return giftRedeemItemOmni.getFetNo();
			}
		}
		return null;
	}
	
	public String getSubsidyCode(){
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_SUBSIDY.equals(giftRedeemItemOmni.getGiftType())){
				return giftRedeemItemOmni.getGiftCode();
			}
		}
		return null;
	}
	
	public Long getSubsidyPrice(){
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_SUBSIDY.equals(giftRedeemItemOmni.getGiftType())){
				return giftRedeemItemOmni.getPrice();
			}
		}
		return null;
	}
	
	public String getPrepaymentName(){
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_PREPAYMENT.equals(giftRedeemItemOmni.getGiftType())){
				return giftRedeemItemOmni.getGiftName();
			}
		}
		return null;
	}
	
	public String getPrepaymentPromotionId(){
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_PREPAYMENT.equals(giftRedeemItemOmni.getGiftType())){
				return giftRedeemItemOmni.getPromotionId();
			}
		}
		return null;
	}
	
	public String getPrepaymentPromotionType(){
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_PREPAYMENT.equals(giftRedeemItemOmni.getGiftType())){
				return giftRedeemItemOmni.getVoiceOrData();
			}
		}
		return null;
	}
	
	public String getDepositCode(){
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(GiftRedeemItemOmni.GIFT_REDEEM_TYPE_DEPOSIT.equals(giftRedeemItemOmni.getGiftType())){
				return giftRedeemItemOmni.getGiftCode();
			}
		}
		return null;
	}
	//campaign code : GiftRedeemItemOmni
	private Map<String, List<GiftRedeemItemOmni>> getCampaignMap(){
		Map<String, List<GiftRedeemItemOmni>> campaignMap = new HashMap<String, List<GiftRedeemItemOmni>>();
		
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			
			if(!campaignMap.containsKey(giftRedeemItemOmni.getCampaignCode())){
				List<GiftRedeemItemOmni> giftRedeemItemOmniList = new ArrayList<GiftRedeemItemOmni>();
				giftRedeemItemOmniList.add(giftRedeemItemOmni);
				campaignMap.put(giftRedeemItemOmni.getCampaignCode(), giftRedeemItemOmniList);
			}else{
				campaignMap.get(giftRedeemItemOmni.getCampaignCode()).add(giftRedeemItemOmni);
			}
		}
		
		return campaignMap;
	}
	
	public String getCampaignStringForCoHistory(){
		Map<String, List<GiftRedeemItemOmni>> campaignMap = this.getCampaignMap();
		StringBuilder sb = new StringBuilder();
		
		for(String key : campaignMap.keySet()){
			sb.append("[Campaign: ");
			sb.append(key);
			sb.append(", Gift:(");
			
			for(int i=0; i<campaignMap.get(key).size(); i++){
				sb.append(campaignMap.get(key).get(i).getGiftName());
				if(i < campaignMap.get(key).size() - 1){
					sb.append(",");
				}
			}
			sb.append(")");
			sb.append("]");
		}
		
		return sb.toString();
	}
	
	
	
	
	
	
	public String getANote(String promotionId){
		StringBuilder sb = new StringBuilder();
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			if(giftRedeemItemOmni.getPromotionId().equals(promotionId)){
				if(giftRedeemItemOmni.getAnote() != null){
					sb.append(giftRedeemItemOmni.getAnote());
				}
			}
		}
		
		if(sb.length() > 0){
			return sb.toString();
		}
		
		return null;
	}
	
	/**
	 * 
	 * @return	promotionId, aNote
	 */
	public Map<String, String> getAllANote(){
		Map<String, String> aNoteMap = new HashMap<String, String>();
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			String promotionId = giftRedeemItemOmni.getPromotionId();
			if(!aNoteMap.containsKey(promotionId)){
				aNoteMap.put(promotionId, this.getANote(promotionId));
			}
		}
		return aNoteMap;
	}
	
	//camapign code : gift code
	public Map<String, String> getAllReemCode(){
		Map<String, String> redeemCodes = new HashMap<String, String>();
		for(GiftRedeemItemOmni giftRedeemItemOmni : this.giftRedeemItemsOmni){
			redeemCodes.put(giftRedeemItemOmni.getCampaignCode(), giftRedeemItemOmni.getGiftCode());
		}
		
		return redeemCodes;
	}

	public List<GiftRedeemItemOmni> getGiftRedeemItemsOmni() {
		return giftRedeemItemsOmni;
	}

	public void setGiftRedeemItemsOmni(List<GiftRedeemItemOmni> giftRedeemItemsOmni) {
		this.giftRedeemItemsOmni = giftRedeemItemsOmni;
	}
	
	
	
}
