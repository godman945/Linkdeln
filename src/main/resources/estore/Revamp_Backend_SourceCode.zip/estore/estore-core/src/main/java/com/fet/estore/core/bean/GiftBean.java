package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class GiftBean implements Serializable {

	private static final long serialVersionUID = 8634898295603773401L;
	private String title;
	private Integer minNumber;
	private List<GiftOptionsBean> options;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getMinNumber() {
		return minNumber;
	}
	public void setMinNumber(Integer minNumber) {
		this.minNumber = minNumber;
	}
	public List<GiftOptionsBean> getOptions() {
		return options;
	}
	public void setOptions(List<GiftOptionsBean> options) {
		this.options = options;
	}
	
}
