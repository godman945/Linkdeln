package com.fet.estore.core.dao.newstore;
import java.util.List;
import java.util.Map;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.DonateUnit;

/**
 * 電子發票捐贈單位資料存取層介面。
 *
 * @version $Id: NDonateUnitDAO.java,v 1.0, 2017-05-16 11:04:30Z, Evan Tung$
 */
public interface NDonateUnitDAO extends BaseDAO<DonateUnit, String> {

	/**
	 * 返回愛心捐贈單位
	 * @param DonationUnit
	 * @return
	 */
	public DonateUnit getDonateUnitByVOId(String donationUnit);
}