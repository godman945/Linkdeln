
package com.fet.estore.core.dao.base.impl;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fet.estore.core.bean.MetaInfo;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.hibernate.type.Type;
import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.base.PropertiesDAO;
import com.fet.estore.core.model.Properties;
import com.fet.estore.core.model.support.Page;
import com.fet.estore.core.bean.vo.PropertiesVO;

@Repository
public class PropertiesDAOImpl extends AbstractBaseDAO<Properties, Long> implements PropertiesDAO {
	
	public Properties findByName(String name){
		Criteria criteria = createCriteria();
		criteria.add(Restrictions.eq("name", name));
		
		if(criteria.list().size()>0){
			return (Properties)criteria.list().get(0);
		}else{
			return null;
		}
	}

	public List<Properties> findByNames(Collection<String> names) {
		Criteria criteria = createCriteria();
		criteria.add(Restrictions.in("name", names));
		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	public List<PropertiesVO> findMainCategoryList(){
		StringBuilder sb = new StringBuilder();
        sb.append("select fn2.id, handle_pro.tempParentName as parentName, fn2.display_name as parentDisplayName ");
        sb.append("from ");
        sb.append("( ");
        sb.append("select distinct decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.name,'',fn.name,fn2.name) as tempParentName ");
        sb.append("from FRONTEND_NAVIGATION fn ");
        sb.append("join properties pro on fn.name = pro.name and fn.channel = 'ESTORE' ");  // 加入大網條件
        sb.append("left join FRONTEND_NAVIGATION fn2 on FN.PARENT_ID = fn2.id ");
        sb.append(") handle_pro ");
        sb.append("join FRONTEND_NAVIGATION fn2 on handle_pro.tempParentName = fn2.name ");
        sb.append("where handle_pro.tempParentName != 'ACCESSORY_ALONE' ");  //20121228:排除「配件」選項
        sb.append("order by fn2.parent_id nulls first, fn2.display_order ");

//        sb.append("select parentFn.id, handle_pro.tempParentName as parentName, parentFn.display_name as parentDisplayName ");
//        sb.append("from ");
//        sb.append("( ");
//        sb.append("select distinct decode(childFn.Parent_id,decode(parentFn.name,'HOME',parentFn.id,'',childFn.id),parentFn.name,'',childFn.name,parentFn.name) as tempParentName ");
//        sb.append("from FRONTEND_NAVIGATION childFn ");
//        sb.append("join properties pro on childFn.name = pro.name ");
//        sb.append("left join FRONTEND_NAVIGATION parentFn on childFn.PARENT_ID = parentFn.id ");
//        sb.append(") handle_pro ");
//        sb.append("join FRONTEND_NAVIGATION parentFn on handle_pro.tempParentName = parentFn.name ");
//        sb.append("order by parentFn.parent_id nulls first, parentFn.display_order ");
        
        Query query =  this.getSessionFactory().getCurrentSession().createSQLQuery(sb.toString())
        .addScalar("id", LongType.INSTANCE)
		.addScalar("parentName", 		StringType.INSTANCE)
		.addScalar("parentDisplayName", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(PropertiesVO.class));
		
        List<PropertiesVO> result = (List<PropertiesVO>)query.list();
        
		return result;
	}
	
	@SuppressWarnings("unchecked")
	public Page<PropertiesVO> pageQueryMetadataByCondition(String mainCategory, String subCategory,
			String searchColumn, String queryMetaKeyword, int pageNo, int pageSize){
		
		StringBuilder selectSql = new StringBuilder("select handle_pro.* ");
		StringBuilder countSql = new StringBuilder("select count(handle_pro.id) ");
		
		StringBuilder bodySql = new StringBuilder();
		bodySql.append("from ");
		bodySql.append("( ");
		
		bodySql.append("select pro.id as id, decode(fn2.name,'HOME',fn2.id,'',fn.id) as homeId, ");
		bodySql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.id,'',fn2.id,fn2.id) as parentId, ");
		bodySql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.name,'',fn.name,fn2.name) as parentName, ");
		bodySql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.display_name,'',fn.display_name,fn2.display_name) as parentDisplayName, ");
		bodySql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.id,'',fn2.id,fn.id) as childId, ");
		bodySql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),'NIL','','NIL',fn.name) as childName, ");
		bodySql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),'無','','無',fn.display_name) as childDisplayName, ");
		bodySql.append("pro.content as content, pro.title as title, pro.description as description ");
		bodySql.append("from FRONTEND_NAVIGATION fn ");
		bodySql.append("join properties pro on fn.name = pro.name and fn.channel = 'ESTORE' ");
		bodySql.append("left join FRONTEND_NAVIGATION fn2 on FN.PARENT_ID = fn2.id ");
		bodySql.append("order by fn.parent_id nulls first, fn.parent_id, pro.id ");
		
//		bodySql.append("select pro.id as id, decode(fn2.name,'HOME',fn2.id,'',fn.id) as homeId, ");
//		bodySql.append("decode(childFn.Parent_id,decode(parentFn.name,'HOME',parentFn.id,'',childFn.id),parentFn.id,'',childFn.id,parentFn.id)  as parentId, ");
//		bodySql.append("decode(childFn.Parent_id,decode(parentFn.name,'HOME',parentFn.id,'',childFn.id),parentFn.name,'',childFn.name,parentFn.name) as parentName, ");
//		bodySql.append("decode(childFn.Parent_id,decode(parentFn.name,'HOME',parentFn.id,'',childFn.id),parentFn.display_name,'',childFn.display_name,parentFn.display_name) as parentDisplayName, ");
//		bodySql.append("decode(childFn.Parent_id,decode(parentFn.name,'HOME',parentFn.id,'',childFn.id),childFn.id,'',childFn.id,childFn.id) as childId, ");
//		bodySql.append("decode(childFn.Parent_id,decode(parentFn.name,'HOME',parentFn.id,'',childFn.id),childFn.name,'','NIL',childFn.name) as childName, ");
//		bodySql.append("decode(childFn.Parent_id,decode(parentFn.name,'HOME',parentFn.id,'',childFn.id),childFn.display_name,'','無',childFn.display_name) as childDisplayName, ");
//		bodySql.append("pro.content as content, pro.title as title, pro.description as description ");
//		bodySql.append("from FRONTEND_NAVIGATION childFn ");
//		bodySql.append("left join FRONTEND_NAVIGATION parentFn on childFn.PARENT_ID = parentFn.id ");
//		bodySql.append("join properties pro on childFn.name = pro.name ");
//		bodySql.append("order by childFn.parent_id nulls first, childFn.parent_id, childFn.display_order ");
		
		bodySql.append(") handle_pro ");
		bodySql.append("where 1=1 ");
		bodySql.append("and handle_pro.parentName != 'ACCESSORY_ALONE' ");  //20121228:排除「配件」下所有子類別
		
		Map<String,Object> properties = new HashMap<String,Object>();
		
		if(StringUtils.isNotBlank(mainCategory)){
			//若handle_pro.homeId == :mainCategory 就用homeId做判斷；非則用parentId判斷
			bodySql.append("and decode(handle_pro.homeId, :mainCategory, handle_pro.homeId, handle_pro.parentId) = :mainCategory ");
			properties.put("mainCategory", mainCategory);
		}
		
		if(StringUtils.isNotBlank(subCategory)){
			bodySql.append("and handle_pro.childId = :subCategory ");
			properties.put("subCategory", subCategory);
		}
		
		if(StringUtils.isNotBlank(searchColumn)){
			if(PropertiesVO.META_KEYWORDS.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and handle_pro.content like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}else if(PropertiesVO.META_TITLE.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and handle_pro.title like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}else if(PropertiesVO.META_DESCRIPTION.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and handle_pro.description like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}
			
		}else{
			if(StringUtils.isNotBlank(queryMetaKeyword)){
				bodySql.append("and (handle_pro.content like :searchKeyword or handle_pro.title like :searchKeyword or handle_pro.description like :searchKeyword) ");
				properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
			}
		}
		
		countSql.append(bodySql);
		SQLQuery countSqlQuery = this.getSessionFactory().getCurrentSession().createSQLQuery(countSql.toString());
		countSqlQuery.setProperties(properties);
		int totalCount = ((BigDecimal)countSqlQuery.uniqueResult()).intValue();
		
		selectSql.append(bodySql);
		Query selectSqlQuery =  this.getSessionFactory().getCurrentSession().createSQLQuery(selectSql.toString())
		.addScalar("id", LongType.INSTANCE)
		.addScalar("homeId", 			StringType.INSTANCE)
		.addScalar("parentId", 			StringType.INSTANCE)
		.addScalar("parentName", 		StringType.INSTANCE)
		.addScalar("parentDisplayName", StringType.INSTANCE)
		.addScalar("childId", 			StringType.INSTANCE)
		.addScalar("childName", 		StringType.INSTANCE)
		.addScalar("childDisplayName", 	StringType.INSTANCE)
		.addScalar("content", 			StringType.INSTANCE)
		.addScalar("title", 			StringType.INSTANCE)
		.addScalar("description", 		StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(PropertiesVO.class));
		
		selectSqlQuery.setProperties(properties);
		
		int fromIndex = (pageNo - 1) * pageSize;
		selectSqlQuery.setFirstResult(fromIndex);
		selectSqlQuery.setMaxResults(pageSize);
		
		List<PropertiesVO> result = (List<PropertiesVO>)selectSqlQuery.list();
		Page<PropertiesVO> pages = new Page<PropertiesVO>(new Long(fromIndex), pageSize, new Long(totalCount), result);
		
		return pages;
		
	}
	
	@SuppressWarnings("unchecked")
	public Page<PropertiesVO> pageQueryMetadataByConditionForMobile(String mainCategory, 
			String searchColumn, String queryMetaKeyword, int pageNo, int pageSize){
		
		StringBuilder selectSql = new StringBuilder("select pro.* ");
		StringBuilder countSql = new StringBuilder("select count(pro.id) ");
		
		StringBuilder bodySql = new StringBuilder();
		bodySql.append("from PROPERTIES pro ");
		bodySql.append("where pro.name like 'MOBILE_%' ");
		
		Map<String,Object> properties = new HashMap<String,Object>();
		
		if(StringUtils.isNotBlank(mainCategory)){
			bodySql.append("and pro.name = :mainCategory ");
			properties.put("mainCategory", mainCategory);
		}
		
		if(StringUtils.isNotBlank(searchColumn)){
			if(PropertiesVO.META_KEYWORDS.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and pro.content like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}else if(PropertiesVO.META_TITLE.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and pro.title like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}else if(PropertiesVO.META_DESCRIPTION.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and pro.description like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}
			
		}else{
			if(StringUtils.isNotBlank(queryMetaKeyword)){
				bodySql.append("and (pro.content like :searchKeyword or pro.title like :searchKeyword or pro.description like :searchKeyword) ");
				properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
			}
		}
		
		StringBuilder orderbySql = new StringBuilder("order by pro.id ");
		
		countSql.append(bodySql);
		SQLQuery countSqlQuery =  this.getSessionFactory().getCurrentSession().createSQLQuery(countSql.toString());
		countSqlQuery.setProperties(properties);
		int totalCount = ((BigDecimal)countSqlQuery.uniqueResult()).intValue();
		
		selectSql.append(bodySql).append(orderbySql);
		Query selectSqlQuery =  this.getSessionFactory().getCurrentSession().createSQLQuery(selectSql.toString())
		.addScalar("id", LongType.INSTANCE)
		.addScalar("name", StringType.INSTANCE)
		.addScalar("content", StringType.INSTANCE)
		.addScalar("title", StringType.INSTANCE)
		.addScalar("description", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(PropertiesVO.class));
		selectSqlQuery.setProperties(properties);
		
		int fromIndex = (pageNo - 1) * pageSize;
		selectSqlQuery.setFirstResult(fromIndex);
		selectSqlQuery.setMaxResults(pageSize);
		
		List<PropertiesVO> result = (List<PropertiesVO>)selectSqlQuery.list();
		Page<PropertiesVO> pages = new Page<PropertiesVO>(new Long(fromIndex), pageSize, new Long(totalCount), result);
		
		return pages;
	}
	
	public List<PropertiesVO> findMetadataByCondition(String mainCategory, String subCategory, 
			String searchColumn, String queryMetaKeyword){
		
		StringBuilder selectSql = new StringBuilder("select handle_pro.* ");
		selectSql.append("from ");
		selectSql.append("( ");
		selectSql.append("select pro.id as id, decode(fn2.name,'HOME',fn2.id,'',fn.id) as homeId, ");
		selectSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.id,'',fn2.id,fn2.id) as parentId, ");
		selectSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.name,'',fn.name,fn2.name) as parentName, ");
		selectSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.display_name,'',fn.display_name,fn2.display_name) as parentDisplayName, ");
		selectSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.id,'',fn2.id,fn.id) as childId, ");
		selectSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),'NIL','','NIL',fn.name) as childName, ");
		selectSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),'無','','無',fn.display_name) as childDisplayName, ");
		selectSql.append("pro.content as content, pro.title as title, pro.description as description ");
		selectSql.append("from FRONTEND_NAVIGATION fn ");
		selectSql.append("join properties pro on fn.name = pro.name and fn.channel = 'ESTORE' ");
		selectSql.append("left join FRONTEND_NAVIGATION fn2 on FN.PARENT_ID = fn2.id ");
		selectSql.append("order by fn.parent_id nulls first, fn.parent_id, pro.id ");
		
		selectSql.append(") handle_pro ");
		selectSql.append("where 1=1 ");
		
		Map<String,Object> properties = new HashMap<String,Object>();
		
		if(StringUtils.isNotBlank(mainCategory)){
			//若handle_pro.homeId == :mainCategory 就用homeId做判斷；非則用parentId判斷
			selectSql.append("and decode(handle_pro.homeId, :mainCategory, handle_pro.homeId, handle_pro.parentId) = :mainCategory ");
			properties.put("mainCategory", mainCategory);
		}
		
		if(StringUtils.isNotBlank(subCategory)){
			selectSql.append("and handle_pro.childId = :subCategory ");
			properties.put("subCategory", subCategory);
		}
		
		if(StringUtils.isNotBlank(searchColumn)){
			if(PropertiesVO.META_KEYWORDS.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					selectSql.append("and handle_pro.content like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}else if(PropertiesVO.META_TITLE.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					selectSql.append("and handle_pro.title like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}else if(PropertiesVO.META_DESCRIPTION.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					selectSql.append("and handle_pro.description like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}
			
		}else{
			if(StringUtils.isNotBlank(queryMetaKeyword)){
				selectSql.append("and (handle_pro.content like :searchKeyword or handle_pro.title like :searchKeyword or handle_pro.description like :searchKeyword) ");
				properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
			}
		}
		
		Query query =  this.getSessionFactory().getCurrentSession().createSQLQuery(selectSql.toString())
		.addScalar("id", LongType.INSTANCE)
		.addScalar("homeId", 			StringType.INSTANCE)
		.addScalar("parentId", 			StringType.INSTANCE)
		.addScalar("parentName", 		StringType.INSTANCE)
		.addScalar("parentDisplayName", StringType.INSTANCE)
		.addScalar("childId", 			StringType.INSTANCE)
		.addScalar("childName", 		StringType.INSTANCE)
		.addScalar("childDisplayName", 	StringType.INSTANCE)
		.addScalar("content", 			StringType.INSTANCE)
		.addScalar("title", 			StringType.INSTANCE)
		.addScalar("description", 		StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(PropertiesVO.class));
		
		query.setProperties(properties);
		
		@SuppressWarnings("unchecked")
		List<PropertiesVO> result = (List<PropertiesVO>)query.list();
		
		return result;
	}
	
	public List<PropertiesVO> findMetadataByConditionForMobile(String mainCategory,
			String searchColumn, String queryMetaKeyword){
		
		StringBuilder selectSql = new StringBuilder("select pro.* ");
		
		StringBuilder bodySql = new StringBuilder();
		bodySql.append("from PROPERTIES pro ");
		bodySql.append("where pro.name like 'MOBILE_%' ");
		
		Map<String,Object> properties = new HashMap<String,Object>();
		
		if(StringUtils.isNotBlank(mainCategory)){
			bodySql.append("and pro.name = :mainCategory ");
			properties.put("mainCategory", mainCategory);
		}
		
		if(StringUtils.isNotBlank(searchColumn)){
			if(PropertiesVO.META_KEYWORDS.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and pro.content like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}else if(PropertiesVO.META_TITLE.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and pro.title like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}else if(PropertiesVO.META_DESCRIPTION.equals(searchColumn)){
				if(StringUtils.isNotBlank(queryMetaKeyword)){
					bodySql.append("and pro.description like :searchKeyword ");
					properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
				}
			}
			
		}else{
			if(StringUtils.isNotBlank(queryMetaKeyword)){
				bodySql.append("and (pro.content like :searchKeyword or pro.title like :searchKeyword or pro.description like :searchKeyword) ");
				properties.put("searchKeyword", "%"+queryMetaKeyword+"%");
			}
		}
		
		StringBuilder orderbySql = new StringBuilder("order by pro.id ");
		
		selectSql.append(bodySql).append(orderbySql);
		Query selectSqlQuery =  this.getSessionFactory().getCurrentSession().createSQLQuery(selectSql.toString())
		.addScalar("id", LongType.INSTANCE)
		.addScalar("name", StringType.INSTANCE)
		.addScalar("content", StringType.INSTANCE)
		.addScalar("title", StringType.INSTANCE)
		.addScalar("description", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(PropertiesVO.class));
		selectSqlQuery.setProperties(properties);
		
		@SuppressWarnings("unchecked")
		List<PropertiesVO> result = (List<PropertiesVO>)selectSqlQuery.list();
		
		return result;
	}
	
	public boolean isCategoryNameDuplicate(String mainName, String subName){
		StringBuilder countSql = new StringBuilder("select count(handle_pro.id) ");
		countSql.append("from ");
		countSql.append("( ");
		countSql.append("select pro.id as id, fn.parent_id as parentId, ");
		countSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.name,'',fn.name,fn2.name) as parentName, ");
		countSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.display_name,'',fn.display_name,fn2.display_name) as parentDisplayName, ");
		countSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),fn.id,'',fn2.id,fn.id) as childId, ");
		countSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),'NIL','','NIL',fn.name) as childName, ");
		countSql.append("decode(fn.Parent_id,decode(fn2.name,'HOME',fn2.id),'無','','無',fn.display_name) as childDisplayName, ");
		countSql.append("pro.content as content, pro.title as title, pro.description as description ");
		countSql.append("from FRONTEND_NAVIGATION fn ");
		countSql.append("join properties pro on fn.name = pro.name ");
		countSql.append("left join FRONTEND_NAVIGATION fn2 on FN.PARENT_ID = fn2.id ");
		countSql.append("order by fn.parent_id nulls first, fn.parent_id, pro.id ");
		countSql.append(") handle_pro ");
		countSql.append("where 1=1 ");
		
		Map<String,Object> properties = new HashMap<String,Object>();
		
		if(StringUtils.isNotBlank(mainName) && StringUtils.isNotBlank(subName)){
			countSql.append("and handle_pro.parentDisplayName = :mainName ");
			countSql.append("and handle_pro.childDisplayName = :subName ");
			properties.put("mainName", mainName);
			properties.put("subName", subName);
		}
		
		Query countSqlQuery =  this.getSessionFactory().getCurrentSession().createSQLQuery(countSql.toString());
		countSqlQuery.setProperties(properties);
		int totalCount = ((BigDecimal)countSqlQuery.uniqueResult()).intValue();
		boolean isDuplicate = (totalCount > 0) ? true : false;
		
		return isDuplicate;
	}

	public boolean isNormalAct(Long activityId){
		boolean result = false;
		Map<String, Object> sqlParams = new HashMap<String, Object>();

		StringBuilder sb = new StringBuilder();
		sb.append("SELECT COUNT(*) AS NUM                             ");
		sb.append("FROM PROPERTIES                                    ");
		sb.append("WHERE NAME IN ('NORMAL_ACT_ID', 'NORMAL_ACT_ID_LY')");
		sb.append("AND CONTENT = :activityId                          ");

		sqlParams.put("activityId", activityId);
		NativeQuery query = this.getSessionFactory().getCurrentSession().createNativeQuery(sb.toString());
		query.addScalar("NUM", IntegerType.INSTANCE);
		query.setProperties(sqlParams);
		int count = ((Integer)query.getSingleResult()).intValue();


		return count > 0;
	}

	/**
	 * 用頁面路徑取得Meta Data
	 * @param path
	 * @return
	 * @author Roil.Li
	 * @date 2020-10-19
	 */
	public MetaInfo findPageMetaByPath(String path) {
		if(path == null) {
			throw new NullPointerException("請輸入path");
		}
		StringBuilder sql = new StringBuilder();
		Map<String, Object> params = new HashMap<>();
		sql.append("SELECT ");
		sql.append("    cmi.META_KEYWORDS as keywords, ");
		sql.append("    cmi.META_TITLE as title, ");
		sql.append("    cmi.META_DESCRIPTION as description ");
		sql.append("FROM ");
		sql.append("    CFG_META_INFO cmi ");
		sql.append("WHERE ");
		sql.append("    cmi.PAGE_LINK = :path ");
		params.put("path", path);

		Map<String, Type> scalar = new HashMap<>();
		scalar.put("keywords", StringType.INSTANCE);
		scalar.put("title", StringType.INSTANCE);
		scalar.put("description", StringType.INSTANCE);

		List<MetaInfo> result = executeQuery(sql, scalar, params, MetaInfo.class);

		// 正常來說url不會重複，所以只會有一筆
		return result != null && !result.isEmpty() ? result.get(0) : null;
	}
}
