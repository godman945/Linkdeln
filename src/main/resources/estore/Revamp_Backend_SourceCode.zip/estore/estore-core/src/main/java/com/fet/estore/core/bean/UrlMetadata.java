package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-09-02
 * @description
 */
public class UrlMetadata implements Serializable {

    /** Html Head MetaTag title */
    private String title;
    /** Html Head MetaTag description */
    private String description;
    /** Html Head MetaTag keywords */
    private String keywords;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }
}
