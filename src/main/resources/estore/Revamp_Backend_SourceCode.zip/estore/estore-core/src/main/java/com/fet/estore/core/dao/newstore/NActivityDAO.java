package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.bean.po.ActivityGiftPO;
import com.fet.estore.core.bean.po.ActivityTargetPromoPO;
import com.fet.estore.core.bean.po.OpenActivityPO;
import com.fet.estore.core.bean.vo.frontend.DiscountVO;
import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.Activity;

import java.util.List;
import java.util.Set;

/**
 * 活動DAO
 * @author Max Chen
 *
 */
public interface NActivityDAO extends BaseDAO<Activity, Long>  {
	
	/**
	 * 取得折扣
	 * 取贈品規則: (參數有值: HAS_PARAM, 取出的開放式活動有對應限制: HAS_COND) <br />
	 *  HAS_PARAM &&  HAS_COND → → 取參數及限制條件交集後填入結果<br />
	 *  HAS_PARAM && !HAS_COND → → 取參數填入結果(即均符合此活動)<br />
	 * !HAS_PARAM &&  HAS_COND → → 取限制條件(即取得此活動在不限定此類型下的贈品清單)<br />
	 * !HAS_PARAM && !HAS_COND → → 跳過不取<br /> 
	 * @param orderType 申辦類別
	 * @param productIds 設備ID
	 * @param promoIds 促案ID
	 * @param deliveryType 遞送類型
	 * @param activityId 活動ID
	 * @param isHgDetail
	 * @param isAccDetail
	 * @param channel Activity.ACTIVITY_CHANNEL_ESTORE / Activity.ACTIVITY_CHANNEL_MOBILE
	 */
	public DiscountVO findActivityTargets(String orderType, String[] productIds, String[] promoIds, String deliveryType, String[] accIds, Long activityId, Boolean isHgDetail, Boolean isAccDetail, String channel);

	/**
	 * 活動是否有效
	 * @param id
	 * @return
	 */
	public boolean isValidActivity(Long id);

	/**
	 * 檢查外部網站合法性
	 * @param siteId
	 * @return
	 */
	public boolean isValidWebsite(Long actId, Integer siteId);

	/**
	 * 活動channel驗證
	 * @param id
	 * @param channel
	 * @return
	 */
	public boolean isActivityChannel(Long id, String channel);

	/**
	 * @description 撈取該賣場設定開賣的促案ONSALE_PROMO_LIST.SEQ 等同於 ACTIVITY_AWARD_TARGET.TARGET_ID
	 * @author Dennis.Chen
	 * @Date 2020-09-28
	 */
	public List<ActivityTargetPromoPO>  findActivityPromotions(String orderType, Long activityId);

	/**
	 * @description 取得開放式賣場
	 * @author Dennis.Chen
	 * @return
	 */
	public List<OpenActivityPO> findOpenActivity();

	/**
	 * @description 取得活動賣場贈品(優惠)
	 * @author Dennis.Chen
	 * @param activitIdList 活動ID List
	 * @return
	 */
	public List<ActivityGiftPO> findActivityGift(Set<Long> activitIdList);
	
	/**
	 * 取得門證號有在續約促銷活動名單裡的活動ID
	 * @param msisdn
	 * @param rocId
	 * @return
	 */
	public Activity findNameListByMsisdnAndRocId(String msisdn, String rocId);
}
