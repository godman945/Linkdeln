package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

public class HandsetDesciptionVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4963247037225992136L;

	private String title1;
	private String title2;
	private String title3;
	private String title4;
	private String description1;
	private String description2;
	private String description3;
	private String description4;
	private String feature1;
	private String feature2;
	private String feature3;
	private String feature4;
	/** 更多商品介紹 */
	private String detailLink;

	private String featureFlag;

	private String descriptionFlag;
	
	private String dimDescription;
	
	private String dimDescription1;
	
	private String dimDescription2;
	
	private Boolean isSpecShow;
	private Boolean isDescShow;
	public String getTitle1() {
		return title1;
	}

	public void setTitle1(String title1) {
		this.title1 = title1;
	}

	public String getTitle2() {
		return title2;
	}

	public void setTitle2(String title2) {
		this.title2 = title2;
	}

	public String getTitle3() {
		return title3;
	}

	public void setTitle3(String title3) {
		this.title3 = title3;
	}

	public String getTitle4() {
		return title4;
	}

	public void setTitle4(String title4) {
		this.title4 = title4;
	}

	public String getDescription1() {
		return description1;
	}

	public void setDescription1(String description1) {
		this.description1 = description1;
	}

	public String getDescription2() {
		return description2;
	}

	public void setDescription2(String description2) {
		this.description2 = description2;
	}

	public String getDescription3() {
		return description3;
	}

	public void setDescription3(String description3) {
		this.description3 = description3;
	}

	public String getDescription4() {
		return description4;
	}

	public void setDescription4(String description4) {
		this.description4 = description4;
	}

	public String getFeature1() {

//		if (StringUtils.isBlank(this.feature1)) {
//			this.feature1 = "/newstore/img/shared/nopic_medium.jpg";
//		}
		return feature1;
	}

	public void setFeature1(String feature1) {
		this.feature1 = feature1;
	}

	public String getFeature2() {
//		if (StringUtils.isBlank(this.feature2)) {
//			this.feature2 = "/newstore/img/shared/nopic_medium.jpg";
//		}
		return feature2;
	}

	public void setFeature2(String feature2) {
		this.feature2 = feature2;
	}

	public String getFeature3() {
//		if (StringUtils.isBlank(this.feature3)) {
//			this.feature3 = "/newstore/img/shared/nopic_medium.jpg";
//		}
		return feature3;
	}

	public void setFeature3(String feature3) {
		this.feature3 = feature3;
	}

	public String getFeature4() {
//		if (StringUtils.isBlank(this.feature4)) {
//			this.feature4 = "/newstore/img/shared/nopic_medium.jpg";
//		}
		return feature4;
	}

	public void setFeature4(String feature4) {
		this.feature4 = feature4;
	}

	public String getDetailLink() {
		return detailLink;
	}

	public void setDetailLink(String detailLink) {
		this.detailLink = detailLink;
	}

	public String getDescriptionFlag() {
		String descriptionFlag = "Y";
		if (StringUtils.isBlank(this.title1) && StringUtils.isBlank(this.title2) && StringUtils.isBlank(this.title3) && StringUtils.isBlank(this.title4)
				&& StringUtils.isBlank(this.dimDescription) && StringUtils.isBlank(this.dimDescription1) && StringUtils.isBlank(this.dimDescription2)
				&& StringUtils.isBlank(this.description4)) {
			descriptionFlag = "N";
		}
		return descriptionFlag;
	}

	public void setDescriptionFlag(String descriptionFlag) {
		this.descriptionFlag = descriptionFlag;
	}

	public String getFeatureFlag() {
		String featureFlag = "Y";
		if (StringUtils.isBlank(this.feature1) && StringUtils.isBlank(this.feature2) && StringUtils.isBlank(this.feature3) && StringUtils.isBlank(this.feature4)) {
			featureFlag = "N";
		}
		return featureFlag;
	}	

	public String getDimDescription() {
		return dimDescription;
	}

	public void setDimDescription(String dimDescription) {
		this.dimDescription = dimDescription;
	}

	public String getDimDescription1() {
		return dimDescription1;
	}

	public void setDimDescription1(String dimDescription1) {
		this.dimDescription1 = dimDescription1;
	}

	public String getDimDescription2() {
		return dimDescription2;
	}

	public void setDimDescription2(String dimDescription2) {
		this.dimDescription2 = dimDescription2;
	}

	public void setFeatureFlag(String featureFlag) {
		this.featureFlag = featureFlag;
	}

	public Boolean getIsSpecShow() {
		return isSpecShow;
	}

	public void setIsSpecShow(Boolean isSpecShow) {
		this.isSpecShow = isSpecShow;
	}

	public Boolean getIsDescShow() {
		return isDescShow;
	}

	public void setIsDescShow(Boolean isDescShow) {
		this.isDescShow = isDescShow;
	}

}
