package com.fet.estore.core.bean.vo.frontend;
/*20200627 Dennis.Chen - 之後沒有小網，此物件先註解*/

//package com.fet.estore.core.vo.frontend;
//
//import java.io.Serializable;
//import java.util.List;
//
//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//
///**
// * 購物流程VO
// * @author Max Chen
// *
// */
//@JsonIgnoreProperties(ignoreUnknown = true)
//public class ShoppingHelperVO extends com.sti.mobilestore.frontend.vo.ShoppingHelperVO implements Serializable {
//	
//	private static final long serialVersionUID = 4855573195622621934L;
//	
//	/** 流程分配 - 流程ID(用於追蹤) */
//	private String flwId;
//		
//	/** COUPON頁 - 是否已驗證攜碼 */
//	private boolean cpnNpVerified;
//	
//	/** COUPON頁 - 是否已驗證續約 */
//	private boolean cpnLyVerified;
//	
//	/** 流程分配 - 各頁token */
//	private String flwToken;
//	
//	/** 流程分配 - 視窗token(防止多重分頁) */
//	private String flwWindowToken;
//	
//	/** 流程分配 - COUPON驗證碼 */
//	private String flwCouponPwd;	
//	
//	/** 流程分配 - 套裝資費ID */
//	private Long flwHeroBundleId;	
//	
//	/** 流程分配 - 設備ID */
//	private String flwProductId;
//	
//	/** 流程分配 - 促案ID */
//	private String flwOnsalePromoListId;
//	
//	/** 流程分配 - 語音資費 */
//	private String flwVOfferId;
//	
//	/** 流程分配 - 數據資費 */
//	private String flwDOfferId;
//	
//	/** 流程分配 - 料號 */
//	private String flwFetNo;	
//	
//	/** 流程分配 - 門號ID */
//	private String flwMsisdnId;
//	
//	/** 流程分配 - 關聯性商品料號 */
//	private String flwRelAccFetNos;
//	
//	/** 流程分配 - 關聯性商品數量 */
//	private String flwRelAccQtys;
//	
//	/** 流程分配 - 單買錯誤訊息 */
//	private String flwDaErrMsg;
//	
//	/** 流程分配 - 配件活動料號清單 */
//	private String flwActAccFetnos;
//	
//	/** 流程分配 - 配件活動數量清單 */
//	private String flwActAccQtys;
//	
//	/** 流程分配 - webtrend(mc_id) */
//	private String flwWtMcId;
//	
//	/** 活動設備頁 - 設備ID */
//	private String devProductId;
//
//	/** 活動設備頁 - 設備料號 */
//	private String devFetNo;
//	
//	/** 活動配件頁 - 配件料號清單 */
//	private String accFetNos;
//	
//	/** 活動促案頁 - 群組ID */
//	private String prmGroupId;
//	
//	/** 設備頁 - 設備ID */
//	private String prdProductId;
//	
//	/** 流程分配 - 離開路徑 */
//	private String flwExitPath;
//	
//	/** 流程分配 - 重設流程路徑 */
//	private String flwResetPath;
//	
//	/** 流程分配 - 外部網址ID */
//	private Integer flwSiteId;
//	
//	/** 流程分配 - 續約類型 */
//	private String flwLyWireless;
//	
//	/** 流程分配 - 是否跳過活動首頁 */
//	private boolean flwSkipActIndex;
//	
//	/** 流程分配 - 單買版型 */
//	private String flwDaDefaultType;
//	
//	/** 申辦人資料頁 - 首次進入 */
//	private String subFirst;		
//	/** 申辦人資料頁 - 合併帳單 - 是否合併 */
//	private String subCombineBill;	
//	/** 申辦人資料頁 - 合併帳單 - 門號 */
//	private String subCombineMdn;	
//	/** 申辦人資料頁 - 合併帳單 - 身分證 */
//	private String subCombineRocId;
//	/** 申辦人資料頁 - 申購人資料 - 姓名 */
//	private String subName;
//	/** 申辦人資料頁 - 申購人資料 - 身分證 */
//	private String subRocId;
//	/** 申辦人資料頁 - 申購人資料 - 第二證件類別 */
//	private String subSecTp;
//	/** 申辦人資料頁 - 申購人資料 - 第二證件號碼 */
//	private String subSecId;
//	/** 申辦人資料頁 - 申購人資料 - 出生日期(年) */
//	private String subBirthYear;
//	/** 申辦人資料頁 - 申購人資料 - 出生日期(月) */
//	private String subBirthMonth;
//	/** 申辦人資料頁 - 申購人資料 - 出生日期(日) */
//	private String subBirthDate;
//	/** 申辦人資料頁 - 申購人資料 - 帳單類型 */
//	private String subBillTp;
//	/** 申辦人資料頁 - 申購人資料 - 電子郵件 */
//	private String subEmail;	
//	/** 申辦人資料頁 - 帳單地址 - 縣市 */
//	private String subBillAddrCity;
//	/** 申辦人資料頁 - 帳單地址 - 鄉鎮市區 */
//	private String subBillAddrTown;
//	/** 申辦人資料頁 - 帳單地址 - 地址 */
//	private String subBillAddrTail;
//	/** 申辦人資料頁 - 戶籍地址 - 是否同帳單(true/false) */
//	private String subRegAsBill;
//	/** 申辦人資料頁 - 戶籍地址 - 縣市 */
//	private String subRegAddrCity;
//	/** 申辦人資料頁 - 戶籍地址 - 鄉鎮市區 */
//	private String subRegAddrTown;
//	/** 申辦人資料頁 - 戶籍地址 - 地址 */
//	private String subRegAddrTail;
//	/** 申辦人資料頁 - 申購人資料 - 連絡電話一區碼 */
//	private String subTelPre1;
//	/** 申辦人資料頁 - 申購人資料 - 連絡電話一 */
//	private String subTel1;
//	/** 申辦人資料頁 - 申購人資料 - 連絡電話二區碼 */
//	private String subTelPre2;
//	/** 申辦人資料頁 - 申購人資料 - 連絡電話二 */
//	private String subTel2;
//	/** 申辦人資料頁 - 取貨方式 - 類型 */
//	private String subDeliveryTp;
//	/** 申辦人資料頁 - 宅配 - 宅配資料同申購人資料 */
//	private String subHomeAsApp;
//    /** 申辦人資料頁  (新申辦, 攜碼)- 宅配 - 宅配資料同申購人資料 */
//    private String subHomeAsNormal;
//	/** 申辦人資料頁 - 宅配 - 收貨人姓名 */
//	private String subHomeName;
//	/** 申辦人資料頁 - 宅配 - 連絡電話一區碼 */
//	private String subHomeTelPre1;
//	/** 申辦人資料頁 - 宅配 - 連絡電話一 */
//	private String subHomeTel1;
//	/** 申辦人資料頁 - 宅配 - 連絡電話二區碼 */
//	private String subHomeTelPre2;
//	/** 申辦人資料頁 - 宅配 - 連絡電話二 */
//	private String subHomeTel2;
//	/** 申辦人資料頁 - 宅配 - 送貨時段 */
//	private String subHomeShipTime;
//	/** 申辦人資料頁 - 宅配 - 貨品代收 */
//	private String subHomeDeliAlt;
//	/** 申辦人資料頁 - 宅配地址 - 縣市 */
//	private String subHomeAddrCity;
//	/** 申辦人資料頁 - 宅配地址 - 鄉鎮市區 */
//	private String subHomeAddrTown;
//	/** 申辦人資料頁 - 宅配地址 - 地址 */
//	private String subHomeAddrTail;
//	/** 申辦人資料頁 - 門市 - 縣市 */
//	private String subStoreCity;
//	/** 申辦人資料頁 - 門市 - 門市 */
//	private String subStoreNo;
//	/** 申辦人資料頁 - 發票資訊 - 發票類別 */
//	private String subVatTp;
//	/** 申辦人資料頁 - 發票資訊 - 統一編號 */
//	private String subVatBan;
//	/** 申辦人資料頁 - 發票資訊 - 發票抬頭 */
//	private String subVatTitle;
//	/** 申辦人資料頁 - 發票地址 - 縣市 */
//	private String subVatAddrCity;
//	/** 申辦人資料頁 - 發票資訊 - 鄉鎮市區 */
//	private String subVatAddrTown;
//	/** 申辦人資料頁 - 發票資訊 - 地址 */
//	private String subVatAddrTail;
//	/** 申辦人資料頁 - 優惠券折抵 - 是否使用 */
//	private String subCoupon;
//	/** 申辦人資料頁 - 優惠券折抵 - 序號 */
//	private String subCouponSn;
//	/** 申辦人資料頁 - HappyGo - 是否使用 */
//	private String subHg;
//	/** 申辦人資料頁 - HappyGo - 點數 */
//	private String subHgPoint;		
//	/** 申辦人資料頁 - 其他訊息 - 額外加值服務 */
//	private String subExVaServ;
//	/** 申辦人資料頁 - 其他訊息 - 是否接受促銷簡訊 */
//	private String subAgreeSms;
//	/** 申辦人資料頁 - 其他訊息 - 是否接受啟用無線上網試用專案 */
//	private String subAgreeTrial;		
//	/** 申辦人資料頁 - 其他訊息 - 是否接受數據服務 */
//	private String subAgreeData;	
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String subAgreeContract;	
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String agreeContract1;
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String agreeContract2;
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String agreeContract3;
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String agreeContract4;
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String agreeContract5;
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String agreeContract6;
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String agreeContract7;
//	/** 申辦人資料頁 - 契約條款 - 是否同意條款 */
//	private String agreeContract8;
//	/**電子發票載具類別**/
//	private String einvoiceDeviceType;
//	/**電子發票載具代碼**/
//	private String einvoiceDeviceId;
//	/**電子發票愛心捐贈碼**/
//	private String donateUnitId;
//	/**電子發票愛心捐贈單位**/
//	private String donateUnitName;
//	/**電子發票類別**/
//	private String invoiceType;
//    /** 訊息來源 */
//    private String recommendSource;
//	/** 訊息來源資料 */
//    private String recommendDesc;
//    /** 企業客戶統編資料 */
//    private String mvpnVatNo;
//    /** 網路涵蓋率 */
//    private String subNetCoverRate;
//    /** 是否同意電信費用及小額付費帳單合併 */
//    private String subPaymentConsolidation;
//    /** 申辦人資料頁 - 申購人資料 - 發證日期(年) */
//    private String subIdCardYear;
//    /** 申辦人資料頁 - 申購人資料 - 發證日期(月) */
//    private String subIdCardMonth;
//    /** 申辦人資料頁 - 申購人資料 - 發證日期(日) */
//    private String subIdCardDate;
//    /** 申辦人資料頁 - 申購人資料 - 發證地點 */
//    private String subIdCardCity;
//    /** 申辦人資料頁 - 申購人資料 - 領補換類別 */
//    private String subIdCardType;
//    //多主商品
//    /** 多主商品群組1, 群組2的 proudct id**/
//    private List<String> flwProductIds;
//    /** 多主商品群組1, 群組2的fet no**/
//    private List<String> flwFetNos;
//    
//    private String isApp;
//    
//    /** 資費自由選  D_OFFERID**/
//    private String selfHelpingPromotion1;
//    /** 資費自由選  ONNET_OFFERID**/
//    private String selfHelpingPromotion2;
//    /** 資費自由選  OFFNET_OFFERID**/
//    private String selfHelpingPromotion3;
//    
//    /** 四合一頁 - 重選區塊 */
//	private String fourRecordZone;
//
//	//舊賣場搬過來的 added by Roil.Li 20200422
//	private String csStoreCvsid;
//	private String csStoreCvsname;
//	private String csStoreNo;
//	private String csStoreName;
//	private String csStoreTel;
//	private String csStoreAddress;
//    
//	/**
//	 * 建構子
//	 * @param flwId
//	 */
//    public ShoppingHelperVO() {
//    }
//    
//	public ShoppingHelperVO(String flwId) {
//		this.flwId = flwId;
//	}
//
//	public String getDevProductId() {
//		return devProductId;
//	}
//
//	public void setDevProductId(String devProductId) {
//		this.devProductId = devProductId;
//	}
//
//	public String getPrdProductId() {
//		return prdProductId;
//	}
//
//	public void setPrdProductId(String prdProductId) {
//		this.prdProductId = prdProductId;
//	}
//
//	public String getFlwProductId() {
//		return flwProductId;
//	}
//
//	public void setFlwProductId(String flwProductId) {
//		this.flwProductId = flwProductId;
//	}
//
//	public String getFlwMsisdnId() {
//		return flwMsisdnId;
//	}
//
//	public void setFlwMsisdnId(String flwMsisdnId) {
//		this.flwMsisdnId = flwMsisdnId;
//	}
//
//	public Long getFlwHeroBundleId() {
//		return flwHeroBundleId;
//	}
//
//	public void setFlwHeroBundleId(Long flwHeroBundleId) {
//		this.flwHeroBundleId = flwHeroBundleId;
//	}
//
//	public boolean isCpnNpVerified() {
//		return cpnNpVerified;
//	}
//
//	public void setCpnNpVerified(boolean cpnNpVerified) {
//		this.cpnNpVerified = cpnNpVerified;
//	}
//
//	public boolean isCpnLyVerified() {
//		return cpnLyVerified;
//	}
//
//	public void setCpnLyVerified(boolean cpnLyVerified) {
//		this.cpnLyVerified = cpnLyVerified;
//	}
//
//	public String getFlwCouponPwd() {
//		return flwCouponPwd;
//	}
//
//	public void setFlwCouponPwd(String flwCouponPwd) {
//		this.flwCouponPwd = flwCouponPwd;
//	}
//
//	public String getPrmGroupId() {
//		return prmGroupId;
//	}
//
//	public void setPrmGroupId(String prmGroupId) {
//		this.prmGroupId = prmGroupId;
//	}
//
//	public String getFlwFetNo() {
//		return flwFetNo;
//	}
//
//	public void setFlwFetNo(String flwFetNo) {
//		this.flwFetNo = flwFetNo;
//	}
//
//	public String getFlwExitPath() {
//		return flwExitPath;
//	}
//
//	public void setFlwExitPath(String flwExitPath) {
//		this.flwExitPath = flwExitPath;
//	}
//
//	public String getFlwToken() {
//		return flwToken;
//	}
//
//	public void setFlwToken(String flwToken) {
//		this.flwToken = flwToken;
//	}
//
//	public String getSubCombineBill() {
//		return subCombineBill;
//	}
//
//	public void setSubCombineBill(String subCombineBill) {
//		this.subCombineBill = subCombineBill;
//	}
//
//	public String getSubCombineMdn() {
//		return subCombineMdn;
//	}
//
//	public void setSubCombineMdn(String subCombineMdn) {
//		this.subCombineMdn = subCombineMdn;
//	}
//
//	public String getSubCombineRocId() {
//		return subCombineRocId;
//	}
//
//	public void setSubCombineRocId(String subCombineRocId) {
//		this.subCombineRocId = subCombineRocId;
//	}
//
//	public String getSubName() {
//		return subName;
//	}
//
//	public void setSubName(String subName) {
//		this.subName = subName;
//	}
//
//	public String getSubRocId() {
//		return subRocId;
//	}
//
//	public void setSubRocId(String subRocId) {
//		this.subRocId = subRocId;
//	}
//
//	public String getSubSecTp() {
//		return subSecTp;
//	}
//
//	public void setSubSecTp(String subSecTp) {
//		this.subSecTp = subSecTp;
//	}
//
//	public String getSubSecId() {
//		return subSecId;
//	}
//
//	public void setSubSecId(String subSecId) {
//		this.subSecId = subSecId;
//	}
//
//	public String getSubBirthYear() {
//		return subBirthYear;
//	}
//
//	public void setSubBirthYear(String subBirthYear) {
//		this.subBirthYear = subBirthYear;
//	}
//
//	public String getSubBirthMonth() {
//		return subBirthMonth;
//	}
//
//	public void setSubBirthMonth(String subBirthMonth) {
//		this.subBirthMonth = subBirthMonth;
//	}
//
//	public String getSubBirthDate() {
//		return subBirthDate;
//	}
//
//	public void setSubBirthDate(String subBirthDate) {
//		this.subBirthDate = subBirthDate;
//	}
//
//	public String getSubBillTp() {
//		return subBillTp;
//	}
//
//	public void setSubBillTp(String subBillTp) {
//		this.subBillTp = subBillTp;
//	}
//
//	public String getSubEmail() {
//		return subEmail;
//	}
//
//	public void setSubEmail(String subEmail) {
//		this.subEmail = subEmail;
//	}
//
//	public String getSubBillAddrCity() {
//		return subBillAddrCity;
//	}
//
//	public void setSubBillAddrCity(String subBillAddrCity) {
//		this.subBillAddrCity = subBillAddrCity;
//	}
//
//	public String getSubBillAddrTown() {
//		return subBillAddrTown;
//	}
//
//	public void setSubBillAddrTown(String subBillAddrTown) {
//		this.subBillAddrTown = subBillAddrTown;
//	}
//
//	public String getSubBillAddrTail() {
//		return subBillAddrTail;
//	}
//
//	public void setSubBillAddrTail(String subBillAddrTail) {
//		this.subBillAddrTail = subBillAddrTail;
//	}
//
//	public String getSubRegAsBill() {
//		return subRegAsBill;
//	}
//
//	public void setSubRegAsBill(String subRegAsBill) {
//		this.subRegAsBill = subRegAsBill;
//	}
//
//	public String getSubRegAddrCity() {
//		return subRegAddrCity;
//	}
//
//	public void setSubRegAddrCity(String subRegAddrCity) {
//		this.subRegAddrCity = subRegAddrCity;
//	}
//
//	public String getSubRegAddrTown() {
//		return subRegAddrTown;
//	}
//
//	public void setSubRegAddrTown(String subRegAddrTown) {
//		this.subRegAddrTown = subRegAddrTown;
//	}
//
//	public String getSubRegAddrTail() {
//		return subRegAddrTail;
//	}
//
//	public void setSubRegAddrTail(String subRegAddrTail) {
//		this.subRegAddrTail = subRegAddrTail;
//	}
//
//	public String getSubTelPre1() {
//		return subTelPre1;
//	}
//
//	public void setSubTelPre1(String subTelPre1) {
//		this.subTelPre1 = subTelPre1;
//	}
//
//	public String getSubTel1() {
//		return subTel1;
//	}
//
//	public void setSubTel1(String subTel1) {
//		this.subTel1 = subTel1;
//	}
//
//	public String getSubTelPre2() {
//		return subTelPre2;
//	}
//
//	public void setSubTelPre2(String subTelPre2) {
//		this.subTelPre2 = subTelPre2;
//	}
//
//	public String getSubTel2() {
//		return subTel2;
//	}
//
//	public void setSubTel2(String subTel2) {
//		this.subTel2 = subTel2;
//	}
//
//	public String getSubDeliveryTp() {
//		return subDeliveryTp;
//	}
//
//	public void setSubDeliveryTp(String subDeliveryTp) {
//		this.subDeliveryTp = subDeliveryTp;
//	}
//
//	public String getSubHomeAsApp() {
//		return subHomeAsApp;
//	}
//
//	public void setSubHomeAsApp(String subHomeAsApp) {
//		this.subHomeAsApp = subHomeAsApp;
//	}
//
//    public String getSubHomeAsNormal() {
//        return subHomeAsNormal;
//    }
//
//    public void setSubHomeAsNormal(String subHomeAsNormal) {
//        this.subHomeAsNormal = subHomeAsNormal;
//    }
//
//	public String getSubHomeName() {
//		return subHomeName;
//	}
//
//	public void setSubHomeName(String subHomeName) {
//		this.subHomeName = subHomeName;
//	}
//
//	public String getSubHomeTelPre1() {
//		return subHomeTelPre1;
//	}
//
//	public void setSubHomeTelPre1(String subHomeTelPre1) {
//		this.subHomeTelPre1 = subHomeTelPre1;
//	}
//
//	public String getSubHomeTel1() {
//		return subHomeTel1;
//	}
//
//	public void setSubHomeTel1(String subHomeTel1) {
//		this.subHomeTel1 = subHomeTel1;
//	}
//
//	public String getSubHomeTelPre2() {
//		return subHomeTelPre2;
//	}
//
//	public void setSubHomeTelPre2(String subHomeTelPre2) {
//		this.subHomeTelPre2 = subHomeTelPre2;
//	}
//
//	public String getSubHomeTel2() {
//		return subHomeTel2;
//	}
//
//	public void setSubHomeTel2(String subHomeTel2) {
//		this.subHomeTel2 = subHomeTel2;
//	}
//
//	public String getSubHomeShipTime() {
//		return subHomeShipTime;
//	}
//
//	public void setSubHomeShipTime(String subHomeShipTime) {
//		this.subHomeShipTime = subHomeShipTime;
//	}
//
//	public String getSubHomeDeliAlt() {
//		return subHomeDeliAlt;
//	}
//
//	public void setSubHomeDeliAlt(String subHomeDeliAlt) {
//		this.subHomeDeliAlt = subHomeDeliAlt;
//	}
//
//	public String getSubHomeAddrCity() {
//		return subHomeAddrCity;
//	}
//
//	public void setSubHomeAddrCity(String subHomeAddrCity) {
//		this.subHomeAddrCity = subHomeAddrCity;
//	}
//
//	public String getSubHomeAddrTown() {
//		return subHomeAddrTown;
//	}
//
//	public void setSubHomeAddrTown(String subHomeAddrTown) {
//		this.subHomeAddrTown = subHomeAddrTown;
//	}
//
//	public String getSubHomeAddrTail() {
//		return subHomeAddrTail;
//	}
//
//	public void setSubHomeAddrTail(String subHomeAddrTail) {
//		this.subHomeAddrTail = subHomeAddrTail;
//	}
//
//	public String getSubStoreCity() {
//		return subStoreCity;
//	}
//
//	public void setSubStoreCity(String subStoreCity) {
//		this.subStoreCity = subStoreCity;
//	}
//
//	public String getSubStoreNo() {
//		return subStoreNo;
//	}
//
//	public void setSubStoreNo(String subStoreNo) {
//		this.subStoreNo = subStoreNo;
//	}
//
//	public String getSubVatTp() {
//		return subVatTp;
//	}
//
//	public void setSubVatTp(String subVatTp) {
//		this.subVatTp = subVatTp;
//	}
//
//	public String getSubVatBan() {
//		return subVatBan;
//	}
//
//	public void setSubVatBan(String subVatBan) {
//		this.subVatBan = subVatBan;
//	}
//
//	public String getSubVatTitle() {
//		return subVatTitle;
//	}
//
//	public void setSubVatTitle(String subVatTitle) {
//		this.subVatTitle = subVatTitle;
//	}
//
//	public String getSubVatAddrCity() {
//		return subVatAddrCity;
//	}
//
//	public void setSubVatAddrCity(String subVatAddrCity) {
//		this.subVatAddrCity = subVatAddrCity;
//	}
//
//	public String getSubVatAddrTown() {
//		return subVatAddrTown;
//	}
//
//	public void setSubVatAddrTown(String subVatAddrTown) {
//		this.subVatAddrTown = subVatAddrTown;
//	}
//
//	public String getSubVatAddrTail() {
//		return subVatAddrTail;
//	}
//
//	public void setSubVatAddrTail(String subVatAddrTail) {
//		this.subVatAddrTail = subVatAddrTail;
//	}
//
//	public String getSubCoupon() {
//		return subCoupon;
//	}
//
//	public void setSubCoupon(String subCoupon) {
//		this.subCoupon = subCoupon;
//	}
//
//	public String getSubCouponSn() {
//		return subCouponSn;
//	}
//
//	public void setSubCouponSn(String subCouponSn) {
//		this.subCouponSn = subCouponSn;
//	}
//
//	public String getSubHg() {
//		return subHg;
//	}
//
//	public void setSubHg(String subHg) {
//		this.subHg = subHg;
//	}
//
//	public String getSubHgPoint() {
//		return subHgPoint;
//	}
//
//	public void setSubHgPoint(String subHgPoint) {
//		this.subHgPoint = subHgPoint;
//	}
//
//	public String getSubExVaServ() {
//		return subExVaServ;
//	}
//
//	public void setSubExVaServ(String subExVaServ) {
//		this.subExVaServ = subExVaServ;
//	}
//
//	public String getSubAgreeSms() {
//		return subAgreeSms;
//	}
//
//	public void setSubAgreeSms(String subAgreeSms) {
//		this.subAgreeSms = subAgreeSms;
//	}
//
//	public String getSubAgreeContract() {
//		return subAgreeContract;
//	}
//
//	public void setSubAgreeContract(String subAgreeContract) {
//		this.subAgreeContract = subAgreeContract;
//	}
//
//	public String getAgreeContract1() {
//		return agreeContract1;
//	}
//
//	public void setAgreeContract1(String agreeContract1) {
//		this.agreeContract1 = agreeContract1;
//	}
//
//	public String getAgreeContract2() {
//		return agreeContract2;
//	}
//
//	public void setAgreeContract2(String agreeContract2) {
//		this.agreeContract2 = agreeContract2;
//	}
//
//	public String getAgreeContract3() {
//		return agreeContract3;
//	}
//
//	public void setAgreeContract3(String agreeContract3) {
//		this.agreeContract3 = agreeContract3;
//	}
//
//	public String getAgreeContract4() {
//		return agreeContract4;
//	}
//
//	public void setAgreeContract4(String agreeContract4) {
//		this.agreeContract4 = agreeContract4;
//	}
//
//	public String getAgreeContract5() {
//		return agreeContract5;
//	}
//
//	public void setAgreeContract5(String agreeContract5) {
//		this.agreeContract5 = agreeContract5;
//	}
//
//	public String getAgreeContract6() {
//		return agreeContract6;
//	}
//
//	public void setAgreeContract6(String agreeContract6) {
//		this.agreeContract6 = agreeContract6;
//	}
//
//	public String getAgreeContract7() {
//		return agreeContract7;
//	}
//
//	public void setAgreeContract7(String agreeContract7) {
//		this.agreeContract7 = agreeContract7;
//	}
//
//	public String getAgreeContract8() {
//		return agreeContract8;
//	}
//
//	public void setAgreeContract8(String agreeContract8) {
//		this.agreeContract8 = agreeContract8;
//	}
//
//	public String getFlwWindowToken() {
//		return flwWindowToken;
//	}
//
//	public void setFlwWindowToken(String flwWindowToken) {
//		this.flwWindowToken = flwWindowToken;
//	}
//
//	public Integer getFlwSiteId() {
//		return flwSiteId;
//	}
//
//	public void setFlwSiteId(Integer flwSiteId) {
//		this.flwSiteId = flwSiteId;
//	}
//
//	public String getFlwLyWireless() {
//		return flwLyWireless;
//	}
//
//	public void setFlwLyWireless(String flwLyWireless) {
//		this.flwLyWireless = flwLyWireless;
//	}
//
//	public String getFlwOnsalePromoListId() {
//		return flwOnsalePromoListId;
//	}
//
//	public void setFlwOnsalePromoListId(String flwOnsalePromoListId) {
//		this.flwOnsalePromoListId = flwOnsalePromoListId;
//	}
//
//	public String getFlwVOfferId() {
//		return flwVOfferId;
//	}
//
//	public void setFlwVOfferId(String flwVOfferId) {
//		this.flwVOfferId = flwVOfferId;
//	}
//
//	public String getFlwDOfferId() {
//		return flwDOfferId;
//	}
//
//	public void setFlwDOfferId(String flwDOfferId) {
//		this.flwDOfferId = flwDOfferId;
//	}
//
//	public String getFlwId() {
//		return flwId;
//	}
//
//	public void setFlwId(String flwId) {
//		this.flwId = flwId;
//	}
//
//	public boolean isFlwSkipActIndex() {
//		return flwSkipActIndex;
//	}
//
//	public void setFlwSkipActIndex(boolean flwSkipActIndex) {
//		this.flwSkipActIndex = flwSkipActIndex;
//	}
//
//	public String getSubFirst() {
//		return subFirst;
//	}
//
//	public void setSubFirst(String subFirst) {
//		this.subFirst = subFirst;
//	}
//
//	public String getFlwRelAccFetNos() {
//		return flwRelAccFetNos;
//	}
//
//	public void setFlwRelAccFetNos(String flwRelAccFetNos) {
//		this.flwRelAccFetNos = flwRelAccFetNos;
//	}
//
//	public String getAccFetNos() {
//		return accFetNos;
//	}
//
//	public void setAccFetNos(String accFetNos) {
//		this.accFetNos = accFetNos;
//	}
//
//	public String getFlwDaDefaultType() {
//		return flwDaDefaultType;
//	}
//
//	public void setFlwDaDefaultType(String flwDaDefaultType) {
//		this.flwDaDefaultType = flwDaDefaultType;
//	}
//
//	public String getFlwRelAccQtys() {
//		return flwRelAccQtys;
//	}
//
//	public void setFlwRelAccQtys(String flwRelAccQtys) {
//		this.flwRelAccQtys = flwRelAccQtys;
//	}
//
//	public String getSubAgreeData() {
//		return subAgreeData;
//	}
//
//	public void setSubAgreeData(String subAgreeData) {
//		this.subAgreeData = subAgreeData;
//	}
//
//	public String getFlwDaErrMsg() {
//		return flwDaErrMsg;
//	}
//
//	public void setFlwDaErrMsg(String flwDaErrMsg) {
//		this.flwDaErrMsg = flwDaErrMsg;
//	}
//
//	public String getFlwActAccFetnos() {
//		return flwActAccFetnos;
//	}
//
//	public void setFlwActAccFetnos(String flwActAccFetnos) {
//		this.flwActAccFetnos = flwActAccFetnos;
//	}
//
//	public String getFlwActAccQtys() {
//		return flwActAccQtys;
//	}
//
//	public void setFlwActAccQtys(String flwActAccQtys) {
//		this.flwActAccQtys = flwActAccQtys;
//	}
//
//	public String getSubAgreeTrial() {
//		return subAgreeTrial;
//	}
//
//	public void setSubAgreeTrial(String subAgreeTrial) {
//		this.subAgreeTrial = subAgreeTrial;
//	}
//
//	public String getFlwResetPath() {
//		return flwResetPath;
//	}
//
//	public void setFlwResetPath(String flwResetPath) {
//		this.flwResetPath = flwResetPath;
//	}
//
//	public String getEinvoiceDeviceType() {
//		return einvoiceDeviceType;
//	}
//
//	public void setEinvoiceDeviceType(String einvoiceDeviceType) {
//		this.einvoiceDeviceType = einvoiceDeviceType;
//	}
//
//	public String getEinvoiceDeviceId() {
//		return einvoiceDeviceId;
//	}
//
//	public void setEinvoiceDeviceId(String einvoiceDeviceId) {
//		this.einvoiceDeviceId = einvoiceDeviceId;
//	}
//
//	public String getDonateUnitId() {
//		return donateUnitId;
//	}
//
//	public void setDonateUnitId(String donateUnitId) {
//		this.donateUnitId = donateUnitId;
//	}
//
//	public String getDonateUnitName() {
//		return donateUnitName;
//	}
//
//	public void setDonateUnitName(String donateUnitName) {
//		this.donateUnitName = donateUnitName;
//	}
//
//	public String getInvoiceType() {
//		return invoiceType;
//	}
//
//	public void setInvoiceType(String invoiceType) {
//		this.invoiceType = invoiceType;
//	}
//	
//	public String getFlwWtMcId() {
//		return flwWtMcId;
//	}
//
//	public void setFlwWtMcId(String flwWtMcId) {
//		this.flwWtMcId = flwWtMcId;
//	}
//
//	public String getRecommendSource() {
//		return recommendSource;
//	}
//
//	public void setRecommendSource(String recommendSource) {
//		this.recommendSource = recommendSource;
//	}
//
//	public String getRecommendDesc() {
//		return recommendDesc;
//	}
//
//	public void setRecommendDesc(String recommendDesc) {
//		this.recommendDesc = recommendDesc;
//	}
//
//	public String getMvpnVatNo() {
//		return mvpnVatNo;
//	}
//
//	public void setMvpnVatNo(String mvpnVatNo) {
//		this.mvpnVatNo = mvpnVatNo;
//	}
//
//	public String getSubNetCoverRate() {
//		return subNetCoverRate;
//	}
//
//	public void setSubNetCoverRate(String subNetCoverRate) {
//		this.subNetCoverRate = subNetCoverRate;
//	}
//
//    public String getSubPaymentConsolidation() {
//        return subPaymentConsolidation;
//    }
//
//    public void setSubPaymentConsolidation(String subPaymentConsolidation) {
//        this.subPaymentConsolidation = subPaymentConsolidation;
//    }
//
//    public String getSubIdCardYear() {
//        return subIdCardYear;
//    }
//
//    public void setSubIdCardYear(String subIdCardYear) {
//        this.subIdCardYear = subIdCardYear;
//    }
//
//    public String getSubIdCardMonth() {
//        return subIdCardMonth;
//    }
//
//    public void setSubIdCardMonth(String subIdCardMonth) {
//        this.subIdCardMonth = subIdCardMonth;
//    }
//
//    public String getSubIdCardDate() {
//        return subIdCardDate;
//    }
//
//    public void setSubIdCardDate(String subIdCardDate) {
//        this.subIdCardDate = subIdCardDate;
//    }
//
//    public String getSubIdCardCity() {
//        return subIdCardCity;
//    }
//
//    public void setSubIdCardCity(String subIdCardCity) {
//        this.subIdCardCity = subIdCardCity;
//    }
//
//    public String getSubIdCardType() {
//        return subIdCardType;
//    }
//
//    public void setSubIdCardType(String subIdCardType) {
//        this.subIdCardType = subIdCardType;
//    }
//
//	public List<String> getFlwProductIds() {
//		return flwProductIds;
//	}
//
//	public void setFlwProductIds(List<String> flwProductIds) {
//		this.flwProductIds = flwProductIds;
//	}
//
//	public List<String> getFlwFetNos() {
//		return flwFetNos;
//	}
//
//	public void setFlwFetNos(List<String> flwFetNos) {
//		this.flwFetNos = flwFetNos;
//	}
//	
//	public String getIsApp() {
//		return isApp;
//	}
//
//	public void setIsApp(String isApp) {
//		this.isApp = isApp;
//	}
//	public String getSelfHelpingPromotion1() {
//		return selfHelpingPromotion1;
//	}
//	public void setSelfHelpingPromotion1(String selfHelpingPromotion1) {
//		this.selfHelpingPromotion1 = selfHelpingPromotion1;
//	}
//	public String getSelfHelpingPromotion2() {
//		return selfHelpingPromotion2;
//	}
//	public void setSelfHelpingPromotion2(String selfHelpingPromotion2) {
//		this.selfHelpingPromotion2 = selfHelpingPromotion2;
//	}
//	public String getSelfHelpingPromotion3() {
//		return selfHelpingPromotion3;
//	}
//	public void setSelfHelpingPromotion3(String selfHelpingPromotion3) {
//		this.selfHelpingPromotion3 = selfHelpingPromotion3;
//	}
//	public String getDevFetNo() {
//		return devFetNo;
//	}
//	public void setDevFetNo(String devFetNo) {
//		this.devFetNo = devFetNo;
//	}
//	public String getFourRecordZone() {
//		return fourRecordZone;
//	}
//	public void setFourRecordZone(String fourRecordZone) {
//		this.fourRecordZone = fourRecordZone;
//	}
//
//	public String getCsStoreCvsid() {
//		return csStoreCvsid;
//	}
//
//	public void setCsStoreCvsid(String csStoreCvsid) {
//		this.csStoreCvsid = csStoreCvsid;
//	}
//
//	public String getCsStoreCvsname() {
//		return csStoreCvsname;
//	}
//
//	public void setCsStoreCvsname(String csStoreCvsname) {
//		this.csStoreCvsname = csStoreCvsname;
//	}
//
//	public String getCsStoreNo() {
//		return csStoreNo;
//	}
//
//	public void setCsStoreNo(String csStoreNo) {
//		this.csStoreNo = csStoreNo;
//	}
//
//	public String getCsStoreName() {
//		return csStoreName;
//	}
//
//	public void setCsStoreName(String csStoreName) {
//		this.csStoreName = csStoreName;
//	}
//
//	public String getCsStoreTel() {
//		return csStoreTel;
//	}
//
//	public void setCsStoreTel(String csStoreTel) {
//		this.csStoreTel = csStoreTel;
//	}
//
//	public String getCsStoreAddress() {
//		return csStoreAddress;
//	}
//
//	public void setCsStoreAddress(String csStoreAddress) {
//		this.csStoreAddress = csStoreAddress;
//	}
//}
