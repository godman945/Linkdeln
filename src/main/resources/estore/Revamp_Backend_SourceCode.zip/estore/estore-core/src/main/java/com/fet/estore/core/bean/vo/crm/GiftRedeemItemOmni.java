package com.fet.estore.core.bean.vo.crm;

import java.io.Serializable;

public class GiftRedeemItemOmni implements Serializable {
	
	public static final String GIFT_REDEEM_TYPE_SUBSIDY = "SUBSIDY";
	public static final String GIFT_REDEEM_TYPE_DISCOUNT = "DISCOUNT";
	public static final String GIFT_REDEEM_TYPE_DEPOSIT = "DEPOSIT";
	public static final String GIFT_REDEEM_TYPE_PREPAYMENT = "PREPAYMENT";
	
	
	private String campaignCode;
	private String campaignName;
	private String age;
	private String arpb;
	private String tenure;
	private String vipType;
	private String promotionType;
	private String anote;
	private String promotionId;
	private String giftCode;
	private String giftId;
	private String giftType;
	private String giftValue;
	private String giftName;
	private Long price;
	private String fetNo;
	private String voiceOrData;
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getArpb() {
		return arpb;
	}
	public void setArpb(String arpb) {
		this.arpb = arpb;
	}
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getCampaignName() {
		return campaignName;
	}
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	public String getVipType() {
		return vipType;
	}
	public void setVipType(String vipType) {
		this.vipType = vipType;
	}
	public String getPromotionType() {
		return promotionType;
	}
	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}
	public String getAnote() {
		return anote;
	}
	public void setAnote(String anote) {
		this.anote = anote;
	}
	public String getPromotionId() {
		return promotionId;
	}
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	public String getGiftCode() {
		return giftCode;
	}
	public void setGiftCode(String giftCode) {
		this.giftCode = giftCode;
	}
	public String getGiftId() {
		return giftId;
	}
	public void setGiftId(String giftId) {
		this.giftId = giftId;
	}
	public String getGiftType() {
		return giftType;
	}
	public void setGiftType(String giftType) {
		this.giftType = giftType;
	}
	public String getGiftValue() {
		return giftValue;
	}
	public void setGiftValue(String giftValue) {
		this.giftValue = giftValue;
	}
	public String getGiftName() {
		return giftName;
	}
	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getVoiceOrData() {
		return voiceOrData;
	}
	public void setVoiceOrData(String voiceOrData) {
		this.voiceOrData = voiceOrData;
	}
	
	
}
