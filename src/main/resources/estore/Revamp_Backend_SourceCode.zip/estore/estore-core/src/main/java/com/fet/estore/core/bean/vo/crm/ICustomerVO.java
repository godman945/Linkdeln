package com.fet.estore.core.bean.vo.crm;

import java.util.Date;
import java.util.List;

//import com.fet.car.fact.AccountOwner;
//import com.fet.car.fact.Subscriber;
//import com.fetnet.integration.ia.entity.ExtraService;

public interface ICustomerVO {
	/** 客戶升級類型 - 一般取約 */
	public static final String LOYALTY_UPGRADE_TYPE_NORMAL = "NORMAL";
	/** 客戶升級類型 - 資費價差取約 */
	public static final String LOYALTY_UPGRADE_TYPE_SPREAD = "SPREAD";
	/** 客戶升級類型 - 指定資費 */
	public static final String LOYALTY_UPGRADE_TYPE_ASSIGN = "ASSIGN";
    /** 客戶升級類型 - 換約資費 */
    public static final String LOYALTY_UPGRADE_TYPE_CHANGE = "CHANGE";
	
	
	public abstract String getSubscriberSerializedObject();
	

	public abstract String getAccountOwnerSerializedObject();
	
	
	public abstract boolean isVdOffer();

	public abstract void setVdOffer(boolean vdOffer);

//	public abstract AccountOwner getAccountOwner();
//
//	public abstract void setAccountOwner(AccountOwner accountOwner);
//
//	public abstract Subscriber getSubscriber();
//
//	public abstract void setSubscriber(Subscriber subscriber);

//	public abstract String getSubscriberId();

//	public abstract String getAccountId();

//	public abstract Date getLastContractEndDate();

//	public abstract Long getArpb();

//	public abstract String getLastContractPromotionId();

//	public abstract String getBillingCycle();

//	public abstract String getChurnIndex();

	public abstract String getVipGrade();

	public abstract String getImageCode();

	public abstract String getSubsidy();

	public abstract String getSubscriberMsisdn();

	public abstract String getCurrentVoiceDescription();

	public abstract String getAccountIdType();

	public abstract boolean isWala();

	public abstract boolean isHybrid();

	/**
	 * 檢查續約使用者門號狀態
	 * @return 錯誤訊息
	 */
	public abstract String checkMsisdnStatus();

	public abstract String getLyMdn();

	public abstract void setLyMdn(String lyMdn);

	public abstract String getNpMdn();

	public abstract void setNpMdn(String npMdn);

	public abstract String getLyVOfferId();

	public abstract void setLyVOfferId(String lyVOfferId);

	public abstract String getLyDOfferId();

	public abstract void setLyDOfferId(String lyDOfferId);

	public abstract Long getLyVOfferPrice();

	public abstract void setLyVOfferPrice(Long lyVOfferPrice);

	public abstract Long getLyDOfferPrice();

	public abstract void setLyDOfferPrice(Long lyDOfferPrice);

	public abstract boolean isLyDataOnly();

	public abstract void setLyDataOnly(boolean lyDataOnly);

	public abstract String getCustomerName();

	public abstract void setCustomerName(String customerName);

	public abstract String getCustomerRocId();

	public abstract void setCustomerRocId(String customerRocId);

	public abstract Date getCustomerBirthDay();

	public abstract void setCustomerBirthDay(Date customerBirthDay);

	public abstract String getCustomerRegAddr();

	public abstract void setCustomerRegAddr(String customerRegAddr);

	public abstract String getCustomerBillAddr();

	public abstract void setCustomerBillAddr(String customerBillAddr);

	public abstract String getCustomerBillTp();

	public abstract boolean isBillingMethodMidifiable();

	public abstract void setCustomerBillTp(String customerBillTp);

	public abstract String getLyVOfferName();

	public abstract void setLyVOfferName(String lyVOfferName);

	public abstract String getLyDOfferName();

	public abstract void setLyDOfferName(String lyDOfferName);

	public abstract String getCustomerSex();

	public abstract void setCustomerSex(String customerSex);

	public abstract String getCustomerEmail();

	public abstract void setCustomerEmail(String customerEmail);

	public abstract String getCustomerRegZipCode();

	public abstract void setCustomerRegZipCode(String customerRegZipCode);

	public abstract String getCustomerBillZipCode();

	public abstract void setCustomerBillZipCode(String customerBillZipCode);

	public abstract String getCustomerLastName();

	public abstract void setCustomerLastName(String customerLastName);

	public abstract String getCustomerTelPre1();

	public abstract String getCustomerTel1();

	public abstract boolean hasFutureTask();

	public abstract String getCustomerTelPre2();

	public abstract String getCustomerTel2();

	/**
	 * 取得使用者目前服務(2G/3G/4G)
	 * @return
	 */
	public abstract String getSubscriberType();

	public abstract String getBizEntity();

	public abstract Integer getDataMasterReduceAmoun();

	public abstract void setDataMasterReduceAmoun(Integer dataMasterReduceAmoun);

	public abstract Integer getVoiceMasterReduceAmoun();

	public abstract void setVoiceMasterReduceAmoun(
			Integer voiceMasterReduceAmoun);

	public abstract List<CarPromotionVO> getAvailablePromotions();

	public abstract void setAvailablePromotions(
			List<CarPromotionVO> availablePromotions);

//	public abstract ServiceDetailVO getServiceDetailVO();
//
//	public abstract void setServiceDetailVO(ServiceDetailVO serviceDetailVO);
	
//	public abstract List<ExtraService> getExtraServices();
//	
//	public abstract void setExtraServices(List<ExtraService> extraServices);
	
	public abstract Date getLastContractEndDateForNewIncentive();
	
	public abstract String getLastContractPromotionIdForNewIncentive();
	
	public abstract String getLastContractPromotionCodeForNewIncentive();
	
	public abstract String getLastContractPromotionNameForNewIncentive();
	
	public abstract String getLastSubContractPromotionCodeForNewIncentive();
	
	public abstract String getLastSubContractPromotionNameForNewIncentive();
	
	public abstract String getLastSubContractPromotionIdForNewIncentive();
	
	public abstract Date getLastSubContractEndDateForNewIncentive();
	
	public abstract boolean isPassVipLoyalty();

	public abstract void setPassVipLoyalty(boolean passVipLoyalty);
	
	public abstract String getLoyaltyUpgradeType();
	
	public abstract void setLoyaltyUpgradeType(String loyaltyUpgradeType);
}