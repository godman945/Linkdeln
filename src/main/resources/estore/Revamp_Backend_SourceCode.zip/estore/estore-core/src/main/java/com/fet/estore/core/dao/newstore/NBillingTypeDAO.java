package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.BillingType;

public interface NBillingTypeDAO extends BaseDAO<BillingType, Long> {

	/**
	 * 依名稱取得帳單類別
	 * @param name
	 * @return
	 */
	public BillingType findByName(String name);
}
