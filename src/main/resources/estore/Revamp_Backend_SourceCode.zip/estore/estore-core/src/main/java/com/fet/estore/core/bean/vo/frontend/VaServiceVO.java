package com.fet.estore.core.bean.vo.frontend;

public class VaServiceVO {
	/** 加值服務ID */
	private String seq;
	/** 名稱 */
	private String vasName;
	/** 加值服務代碼 */
	private String vasCode;	
	/** 費率說明 */
	private String rate;
	/** 加值服務ID */
	private String description;	
	/** 是否已預先選取 */
	private boolean checked;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getVasName() {
		return vasName;
	}
	public void setVasName(String vasName) {
		this.vasName = vasName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public String getVasCode() {
		return vasCode;
	}
	public void setVasCode(String vasCode) {
		this.vasCode = vasCode;
	}
}
