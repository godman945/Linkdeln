package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.bean.Product;
import com.fet.estore.core.bean.bo.FindProductBO;
import com.fet.estore.core.bean.req.ProductListReq;
import com.fet.estore.core.dao.base.BaseDAO;

/**
 *
 */
public interface IAccessoryDAO extends BaseDAO<Product, String>  {

	/**
	 * 依據 ProductListQueryForm 帶入條件查詢配件清單
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-08-03
	 * @param findProductBO
	 * @return
	 */
	List<Product> findAccessories(FindProductBO findProductBO);
	
	
}
