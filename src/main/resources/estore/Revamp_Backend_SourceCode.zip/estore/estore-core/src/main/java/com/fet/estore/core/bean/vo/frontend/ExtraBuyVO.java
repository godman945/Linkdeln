package com.fet.estore.core.bean.vo.frontend;

public class ExtraBuyVO {

	private String productId;
	/** 商品名稱 */
	private String productName;
	/** 商品單價 */
	private Long money;
	/** 數量 **/
	private Integer amount;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Long getMoney() {
		return money;
	}
	public void setMoney(Long money) {
		this.money = money;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
}
