package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.fet.estore.core.util.LogUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HandsetGroupVO implements Serializable {
	
	private static final Logger logger = LogManager.getLogger(HandsetGroupVO.class);
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8506152410588926309L;
	/** 手機廠牌 */
	private String brand;
	private String brandId;
	/** 預設圖檔 */
	private String defaultImage;
	/** 預設第二順位圖檔 */
	private String secondImage;
	/** 圖檔路徑 */
	private String imagePath;
	/** 小圖圖檔路徑 */
	private String smallImagePath;
	/** 大圖圖檔路徑 */
	private String largeImagePath;
	/** 料號 */
	private String fetNo;
	/** 顏色ID */
	private String colorId;
	/** 顏色 */
	private String color;
	/** 設備摘要 */
	private String brief;
	/** 設備代碼 */
	private String deviceId;
	/** 商品編號 */
	private String productId;
	/** 手機型號 */
	private String modelName;
	/** 是否加入手機比較 */
	private Boolean isComparable;
	/** 是否為獨家商品 */
	private Boolean isExclusive;
	/** 預購開始時間 */
	private Date preSubscribeBeginDate;
	/** 預購結束時間 */
	private Date preSubscribeEndDate;
	/** 說明小標題 */
	private String viewTitle;
	/** 說明小標題2。 */
	private String viewTitle2;
	/** 說明小標題3。 */
	private String viewTitle3;
	/** 說明小標題4。 */
	private String viewTitle4;
	/** 說明小標題5。 */
	private String viewTitle5;
	/** 簡要說明 */
	private String viewDesc;
	 /** 簡要說明2。 */
	private String viewDesc2;
	 /** 簡要說明3。 */
	private String viewDesc3;
	 /** 簡要說明4。 */
	private String viewDesc4;
	 /** 簡要說明5。 */
	private String viewDesc5;
	/** 簡要說明清單 */
	private String[] viewDescs;
	/** 最低價格。 */
	private Long lowestPrice;
	/** 一般資費最低價格。 */
	private Long lowestPriceLow;
	/** 中資費最低價格。 */
	private Long lowestPriceNormal;
	/** 高資費最低價格。 */
	private Long lowestPriceHigh;
	/** 續約資費最低價格。 */
	private Long lowestInstalmentPrice;
	/** 分期付款-期數 */
	private Long installmentTenor;
	/** 分期付款-最低期數 */
	private Long lowestInstalment;
	/** 分期付款-續約最低期數 */
	private Long lowestInstalmentInLy;
	/** totalPayment */
	private Long totalPayment;
	/** 手機促銷圖示 */
	private List<PromoIconVO> promoIconPromotions;
	/** 手機功能圖示 */
	private List<PromoIconVO> promoIconFunctions;
	/** 手機圖片(大) */
	private Set<String> largePicFileNames;
	/** 手機圖片(中) */
	private Set<String> mediumPicFileNames;
	/** 手機圖片(小) */
	private Set<String> smallPicFileNames;
	/** 手機圖片(特大) */
	private Set<String> bigLargePicFileNames;
	/** 搜尋關鍵字。 */
	private String searchKeyword;
	/** 單買最低價。 */
	private Long erpPrice;
	/** 續約最低價。 */
	private Long lyLowestPrice;
	/** 新申辦最低價。 */
	private Long gaLowestPrice;
	/** 攜碼申辦最低價。 */
	private Long npLowestPrice;
	 /** 銷售型態 */
    private String sellType;
    /** 是否為置頂商品  是:'Y',否:'N'*/
    private String stickyFlag;
    /** 置頂商品 圖示*/
    private String stickyPicPath;
    /** 置頂商品 圖示名稱*/
    private String stickyPicName;
    /** 是否可宅配 */
    private Boolean isHomeDeliverable;
    /** 是否可門市 */
    private Boolean isStoreDeliverable;
    /** 置頂商品flag */
    private String stickFlag;
    /** 料號庫存 */
    private Long inventory;
    /** aliasUrl */
    private String aliasUrl;
    /** 熱銷數量 */
    private Integer cohotCount;
    /** 上架日期 */
    private Date onsaleDate;
    
    private Long discountPrice;
    
    /** 新申辦最低優惠價 */
    private Long gaDiscountLowestPrice;
    /** 續約最低優惠價 */
    private Long lyDiscountLowestPrice;
    /** 單買最低優惠價 */
    private Long daDiscountLowestPrice;    
    
    /** 判斷是否為預購期間 */
    private Boolean isPreSubscribeDate;
    
    /** 畫面顯示brand modelName*/
    private String showProductName;
    
    /** 畫面顯示brand modelName*/
    private String showViewDesc;
    
    /** 預設byte length*/
    private static final int SUB_BYTE_LENGTH = 30;
    
    /** 畫面顯示brand modelName*/
    private String showHomeProductName;
    
    /** 預設byte length*/
    private static final int SUB_BYTE_LENGTH_4HOME = 35;
    
    /** 預設超過字符*/
    private static final String OVER_STR = "..";
    /** 預設超過字符*/
    private static final String OVER_STR_W = "...";
    
    private Long estoreInventory;
    /** 配件名稱*/
    private String name;
    
    private Long atrInventory;
    
    private Long unavailableQuantity;
    
    private Boolean isUnavailableInform;
    
    private Date unavailableStartTime;
    
    private Date unavailableEndTime;
    
    private String atrStatus;
    
    private Boolean applyUnavailable;
    
    private Boolean is2G;
    private Boolean is3G;
    private Boolean is4G;
    private Boolean allowPick;
    private Boolean reservation;
    //小網五點說明
    private String mobileViewDesc;
    private String mobileViewDesc2;
    private String mobileViewDesc3;
    private String mobileViewDesc4;
    private String mobileViewDesc5;
	/** 簡要說明清單 */
	private String[] mobileViewDescs;
    //seo
	private String seoTitle;
	private String seoDescription;
	private String seoKeywords;
	
	/** 大圖可局部放大 */
	private Boolean isPicZoom;
	/** 商品規格頁籤是否顯示 */
	private Boolean isSpecShow;
	/** 商品介紹頁籤是否顯示 */
	private Boolean isDescShow;
	/** 商品圖右方重點說明 */
	private String wrighthandDesc;
	/** 推薦文URL*/
	private String recommendUrl;
	/**商品介紹**/
	private String dimDescription;
	/**商品介紹1**/
	private String dimDescription1;
	/**商品介紹2**/
	private String dimDescription2;
	
	/** 上蓋銷售量檢查 */
    private Boolean checkAtr;
	/**	是否檢查ESTORE自訂量 */
	private Boolean checkLocalAtr;
	/** ESTORE自訂量狀態 */
	private Boolean localAtrStatus;
	/** ATR檢查狀態 */
	private Boolean newAtrStatus;
	//（檢查ESTORE自訂量起始時間）
	private Date checkLocalAtrStartTime;
	//（檢查ESTORE自訂量結束時間）
	private Date checkLocalAtrEndTime;
	//多主商品的群組編號
	private String groupNumber;
	//商品型態1:手機 , 2:配件
	private String prodtypeno;
	
  	private Integer extraBuyId;
  	
  	private Integer extraBuyItemId;
  	
  	private Integer categoryExtarBuyLimit;
  	
  	private Integer handsetExtarBuyLimit;
	//多主商品價格
	private List<MultiprodActPriceVO> multiprodActPrices;
	//NDS phase2
	private List<HandsetGroupVO> subHandsetGroupVOs = new ArrayList<HandsetGroupVO>();

    /** 商品圖右方重點說明:一般賣場 */
    private Boolean wrighthandDescBau;
    /** 商品圖右方重點說明:CBU賣場 */
    private Boolean wrighthandDescCbu;
    /** 商品圖右方重點說明:EBU賣場 */
    private Boolean wrighthandDescEbu;
	/** 2020-08-14 Ted.Hsieh 新增 商品圖右方重點說明:標題 */
	private String wrighthandDescTitle;
	
    // 有貨: return true;
    // 缺貨: return false;
    public Boolean getIsOutOfStock() throws Exception {
        
        /*
        if( unavailableQuantity > 0 ) {
            return false;
        } else if ( estoreInventory == 0 && atrInventory == 0 ) {
            return false;
        } else {
            return true;
        }
        */
        
        if ( getIsUnavailableInformDate() && "UNAVAILABLE".equals(atrStatus) ) {
            return false;
        }
        
        if (checkAtr != null && checkAtr) {
            if (checkLocalAtr != null && checkLocalAtr ) {
            	Date date = new Date();
            	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            	Date start = null;
				Date end = null;
				try {
					start = sdf.parse(sdf.format(this.checkLocalAtrStartTime));
					end = sdf.parse(StringUtils.replace(sdf.format(this.checkLocalAtrEndTime), " 00:00:00", " 23:59:59"));
				} catch (Exception e) {
					LogUtil.error("執行getIsOutOfStock發生異常", e);
				}
            	if(checkLocalAtrStartTime != null && checkLocalAtrEndTime != null
            			&& start != null && end != null && date.after(start) && date.before(end)){
            		return null != localAtrStatus ? localAtrStatus.booleanValue() : true;
            	}else{
            		return null != newAtrStatus ? newAtrStatus.booleanValue() : true;
            	}                
            } else {
                return null != newAtrStatus ? newAtrStatus.booleanValue() : true;
            }
        }
        
        return true;
    }
    
    // 判斷是否為缺貨通知期間
    // 當該手機有被設定缺貨通知且今天在缺貨通知期間, return true
    // else return false
    public Boolean getIsUnavailableInformDate() throws Exception {
        boolean flag = false;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if(this.unavailableStartTime != null && this.unavailableEndTime !=null){
            Date prb = sdf.parse(sdf.format(this.unavailableStartTime));
            Date pre = sdf.parse(sdf.format(this.unavailableEndTime));
            Date today = sdf.parse(sdf.format(new Date()));
            if(Boolean.TRUE.equals(isUnavailableInform) && pre.after(today) && prb.before(today)){
                flag = true;
            }
        }
        return flag;
    }
    
    /** 判斷是否為預購期間 
     * @throws Exception */
	
	public Boolean getIsPreSubscribeDate() throws Exception {
		boolean flag = false;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if(this.preSubscribeBeginDate != null && this.preSubscribeEndDate !=null){
			Date prb = sdf.parse(sdf.format(this.preSubscribeBeginDate));
			Date pre = sdf.parse(sdf.format(this.preSubscribeEndDate));
			Date today = sdf.parse(sdf.format(new Date()));
			if(Boolean.TRUE.equals(isPreSubscribeDate) && pre.after(today) && prb.before(today)){
				flag = true;
			}
		}
		return flag;
	}

	public void setIsPreSubscribeDate(Boolean isPreSubscribeDate) {
		this.isPreSubscribeDate = isPreSubscribeDate;
	}

	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getDefaultImage() {
		return defaultImage;
	}
	public void setDefaultImage(String defaultImage) {
		this.defaultImage = defaultImage;
	}
	
	
	public String getSecondImage() {
		return secondImage;
	}

	public void setSecondImage(String secondImage) {
		this.secondImage = secondImage;
	}

	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getSmallImagePath() {
		return smallImagePath;
	}
	public void setSmallImagePath(String smallImagePath) {
		this.smallImagePath = smallImagePath;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public Boolean getIsComparable() {
		return isComparable;
	}
	public void setIsComparable(Boolean isComparable) {
		this.isComparable = isComparable;
	}
	public Boolean getIsExclusive() {
		return isExclusive;
	}
	public void setIsExclusive(Boolean isExclusive) {
		this.isExclusive = isExclusive;
	}
	public Date getPreSubscribeBeginDate() {
		return preSubscribeBeginDate;
	}
	public void setPreSubscribeBeginDate(Date preSubscribeBeginDate) {
		this.preSubscribeBeginDate = preSubscribeBeginDate;
	}
	public Date getPreSubscribeEndDate() {
		return preSubscribeEndDate;
	}
	public void setPreSubscribeEndDate(Date preSubscribeEndDate) {
		this.preSubscribeEndDate = preSubscribeEndDate;
	}
	public String getViewTitle() {
		return viewTitle;
	}
	public void setViewTitle(String viewTitle) {
		this.viewTitle = viewTitle;
	}
	public String getViewDesc() {
		return viewDesc;
	}
	public void setViewDesc(String viewDesc) {
		this.viewDesc = viewDesc;
	}
	public Long getInstallmentTenor() {
		return installmentTenor;
	}
	public void setInstallmentTenor(Long installmentTenor) {
		this.installmentTenor = installmentTenor;
	}
	public Long getLowestInstalment() {
		return lowestInstalment;
	}
	public void setLowestInstalment(Long lowestInstalment) {
		this.lowestInstalment = lowestInstalment;
	}
	public Long getLowestInstalmentInLy() {
		return lowestInstalmentInLy;
	}
	public void setLowestInstalmentInLy(Long lowestInstalmentInLy) {
		this.lowestInstalmentInLy = lowestInstalmentInLy;
	}
	public Long getTotalPayment() {
		return totalPayment;
	}
	public void setTotalPayment(Long totalPayment) {
		this.totalPayment = totalPayment;
	}
	public List<PromoIconVO> getPromoIconPromotions() {
		return promoIconPromotions;
	}
	public void setPromoIconPromotions(List<PromoIconVO> promoIconPromotions) {
		this.promoIconPromotions = promoIconPromotions;
	}
	public List<PromoIconVO> getPromoIconFunctions() {
		return promoIconFunctions;
	}
	public void setPromoIconFunctions(List<PromoIconVO> promoIconFunctions) {
		this.promoIconFunctions = promoIconFunctions;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getColorId() {
		return colorId;
	}
	public void setColorId(String colorId) {
		this.colorId = colorId;
	}
	public Set<String> getLargePicFileNames() {
		return largePicFileNames;
	}
	public void setLargePicFileNames(Set<String> largePicFileNames) {
		this.largePicFileNames = largePicFileNames;
	}
	public Set<String> getMediumPicFileNames() {
		return mediumPicFileNames;
	}
	public void setMediumPicFileNames(Set<String> mediumPicFileNames) {
		this.mediumPicFileNames = mediumPicFileNames;
	}
	public Set<String> getSmallPicFileNames() {
		return smallPicFileNames;
	}
	public void setSmallPicFileNames(Set<String> smallPicFileNames) {
		this.smallPicFileNames = smallPicFileNames;
	}
	public String getLargeImagePath() {
		return largeImagePath;
	}

	public void setLargeImagePath(String largeImagePath) {
		this.largeImagePath = largeImagePath;
	}

	public Set<String> getBigLargePicFileNames() {
		return bigLargePicFileNames;
	}
	public void setBigLargePicFileNames(Set<String> bigLargePicFileNames) {
		this.bigLargePicFileNames = bigLargePicFileNames;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getViewTitle2() {
		return viewTitle2;
	}
	public void setViewTitle2(String viewTitle2) {
		this.viewTitle2 = viewTitle2;
	}
	public String getViewTitle3() {
		return viewTitle3;
	}
	public void setViewTitle3(String viewTitle3) {
		this.viewTitle3 = viewTitle3;
	}
	public String getViewTitle4() {
		return viewTitle4;
	}
	public void setViewTitle4(String viewTitle4) {
		this.viewTitle4 = viewTitle4;
	}
	public String getViewTitle5() {
		return viewTitle5;
	}
	public void setViewTitle5(String viewTitle5) {
		this.viewTitle5 = viewTitle5;
	}
	public String getViewDesc2() {
		return viewDesc2;
	}
	public void setViewDesc2(String viewDesc2) {
		this.viewDesc2 = viewDesc2;
	}
	public String getViewDesc3() {
		return viewDesc3;
	}
	public void setViewDesc3(String viewDesc3) {
		this.viewDesc3 = viewDesc3;
	}
	public String getViewDesc4() {
		return viewDesc4;
	}
	public void setViewDesc4(String viewDesc4) {
		this.viewDesc4 = viewDesc4;
	}
	public String getViewDesc5() {
		return viewDesc5;
	}
	public void setViewDesc5(String viewDesc5) {
		this.viewDesc5 = viewDesc5;
	}
	public Long getLowestPrice() {
		return lowestPrice;
	}
	public void setLowestPrice(Long lowestPrice) {
		this.lowestPrice = lowestPrice;
	}
	public Long getLowestPriceLow() {
		return lowestPriceLow;
	}
	public void setLowestPriceLow(Long lowestPriceLow) {
		this.lowestPriceLow = lowestPriceLow;
	}
	public Long getLowestPriceNormal() {
		return lowestPriceNormal;
	}
	public void setLowestPriceNormal(Long lowestPriceNormal) {
		this.lowestPriceNormal = lowestPriceNormal;
	}
	public Long getLowestPriceHigh() {
		return lowestPriceHigh;
	}
	public void setLowestPriceHigh(Long lowestPriceHigh) {
		this.lowestPriceHigh = lowestPriceHigh;
	}
	public Long getLowestInstalmentPrice() {
		return lowestInstalmentPrice;
	}
	public void setLowestInstalmentPrice(Long lowestInstalmentPrice) {
		this.lowestInstalmentPrice = lowestInstalmentPrice;
	}
	public String getSearchKeyword() {
		return searchKeyword;
	}
	public void setSearchKeyword(String searchKeyword) {
		this.searchKeyword = searchKeyword;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	public Long getLyLowestPrice() {
		return lyLowestPrice;
	}
	public void setLyLowestPrice(Long lyLowestPrice) {
		this.lyLowestPrice = lyLowestPrice;
	}
	public Long getGaLowestPrice() {
		return gaLowestPrice;
	}
	public void setGaLowestPrice(Long gaLowestPrice) {
		this.gaLowestPrice = gaLowestPrice;
	}
	public Long getNpLowestPrice() {
		return npLowestPrice;
	}

	public void setNpLowestPrice(Long npLowestPrice) {
		this.npLowestPrice = npLowestPrice;
	}

	public String getSellType() {
		return sellType;
	}
	public void setSellType(String sellType) {
		this.sellType = sellType;
	}
	public String[] getViewDescs() {
		viewDescs = new String[]{this.viewDesc,this.viewDesc2,this.viewDesc3,this.viewDesc4,this.viewDesc5};
		return viewDescs;
	}
	public void setViewDescs(String[] viewDescs) {
		this.viewDescs = viewDescs;
	}

	public String getStickyFlag() {
		return stickyFlag;
	}

	public void setStickyFlag(String stickyFlag) {
		this.stickyFlag = stickyFlag;
	}

	public String getStickyPicPath() {
		return stickyPicPath;
	}

	public void setStickyPicPath(String stickyPicPath) {
		this.stickyPicPath = stickyPicPath;
	}

	public String getStickyPicName() {
		return stickyPicName;
	}

	public void setStickyPicName(String stickyPicName) {
		this.stickyPicName = stickyPicName;
	}

	public Boolean getIsHomeDeliverable() {
		return isHomeDeliverable;
	}

	public void setIsHomeDeliverable(Boolean isHomeDeliverable) {
		this.isHomeDeliverable = isHomeDeliverable;
	}

	public Boolean getIsStoreDeliverable() {
		Boolean isStore = isStoreDeliverable; 
		if(isStoreDeliverable != null) {
			try {			
				boolean isPreDate = this.getIsPreSubscribeDate();
				if(isPreDate) isStore = false;
			} catch(Exception ex) {}
		}
		return isStore;
	}

	public void setIsStoreDeliverable(Boolean isStoreDeliverable) {
		this.isStoreDeliverable = isStoreDeliverable;
	}

	public String getStickFlag() {
		return stickFlag;
	}

	public void setStickFlag(String stickFlag) {
		this.stickFlag = stickFlag;
	}

	public Long getInventory() {
		return inventory;
	}

	public void setInventory(Long inventory) {
		this.inventory = inventory;
	}

	public String getAliasUrl() {
		return aliasUrl;
	}

	public void setAliasUrl(String aliasUrl) {
		this.aliasUrl = aliasUrl;
	}

	
	public String getShowHomeProductName() {
		String subProductName = null;
		try {
			StringBuilder br = new StringBuilder();
			br.append(StringUtils.isNotBlank(this.getBrand()) ? this.getBrand() : "" );
			br.append(" ");
			br.append(StringUtils.isNotBlank(this.getModelName()) ? this.getModelName() : "");
			subProductName = br.toString();
			if(subProductName.getBytes().length > this.SUB_BYTE_LENGTH_4HOME){
				subProductName = subStr_W(subProductName,this.SUB_BYTE_LENGTH_4HOME);
			}
		} catch (Exception e) {
			LogUtil.error("執行getShowHomeProductName發生異常", e);
		}
		
		return subProductName;
	}

	public void setShowHomeProductName(String showHomeProductName) {
		this.showHomeProductName = showHomeProductName;
	}

	public String getShowProductName() {
		String subProductName = null;
		try {
			StringBuilder br = new StringBuilder();
			br.append(StringUtils.isNotBlank(this.getBrand()) ? this.getBrand() : "" );
			br.append(" ");
			br.append(StringUtils.isNotBlank(this.getModelName()) ? this.getModelName() : "");
			subProductName = br.toString();
			if(subProductName.getBytes().length > this.SUB_BYTE_LENGTH){
				subProductName = subStr(subProductName,this.SUB_BYTE_LENGTH);
			}
		} catch (Exception e) {
			LogUtil.error("執行getShowProductName發生異常", e);
		}
		
		return subProductName;
	}

	public void setShowProductName(String showProductName) {
		this.showProductName = showProductName;
	}
	
	
	public String getShowViewDesc() {
		String subViewDesc = null;
			try {
				subViewDesc = StringUtils.isNotBlank(this.viewDesc) ? this.viewDesc : "" ;
				if(subViewDesc.getBytes().length > this.SUB_BYTE_LENGTH){
					subViewDesc = subStr(subViewDesc,this.SUB_BYTE_LENGTH);
				}
			} catch (Exception e) {
				LogUtil.error(e);
			}
		return subViewDesc;
	}

	public void setShowViewDesc(String showViewDesc) {
		this.showViewDesc = showViewDesc;
	}

	/**
	 * 依照byte擷取 字符 (title description)
	 * @param title
	 * @param subSLength
	 * @return 擷取擷取後的字串
	 * @throws UnsupportedEncodingException 
	 */
	private String subStr(String str, int subSLength) throws UnsupportedEncodingException{
		String subStr = null;
			int tempSubLength = subSLength;// 擷取長度
			subStr = str.substring(0, str.length() < subSLength ? str.length() : subSLength);//擷取的字串
			int subStrByetsL;
			subStrByetsL = subStr.getBytes("UTF-8").length;
			// 擷取的字符串中包含有中文
			while (subStrByetsL > tempSubLength) {
				int subSLengthTemp = --subSLength;
				subStr = str.substring(0, subSLengthTemp > str.length() ? str.length() : subSLengthTemp);
				subStrByetsL = subStr.getBytes("UTF-8").length;
				 subStrByetsL = subStr.getBytes().length;
			}
		return subStr.format(subStr+"%s", this.OVER_STR);
	}

	/**
	 * 
	 * 依照byte擷取 字符 (title description)
	 * @param title
	 * @param subSLength
	 * @return 擷取擷取後的字串
	 * @throws UnsupportedEncodingException 
	 */
	private String subStr_W(String str, int subSLength) throws UnsupportedEncodingException{
		String subStr = null;
			int tempSubLength = subSLength;// 擷取長度
			subStr = str.substring(0, str.length() < subSLength ? str.length() : subSLength);//擷取的字串
			int subStrByetsL;
			subStrByetsL = subStr.getBytes("UTF-8").length;
			// 擷取的字符串中包含有中文
			while (subStrByetsL > tempSubLength) {
				int subSLengthTemp = --subSLength;
				subStr = str.substring(0, subSLengthTemp > str.length() ? str.length() : subSLengthTemp);
				subStrByetsL = subStr.getBytes("UTF-8").length;
				 subStrByetsL = subStr.getBytes().length;
			}
		return subStr.format(subStr+"%s", this.OVER_STR_W);
	}
	
    public Long getEstoreInventory() {
        return estoreInventory;
    }
	public String getName() {
		return name;
	}

    public void setEstoreInventory(Long estoreInventory) {
        this.estoreInventory = estoreInventory;
    }

    public Long getAtrInventory() {
        return atrInventory;
    }

    public void setAtrInventory(Long atrInventory) {
        this.atrInventory = atrInventory;
    }

    public Long getUnavailableQuantity() {
        return unavailableQuantity;
    }

    public void setUnavailableQuantity(Long unavailableQuantity) {
        this.unavailableQuantity = unavailableQuantity;
    }

    public Boolean getIsUnavailableInform() {
        return isUnavailableInform;
    }

    public void setIsUnavailableInform(Boolean isUnavailableInform) {
        this.isUnavailableInform = isUnavailableInform;
    }

    public Date getUnavailableStartTime() {
        return unavailableStartTime;
    }

    public void setUnavailableStartTime(Date unavailableStartTime) {
        this.unavailableStartTime = unavailableStartTime;
    }

    public Date getUnavailableEndTime() {
        return unavailableEndTime;
    }

    public void setUnavailableEndTime(Date unavailableEndTime) {
        this.unavailableEndTime = unavailableEndTime;
    }
	public void setName(String name) {
		this.name = name;
	}

	public String getAtrStatus() {
		return atrStatus;
	}

	public void setAtrStatus(String atrStatus) {
		this.atrStatus = atrStatus;
	}

	public Boolean getApplyUnavailable() {
		return applyUnavailable;
	}

	public void setApplyUnavailable(Boolean applyUnavailable) {
		this.applyUnavailable = applyUnavailable;
	}
	
	@Override
    public String toString() {
        
        StringBuffer buffer = new StringBuffer();
        buffer.append("\n\tproductId: " + productId + "\n");
        buffer.append("\tname: " + name + "\n");
        buffer.append("\tfetNo: " + fetNo + "\n");
        buffer.append("\tisExclusive: " + isExclusive + "\n");
        buffer.append("\tatrStatus: " + atrStatus + "\n");
        buffer.append("\tinventory: " + inventory + "\n");
        buffer.append("\tisPreSubscribeDate: " + isPreSubscribeDate + "\n");
        buffer.append("\tpreSubscribeBeginDate: " + preSubscribeBeginDate + "\n");
        buffer.append("\tpreSubscribeEndDate: " + preSubscribeEndDate + "\n");
        buffer.append("\tisUnavailableInform: " + isUnavailableInform + "\n");
        buffer.append("\tunavailableStartTime: " + unavailableStartTime + "\n");
        buffer.append("\tunavailableEndTime: " + unavailableEndTime + "\n");
        
        return buffer.toString();
    }

    public Long getDiscountPrice() {
        return discountPrice;
    }

    public void setDiscountPrice(Long discountPrice) {
        this.discountPrice = discountPrice;
    }

	public Long getGaDiscountLowestPrice() {
		return gaDiscountLowestPrice;
	}

	public void setGaDiscountLowestPrice(Long gaDiscountLowestPrice) {
		this.gaDiscountLowestPrice = gaDiscountLowestPrice;
	}

	public Long getLyDiscountLowestPrice() {
		return lyDiscountLowestPrice;
	}

	public void setLyDiscountLowestPrice(Long lyDiscountLowestPrice) {
		this.lyDiscountLowestPrice = lyDiscountLowestPrice;
	}

	public Long getDaDiscountLowestPrice() {
		return daDiscountLowestPrice;
	}

	public void setDaDiscountLowestPrice(Long daDiscountLowestPrice) {
		this.daDiscountLowestPrice = daDiscountLowestPrice;
	}

	public Boolean getIs2G() {
		return is2G;
	}

	public void setIs2G(Boolean is2g) {
		is2G = is2g;
	}

	public Boolean getIs3G() {
		return is3G;
	}

	public void setIs3G(Boolean is3g) {
		is3G = is3g;
	}

	public Boolean getIs4G() {
		return is4G;
	}

	public void setIs4G(Boolean is4g) {
		is4G = is4g;
	}



	public Boolean getAllowPick() {
		return allowPick;
	}

	public void setAllowPick(Boolean allowPick) {
		this.allowPick = allowPick;
	}

	public Boolean getReservation() {
		return reservation;
	}

	public void setReservation(Boolean reservation) {
		this.reservation = reservation;
	}

	public String getMobileViewDesc() {
		return mobileViewDesc;
	}

	public void setMobileViewDesc(String mobileViewDesc) {
		this.mobileViewDesc = mobileViewDesc;
	}

	public String getMobileViewDesc2() {
		return mobileViewDesc2;
	}

	public void setMobileViewDesc2(String mobileViewDesc2) {
		this.mobileViewDesc2 = mobileViewDesc2;
	}

	public String getMobileViewDesc3() {
		return mobileViewDesc3;
	}

	public void setMobileViewDesc3(String mobileViewDesc3) {
		this.mobileViewDesc3 = mobileViewDesc3;
	}

	public String getMobileViewDesc4() {
		return mobileViewDesc4;
	}

	public void setMobileViewDesc4(String mobileViewDesc4) {
		this.mobileViewDesc4 = mobileViewDesc4;
	}

	public String getMobileViewDesc5() {
		return mobileViewDesc5;
	}

	public void setMobileViewDesc5(String mobileViewDesc5) {
		this.mobileViewDesc5 = mobileViewDesc5;
	}

	public String[] getMobileViewDescs() {
		return mobileViewDescs;
	}

	public void setMobileViewDescs(String[] mobileViewDescs) {
		this.mobileViewDescs = mobileViewDescs;
	}

	public String getSeoTitle() {
		return seoTitle;
	}

	public void setSeoTitle(String seoTitle) {
		this.seoTitle = seoTitle;
	}

	public String getSeoDescription() {
		return seoDescription;
	}

	public void setSeoDescription(String seoDescription) {
		this.seoDescription = seoDescription;
	}

	public String getSeoKeywords() {
		return seoKeywords;
	}

	public void setSeoKeywords(String seoKeywords) {
		this.seoKeywords = seoKeywords;
	}

	public Boolean getIsPicZoom() {
	    return isPicZoom;
	}

	public void setIsPicZoom(Boolean isPicZoom) {
	    this.isPicZoom = isPicZoom;
	}

	public Boolean getIsSpecShow() {
	    return isSpecShow;
	}

	public void setIsSpecShow(Boolean isSpecShow) {
	    this.isSpecShow = isSpecShow;
	}

	public Boolean getIsDescShow() {
	    return isDescShow;
	}

	public void setIsDescShow(Boolean isDescShow) {
	    this.isDescShow = isDescShow;
	}

	public String getWrighthandDesc() {
	    return wrighthandDesc;
	}

	public void setWrighthandDesc(String wrighthandDesc) {
	    this.wrighthandDesc = wrighthandDesc;
	}

	public String getRecommendUrl() {
	    return recommendUrl;
	}

	public void setRecommendUrl(String recommendUrl) {
	    this.recommendUrl = recommendUrl;
	}

	public String getDimDescription() {
		return dimDescription;
	}

	public void setDimDescription(String dimDescription) {
		this.dimDescription = dimDescription;
	}

	public String getDimDescription1() {
		return dimDescription1;
	}

	public void setDimDescription1(String dimDescription1) {
		this.dimDescription1 = dimDescription1;
	}

	public String getDimDescription2() {
		return dimDescription2;
	}

	public void setDimDescription2(String dimDescription2) {
		this.dimDescription2 = dimDescription2;
	}
	
    public Boolean getCheckAtr() {
        return checkAtr;
    }

    public void setCheckAtr(Boolean checkAtr) {
        this.checkAtr = checkAtr;
    }

    public Boolean getCheckLocalAtr() {
        return checkLocalAtr;
    }

    public void setCheckLocalAtr(Boolean checkLocalAtr) {
        this.checkLocalAtr = checkLocalAtr;
    }

    public Boolean getLocalAtrStatus() {
        return localAtrStatus;
    }

    public void setLocalAtrStatus(Boolean localAtrStatus) {
        this.localAtrStatus = localAtrStatus;
    }

    public Boolean getNewAtrStatus() {
        return newAtrStatus;
    }

    public void setNewAtrStatus(Boolean newAtrStatus) {
        this.newAtrStatus = newAtrStatus;
    }

	public Date getCheckLocalAtrStartTime() {
		return checkLocalAtrStartTime;
	}

	public void setCheckLocalAtrStartTime(Date checkLocalAtrStartTime) {
		this.checkLocalAtrStartTime = checkLocalAtrStartTime;
	}

	public Date getCheckLocalAtrEndTime() {
		return checkLocalAtrEndTime;
	}

	public void setCheckLocalAtrEndTime(Date checkLocalAtrEndTime) {
		this.checkLocalAtrEndTime = checkLocalAtrEndTime;
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getProdtypeno() {
		return prodtypeno;
	}

	public void setProdtypeno(String prodtypeno) {
		this.prodtypeno = prodtypeno;
	}

	public List<MultiprodActPriceVO> getMultiprodActPrices() {
	    return multiprodActPrices;
	}

	public void setMultiprodActPrices(List<MultiprodActPriceVO> multiprodActPrices) {
	    this.multiprodActPrices = multiprodActPrices;
	}

	public List<HandsetGroupVO> getSubHandsetGroupVOs() {
		return subHandsetGroupVOs;
	}

	public void setSubHandsetGroupVOs(List<HandsetGroupVO> subHandsetGroupVOs) {
		this.subHandsetGroupVOs = subHandsetGroupVOs;
	}
	
	public Integer getCohotCount() {
		return cohotCount;
	}

	public void setCohotCount(Integer cohotCount) {
		this.cohotCount = cohotCount;
	}

	public String getBrandId() {
		return brandId;
	}

	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}

	public Date getOnsaleDate() {
		return onsaleDate;
	}

	public void setOnsaleDate(Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}

	public Integer getExtraBuyId() {
		return extraBuyId;
	}

	public Integer getExtraBuyItemId() {
		return extraBuyItemId;
	}

	public void setExtraBuyId(Integer extraBuyId) {
		this.extraBuyId = extraBuyId;
	}

	public void setExtraBuyItemId(Integer extraBuyItemId) {
		this.extraBuyItemId = extraBuyItemId;
	}

	public Integer getCategoryExtarBuyLimit() {
		return categoryExtarBuyLimit;
	}

	public Integer getHandsetExtarBuyLimit() {
		return handsetExtarBuyLimit;
	}

	public void setCategoryExtarBuyLimit(Integer categoryExtarBuyLimit) {
		this.categoryExtarBuyLimit = categoryExtarBuyLimit;
	}

	public void setHandsetExtarBuyLimit(Integer handsetExtarBuyLimit) {
		this.handsetExtarBuyLimit = handsetExtarBuyLimit;
	}

	public Boolean getWrighthandDescBau() {
		return wrighthandDescBau;
	}

	public void setWrighthandDescBau(Boolean wrighthandDescBau) {
		this.wrighthandDescBau = wrighthandDescBau;
	}

	public Boolean getWrighthandDescCbu() {
		return wrighthandDescCbu;
	}

	public void setWrighthandDescCbu(Boolean wrighthandDescCbu) {
		this.wrighthandDescCbu = wrighthandDescCbu;
	}

	public Boolean getWrighthandDescEbu() {
		return wrighthandDescEbu;
	}

	public void setWrighthandDescEbu(Boolean wrighthandDescEbu) {
		this.wrighthandDescEbu = wrighthandDescEbu;
	}

	public String getWrighthandDescTitle() {
		return wrighthandDescTitle;
	}

	public void setWrighthandDescTitle(String wrighthandDescTitle) {
		this.wrighthandDescTitle = wrighthandDescTitle;
	}
}
