package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

public class KeywordSearchVo implements Serializable {

    private static final long serialVersionUID = 6395759513870229240L;
    private String sourceType;
    private String productId;
    private String title;
    private String titleUrl;
    private String imageSrc;
    private String navName;
    private String navDisplayName;
    private String navLinkUrl;
    private String aliasUrl;
    private String description1;
    private String description2;
    private String description3;
    private String description4;
    private String description5;
    private String eventId;
    private String coType;
    private String daType;
    private String activityUrl;
    private String activityUrlType;
    private String templateType;
    private String entryPoint;

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitleUrl() {
        return titleUrl;
    }

    public void setTitleUrl(String titleUrl) {
        this.titleUrl = titleUrl;
    }

    public String getImageSrc() {
        return imageSrc;
    }

    public void setImageSrc(String imageSrc) {
        this.imageSrc = imageSrc;
    }

    public String getDescription1() {
        return description1;
    }

    public void setDescription1(String description1) {
        this.description1 = description1;
    }

    public String getDescription2() {
        return description2;
    }

    public void setDescription2(String description2) {
        this.description2 = description2;
    }

    public String getDescription3() {
        return description3;
    }

    public void setDescription3(String description3) {
        this.description3 = description3;
    }

    public String getDescription4() {
        return description4;
    }

    public void setDescription4(String description4) {
        this.description4 = description4;
    }

    public String getDescription5() {
        return description5;
    }

    public void setDescription5(String description5) {
        this.description5 = description5;
    }

    public String getNavDisplayName() {
        return navDisplayName;
    }

    public void setNavDisplayName(String navDisplayName) {
        this.navDisplayName = navDisplayName;
    }

    public String getNavLinkUrl() {
        return navLinkUrl;
    }

    public void setNavLinkUrl(String navLinkUrl) {
        this.navLinkUrl = navLinkUrl;
    }

    public String getAliasUrl() {
        return aliasUrl;
    }

    public void setAliasUrl(String aliasUrl) {
        this.aliasUrl = aliasUrl;
    }

    public String getNavName() {
        return navName;
    }

    public void setNavName(String navName) {
        this.navName = navName;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getCoType() {
        return coType;
    }

    public void setCoType(String coType) {
        this.coType = coType;
    }

    public String getDaType() {
        return daType;
    }

    public String getActivityUrl() {
        return activityUrl;
    }

    public void setDaType(String daType) {
        this.daType = daType;
    }

    public void setActivityUrl(String activityUrl) {
        this.activityUrl = activityUrl;
    }

    public String getActivityUrlType() {
        return activityUrlType;
    }

    public void setActivityUrlType(String activityUrlType) {
        this.activityUrlType = activityUrlType;
    }

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public String getEntryPoint() {
		return entryPoint;
	}

	public void setEntryPoint(String entryPoint) {
		this.entryPoint = entryPoint;
	}

}
