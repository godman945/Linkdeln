package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.DefaultInstructions;

public interface NDefaultInstructionsDAO extends BaseDAO<DefaultInstructions, Integer> {

	/**
	 * 取回促代使用說明
	 * @param name
	 * @return
	 */
	public String getInstructionsByInstructionName(String name);
}
