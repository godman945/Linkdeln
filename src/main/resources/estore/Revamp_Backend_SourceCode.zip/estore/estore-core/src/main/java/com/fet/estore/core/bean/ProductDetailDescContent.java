package com.fet.estore.core.bean;

import java.io.Serializable;

public class ProductDetailDescContent implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 商品說明子標題 */
    private String key;
    /** 商品說明子標題內容 */
    private String value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
