package com.fet.estore.core.bean;

import java.io.Serializable;

public class CspUserProfile implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2232724110549143851L;
	String id;
	String msisdn;
	String bizEntity;
	String rocid;
	String mobStatus;
	String cspStatus;
	int paidType;
	int subType;
	String email;
	String wapCspFlag;
	String cspRegDate;
	String txtLang;
	String vocLang;
	String nickName;
	String name;
	String gender;
	String birth;
	String telMobile;
	String telFix;
	String region;
	String city;
	String address;
	String occupation;
	String income;
	String education;
	String apid;
	String rcvAdMail;
	String usrConfirm;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getBizEntity() {
		return bizEntity;
	}
	public void setBizEntity(String bizEntity) {
		this.bizEntity = bizEntity;
	}
	public String getRocid() {
		return rocid;
	}
	public void setRocid(String rocid) {
		this.rocid = rocid;
	}
	public String getMobStatus() {
		return mobStatus;
	}
	public void setMobStatus(String mobStatus) {
		this.mobStatus = mobStatus;
	}
	public String getCspStatus() {
		return cspStatus;
	}
	public void setCspStatus(String cspStatus) {
		this.cspStatus = cspStatus;
	}
	public int getPaidType() {
		return paidType;
	}
	public void setPaidType(int paidType) {
		this.paidType = paidType;
	}
	public int getSubType() {
		return subType;
	}
	public void setSubType(int subType) {
		this.subType = subType;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWapCspFlag() {
		return wapCspFlag;
	}
	public void setWapCspFlag(String wapCspFlag) {
		this.wapCspFlag = wapCspFlag;
	}
	public String getCspRegDate() {
		return cspRegDate;
	}
	public void setCspRegDate(String cspRegDate) {
		this.cspRegDate = cspRegDate;
	}
	public String getTxtLang() {
		return txtLang;
	}
	public void setTxtLang(String txtLang) {
		this.txtLang = txtLang;
	}
	public String getVocLang() {
		return vocLang;
	}
	public void setVocLang(String vocLang) {
		this.vocLang = vocLang;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getTelMobile() {
		return telMobile;
	}
	public void setTelMobile(String telMobile) {
		this.telMobile = telMobile;
	}
	public String getTelFix() {
		return telFix;
	}
	public void setTelFix(String telFix) {
		this.telFix = telFix;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getIncome() {
		return income;
	}
	public void setIncome(String income) {
		this.income = income;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getApid() {
		return apid;
	}
	public void setApid(String apid) {
		this.apid = apid;
	}
	public String getRcvAdMail() {
		return rcvAdMail;
	}
	public void setRcvAdMail(String rcvAdMail) {
		this.rcvAdMail = rcvAdMail;
	}
	public String getUsrConfirm() {
		return usrConfirm;
	}
	public void setUsrConfirm(String usrConfirm) {
		this.usrConfirm = usrConfirm;
	}	

}
