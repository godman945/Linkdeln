package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

import com.fet.estore.core.bean.vo.UploadFileInfo;

public class CredentialInitRes implements Serializable{
	private boolean needFirstCredentialFront;
	private boolean needFirstCredentialBack;
	private boolean needSecondCredentialFront;
	private boolean needSecondCredentialBack;
	private boolean needThirdCredential;
	private boolean needOcr;
	private boolean ForceUploadNow;
	private boolean ForceUploadLater;
	private String errMsg;
	private String errCode;
    private boolean isStudentPromotion;
    private String orderType;
    private List<UploadFileInfo> uploadFileInfoList;
    private String staffType;
    private String applicantSecondIdType;
	//補證件上傳才有的參數
//	private String file1;
//	private String file2;
//	private String file3;
//	private String file4;
//	private List<String> file5;
//	private String fromWhere;
//	private String rocId;
//	private boolean isPostUpload;
//	private boolean hasCredentials;//true=證件有誤補上傳；false=一般流程、延後證件上傳
//	private String staffType;//員工或員眷
	public boolean isNeedThirdCredential() {
		return needThirdCredential;
	}
	public void setNeedThirdCredential(boolean needThirdCredential) {
		this.needThirdCredential = needThirdCredential;
	}
	public boolean isNeedOcr() {
		return needOcr;
	}
	public void setNeedOcr(boolean needOcr) {
		this.needOcr = needOcr;
	}
	public boolean isForceUploadNow() {
		return ForceUploadNow;
	}
	public void setForceUploadNow(boolean forceUploadNow) {
		ForceUploadNow = forceUploadNow;
	}
	public boolean isForceUploadLater() {
		return ForceUploadLater;
	}
	public void setForceUploadLater(boolean forceUploadLater) {
		ForceUploadLater = forceUploadLater;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public boolean getNeedFirstCredentialFront() {
		return needFirstCredentialFront;
	}
	public void setNeedFirstCredentialFront(boolean needFirstCredentialFront) {
		this.needFirstCredentialFront = needFirstCredentialFront;
	}
	public boolean getNeedFirstCredentialBack() {
		return needFirstCredentialBack;
	}
	public void setNeedFirstCredentialBack(boolean needFirstCredentialBack) {
		this.needFirstCredentialBack = needFirstCredentialBack;
	}
	public boolean getNeedSecondCredentialFront() {
		return needSecondCredentialFront;
	}
	public void setNeedSecondCredentialFront(boolean needSecondCredentialFront) {
		this.needSecondCredentialFront = needSecondCredentialFront;
	}
	public boolean getNeedSecondCredentialBack() {
		return needSecondCredentialBack;
	}
	public void setNeedSecondCredentialBack(boolean needSecondCredentialBack) {
		this.needSecondCredentialBack = needSecondCredentialBack;
	}
	public boolean getIsStudentPromotion() {
		return isStudentPromotion;
	}
	public void setIsStudentPromotion(boolean isStudentPromotion) {
		this.isStudentPromotion = isStudentPromotion;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public List<UploadFileInfo> getUploadFileInfoList() {
		return uploadFileInfoList;
	}
	public void setUploadFileInfoList(List<UploadFileInfo> uploadFileInfoList) {
		this.uploadFileInfoList = uploadFileInfoList;
	}
	public String getStaffType() {
		return staffType;
	}
	public void setStaffType(String staffType) {
		this.staffType = staffType;
	}
	public String getApplicantSecondIdType() {
		return applicantSecondIdType;
	}
	public void setApplicantSecondIdType(String applicantSecondIdType) {
		this.applicantSecondIdType = applicantSecondIdType;
	}
}
