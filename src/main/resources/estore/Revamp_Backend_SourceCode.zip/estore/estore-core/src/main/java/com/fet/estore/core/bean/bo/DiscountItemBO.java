package com.fet.estore.core.bean.bo;

import com.fet.estore.core.bean.vo.IDiscountItem;

public class DiscountItemBO implements Comparable<DiscountItemBO>, IDiscountItem {
	/** 原始贈品ID */
	private Long aaiId;
	/** 原始設定CODE */
	private String discountCode;
	/** 折扣料號 */
	private String fetNo;
	/** 折扣所屬活動 */
	private Long activityId;
	/** 折扣名稱 */
	private String name;
	/** 折扣金額 */
	private Long discountAmount;
	/** COUPON ID */
	private Long couponId;
	/** 帳單折抵ID */
	private Long offerId;
	/** 成本中心ID */
	private Long costCenterId;
	/** 折扣名稱 */
	private String discountName;
	/** 是否不顯示於前台 */
	private boolean notShow;

	public int compareTo(DiscountItemBO o) {
		Long l1 = this.getAaiId();
		Long l2 = o.getAaiId();
		if(l1 == null) l1 = Long.MAX_VALUE;
		if(l2 == null) l2 = Long.MAX_VALUE;
		return l1.compareTo(l2);
	}
	
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(Long amount) {
		this.discountAmount = amount;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Long getCouponId() {
		return couponId;
	}
	public void setCouponId(Long couponId) {
		this.couponId = couponId;
	}
	public Long getOfferId() {
		return offerId;
	}
	public void setOfferId(Long offerId) {
		this.offerId = offerId;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public Long getAaiId() {
		return aaiId;
	}
	public void setAaiId(Long aaiId) {
		this.aaiId = aaiId;
	}
	public Long getCostCenterId() {
		return costCenterId;
	}
	public void setCostCenterId(Long costCenterId) {
		this.costCenterId = costCenterId;
	}
	public boolean isNotShow() {
	    return notShow;
	}
	public void setNotShow(boolean notShow) {
	    this.notShow = notShow;
	}

	@Override
	public String getCode() {
		return discountCode;
	}

	@Override
	public Long getAmount() {
		return discountAmount;
	}

	@Override
	public Double getDiscountRatio() {
		return null;
	}

	@Override
	public Long getActualDiscountAmt() {
		return null;
	}

	@Override
	public String getDisplayGroup() {
		return null;
	}

	@Override
	public String getDiscountName() {
		
		return discountName;
	}
}
