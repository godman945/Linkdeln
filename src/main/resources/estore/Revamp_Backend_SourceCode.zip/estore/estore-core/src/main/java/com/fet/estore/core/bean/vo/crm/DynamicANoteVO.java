package com.fet.estore.core.bean.vo.crm;

import com.fet.estore.core.util.LogUtil;
import net.sf.json.JSONArray;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DynamicANoteVO implements Serializable {

	private Map<String, List<ANoteVO>> dynamicANoteMap = new HashMap<String, List<ANoteVO>>();
	List<String> anoteKeys = new ArrayList<String>();
	
	public void addANote(String promotionId, JSONArray anotes, String promoType){
		List<ANoteVO> aNoteVOs = new ArrayList<ANoteVO>();
		
		for(Object object : anotes){
			String itemType = ((Map)object).get("itemType").toString();
			String itemArea = ((Map)object).get("itemArea").toString();
			String sortSeq = ((Map)object).get("sortSeq").toString();
			String itemId = ((Map)object).get("itemId").toString();
			String itemValue = ((Map)object).get("itemValue").toString();
			String anote = ((Map)object).get("anote").toString();
			
			//爛API,叫我們自己把需要的promoType(POS4G/NPF4G/LOY4G/3GT4G......)留起來,不要的濾掉
			if("PROMOTION_TYPE".equals(itemType) && !StringUtils.equals(promoType, itemId)){
				continue;
			}
			
			
			String anoteKey = String.format("%s-%s-%s", itemType, itemId, itemValue);
			LogUtil.info("key: " + anoteKey);
			//爛API,叫我們自己把重複的濾掉
			//濾掉的工作不在這裡做,取出所有(bundle)A貼時過濾
			//if(!anoteKeys.contains(anoteKey)){
				ANoteVO aNoteVO = new ANoteVO(itemType, itemArea, sortSeq, itemId, itemValue, anote);
				
				int insertPosition = 0;
				for(int i=0; i<aNoteVOs.size(); i++){
					int sortSeqNumber = Integer.parseInt(aNoteVOs.get(i).getItemArea())*100 + Integer.parseInt(aNoteVOs.get(i).getSortSeq());
					int thisSortSeqNumber = Integer.parseInt(aNoteVO.getItemArea())*100 + Integer.parseInt(aNoteVO.getSortSeq());
					if(thisSortSeqNumber >= sortSeqNumber){
						insertPosition++;
					}
				}
				aNoteVOs.add(insertPosition, aNoteVO);
				anoteKeys.add(anoteKey);
			//}
		}
		
//		for(ANoteVO aNoteVO : aNoteVOs){
//			System.out.println(aNoteVO.getSortSeq());
//			System.out.println(aNoteVO.getItemType());
//			System.out.println(aNoteVO.getAnote());
//		}
		
		
		this.dynamicANoteMap.put(promotionId, aNoteVOs);
	}
	
	
	
	public String getANote(String promotionId){
		List<ANoteVO> aNotes = this.dynamicANoteMap.get(promotionId);
		if(aNotes != null && aNotes.size() > 0){
			StringBuilder sb = new StringBuilder();
			for(int i=0; i< aNotes.size(); i++){
				sb.append(aNotes.get(i).getAnote());
				if(i < aNotes.size() - 1){
					sb.append("\r\n");
				}
			}
			return sb.toString();
		}
		
		return null;
	}
	
	/**
	 * 
	 * @return	promotionId, aNote
	 */
	public Map<String, String> getAllANote(){
		Map<String, String> aNoteMap = new HashMap<String, String>();
		Set<String> keys = this.dynamicANoteMap.keySet();
		List<String> duplicateKeys = new ArrayList<String>();
		for(String key : keys){
			
			List<ANoteVO> aNotes = this.dynamicANoteMap.get(key);
			StringBuilder sb = new StringBuilder();
			for(int i=0; i< aNotes.size(); i++){
				String anoteKey = String.format("%s-%s-%s", aNotes.get(i).getItemType(), aNotes.get(i).getItemId(), aNotes.get(i).getItemValue());
				if(duplicateKeys.contains(anoteKey)){
					continue;
				}
				
				duplicateKeys.add(anoteKey);
			
				sb.append(aNotes.get(i).getAnote());
				if(i < aNotes.size() - 1){
					sb.append("\r\n");
				}
			}
			
			if(sb.length() > 0){
				aNoteMap.put(key, sb.toString());
			}
		}
		return aNoteMap;
	}
	
	
	
	class ANoteVO implements Serializable{
		
		private String itemType;
		private String itemArea;
		private String sortSeq;
		private String itemId;
		private String itemValue;
		private String anote;

		public ANoteVO(String itemType, String itemArea, String sortSeq, String itemId, String itemValue,
				String anote) {
			super();
			this.itemType = itemType;
			this.itemArea = itemArea;
			this.sortSeq = sortSeq;
			this.itemId = itemId;
			this.itemValue = itemValue;
			this.anote = anote;
		}
		public String getItemType() {
			return itemType;
		}
		public void setItemType(String itemType) {
			this.itemType = itemType;
		}
		public String getItemArea() {
			return itemArea;
		}
		public void setItemArea(String itemArea) {
			this.itemArea = itemArea;
		}
		public String getSortSeq() {
			return sortSeq;
		}
		public void setSortSeq(String sortSeq) {
			this.sortSeq = sortSeq;
		}
		public String getItemId() {
			return itemId;
		}
		public void setItemId(String itemId) {
			this.itemId = itemId;
		}
		public String getItemValue() {
			return itemValue;
		}
		public void setItemValue(String itemValue) {
			this.itemValue = itemValue;
		}
		public String getAnote() {
			return anote;
		}
		public void setAnote(String anote) {
			this.anote = anote;
		}

	}

}
