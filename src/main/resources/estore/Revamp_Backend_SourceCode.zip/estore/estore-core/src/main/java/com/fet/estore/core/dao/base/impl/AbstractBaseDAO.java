/**
 * $Id: AbstractBaseDAO.java,v 1.0, 2017-05-16 10:51:49Z, Evan Tung$
 * Copyright (c) 2007-2008 Stark Technology	Inc. All Rights	Reserved.
 */
package	com.fet.estore.core.dao.base.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.EntityMode;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.CriteriaImpl;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.Type;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.fet.estore.core.model.support.Page;
import com.fet.estore.core.model.support.Restriction;
import com.fet.estore.core.model.support.RestrictionBetween;
import com.fet.estore.core.model.support.RestrictionIn;
import com.fet.estore.core.model.support.RestrictionNe;
import com.fet.estore.core.util.GenericsUtil;


/**
 * 基礎資料存取層實作。
 *
 * @version		$Id: AbstractBaseDAO.java,v 1.0, 2017-05-16 10:51:49Z, Evan Tung$
 */
public abstract	class AbstractBaseDAO<T, ID	extends	Serializable>
{
	protected final Logger logger = LogManager.getLogger(getClass());
	/** 領域類別。 */
	@SuppressWarnings("unchecked")
	private	Class domainClass;
	
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * 基礎建構式。
	 */
	@SuppressWarnings("unchecked")
	public AbstractBaseDAO() {
//		this.domainClass = (Class<T>) ((ParameterizedType)	getClass()
//				.getGenericSuperclass()).getActualTypeArguments()[0];
		domainClass = GenericsUtil.getSuperClassGenricType(getClass());
	}

	/**
	 * 檢查物件是否存在。
	 * @param id 物件識別
	 * @return 是否存在
	 */
	public boolean exists (ID id)  {
		Criteria criteria =	createCriteria();
		criteria.add(Restrictions.idEq(id));
		criteria.setProjection(Projections.rowCount());

		return 0 < ((Integer) criteria.uniqueResult()).intValue();
	}

	/**
	 * 以物件識別取得物件。
	 * @param id 物件識別
	 * @return 對應物件
	 */
	@SuppressWarnings("unchecked")
	public T findById(ID id) {
		return (T) this.sessionFactory.getCurrentSession().get(domainClass,	id);
	}

	/**
	 * 儲存物件。
	 * @param entity 被儲存的物件
	 */
	public void	save(T entity) {
//		Session session = this.sessionFactory.openSession();
//		Transaction tx = session.beginTransaction();
//		session.saveOrUpdate(entity);
//		tx.commit();
//		session.close();
		this.sessionFactory.getCurrentSession().save(entity);
	}

	/**
	 * 儲存所有物件。
	 * @param entities 被儲存的所有物件
	 */
	public void	saveAll(List<T>	entities) {
		for(Object entity : entities) {
			this.sessionFactory.getCurrentSession().save(entity);
		}
		
	}

	/**
	 * 刪除物件。
	 * @param entity 被刪除的物件
	 */
	public void	delete(T entity) {
		this.sessionFactory.getCurrentSession().delete(entity);
	}

	/**
	 * 以物件唯一識別值刪除。
	 * @param id 唯一識別值
	 */
	public void	deleteById(ID id) {
		this.sessionFactory.getCurrentSession().delete(this.findById(id));
	}

	/**
	 * 刪除所有物件。
	 * @param entities 被刪除的所有物件
	 */
	public void	deleteAll(List<T> entities)	{
		//this.sessionFactory.getCurrentSession().deleteAll(entities);
	}

	/**
	 * 取得條件下的物件資料。
	 * @param entity 物件樣版
	 * @param ascProperties 升冪排序
	 * @param descProperties 降冪排序
	 * @return 泛型物件資料
	 */
	public List<T> findByExample(T entity, String[]	ascProperties, String[]	descProperties)	{
		return findByExample(entity, new ArrayList<Restriction>(0),	ascProperties, descProperties);
	}
	
	/**
	 * 取得條件下的物件資料。
	 * @param criteria 查詢條件式
	 * @param ascProperties 升冪排序
	 * @param descProperties 降冪排序
	 * @return 泛型物件資料
	 */
	protected List<T> findByExample(Criteria criteria, String[]	ascProperties, String[]	descProperties)	{
		return findByExample(criteria, new ArrayList<Restriction>(0),	ascProperties, descProperties);
	}
	
	/**
	 * 取得條件下的物件資料。
	 * @param entity 物件樣版
	 * @return 泛型物件資料
	 */
	public List<T> findByExample(T entity)	{
		return findByExample(entity, new ArrayList<Restriction>(0),	null, null);
	}

	/**
	 * 取得條件下的物件資料。
	 * @param entity 物件樣版
	 * @param ins 包含屬性
	 * @param rbs 在屬性區間
	 * @param ascProperties 升冪排序
	 * @param descProperties 降冪排序
	 * @return 泛型物件資料
	 */
	public List<T> findByExample(T entity, List<RestrictionIn> ins,	List<RestrictionBetween> rbs, String[] ascProperties,
			String[] descProperties) {
		return findByExample(entity, addRestriction(ins, rbs), ascProperties, descProperties);
	}
	/**
	 * 取得條件下的物件資料。
	 * @param criteria 查詢條件式
	 * @param ins 包含屬性
	 * @param rbs 在屬性區間
	 * @param ascProperties 升冪排序
	 * @param descProperties 降冪排序
	 * @return 泛型物件資料
	 */
	protected List<T> findByExample(Criteria criteria, List<RestrictionIn> ins,	List<RestrictionBetween> rbs, String[] ascProperties,
			String[] descProperties) {
		return findByExample(criteria, addRestriction(ins, rbs), ascProperties, descProperties);
	}
	/**
	 * 加上限制式。
	 * @param ins 包含屬性
	 * @param rbs 在屬性區間
	 * @return 限制式清單
	 */
	protected List<Restriction> addRestriction(List<RestrictionIn> ins, List<RestrictionBetween> rbs){
		List<Restriction> restrictions = new ArrayList<Restriction>();
		if (null !=	ins	&& !ins.isEmpty()) {
			restrictions.addAll(ins);
		}
		if (null !=	rbs	&& !rbs.isEmpty()) {
			restrictions.addAll(rbs);
		}
		return restrictions;
	}

	/**
	 * 取得條件下的物件資料。
	 * @param entity 物件樣版
	 * @param restrictions 條件式
	 * @param ascProperties 升冪排序
	 * @param descProperties 降冪排序
	 * @return 泛型物件資料
	 */
	public List<T> findByExample(T entity, List<Restriction> restrictions, String[]	ascProperties,
			String[] descProperties) {
//		Criteria criteria =	createCriteria();
		Criteria criteria =	enhanceQueryByExample(entity);
		return findByExample(criteria, restrictions, ascProperties, descProperties);
	}
	
	/**
	 * 取得條件下的物件資料。
	 * @param criteria 查詢條件式
	 * @param restrictions 條件式
	 * @param ascProperties 升冪排序
	 * @param descProperties 降冪排序
	 * @return 泛型物件資料
	 */
	@SuppressWarnings("unchecked")
	protected List<T> findByExample(Criteria criteria, List<Restriction> restrictions, String[]	ascProperties,
			String[] descProperties) {
		// Pattern [Vistor]	will be	better?	to much	if/else	statement....
		for	(Restriction rc: restrictions) {
			if (null ==	rc)	{
				continue;
			}
			if (rc instanceof RestrictionIn) {
				RestrictionIn rin =	(RestrictionIn)	rc;
				criteria.add(Restrictions.in(rin.getProperty(),	rin.getValues()));
			} else if (rc instanceof RestrictionBetween) {
				RestrictionBetween rb =	(RestrictionBetween) rc;
				criteria.add(Restrictions.between(rb.getProperty(),	rb.getFromData(), rb.getEndData()));
			} else if (rc instanceof RestrictionNe)	{
				RestrictionNe rne =	(RestrictionNe)	rc;
				criteria.add(Restrictions.ne(rne.getProperty(),	rne.getValue()));
			}
		}
//		criteria.add(Example.create(entity));
		this.setOrderToCriteria(criteria, ascProperties, descProperties);
		return (List<T>) criteria.list();
	}


	/**
	 * 取得條件下的物件資料。
	 * @param entity 物件樣版
	 * @param pageNo 指定第幾頁
	 * @param pageSize 一頁幾筆
	 * @param ascProperties 升冪排序屬性
	 * @param descProperties 降冪排序屬性
	 * @return 泛型物件資料
	 */
	public List<T> findByExample(T entity, int pageNo, int pageSize,
			String[] ascProperties,	String[] descProperties) {
//		Criteria criteria =	createCriteria();
//		criteria.add(Example.create(entity));
		Criteria criteria =	enhanceQueryByExample(entity);
		return findByExample(criteria, pageNo, pageSize, ascProperties, descProperties);
	}
	
	/**
	 * 取得條件下的物件資料。
	 * @param criteria 查詢條件式
	 * @param pageNo 指定第幾頁
	 * @param pageSize 一頁幾筆
	 * @param ascProperties 升冪排序屬性
	 * @param descProperties 降冪排序屬性
	 * @return 泛型物件資料
	 */
	@SuppressWarnings("unchecked")
	protected List<T> findByExample(Criteria criteria, int pageNo, int pageSize,
			String[] ascProperties,	String[] descProperties) {
		this.setOrderToCriteria(criteria, ascProperties, descProperties);
		if (0 <	pageSize) {
			criteria.setFirstResult(pageNo * pageSize -	1);
		} else {
			criteria.setFirstResult(0);
		}
		criteria.setMaxResults(pageSize);
		return (List<T>) criteria.list();
	}
	

	/**
	 * 計算出筆數。
	 * @param entity 物件樣版
	 * @return 泛型物件資料
	 */
	public Integer count(T entity) {
//		Criteria criteria =	createCriteria();
//		criteria.add(Example.create(entity));
		Criteria criteria =	enhanceQueryByExample(entity);

		criteria.setProjection(Projections.rowCount());
		return (Integer) criteria.uniqueResult();
	}

	/**
	 * 設定查詢條件式的排序方式。
	 * @param criteria 查詢條件式
	 * @param ascProperties 升冪排序屬性
	 * @param descProperties 降冪排序屬性
	 */
	protected void setOrderToCriteria(Criteria criteria,
			String[] ascProperties,	String[] descProperties) {
		if (null !=	ascProperties && 0 < ascProperties.length) {
			for	(int i = 0;	i <	ascProperties.length; i++) {
				criteria.addOrder(Order.asc(ascProperties[i]));
			}
		}
		if (null !=	descProperties && 0	< descProperties.length) {
			for	(int i = 0;	i <	descProperties.length; i++)	{
				criteria.addOrder(Order.desc(descProperties[i]));
			}
		}
	}

	/**
	 * 取得全部資料。
	 * @return 泛型所有物件
	 */
	@SuppressWarnings("unchecked")
	public List<T> findAll() {
		return this.sessionFactory.getCurrentSession().createCriteria(this.domainClass).list();
	}

	/**
	 * 依屬性相似值取得資料。
	 * @param property 屬性名稱
	 * @param value 屬性值
	 * @return 泛型物件資料
	 */
	@SuppressWarnings("unchecked")
	public List<T> findByProperty(String property, Object value) {
		List<T>	result = null;
		T entity = null;
		try	{
			entity = (T)BeanUtils.instantiateClass(this.domainClass);
			org.apache.commons.beanutils.BeanUtils.setProperty(entity, property, value);
		} catch	(Exception e) {
			//logger.error(e);
		}
		if (null !=	entity){
			result = this.findByExample(entity,	null, null);
		} else {
			result = (List<T>) new ArrayList();
		}
		return result;
	}

	/**
	 * 依屬性相似值取得資料。
	 * @param property 屬性名稱
	 * @param value 屬性值
	 * @return 泛型物件資料
	 */
	public List<T> findByPropertyLike (String property,	String value)  {
		return findByPropertyLike(property,	value, Page.DEFAULT_PAGE_SIZE);
	}

	/**
	 * 依屬性相似值取得資料。
	 * @param property 屬性名稱
	 * @param value 屬性值
	 * @param pageSize 總頁數
	 * @return 泛型物件資料
	 */
	@SuppressWarnings("unchecked")
	public List<T> findByPropertyLike (String property,	String value, int pageSize)	 {
		List<T>	result = null;

		try	 {
			Criteria criteria =	createCriteria();
			criteria.add(Restrictions.like(property, value,	MatchMode.START));
			criteria.setFirstResult(0);
			criteria.setMaxResults(pageSize);
			result = (List<T>) criteria.list();

		} catch(Exception cause)  {
			//logger.error(cause.getMessage(), cause);
			result = (List<T>) new ArrayList();
		}

		return result;
	}

	/**
	 * 合併不同Session間同一個持久化物件。
	 * @param entity 物件
	 * @return 泛型物件
	 */
	@SuppressWarnings("unchecked")
	public T merge(T entity) {
		return (T) this.sessionFactory.getCurrentSession().merge(entity);
	}

	/**
	 * 更新持久化物件。
	 * @param entity 物件
	 */
	public void	attachDirty(T entity) {
		this.sessionFactory.getCurrentSession().saveOrUpdate(entity);
	}

	/**
	 * 不更新持久化物件但置於第一層快取。
	 * @param entity 物件
	 */
	public void	attachClean(T entity) {
		this.sessionFactory.getCurrentSession().lock(entity, LockMode.NONE);
	}

	/**
	 * 以分頁方式取得泛型資料。
	 * @param criteria 查詢條件式
	 * @param pageNo 指定第幾頁
	 * @param pageSize 一頁幾筆
	 * @return 分頁泛型資料
	 */
	@SuppressWarnings("unchecked")
	public Page<T> pageQuery(Criteria criteria,	int	pageNo,	int	pageSize) {
		Assert.notNull(criteria);
		Assert.isTrue(pageNo >=	1, "pageNo should start	from 1");
		CriteriaImpl impl =	(CriteriaImpl) criteria;

		Projection projection =	impl.getProjection();

		/*
		List<CriteriaImpl.OrderEntry> orderEntries;
		try	{
			orderEntries = (List) BeanUtils.forceGetProperty(impl, "orderEntries");
			BeanUtils.forceSetProperty(impl, "orderEntries", new ArrayList());
		} catch	(Exception e) {
			throw new InternalError(" Runtime Exception	impossibility throw	");
		}
		*/
		Integer	totalCount = (Integer) criteria.setProjection(Projections.rowCount()).uniqueResult();

		criteria.setProjection(projection);
		if (projection == null)	{
			criteria.setResultTransformer(CriteriaSpecification.ROOT_ENTITY);
		}
		/*
		try	{
			org.apache.commons.beanutils.BeanUtils.setProperty(impl, "orderEntries", orderEntries);
		} catch	(Exception e) {
			throw new InternalError(" Runtime Exception	impossibility throw	");
		}
		*/
		if (totalCount < 1)	{
			return new Page();
		}

		Integer	currentIndex = Page.getStartOfPage(pageNo, pageSize);
		List<T>	result = (criteria.setFirstResult(currentIndex).setMaxResults(pageSize)).list();

		return new Page<T>(new Long(currentIndex.longValue()), pageSize, new Long(totalCount.longValue()), result);
	}

	/**
	 * 取得條件下的物件資料。
	 * @param entity 物件樣版
	 * @param pageNo 頁數
	 * @param pageSize 幾頁
	 * @return 分頁泛型物件資料
	 */
	public Page<T> pageQueryByExample(T	entity,	int	pageNo,	int	pageSize) {
//		Criteria criteria =	this.createCriteria();
//		criteria.add(Example.create(entity));
//		return pageQuery(criteria, pageNo, pageSize);
		return pageQueryByExample(entity, null,	null, pageNo, pageSize);
	}

	/**
	 * 取得條件下的物件資料。
	 * @param entity 物件樣版
	 * @param ascProperties 升冪排序
	 * @param descProperties 降冪排序
	 * @param pageNo 頁數
	 * @param pageSize 幾頁
	 * @return 分頁泛型物件資料
	 */
	public Page<T> pageQueryByExample(T	entity,	String[] ascProperties,	String[] descProperties, int pageNo, int pageSize) {
//		Criteria criteria =	createCriteria();
//		criteria.add(Example.create(entity));
		Criteria criteria =	enhanceQueryByExample(entity);

		if(null	!= ascProperties ||	null !=	descProperties)	 {
			this.setOrderToCriteria(criteria, ascProperties, descProperties);
		}

		return this.pageQuery(criteria,	pageNo,	pageSize);
	}

	/**
	 * 建立查詢條件式。
	 * @return 查詢條件式
	 */
	protected Criteria createCriteria()	{
		Session	session	= this.sessionFactory.getCurrentSession();
		Criteria criteria =	session.createCriteria(domainClass);
		return criteria;
	}

	/**
	 * 設定查詢條件式內區間條件式。
	 * @param criteria 查詢條件式
	 * @param ins 區間條件式
	 */
	protected void setInsToCriteria(Criteria criteria,
			List<RestrictionIn>	ins) {
		if (null !=	ins	&& !ins.isEmpty()) {
			for	(RestrictionIn rin:ins)	{
				criteria.add(Restrictions.in(rin.getProperty(),	rin.getValues()));
			}
		}
	}

	/**
	 * 設定查詢條件式內區間條件式。
	 * @param criteria 查詢條件式
	 * @param rbs 區間條件式
	 */
	protected void setBetweensToCriteria(Criteria criteria,
			List<RestrictionBetween> rbs) {
		if (null !=	rbs	&& !rbs.isEmpty()) {
			for	(RestrictionBetween	rb:rbs)	{
				criteria.add(Restrictions.between(rb.getProperty(),	rb.getFromData(), rb.getEndData()));
			}
		}
	}

    /**
     * 取得條件下相似的物件資料。
     * @param entity 物件樣版
     * @param pageNo 頁數
     * @param pageSize 幾頁
     * @return 分頁泛型物件資料
     */
	public Page<T> pageQueryByLikeExample(T	entity,	int	pageNo,	int	pageSize) {
	    return pageQueryByLikeExample(entity, pageNo, pageSize, null, null);
	}

    /**
     * 取得條件下相似的物件資料。
     * @param entity 物件樣版
     * @param pageNo 頁數
     * @param pageSize 幾頁
     * @param ascProperties 升冪排序
     * @param descProperties 降冪排序
     * @return 分頁泛型物件資料
     */
    public Page<T> pageQueryByLikeExample(T entity, int pageNo, int pageSize, String[] ascProperties, String[] descProperties) {
        Example example = Example.create(entity).enableLike(MatchMode.ANYWHERE);
        Criteria criteria = enhanceQueryByExample(example, entity);

        if(null != ascProperties || null != descProperties)  {
            this.setOrderToCriteria(criteria, ascProperties, descProperties);
        }

        return this.pageQuery(criteria, pageNo, pageSize);
    }

	/**
	 * 移去存在Session的持久化物件。
	 * @param entity 持久化物件
	 */
	public void	evict(T	entity){
		this.sessionFactory.getCurrentSession().evict(entity);
	}

	/**
	 * 更新在Session的持久化物件。
	 * @param entity 持久化物件
	 */
	public void	update(T entity){
		this.sessionFactory.getCurrentSession().update(entity);
	}

	/**
	 * This	method will	makes Hibernate	QBE	(Query by Example) work	with the
	 * identifier property of the entity.
	 * <p>
	 * Use this method instead of the following codes:
	 * <pre>
	 *   Criteria criteria = createCriteria();
	 *   criteria.add(Example.create(entity));
	 * </pre>
	 */
	public Criteria	createEnhancedCriteriaByExample	(T entity)	{
		return enhanceQueryByExample(entity);
	}

	// @(#)	PROTECTED METHODS
	/**
	 * See {@link #enhanceQueryByExample(Example, Object)}.
	 */
	protected Criteria enhanceQueryByExample (T	entity)	 {
		return enhanceQueryByExample(Example.create(entity), entity);
	}

	/**
	 * This	method will	makes Hibernate	QBE	(Query by Example) work	with the
	 * identifier property of the entity.
	 * <p>
	 * The given example might enable the "like" operator or ignore	case, so
	 * this	method don't create	the	example	from the given entity automatically.
	 * See {@link #pageQueryByLikeExample(Object, int, int)}.
	 * <p>
	 * In addition,	the	identifier property	will not use the "like"	operator;
	 * that	is,	it uses	the	"="	operator.
	 *
	 * @author arthur.ouyang
	 *
	 * TODO: if	the	type of	the	property is	associationType, QBE doesn't support it.
	 */
	protected Criteria enhanceQueryByExample (Example example, T entity)  {
		/*
		 * Hibernate QBE ignores ID	fields!! arthur.ouyang 2008-04-30
		 *
		 * Query By	Example	not	working	with Id	Field
		 * http://www.servicerules.com.ar/articles.do?pageId=qbe
		 *
		 * http://forum.hibernate.org/viewtopic.php?t=938036
		 * gavin  Wed Jan 26, 2005
		 *	 rhinman wrote:	You	may	want to	make a note	of the fact	QBE	ignores	ID fields. For simple primary keys it makes	sense, but composite IDs create	surprises.
		 * I think this	is a bad limitation	of our QBE.
		 *
		 * http://forum.hibernate.org/viewtopic.php?t=927063
		 * michael	Wed	Jan	14,	2004
		 * The ID is ignored when using	query by example. This is done because an example object with the id set would return only one object anyways.
		 *
		 * [HB-1437] Complications arising when	QBE	ignores	ID fields
		 * http://opensource.atlassian.com/projects/hibernate/browse/HB-1437
		 */
		Criteria criteria =	createCriteria();
		criteria.add(example);

		ClassMetadata meta = getSessionFactory().getClassMetadata(domainClass);
		if(meta.hasIdentifierProperty())  {
			Serializable id	= meta.getIdentifier(entity);
			if(null	!= id)	{
				criteria.add(Restrictions.idEq(id));
			}
		}
//		logger.debug("not support enhanceQueryByExample");
		return criteria;
	}
	
	public String getNamedQueryString(String name){
		//Query query = this.getSessionFactory().getCurrentSession().getNamedQuery(name);
		Query query = this.sessionFactory.getCurrentSession().getNamedQuery(name);
		return query.getQueryString();
	}

	protected int oracleOverflowNo = 1000;

	/**
	 * 以物件識別取得物件。
	 * @param ids 物件識別陣列
	 * @return 對應物件
	 */
	@SuppressWarnings("unchecked")
	public List<T> findByIds(Collection<ID> idsCollection) {
		List<ID> ids = new ArrayList<>(idsCollection);
		List<T> result = new ArrayList<>();
		Query query =  this.sessionFactory.getCurrentSession().createQuery(String.format("from %s o where o.id in (:ids)", domainClass.getName()));
		int i = 0;
		for (;(i + 1) * oracleOverflowNo < ids.size(); i++) {
			query.setParameterList("ids", ids.subList(i * oracleOverflowNo, (i + 1) * oracleOverflowNo));
			result.addAll(query.list());
		}
		if (ids.subList(i * oracleOverflowNo, ids.size()).size() > 0) {
			query.setParameterList("ids", ids.subList(i * oracleOverflowNo, ids.size()));
			result.addAll(query.list());
		}
		return result;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	/**
	 *  呼叫 Native Sql Query
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-30
	 * @param <TMPL>
	 * @param sb
	 * @param scalarMap
	 * @param paramMap
	 * @param clazz
	 * @return
	 */
	protected <TMPL> List<TMPL> executeQuery(StringBuilder sb, 
			Map<String, Type> scalarMap, 
			Map<String, Object> paramMap, 
			Class<TMPL> clazz) {
		
		NativeQuery query = this.getSessionFactory().getCurrentSession().createSQLQuery(sb.toString());
		
		if (scalarMap != null) {
			scalarMap.forEach((k,v)->query.addScalar(k,v));
		}
		if (paramMap != null) {
			query.setProperties(paramMap);
		}
		query.setResultTransformer(Transformers.aliasToBean(clazz));
		
		List<TMPL> result = query.list();
		
		return result;
	}
	
	/**
	 * 呼叫 Native Sql Query ，可輸入起始位置(startIndex)與筆數(dataSize)，未輸入時為全撈
	 * 
	 * @description
	 * @author Phil.lin
	 * @date 2020-07-31
	 * @param sb
	 * @param scalarMap
	 * @param paramMap
	 * @param clazz
	 * @param startIndex
	 * @param dataSize
	 * @return
	 */
	protected <T> List<T> executeQuery(StringBuilder sb,
			Map<String, Type> scalarMap, 
			Map<String, Object> paramMap, 
			Class<T> clazz,
			Integer startIndex,
			Integer dataSize) {
		
        if (startIndex == null && dataSize == null ) {
            
            return executeQuery(sb, scalarMap, paramMap, clazz);
            
        } else {
            
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT * FROM (").append(sb.toString()).append(" ) WHERE 1=1 ");
            
            if (startIndex != null) {
                sql.append(" AND ROWNUM >= :startIndex");
                paramMap.put("startIndex", startIndex);
            } else {
                startIndex = 1;
            }
            
            if (dataSize != null) {
                sql.append(" AND ROWNUM < :endIndex");
                paramMap.put("endIndex", startIndex + dataSize);
            }
            
            return executeQuery(sql, scalarMap, paramMap, clazz);
        }        
	}
}
