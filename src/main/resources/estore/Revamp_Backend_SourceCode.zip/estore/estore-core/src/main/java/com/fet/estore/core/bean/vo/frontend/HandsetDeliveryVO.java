package com.fet.estore.core.bean.vo.frontend;

/**
 * 設備遞送方式
 * @author Max Chen
 *
 */
public class HandsetDeliveryVO {
	private Boolean isExclusive;
	private Boolean isPresubscribe;
	private Boolean isHomeDeliverable;
	private Boolean isStoreDeliverable;
	private String homeDeliFlow;
	private String storeDeliFlow;
	private Boolean canCnc;
	private Boolean homeDeliH;
	private Boolean homeDeliCnc;
	
	public Boolean getIsHomeDeliverable() {
		return isHomeDeliverable;
	}
	public void setIsHomeDeliverable(Boolean isHomeDeliverable) {
		this.isHomeDeliverable = isHomeDeliverable;
	}
	public Boolean getIsStoreDeliverable() {
		return isStoreDeliverable;
	}
	public void setIsStoreDeliverable(Boolean isStoreDeliverable) {
		this.isStoreDeliverable = isStoreDeliverable;
	}
	public Boolean getIsExclusive() {
		return isExclusive;
	}
	public void setIsExclusive(Boolean isExclusive) {
		this.isExclusive = isExclusive;
	}
	public Boolean getIsPresubscribe() {
		return isPresubscribe;
	}
	public void setIsPresubscribe(Boolean isPresubscribe) {
		this.isPresubscribe = isPresubscribe;
	}
	public String getHomeDeliFlow() {
		return homeDeliFlow;
	}
	public void setHomeDeliFlow(String homeDeliFlow) {
		this.homeDeliFlow = homeDeliFlow;
	}
	public String getStoreDeliFlow() {
		return storeDeliFlow;
	}
	public void setStoreDeliFlow(String storeDeliFlow) {
		this.storeDeliFlow = storeDeliFlow;
	}
	public Boolean getCanCnc() {
		return canCnc;
	}
	public void setCanCnc(Boolean canCnc) {
		this.canCnc = canCnc;
	}
	public Boolean getHomeDeliH() {
		return homeDeliH;
	}
	public void setHomeDeliH(Boolean homeDeliH) {
		this.homeDeliH = homeDeliH;
	}
	public Boolean getHomeDeliCnc() {
		return homeDeliCnc;
	}
	public void setHomeDeliCnc(Boolean homeDeliCnc) {
		this.homeDeliCnc = homeDeliCnc;
	}
	
	
}
