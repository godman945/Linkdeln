package com.fet.estore.core.bean.vo.common;

import java.io.Serializable;
import java.util.List;

/**
 * @description Banner圖文分離資料結構
 * @autor Dennis.Chen
 * @date 2020-07-14
 */
public class BannerVO implements Serializable{

	private static final long serialVersionUID = -3070867420079412186L;
	BannerImageVO image; //Banner圖片(大小圖)
	String tag; //副標題
	String title; //主標題
	String description;  //描述1
	String description2; //描述2
	String description3; //描述3
	List<BannerActionVO> actions; //Button資訊
	
	public BannerImageVO getImage() {
		return image;
	}
	public void setImage(BannerImageVO image) {
		this.image = image;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDescription2() {
		return description2;
	}
	public void setDescription2(String description2) {
		this.description2 = description2;
	}
	public String getDescription3() {
		return description3;
	}
	public void setDescription3(String description3) {
		this.description3 = description3;
	}
	public List<BannerActionVO> getActions() {
		return actions;
	}
	public void setActions(List<BannerActionVO> actions) {
		this.actions = actions;
	}
}
