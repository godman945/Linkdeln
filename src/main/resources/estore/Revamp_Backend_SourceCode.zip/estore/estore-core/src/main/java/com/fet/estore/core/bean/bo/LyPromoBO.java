package com.fet.estore.core.bean.bo;

import java.util.List;

/**
 * @description 用於存放續約情境下撈促案所需資料
 * @author Dennis.Chen
 * @Date 2020-10-23
 */
public class LyPromoBO {

    String userGeneration; //用戶當前資費G數
    List<String> promotionIdList; //該用戶call queryAvailablePromotion() 回傳的promotionId

    public LyPromoBO() { super();
    }

    public LyPromoBO(String userGeneration, List<String> promotionIdList) {
        this.userGeneration = userGeneration;
        this.promotionIdList = promotionIdList;
    }

    public String getUserGeneration() {
        return userGeneration;
    }

    public void setUserGeneration(String userGeneration) {
        this.userGeneration = userGeneration;
    }

    public List<String> getPromotionIdList() {
        return promotionIdList;
    }

    public void setPromotionIdList(List<String> promotionIdList) {
        this.promotionIdList = promotionIdList;
    }
}
