package com.fet.estore.core.bean;

public class IdNum2 implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	/**
	 * 序號
	 */
	String sn; 
	
	/**
	 * 配偶
	 */
	String spouse;  
	
	/**
	 * 父親
	 */
	String father;   
	     
	/**
	 * 母親
	 */
	String mother;
	
	/**
	 *  地址 完整的住址
	 */
	String address;
	
	/**
	 *  出生地 
	 */
	String birthPlace;
	
	/**
	 * 役別
	 */
	String military;
	
	/**
	 * 條碼  
	 */
	String barcode;
	
	//依據(ADDRESS)取得的地址,解析該地址切段擴充的欄位 
	/**
	 * 第一段縣市地址 
	身份證反面、中華民國
	駕照(新版)、中華民國
	汽車行車執照、中華民
	國機車行車執照的縣市 
	 */
	String address1st; 
	/**
	 * 第二段鄉鎮市區地址 
	身份證反面、中華民國
	駕照(新版)、中華民國
	汽車行車執照、中華民
	國機車行車執照的鄉鎮
	市區 
	 */
	String address2nd; 
	/**
	 * 第三段除縣市及鄉鎮市區外的地
	址 
	身份證反面、中華民國
	駕照(新版)、中華民國
	汽車行車執照、中華民
	國機車行車執照中除了
	縣市及鄉鎮市區外的地
	址 
	 */
	String address3rd; 
	
	
	
	//依據(ADDRESS)取得的地址,解析該地址切段擴充的欄位 
	
	/**
	 *  縣市 內容將含縣、市等字樣
	 */
	String addressSplit1; 
	
	/**
	 *  鄉鎮市區 內容將含鄉、鎮、市、
	區等字樣 
	 */
	String addressSplit2;
	
	
	/**
	 *  里
	 */
	String addressSplit3;   
	
	/**
	 *  鄰
	 */
	String addressSplit4;   
	/**
	 *  村
	 */
	String addressSplit5;   
	
	/**
	 *  路
	 */
	String addressSplit6;   
	
	/**
	 *  街
	 */
	String addressSplit7;   
	/**
	 *  大道
	 */
	String addressSplit8;   
	
	/**
	 *  段
	 */
	String addressSplit9;   
	/**
	 *  巷
	 */
	String addressSplit10;   
	/**
	 *  弄 
	 */
	String addressSplit11;  
	/**
	 *  號
	 */
	String addressSplit12;   
	/**
	 *  之
	 */
	String addressSplit13;   
	/**
	 *  樓
	 */
	String addressSplit14;   
	/**
	 *  室 
	 */
	String addressSplit15;  
	/**
	 * 地方名 例: 後窟潭
	 */
	String addressSplit16;
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getSpouse() {
		return spouse;
	}
	public void setSpouse(String spouse) {
		this.spouse = spouse;
	}
	public String getFather() {
		return father;
	}
	public void setFather(String father) {
		this.father = father;
	}
	public String getMother() {
		return mother;
	}
	public void setMother(String mother) {
		this.mother = mother;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBirthPlace() {
		return birthPlace;
	}
	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}
	public String getMilitary() {
		return military;
	}
	public void setMilitary(String military) {
		this.military = military;
	}
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public String getAddress1st() {
		return address1st;
	}
	public void setAddress1st(String address1st) {
		this.address1st = address1st;
	}
	public String getAddress2nd() {
		return address2nd;
	}
	public void setAddress2nd(String address2nd) {
		this.address2nd = address2nd;
	}
	public String getAddress3rd() {
		return address3rd;
	}
	public void setAddress3rd(String address3rd) {
		this.address3rd = address3rd;
	}
	public String getAddressSplit1() {
		return addressSplit1;
	}
	public void setAddressSplit1(String addressSplit1) {
		this.addressSplit1 = addressSplit1;
	}
	public String getAddressSplit2() {
		return addressSplit2;
	}
	public void setAddressSplit2(String addressSplit2) {
		this.addressSplit2 = addressSplit2;
	}
	public String getAddressSplit3() {
		return addressSplit3;
	}
	public void setAddressSplit3(String addressSplit3) {
		this.addressSplit3 = addressSplit3;
	}
	public String getAddressSplit4() {
		return addressSplit4;
	}
	public void setAddressSplit4(String addressSplit4) {
		this.addressSplit4 = addressSplit4;
	}
	public String getAddressSplit5() {
		return addressSplit5;
	}
	public void setAddressSplit5(String addressSplit5) {
		this.addressSplit5 = addressSplit5;
	}
	public String getAddressSplit6() {
		return addressSplit6;
	}
	public void setAddressSplit6(String addressSplit6) {
		this.addressSplit6 = addressSplit6;
	}
	public String getAddressSplit7() {
		return addressSplit7;
	}
	public void setAddressSplit7(String addressSplit7) {
		this.addressSplit7 = addressSplit7;
	}
	public String getAddressSplit8() {
		return addressSplit8;
	}
	public void setAddressSplit8(String addressSplit8) {
		this.addressSplit8 = addressSplit8;
	}
	public String getAddressSplit9() {
		return addressSplit9;
	}
	public void setAddressSplit9(String addressSplit9) {
		this.addressSplit9 = addressSplit9;
	}
	public String getAddressSplit10() {
		return addressSplit10;
	}
	public void setAddressSplit10(String addressSplit10) {
		this.addressSplit10 = addressSplit10;
	}
	public String getAddressSplit11() {
		return addressSplit11;
	}
	public void setAddressSplit11(String addressSplit11) {
		this.addressSplit11 = addressSplit11;
	}
	public String getAddressSplit12() {
		return addressSplit12;
	}
	public void setAddressSplit12(String addressSplit12) {
		this.addressSplit12 = addressSplit12;
	}
	public String getAddressSplit13() {
		return addressSplit13;
	}
	public void setAddressSplit13(String addressSplit13) {
		this.addressSplit13 = addressSplit13;
	}
	public String getAddressSplit14() {
		return addressSplit14;
	}
	public void setAddressSplit14(String addressSplit14) {
		this.addressSplit14 = addressSplit14;
	}
	public String getAddressSplit15() {
		return addressSplit15;
	}
	public void setAddressSplit15(String addressSplit15) {
		this.addressSplit15 = addressSplit15;
	}
	public String getAddressSplit16() {
		return addressSplit16;
	}
	public void setAddressSplit16(String addressSplit16) {
		this.addressSplit16 = addressSplit16;
	}
	
	
	
	
	
}