package com.fet.estore.core.bean.bo;

/**
 * @description 驗證結帳送出資訊結果
 * @author Dennis.Chen
 * @date 2020-09-05
 */
public class CheckoutValidBO {

    boolean isPass;
    String errorReason;

    public CheckoutValidBO() {
    }

    public CheckoutValidBO(boolean isPass, String errorReason) {
        this.isPass = isPass;
        this.errorReason = errorReason;
    }

    public boolean isPass() {
        return isPass;
    }

    public void setIsPass(boolean isPass) {
        this.isPass = isPass;
    }

    public String getErrorReason() {
        return errorReason;
    }

    public void setErrorReason(String errorReason) {
        this.errorReason = errorReason;
    }
}
