package com.fet.estore.core.bean.vo.frontend;

public class AjaxShoppingGuideListForAccVO {
	private String fetNo;
	/** 配件 - 名稱 */
	private String accName;
	/** 配件 - 數量 */
	private Integer accAmt;
	/** 配件 - 最大數量 */
	private Integer accMaxAmt;
	/** 配件 - 小計 */
	private Long accPrice;
	
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public Integer getAccAmt() {
		return accAmt;
	}
	public void setAccAmt(Integer accAmt) {
		this.accAmt = accAmt;
	}
	public Integer getAccMaxAmt() {
		return accMaxAmt;
	}
	public void setAccMaxAmt(Integer accMaxAmt) {
		this.accMaxAmt = accMaxAmt;
	}
	public Long getAccPrice() {
		return accPrice;
	}
	public void setAccPrice(Long accPrice) {
		this.accPrice = accPrice;
	}
}
