package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class SearchLink implements Serializable {

	private static final long serialVersionUID = -7467932058624619510L;
	private String title;
	private List<SearchData> data;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<SearchData> getData() {
		return data;
	}
	public void setData(List<SearchData> data) {
		this.data = data;
	}
	
}
