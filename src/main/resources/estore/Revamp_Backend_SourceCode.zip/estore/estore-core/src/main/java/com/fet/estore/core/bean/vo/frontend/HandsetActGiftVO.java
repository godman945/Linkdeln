package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class HandsetActGiftVO extends AccessoryDiscountVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3264260930385022818L;
	
	
	private static final String NP = "/newstore/img/shared/plan_icon_03.jpg";
	private static final String LH = "/newstore/img/shared/plan_icon_05.jpg";
	private static final String DA = "/newstore/img/shared/plan_icon_06.jpg";
	private static final String PH = "/newstore/img/shared/plan_icon_04.jpg";
	private static final String HOME = "/newstore/img/shared/plan_icon_02.jpg";
	private static final String STORE = "/newstore/img/shared/plan_icon_01.jpg";
	private static final String PROMO = "/newstore/img/shared/plan_icon_08.jpg";
	private static final String DEFAULTIMGPATH = "/newstore/img/shared/gifts_pics_01.jpg";
	
	private Long id;
	private String description;
	private String imagePath;
	/** 區分活動或是贈品 - ACT GIFT */
	private String type;
	
	/** DA=單買商品*/
	private String daFlag;
	private String daPath = DA;
	
	/** NH=新啟用_手機*/
	private String nhFlag;
	private String nhPath = NP;
	
	/** LH=續約_手機*/
	private String lhFlag;
	private String lhPath = LH;
	
	/** PH=門號可攜_手機*/
	private String phFlag;
	private String phPath = PH;
	/** 宅配*/
	private String homeFlag;
	private String homePath = HOME;
	/** 門市*/
	private String storeFlag;
	private String storePath = STORE;
	/** 促銷代碼*/
	private String oplFlag;
	private String oplPath = PROMO;
	
	private Date onsaleDate;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImagePath() {
		String activityImagePath = this.DEFAULTIMGPATH;
		if(StringUtils.isNotBlank(this.imagePath)){
			activityImagePath = this.imagePath;
		}else{
			if(super.isOverAll() || super.isAccessoryActivity()){
				return super.getImagePath();
			}
		}
		return activityImagePath;
	}
	
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDaFlag() {
		return daFlag;
	}
	public void setDaFlag(String daFlag) {
		this.daFlag = daFlag;
	}
	public String getNhFlag() {
		return nhFlag;
	}
	public void setNhFlag(String nhFlag) {
		this.nhFlag = nhFlag;
	}
	public String getLhFlag() {
		return lhFlag;
	}
	public void setLhFlag(String lhFlag) {
		this.lhFlag = lhFlag;
	}
	public String getPhFlag() {
		return phFlag;
	}
	public void setPhFlag(String phFlag) {
		this.phFlag = phFlag;
	}
	public String getHomeFlag() {
		return homeFlag;
	}
	public void setHomeFlag(String homeFlag) {
		this.homeFlag = homeFlag;
	}
	public String getStoreFlag() {
		return storeFlag;
	}
	public void setStoreFlag(String storeFlag) {
		this.storeFlag = storeFlag;
	}
	public String getDaPath() {
		return daPath;
	}
	public void setDaPath(String daPath) {
		this.daPath = daPath;
	}
	public String getNhPath() {
		return nhPath;
	}
	public void setNhPath(String nhPath) {
		this.nhPath = nhPath;
	}
	public String getLhPath() {
		return lhPath;
	}
	public void setLhPath(String lhPath) {
		this.lhPath = lhPath;
	}
	public String getPhPath() {
		return phPath;
	}
	public void setPhPath(String phPath) {
		this.phPath = phPath;
	}
	public String getHomePath() {
		return homePath;
	}
	public void setHomePath(String homePath) {
		this.homePath = homePath;
	}
	public String getStorePath() {
		return storePath;
	}
	public void setStorePath(String storePath) {
		this.storePath = storePath;
	}
	public String getOplFlag() {
		return oplFlag;
	}
	public void setOplFlag(String oplFlag) {
		this.oplFlag = oplFlag;
	}
	public String getOplPath() {
		return oplPath;
	}
	public void setOplPath(String oplPath) {
		this.oplPath = oplPath;
	}
	public Date getOnsaleDate() {
		return onsaleDate;
	}
	public void setOnsaleDate(Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}
	
}
