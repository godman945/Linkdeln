package com.fet.estore.core.bean.vo.frontend;

/**
 * 活動設備VO
 * @author Max Chen
 *
 */
public class ActivityHandsetGroupVO {

	/** 設備ID */
	private String productId;
	/** 廠牌 */
	private String brandName;
	/** 型號 */
	private String modelName;
	/** 價格抬頭 */
	private String priceTitle;
	/** 圖檔 */
	private String img;
	/** 活動價 */
	private Long activityPrice;
	private Long erpPrice;
	/** 最低價 */
	private Long lowestPrice;
	/** 新申辦最低價 */
	private Long galowestPrice;
	/** 續約最低價 */
	private Long lylowestPrice;	
	/** 攜碼最低價 */
	private Long nplowestPrice;	
	/** 申辦類別 */
	private String[] orderTypes;
	/** 單買最低原價(小網) */
	private Long daErpLowestPrice;
	/** 單買最低折扣價(小網) */
	private Long daDiscountLowestPrice;
	/** 簡要說明 */
	private String viewDesc;
	/** 簡要說明(顯示用)*/
	private String showViewDesc;
	/** 小網秀兩張圖*/
	private String secondImage;
	/**20170407 新增 因為活動所需另外加入 **/
	private String fetNo;
	
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getPriceTitle() {
		return priceTitle;
	}
	public void setPriceTitle(String priceTitle) {
		this.priceTitle = priceTitle;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public Long getActivityPrice() {
		return activityPrice;
	}
	public void setActivityPrice(Long activityPrice) {
		this.activityPrice = activityPrice;
	}
	public Long getLowestPrice() {
		return lowestPrice;
	}
	public void setLowestPrice(Long lowestPrice) {
		this.lowestPrice = lowestPrice;
	}
	public String[] getOrderTypes() {
		return orderTypes;
	}
	public void setOrderTypes(String[] orderTypes) {
		this.orderTypes = orderTypes;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public Long getDaDiscountLowestPrice() {
		return daDiscountLowestPrice;
	}
	public void setDaDiscountLowestPrice(Long daDiscountLowestPrice) {
		this.daDiscountLowestPrice = daDiscountLowestPrice;
	}
	public Long getDaErpLowestPrice() {
		return daErpLowestPrice;
	}
	public void setDaErpLowestPrice(Long daErpLowestPrice) {
		this.daErpLowestPrice = daErpLowestPrice;
	}
	public String getViewDesc() {
		return viewDesc;
	}
	public void setViewDesc(String viewDesc) {
		this.viewDesc = viewDesc;
	}
	public String getShowViewDesc() {
		return showViewDesc;
	}
	public void setShowViewDesc(String showViewDesc) {
		this.showViewDesc = showViewDesc;
	}
	public Long getGalowestPrice() {
		return galowestPrice;
	}
	public void setGalowestPrice(Long galowestPrice) {
		this.galowestPrice = galowestPrice;
	}
	public Long getLylowestPrice() {
		return lylowestPrice;
	}
	public void setLylowestPrice(Long lylowestPrice) {
		this.lylowestPrice = lylowestPrice;
	}
	public Long getNplowestPrice() {
		return nplowestPrice;
	}
	public void setNplowestPrice(Long nplowestPrice) {
		this.nplowestPrice = nplowestPrice;
	}
	public String getSecondImage() {
		return secondImage;
	}
	public void setSecondImage(String secondImage) {
		this.secondImage = secondImage;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
}
