package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.List;

/**
 * 折扣計算結果 - 組合商品VO
 * @author Max Chen
 *
 */
public class DiscountResultSetVO {
	
	/** 商品清單 */
	private List<DiscountResultProductVO> products = new ArrayList<DiscountResultProductVO>();
	/** 組合折扣 */
	private List<DiscountResultDiscountVO> discounts = new ArrayList<DiscountResultDiscountVO>();
	

	public List<DiscountResultProductVO> getProducts() {
		return products;
	}

	public void setProducts(List<DiscountResultProductVO> products) {
		this.products = products;
	}

	public Long getDiscPrice() {
		long price = 0L;
		for(DiscountResultProductVO prod : products) {
			Long discPrice = prod.getDiscPrice();
			if(discPrice == null) continue;
			price += discPrice;
		}
		
		return price;
	}

	public Long getDiscAmount() {
		long amount = 0L;
		for(DiscountResultProductVO prod : products) {
			Long discAmount = prod.getDiscAmount();
			if(discAmount == null) continue;
			amount += discAmount;
		}
		
		return amount;
	}

	public List<DiscountResultDiscountVO> getDiscounts() {
		return discounts;
	}

	public void setDiscounts(List<DiscountResultDiscountVO> discounts) {
		this.discounts = discounts;
	}	
}

