package com.fet.estore.core.bean.vo.frontend;

/**
 * 促案遞送方式
 * @author Max Chen
 *
 */
public class OnsalePromoListDeliveryVO {
	private Boolean isHomeDeliverable;
	private Boolean isStoreDeliverable;
	
	public Boolean getIsHomeDeliverable() {
		return isHomeDeliverable;
	}
	public void setIsHomeDeliverable(Boolean isHomeDeliverable) {
		this.isHomeDeliverable = isHomeDeliverable;
	}
	public Boolean getIsStoreDeliverable() {
		return isStoreDeliverable;
	}
	public void setIsStoreDeliverable(Boolean isStoreDeliverable) {
		this.isStoreDeliverable = isStoreDeliverable;
	}
	
}
