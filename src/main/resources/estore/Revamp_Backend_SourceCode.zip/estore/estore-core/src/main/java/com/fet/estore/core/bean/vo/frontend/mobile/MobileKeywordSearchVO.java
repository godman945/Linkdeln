package com.fet.estore.core.bean.vo.frontend.mobile;

import java.io.Serializable;

public class MobileKeywordSearchVO implements Serializable{

	private static final long serialVersionUID = -2628429397579667290L;

	private Long hansdSetCount;
	
	private Long tabletCount;
	
	private Long accessoryCount;
	
	private Long activityCount;
	
	private Long preorderActivityCount;
	
	private Long minisiteActivityCount;

	public Long getHansdSetCount() {
		return hansdSetCount;
	}

	public void setHansdSetCount(Long hansdSetCount) {
		this.hansdSetCount = hansdSetCount;
	}

	public Long getTabletCount() {
		return tabletCount;
	}

	public void setTabletCount(Long tabletCount) {
		this.tabletCount = tabletCount;
	}

	public Long getAccessoryCount() {
		return accessoryCount;
	}

	public void setAccessoryCount(Long accessoryCount) {
		this.accessoryCount = accessoryCount;
	}

	public Long getActivityCount() {
		return activityCount;
	}

	public void setActivityCount(Long activityCount) {
		this.activityCount = activityCount;
	}

	public Long getPreorderActivityCount() {
		return preorderActivityCount;
	}

	public void setPreorderActivityCount(Long preorderActivityCount) {
		this.preorderActivityCount = preorderActivityCount;
	}

	public Long getMinisiteActivityCount() {
		return minisiteActivityCount;
	}

	public void setMinisiteActivityCount(Long minisiteActivityCount) {
		this.minisiteActivityCount = minisiteActivityCount;
	}

	@Override
	public String toString() {
		return "MobileKeywordSearchVO [hansdSetCount=" + hansdSetCount
				+ ", tabletCount=" + tabletCount + ", accessoryCount="
				+ accessoryCount + ", activityCount=" + activityCount + "]";
	}
	
	
	
}
