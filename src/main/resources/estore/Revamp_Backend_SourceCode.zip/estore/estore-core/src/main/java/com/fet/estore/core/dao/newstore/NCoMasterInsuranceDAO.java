package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CoMasterInsurance;

public interface NCoMasterInsuranceDAO extends BaseDAO<CoMasterInsurance, String> {

}
