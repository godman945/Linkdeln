/**
 * $Id: WebTrendsConstant.java,v 1.0.2.0, 2018-02-08 05:07:55Z, Charlie Shih$
 * Copyright (c) 2008 Stark Technology Inc. All Rights Reserved.
 */
package com.fet.estore.core.constant;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * The <code>WebTrendsConstant</code> class defines all query parameters of
 * WebTrends and their corresponding values。
 *
 * @version $Id: WebTrendsConstant.java,v 1.0.2.0, 2018-02-08 05:07:55Z, Charlie Shih$
 */
public class WebTrendsConstant implements java.io.Serializable  {

        /*
         * WebTrends User-Defined Query Parameters
         * These query parameters are typically used in WebTrends custom reports as
         * measures or dimensions.
         * 	DCSext.WTlayout_block
         * 	DCSext.WTlayout_type
         * 	DCSext.WTlayout_type2
         */

        /** CTR區塊LAYOUT_BLOCK名稱 {@value}。 */
        public static final String LAYOUT_BLOCK = "select_index";
        /** LAYOUT_TYPE {@value}。 */
        public static final String LAYOUT_TYPE = "layoutType";
        /** LOGO {@value}。 */
        public static final String LAYOUT_TYPE_LOGO = "logo";
        /** Sitemap {@value}。 */
        public static final String LAYOUT_TYPE_SITEMAP = "sitemap";
        /** 快速連結 {@value}。 */
        public static final String LAYOUT_TYPE_QUICKLINK = "qlink";
        /** Footer {@value}。 */
        public static final String LAYOUT_TYPE_FOOTER = "footer";
        /** 人氣商品 {@value}。 */
        public static final String LAYOUT_TYPE_MAPRODUCT = "mAProduct";
        /** 優惠快遞 {@value}。 */
        public static final String LAYOUT_TYPE_MFEXPRESS = "mFExpress";
        /** 優惠快遞細項 {@value}。 */
        public static final String LAYOUT_TYPE_MFEXPRESS_ITEMS = "block_C";
        /** 優惠快遞 {@value}。 */
        public static final String LAYOUT_TYPE_MFEXPRESS_PREFERENTIAL_EXPRESS = "C";
        /** 站內搜尋 {@value}。 */
        public static final String LAYOUT_TYPE_SEARCH = "search";
        /** 站內搜尋-登入/出 {@value}。 */
        public static final String LAYOUT_TYPE2_SEARCH_LOGIN = "block_L1";
        /** 站內搜尋-加入會員{@value}。 */
        public static final String LAYOUT_TYPE2_SEARCH_ADD = "block_L2";
        /** 站內搜尋-搜尋 {@value}。 */
        public static final String LAYOUT_TYPE2_SEARCH_SEARCH = "block_L3";


        /** 功能列表 {@value}。 */
        public static final String LAYOUT_TYPE_MENU = "menu";
        /** 資費館首頁CTR {@value}。 */
        public static final String LAYOUT_BLOCK_RATE = "rate";
        /** 續約館首頁右邊廣告(一般用戶促銷) {@value}。 */
        public static final String LAYOUT_TYPE_GENERAL_PROMOTION = "g_promotion";
        /** 續約館首頁右邊廣告(大寬頻用戶促銷) {@value}。 */
        public static final String LAYOUT_TYPE_BBB_PROMOTION = "b_promotion";


        /** 手機館首頁CTR {@value}。 */
        public static final String LAYOUT_BLOCK_CELLPHONE = "ctrCellphone";
        /** 手機館 logo {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_LOGO = "A";
        /** 手機館人氣商品 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_POPULAR_PRODUCT = "B";
        /** 優惠快遞 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_PREFERENTIAL_EXPRESS = "C";
        /** 優惠快遞項目1 {@value}。 */
        public static final String LAYOUT_TYPE2_CELLPHONE_PREFERENTIAL_EXPRESS_1 = "C1";
        /** 優惠快遞項目2 {@value}。 */
        public static final String LAYOUT_TYPE2_CELLPHONE_PREFERENTIAL_EXPRESS_2 = "C2";
        /** 優惠快遞項目3 {@value}。 */
        public static final String LAYOUT_TYPE2_CELLPHONE_PREFERENTIAL_EXPRESS_3 = "C3";
        /** 手機館頁尾 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_FOOTER = "D";
        /** 手機館選單 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_MENU= "E";
        /** 手機館手機特搜 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_DEVICE_SEARCH= "F";
        /** 手機館中央廣告 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_CENTRAL_AD= "G";
        /** 手機館手機特賣 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_ON_SALE= "H";
        /** 手機館手機特賣項目1 {@value}。 */
        public static final String LAYOUT_TYPE2_CELLPHONE_ON_SALE_1= "H1";
        /** 手機館手機特賣項目2 {@value}。 */
        public static final String LAYOUT_TYPE2_CELLPHONE_ON_SALE_2= "H2";
        /** 手機館手機特賣項目3 {@value}。 */
        public static final String LAYOUT_TYPE2_CELLPHONE_ON_SALE_3= "H3";
        /** 手機館手機特賣項目4 {@value}。 */
        public static final String LAYOUT_TYPE2_CELLPHONE_ON_SALE_4= "H4";
        /** 手機館手機特賣項目5 {@value}。 */
        public static final String LAYOUT_TYPE2_CELLPHONE_ON_SALE_5= "H5";
        /** 優鮮推薦 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_RECOMMEND= "I";
        /** 頁首連結 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_SITEMAP = "J";
        /** 畫面右上角快速連結 {@value}。 */
        public static final String LAYOUT_TYPE_CELPHONE_QUICKLINK = "K";
        /** 畫面右上角快速搜尋 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_CONTEXT_SEARCH= "L";
        /** 優惠組合 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_PACKAGE= "M";
        /** 文字公告 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_BULLETIN_BOARD = "N";
        /** 一元手機搶購 {@value}。 */
        public static final String LAYOUT_TYPE_CELLPHONE_ONE_DOLLAR= "P";


        /*
         * MSISDN-specific Constants for WebTrends CTR.
         */
        /** CTR 區塊 (DCSext.WTlayout_block) 識別碼: 門號館 - {@value} */
        public static final String LAYOUT_BLOCK_MSISDN = "msisdn";

        /*
         * Common Parts including Header, LeftMenu, and Footer (from top to bottom, left to right).
         * These parts will be set to HTTP request attributes.
         */
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: LOGO - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_LOGO = "A";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 頁首網址連結 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_SITEMAP = "J";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 功能快速連結 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_QUICKLINK = "K";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 導航列 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_MENU = "E";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 搜尋功能 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_SEARCH = "L";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 人氣商品 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_MAPRODUCT = "B";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 優惠快遞 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_MFEXPRESS = "C";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 頁尾 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_FOOTER = "D";

        /*
         * MSISDN-specific Parts (from top to bottom, left to right).
         */
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 門號快查 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_NUMBER_SEARCH= "F";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: Flash 廣告區 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_CENTRAL_AD= "G";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 門號區 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_ON_SALE= "H";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 門號套裝區 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_PACKAGE= "M";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 佈告欄 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_BULLETIN_BOARD = "N";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 付費選號區 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_CHARGED_NUMBER= "P";
        /** CTR 區塊版型 (DCSext.WTlayout_type) 識別碼: 優鮮推薦區 - {@value} */
        public static final String LAYOUT_TYPE_MSISDN_RECOMMEND= "I";



        /** 門號可攜館-首頁CTR {@value}。 */
        public static final String LAYOUT_BLOCK_NP = "np";
        /** 門號可攜館-logo {@value}。 */
        public static final String LAYOUT_TYPE_NP_LOGO = "A";
        /** 門號可攜館-人氣商品 {@value}。 */
        public static final String LAYOUT_TYPE_NP_POPULAR_PRODUCT = "B";
        /** 門號可攜館-優惠快遞 {@value}。 */
        public static final String LAYOUT_TYPE_NP_PREFERENTIAL_EXPRESS = "C";
        /** 門號可攜館-頁尾 {@value}。 */
        public static final String LAYOUT_TYPE_NP_FOOTER = "D";
        /** 門號可攜館-單辦通話方案流程 {@value}。 */
        public static final String LAYOUT_TYPE_NP_WITHOUT_DEVICE_FLOW= "E";
        /** 門號可攜館-搭配手機方案流程 {@value}。 */
        public static final String LAYOUT_TYPE_NP_WITH_DEVICE_FLOW= "F";
        /** 門號可攜館-優鮮推薦 {@value}。 */
        public static final String LAYOUT_TYPE_NP_RECOMMEND= "G";
        /** 門號可攜館-頁首連結 {@value}。 */
        public static final String LAYOUT_TYPE_NP_SITEMAP = "J";
        /** 門號可攜館-畫面右上角快速連結 {@value}。 */
        public static final String LAYOUT_TYPE_NP_QUICKLINK = "K";
        /** 門號可攜館-畫面右上角快速搜尋 {@value}。 */
        public static final String LAYOUT_TYPE_NP_CONTEXT_SEARCH= "L";
        /** 門號可攜館-優惠組合 {@value}。 */
        public static final String LAYOUT_TYPE_NP_PACKAGE= "M";
        /** 門號可攜館-文字公告 {@value}。 */
        public static final String LAYOUT_TYPE_NP_BULLETIN_BOARD = "N";
        /** 門號可攜館-店長推薦 {@value}。 */
        public static final String LAYOUT_TYPE_NP_ONE_DOLLAR= "O";


        /*
         * WebTrends Scenario Analysis Query Parameters
         * Scenario Analysis definitions use the following attributes:
         *	WT.si_n - Name of the Scenario Analysis
         *  WT.si_p - Identifies the step by name
         */

        /** 流程分析 (Scenario Analysis) 屬性名稱 {@value}。 */
        public static final String SI_N = "si_n";

        /** 手機館流程 {@value}。 */
        public static final String SI_N_CELLPHONE = "cellphone";
        /** 資費館流程 {@value}。 */
        public static final String SI_N_RATE = "rate";
        /** 門號館流程 {@value}。 */
        public static final String SI_N_MSISDN = "msisdn";
        /** 續約館流程 {@value}。 */
        public static final String SI_N_CONTRACT_EXTENSION = "contract_extension";
        /** 套裝館流程 {@value}。 */
        public static final String SI_N_PACKAGE = "package";
    /** @deprecated 門號可攜館流程 {@value}。 */
    public static final String SI_N_NP = "np";
    /** @單買流程 {@value}。 */
    public static final String SI_N_DA = "da";
    /** 門號可攜館-單辦門號流程 {@value}。 */
    public static final String SI_N_NP_WITHOUT_DEVICE = "np1";
    /** 門號可攜館-搭配手機流程 {@value}。 */
    public static final String SI_N_NP_WITH_DEVICE = "np2";
    /** 續約館-大寬頻續約流程 {@value}。 */
        public static final String SI_N_CONTRACT_EXTENSION_BBB = "contract_extension_bbb";
        /** 續約館-一般續約流程 {@value}。 */
        public static final String SI_N_CONTRACT_EXTENSION_GENERAL = "contract_extension_general";
        /** Calling Card 申購流程  {@value}。*/
        public static final String SI_N_CALLING_CARD_BUY = "calling_card_buy";
        /** 限時搶購流程  {@value}。*/
        public static final String SI_N_ACTIVITY_LIMIT_ONSALE = "activity_limit_onsale";
        /** 促銷活動流程  {@value}。*/
        public static final String SI_N_ACTIVITY_ONSALE = "activity_onsale";
        /** 合作網站活動流程(123自由專案)  {@value}。*/
        public static final String SI_N_ACTIVITY_COBRAND = "activity_cobrand";
        /** 合購流程  {@value}。*/
        public static final String SI_N_BUNDLE = "bundle";
        /** N1 新申辦流程  {@value}。*/
        public static final String SI_N_N1_GA = "ga";
        /** N1 門號可攜流程  {@value}。*/
        public static final String SI_N_N1_NP = "np";
        /** N1 續約流程  {@value}。*/
        public static final String SI_N_N1_LY = "ly";
        /** N1 單買流程  {@value}。*/
        public static final String SI_N_N1_DS = "ds";
        /** N1 預付卡流程  {@value}。*/
        public static final String SI_N_N1_PR = "pr";

        /** 選擇商品屬品名稱 {@value}。 */
        public static final String SI_P = "si_p";

        /** 選擇手機 {@value}。 */
        public static final String SI_P_SELECT_CELLPHONE = "select_cellphone";
        /** 選擇手機-手機規格頁 {@value}。 */
        public static final String SI_P_SELECT_CELLPHONE_2 = "select_cellphone2";
    /** 選擇申辦類別 {@value}。 */
    public static final String SI_P_SELECT_APPLY_SHOP_FLOW = "select_apply_shop_flow";
        /** 選擇資費 {@value}。 */
        public static final String SI_P_SELECT_RATE = "select_rate";
        /** 選擇門號 {@value}。 */
        public static final String SI_P_SELECT_MSISDN = "select_msisdn";
        /** 選擇配件 {@value}。 */
        public static final String SI_P_SELECT_ACCESSORY = "select_accessory";
        /** 選擇服務 {@value}。 */
        public static final String SI_P_SELECT_SERVICE = "select_service";
    	/** 填寫資料-契約與條款 {@value}。 */
    	public static final String SI_P_READ_AGREEMENT = "read_agreement";
        /** 選擇商品清單明細 {@value}。 */
        public static final String SI_P_SELECT_PRODUCT_LIST = "select_product_list";
        /** 選擇套裝 {@value}。 */
        public static final String SI_P_SELECT_PACKAGE = "select_package";
        /** 收貨與付款 {@value}。 */
        public static final String SI_P_RECEIVE_AND_PAYMENT = "receive_and_payment";
    	/** 選擇合購優惠 {@value}。 */
    	public static final String SI_P_SELECT_BUNDLE = "select_bundle";
        /** 確認訂單 {@value}。 */
        public static final String SI_P_CONFIRM_ORDER = "confirm_order";
        /** 填寫資料登入 {@value}。 */
        public static final String SI_P_LOGIN = "login";
        /** 資費試算 {@value}。 */
        public static final String SI_P_TRY_COUNT = "try_count";
        /** 資費試算結果 {@value}。 */
        public static final String SI_P_TRY_COUNT_RESULT = "try_count_result";
        /** 續約資格確認 {@value}。 */
        public static final String SI_P_MEMBERCERTIFY = "member_certify";
        /** 續約選優惠方式 {@value}。 */
        public static final String SI_P_SELECT_EXTENSION_TYPE = "select_extension_type";
        /** 選擇設備 {@value}。 */
        public static final String SI_P_SELECT_EQUIPMENT = "select_equipment";
        /** 選擇設備型號 {@value}。 */
        public static final String SI_P_SELECT_EQUIPMENT_MODEL = "select_equipment_model";
        /** 填寫申辦人資料 {@value}。 */
        public static final String SI_P_SUBSCRIBER_DATA = "subscriber_data";
        /** 集團商品館首頁 */
        public static final String SI_P_GROUP_INDEX = "group_index";
        /** 消費者收到Email */
        public static final String SI_P_SENT_EMAIL = "sent_email";
        /** Coupon 認證頁 */
        public static final String SI_P_COUPON_CERTIFY = "coupon_certify";
        /** 加入購物車 */
        public static final String SI_P_ADD_SHPPING_CAR = "add_shppingCar";


        /** 選擇步驟不給予有意義值 {@value}。 */
        public static final String SI_P_SELECT_KEEP_BLANK = "";

        /**  產品分析 (Scenario Analysis) 產品編號 屬性名稱 {@value}。 */
        public static final String PN_SKU = "pn_sku";
        /**  產品分析 (Scenario Analysis) 產品名稱 屬性名稱 {@value}。 */
        public static final String PN = "pn";
        /**  產品分析 (Scenario Analysis) 屬性名稱 {@value}。 */
        public static final String TX_E = "tx_e";
        /**  產品分析 (Scenario Analysis) 產品從購物車移除 屬性名稱 {@value}。 */
        public static final String TX_E_R = "r";
        /**  產品分析 (Scenario Analysis) 瀏覽產品階段 屬性名稱 {@value}。 */
        public static final String TX_E_V = "v";
        /**  產品分析 (Scenario Analysis) 將產品加入購物車 屬性名稱 {@value}。 */
        public static final String TX_E_A = "a";
        /**  產品分析 (Scenario Analysis) 瀏覽產品數量 屬性名稱 {@value}。 */
        public static final String TX_U = "tx_u";

    /** 內容組群WT.cg_n,WT.cg_s,WT.cg_sub star--- **/
    /*
     * WebTrends Content Group Query Parameters
     * A Content Group definition uses the following parameters:
     *  WT.cg_n - Name of the Content Group
     *  WT.cg_s - Name of the Sub-Content Group
     *  WT.cg_sub - FET-ES specific parameter
     */
    /** 內容組群 (Content Group) 組群屬性名稱  (WT.cg_n) - {@value}。 */
    public static final String CG_N = "cg_n";
    /** 內容組群 (Content Group) 次組群屬性名稱 (WT.cg_s) - {@value}。 */
    public static final String CG_S = "cg_s";
    /** 內容組群 (Content Group) 子組群屬性名稱 (WT.cg_sub) - {@value}。 */
    public static final String CG_SUB = "cg_sub";
    /** 無SUB群組之預設值 {@value}。 */
    public static final String CG_SUB_NA = "na";

    /** ESTORE群組 {@value}。 */
    public static final String CG_N_ESTORE = "estore";

    //手機館群組
    /** 手機與通訊商品 {@value}。 */
    public static final String CG_S_CELLPHONE = "cgCellphone";
    /** 手機與通訊商品首頁 {@value}。 */
    public static final String CG_SUB_CELLPHONE_MAIN = "cgCellphoneMain";  //首頁已改為導向cgNewArrivals
    /** 本月特賣(原「新機上市」) {@value}。 */
    public static final String CG_SUB_CELLPHONE_NEW_ARRIVALS = "cgNewArrivals";
    /** 獨家手機 {@value}。 */
    public static final String CG_SUB_CELLPHONE_ONLYS = "cgOnlys";
    /** 智慧手機(原「商務智慧機」) {@value}。 */
    public static final String CG_SUB_CELLPHONE_SMART = "cgSmart";
    /** 0元商品(原「熱賣手機」、「0元手機」) {@value}。 */
    public static final String CG_SUB_CELLPHONE_FREE = "cgFree";
    /** 手機通訊(原「全部手機」) {@value}。 */
    public static final String CG_SUB_CELLPHONE_COMMUNICATE = "cgCommunicate";
    /** 視聽家電 {@value}。 */
    public static final String CG_SUB_CELLPHONE_VEDIO = "cgVedio";
    /** 品味生活 {@value}。 */
    public static final String CG_SUB_CELLPHONE_LIFT = "cgLift";
    /** 3C資訊 {@value}。 */
    public static final String CG_SUB_CELLPHONE_OTHER_DEVICES = "cgOtherDevices";
    /** 週邊及配件 {@value}。 */
    public static final String CG_SUB_CELLPHONE_ACCESSORIES = "cgAccessories";
    /** 全部商品 {@value}。 */
    public static final String CG_SUB_CELLPHONE_ALLS = "cgAlls";

//    /** 手機與通訊商品 {@value}。 */
//    public static final String CG_N_CELLPHONE = "cgCellphone";
//    /** 手機與通訊商品首頁 {@value}。 */
//    public static final String CG_S_CELLPHONE_MAIN = "cgCellphoneMain";
//    /** 新機上市 {@value}。 */
//    public static final String CG_S_CELLPHONE_NEW_ARRIVALS = "cgNewArrivals";
//    /** 熱賣手機 {@value}。 */
//    public static final String CG_S_CELLPHONE_HOTS = "cgHots";
//    /** 獨家手機 {@value}。 */
//    public static final String CG_S_CELLPHONE_ONLYS = "cgOnlys";
//    /** i-mode手機 {@value}。 */
//    public static final String CG_S_CELLPHONE_IMODES = "cgIModes";
//    /** 全部手機 {@value}。 */
//    public static final String CG_S_CELLPHONE_ALLS = "cgAlls";
//    /** 其他通訊產品 {@value}。 */
//    public static final String CG_S_CELLPHONE_OTHER_DEVICES = "cgOtherDevices";
//    /** 手機配件 {@value}。 */
//    public static final String CG_S_CELLPHONE_ACCESSORIES = "cgAccessories";

    //資費館群組
    /** 資費館群組 {@value}。 */
    public static final String CG_S_RATE = "rate";
    /** 資費館群組-月租型 {@value}。 */
    public static final String CG_SUB_RATE_MONTHTYPE = "monthType";
    /** 資費館群組-預付型 {@value}。 */
    public static final String CG_SUB_RATE_PREPAYTYPE = "prepayType";
    /** 資費館群組-遠傳大寬頻3.5G {@value}。 */
    public static final String CG_SUB_RATE_BIGBB = "bigBB";
    /** 資費館群組-多媒體服務資費 {@value}。 */
    public static final String CG_SUB_RATE_MULTIMEDIA = "Multimedia";
    /** 資費館群組-國際漫遊資費 {@value}。 */
    public static final String CG_SUB_RATE_ROAM = "Roam";
    /** 資費館群組-特殊簡碼撥號 {@value}。 */
    public static final String CG_SUB_RATE_SPECIALCODE = "SpecialCode";
    /** 資費館群組-其他收費 {@value}。 */
    public static final String CG_SUB_RATE_OTHERPAY = "OtherPay";
    /** 資費館群組-費率異動公告 {@value}。 */
    public static final String CG_SUB_RATE_RATENOTICE = "RateNotice";
    /** 資費館群組-資費試算 {@value}。 */
    public static final String CG_SUB_RATE_TRYCOUNT = "TryCount";

//    /** 資費館群組 {@value}。 */
//    public static final String CG_N_RATE = "rate";
//    /** 資費館群組-月租型 {@value}。 */
//    public static final String CG_S_MONTHTYPE = "monthType";
//    /** 資費館群組-月租型-哈啦精省 {@value}。 */
//    public static final String CG_SUB_HALASAVEMONEY = "halaSaveMoney";
//    /** 資費館群組-月租型-哈啦頭家 {@value}。 */
//    public static final String CG_SUB_HALABOSS = "halaBoss";
//    /** 資費館群組-月租型-大雙網 {@value}。 */
//    public static final String CG_SUB_BIGPAIRNET = "bigPairNet";
//    /** 資費館群組-月租型-全部資費 {@value}。 */
//    public static final String CG_SUB_ALLRATE = "allRate";
//    /** 資費館群組-預付型 {@value}。 */
//    public static final String CG_S_PREPAYTYPE = "prepayType";
//    /** 資費館群組-預付型-遠傳易付一塊卡 {@value}。 */
//    public static final String CG_SUB_PREPAYC1 = "prepayC1";
//    /** 資費館群組-預付型-遠傳親子卡 {@value}。 */
//    public static final String CG_SUB_PREPAYC2 = "prepayC2";
//    /** 資費館群組-預付型-遠傳易付卡 {@value}。 */
//    public static final String CG_SUB_PREPAYC3 = "prepayC3";
//    /** 資費館群組-預付型-原和信輕鬆卡 {@value}。 */
//    public static final String CG_SUB_PREPAYC4 = "prepayC4";
//    /** 資費館群組-預付型-主要費率比較表 {@value}。 */
//    public static final String CG_SUB_MAINRATETABLE = "mainRateTable";
//    /** 資費館群組-遠傳大寬頻 {@value}。 */
//    public static final String CG_S_BIGBB = "bigBB";
//    /** 資費館群組-遠傳大寬頻-大寬頻695 {@value}。 */
//    public static final String CG_SUB_BIGBBTYPE1 = "bigBBType1";
//    /** 資費館群組-遠傳大寬頻-哈啦99型 {@value}。 */
//    public static final String CG_SUB_BIGBBTYPE2 = "bigBBType2";
//    /** 資費館群組-遠傳GPS情報Go {@value}。 */
//    public static final String CG_S_GPSGO = "gpsGo";
//    /** 資費館群組-遠傳GPS情報Go-基本型 {@value}。 */
//    public static final String CG_SUB_GPSGOTYPE1 = "gpsGoType1";
//    /** 資費館群組-遠傳GPS情報Go-199型 {@value}。 */
//    public static final String CG_SUB_GPSGOTYPE2 = "gpsGoType2";
//    /** 資費館群組-多媒體服務資費 {@value}。 */
//    public static final String CG_S_MULTIMEDIA = "Multimedia";
//    /** 資費館群組-國際漫遊資費 {@value}。 */
//    public static final String CG_S_ROAM = "Roam";
//    /** 資費館群組-特殊簡碼撥號 {@value}。 */
//    public static final String CG_S_SPECIALCODE = "SpecialCode";
//    /** 資費館群組-其他收費 {@value}。 */
//    public static final String CG_S_OTHERPAY = "OtherPay";
//    /** 資費館群組-費率異動公告 {@value}。 */
//    public static final String CG_S_RATENOTICE = "RateNotice";
//    /** 資費館群組-資費試算 {@value}。 */
//    public static final String CG_S_TRYCOUNT = "TryCount";
//    /** 遠傳用戶 {@value}。 */
//    public static final String CG_SUB_FETUSER = "FetUser";
//    /** 原和信用戶 {@value}。 */
//    public static final String CG_SUB_KGTUSER = "KgtUser";

    //門號館群組
    /** 門號組群: 門號首頁 {@value}。 */
    public static final String CG_S_MSISDN = "msisdn";
    /** 門號組群 - 主題門號 {@value}。 */
    public static final String CG_SUB_MSISDN_THEME = "msisdn_theme";
    /** 門號組群 - 收費門號 {@value}。 */
    public static final String CG_SUB_MSISDN_CHARGED = "msisdn_charged";
    /** 門號組群 - 全部門號 {@value}。 */
    public static final String CG_SUB_MSISDN_ALL = "msisdn_all";

//    /** 內容組群 (Content Group): Level 1 門號館 - {@value}。 */
//    public static final String CG_N_MSISDN = "msisdn";
//    /** 內容次組群 (Content Group): Level 1: 門號 - Level 2: 門號首頁 - {@value}。 */
//    public static final String CG_S_MSISDN = "msisdn";
//    /** 內容次組群 (Content Group): Level 1: 門號 - Level 2: 主題門號 - {@value}。 */
//    public static final String CG_S_MSISDN_THEME = "msisdn_theme";
//    /** 內容次組群 (Content Group): Level 1: 門號 - Level 2: 收費門號 - {@value}。 */
//    public static final String CG_S_MSISDN_CHARGED = "msisdn_charged";
//    /** 內容次組群 (Content Group): Level 1: 門號 - Level 2: 全部門號 - {@value}。 */
//    public static final String CG_S_MSISDN_ALL = "msisdn_all";

    //寬頻服務館
    /** 寬頻服務館群組 {@value}。 */
    public static final String CG_S_NET = "wireliess";
    /** 寬頻服務館首頁 {@value}。 */
    /** 寬頻服務館-行動飆網 {@value}。 */
    public static final String CG_SUB_NET_WI_ACTION = "wiAction";
    /** 寬頻服務館首頁子群組 {@value}。 */
    public static final String CG_SUB_NET_WI_HOME = "wiHome";

//    //寬頻服務館
//    /** 寬頻服務館主群組 {@value}。 */
//    public static final String CG_N_NET = "wireless";
//    /** 寬頻服務館首頁 {@value}。 */
//    public static final String CG_S_NET_MAIN = "wiMain";
//    /** 寬頻服務館首頁子群組 {@value}。 */
//    public static final String CG_SUB_NET_MAIN = "wiHome";
//    /** 寬頻服務館-行動飆網 {@value}。 */
//    public static final String CG_S_NET_ACTION = "wiAction";
//    /** 寬頻服務館行動飆網首頁子群組 {@value}。 */
//    public static final String CG_SUB_NET_ACTION = "wiActionHome";
//    /** 寬頻服務館-各類商品 {@value}。 */
//    public static final String CG_SUB_NET_HITPRO = "wiActionHitPro";
//    /** 寬頻服務館-最夯專區 {@value}。 */
//    public static final String CG_SUB_NET_BESTHOT = "wiActionBestHot";
//    /** 寬頻服務館-寬頻服務資費 {@value}。 */
//    public static final String CG_SUB_NET_PAY = "wiActionPay";
//    /** 寬頻服務館-無線體驗 {@value}。 */
//    public static final String CG_SUB_NET_WIFI = "wiActionWifi";
//    /** 寬頻服務館-寬頻服務介紹-3g {@value}。 */
//    public static final String CG_SUB_NET_CONS3G = "wiActionCons3G";
//    /** 寬頻服務館-寬頻服務介紹-Wifly {@value}。 */
//    public static final String CG_SUB_NET_CONSWIFLY = "wiActionConsWifly";
//    /** 寬頻服務館-寬頻服務介紹-Conexus {@value}。 */
//    public static final String CG_SUB_NET_CONSCONEXUS = "wiActionConsConexus";
//    /** 寬頻服務館-寬頻服務介紹-全台收訊 {@value}。 */
//    public static final String CG_SUB_NET_CONSSIGNAL = "wiActionConsSignal";
//    /** 寬頻服務館-寬頻服務介紹-連線速度測試 {@value}。 */
//    public static final String CG_SUB_NET_CONSSPEED = "wiActionConsSpeed";
//    /** 寬頻服務館-寬頻服務介紹-網卡內建服務介紹 {@value}。 */
//    public static final String CG_SUB_NET_CONSSERVICE = "wiActionConsService";

    //續約館
    /** 續約館群組 {@value}。 */
    public static final String CG_S_LOYALTY = "loyalty";

	//門號可攜館群組
    /** 門號可攜館群組 {@value}。 */
    public static final String CG_S_NP = "np";

//    //門號可攜館群組
//    /** 門號可攜館群組 {@value}。 */
//    public static final String CG_N_NP = "np";
//    /** 門號可攜館首頁 {@value}。 */
//    public static final String CG_S_NP_MAIN = "np";

    //集團商品館
    /** 集團商品館主群組 {@value}。 */
    public static final String CG_S_GROUP = "group";
    /** 集團商品館 - 數位家庭服務 {@value}。 */
    public static final String CG_SUB_GROUP_DIGITALHOUSE = "digitalHouse";
    /** 集團商品館 - 國際電話服務 {@value}。 */
    public static final String CG_SUB_GROUP_INTERNATIONLSERVICE = "internationlService";

//    /** 集團商品館主群組 {@value}。 */
//    public static final String CG_N_GROUP = "group";
//    /** 集團商品館首頁 {@value}。 */
//    public static final String CG_S_GROUP_MAIN = "groupMain";


    /** 內容組群WT.cg_n,WT.cg_s,WT.cg_sub end--- **/

        //add for estoreHomePage webTrend code
        /** 網路門市首頁_右上方區塊圖文_TAB */
        //public static final String HOME_SHOWLOYALTY=" onclick=\"sendCtrHome('M')\" ";

        /** 網路門市首頁_右上方區塊圖文_TAB1 */
        public static final String HOME_SHOWLOYALTY_1=" onclick=\"sendCtrHome('M','M1')\" ";

        /** 網路門市首頁_右上方區塊圖文_TAB2 */
        public static final String HOME_SHOWLOYALTY_2=" onclick=\"sendCtrHome('M','M2')\" ";

        /** 網路門市首頁_右上方區塊圖文_TAB3 */
        public static final String HOME_SHOWLOYALTY_3=" onclick=\"sendCtrHome('M','M3')\" ";

        /** 網站購物公告區 */
        public static final String HOME_SHOWSHOPBOARD=" onclick=\"sendCtrHome('O')\" ";

        /**網路門市首頁_主打商品 , 店長推薦(home_boss_suggest)、門號可攜(home_np)、網路獨家(home_web_owner) */
        public static final String HOME_BOSS_SUGGEST = " onclick=\"sendCtrHome('D','D1')\" ";

        /** 網路門市首頁_主打商品_店長推薦_圖 */
        public static final String HOME_BOSS_SUGGEST_A = " onclick=\"sendCtrHome('D','D1','D1_a')\" ";

        /** 網路門市首頁_主打商品_店長推薦_文一 */
        public static final String HOME_BOSS_SUGGEST_B = " onclick=\"sendCtrHome('D','D1','D1_b')\" ";

        /** 網路門市首頁_主打商品_店長推薦_文二 */
        public static final String HOME_BOSS_SUGGEST_C = " onclick=\"sendCtrHome('D','D1','D1_c')\" ";

        /** 網路門市首頁_主打商品_店長推薦_MORE */
        public static final String HOME_BOSS_SUGGEST_MORE = " onclick=\"sendCtrHome('D','D1','D1_d')\" ";

        /** 網路門市首頁_主打商品_寬頻服務 */
        public static final String HOME_NET = " onclick=\"sendCtrHome('D','D2')\" ";

        /** 網路門市首頁_主打商品_寬頻服務_圖 */
        public static final String HOME_NET_A = " onclick=\"sendCtrHome('D','D2','D2_a')\" ";

        /** 網路門市首頁_主打商品_寬頻服務_文一 */
        public static final String HOME_NET_B = " onclick=\"sendCtrHome('D','D2','D2_b')\" ";

        /** 網路門市首頁_主打商品_寬頻服務_文二 */
        public static final String HOME_NET_C = " onclick=\"sendCtrHome('D','D2','D2_c')\" ";

        /** 網路門市首頁_主打商品_寬頻服務_MORE */
        public static final String HOME_NET_MORE = " onclick=\"sendCtrHome('D','D2','D2_d')\" ";

        /** 網路門市首頁_主打商品_門號可攜 */
        public static final String HOME_NP = " onclick=\"sendCtrHome('D','D3')\" ";

        /** 網路門市首頁_主打商品_門號可攜_圖 */
        public static final String HOME_NP_A = " onclick=\"sendCtrHome('D','D3','D3_a')\" ";

        /** 網路門市首頁_主打商品_門號可攜_文一 */
        public static final String HOME_NP_B = " onclick=\"sendCtrHome('D','D3','D3_b')\" ";

        /** 網路門市首頁_主打商品_門號可攜_文二 */
        public static final String HOME_NP_C = " onclick=\"sendCtrHome('D','D3','D3_c')\" ";

        /** 網路門市首頁_主打商品_門號可攜_MORE */
        public static final String HOME_NP_MORE = " onclick=\"sendCtrHome('D','D3','D3_d')\" ";

        /** 網路門市首頁_主打商品_限時搶購 */
        public static final String HOME_LIMIT_TIME = " onclick=\"sendCtrHome('D','D4')\" ";

        /** 網路門市首頁_主打商品_限時搶購_圖 */
        public static final String HOME_LIMIT_TIME_A = " onclick=\"sendCtrHome('D','D4','D4_a')\" ";

        /** 網路門市首頁_主打商品_限時搶購_文一 */
        public static final String HOME_LIMIT_TIME_B = " onclick=\"sendCtrHome('D','D4','D4_b')\" ";

        /** 網路門市首頁_主打商品_限時搶購_文二 */
        public static final String HOME_LIMIT_TIME_C = " onclick=\"sendCtrHome('D','D4','D4_c')\" ";

        /** 網路門市首頁_主打商品_限時搶購_MORE */
        public static final String HOME_LIMIT_TIME_MORE = " onclick=\"sendCtrHome('D','D4','D4_d')\" ";

        /** 網路門市首頁_主打商品_網站獨家 */
        public static final String HOME_WEB_OWNER = " onclick=\"sendCtrHome('D','D5')\" ";

        /** 網路門市首頁_主打商品_網站獨家_圖 */
        public static final String HOME_WEB_OWNER_A = " onclick=\"sendCtrHome('D','D5','D5_a')\" ";

        /** 網路門市首頁_主打商品_網站獨家_文一 */
        public static final String HOME_WEB_OWNER_B = " onclick=\"sendCtrHome('D','D5','D5_b')\" ";

        /** 網路門市首頁_主打商品_網站獨家_文二 */
        public static final String HOME_WEB_OWNER_C = " onclick=\"sendCtrHome('D','D5','D5_c')\" ";

        /** 網路門市首頁_主打商品_網站獨家_MORE */
        public static final String HOME_WEB_OWNER_MORE = " onclick=\"sendCtrHome('D','D5','D5_d')\" ";

        /** 網路門市首頁_門號 */
        public static final String HOME_MSISDN = " onclick=\"sendCtrHome('F')\" ";

        /** 網路門市首頁_門號_黃金門號 */
        public static final String HOME_MSISDN_GOLDEN = " onclick=\"sendCtrHome('F','F1')\" ";

        /** 網路門市首頁_門號_免費門號 */
        public static final String HOME_MSISDN_GROUP = " onclick=\"sendCtrHome('F','F2')\" ";

        /** 網路門市首頁_門號_付費門號 */
        public static final String HOME_MSISDN_CHARGE = " onclick=\"sendCtrHome('F','F3')\" ";

        /** 網路門市首頁_門號_more */
        public static final String HOME_MSISDN_MORE = " onclick=\"sendCtrHome('F','F4')\" ";

        //********* Begin 舊的webTrend目前首頁改版後,目前已無對應關係,改由新的webTrend編號
        /** 網路門市首頁_熱門商品 */
        //public static final String HOME_HOT = " onclick=\"sendCtrHome('E')\" ";

        /** 網路門市首頁_熱門商品_精選手機 */
        //public static final String HOME_HOT_PHONE = " onclick=\"sendCtrHome('E','E1')\" ";

        /** 網路門市首頁_熱門商品_熱門3C */
        //public static final String HOME_HOT_3C = " onclick=\"sendCtrHome('E','E2')\" ";

        /** 網路門市首頁_熱門商品_搜尋 */
        //public static final String HOME_HOT_SEARCH = " onclick=\"sendCtrHome('E','E3')\" ";

        /** 網路門市首頁_熱門商品_more */
        //public static final String HOME_HOT_MORE = " onclick=\"sendCtrHome('E','E4')\" ";
        //********* End 舊的webTrend目前首頁改版後,目前已無對應關係,改由新的webTrend編號

        /** 網路門市首頁_熱門商品_Tab1 */
        public static final String HOME_HOT_TAB1 = " onclick=\"sendCtrHome('E','E1')\" ";

        /** 網路門市首頁_熱門商品_Tab1_大圖 */
        public static final String HOME_HOT_TAB1_A = " onclick=\"sendCtrHome('E','E1','E1_a')\" ";

        /** 網路門市首頁_熱門商品_Tab1_小圖 */
        public static final String HOME_HOT_TAB1_B = " onclick=\"sendCtrHome('E','E1','E1_b')\" ";

        /** 網路門市首頁_熱門商品_Tab1_更多 */
        public static final String HOME_HOT_TAB1_MORE = " onclick=\"sendCtrHome('E','E1','E1_c')\" ";

        /** 網路門市首頁_熱門商品_Tab2 */
        public static final String HOME_HOT_TAB2 = " onclick=\"sendCtrHome('E','E2')\" ";

        /** 網路門市首頁_熱門商品_Tab2_大圖 */
        public static final String HOME_HOT_TAB2_A = " onclick=\"sendCtrHome('E','E2','E2_a')\" ";

        /** 網路門市首頁_熱門商品_Tab2_小圖 */
        public static final String HOME_HOT_TAB2_B = " onclick=\"sendCtrHome('E','E2','E2_b')\" ";

        /** 網路門市首頁_熱門商品_Tab2_更多 */
        public static final String HOME_HOT_TAB2_MORE = " onclick=\"sendCtrHome('E','E2','E2_c')\" ";

        /** 網路門市首頁_熱門商品_Tab3 */
        public static final String HOME_HOT_TAB3 = " onclick=\"sendCtrHome('E','E3')\" ";

        /** 網路門市首頁_熱門商品_Tab3_大圖 */
        public static final String HOME_HOT_TAB3_A = " onclick=\"sendCtrHome('E','E3','E3_a')\" ";

        /** 網路門市首頁_熱門商品_Tab3_小圖 */
        public static final String HOME_HOT_TAB3_B = " onclick=\"sendCtrHome('E','E3','E3_b')\" ";

        /** 網路門市首頁_熱門商品_Tab3_更多 */
        public static final String HOME_HOT_TAB3_MORE = " onclick=\"sendCtrHome('E','E3','E3_c')\" ";

        /** 網路門市首頁_熱門商品_Tab4 */
        public static final String HOME_HOT_TAB4 = " onclick=\"sendCtrHome('E','E4')\" ";

        /** 網路門市首頁_熱門商品_Tab4_大圖 */
        public static final String HOME_HOT_TAB4_A = " onclick=\"sendCtrHome('E','E4','E4_a')\" ";

        /** 網路門市首頁_熱門商品_Tab4_小圖 */
        public static final String HOME_HOT_TAB4_B = " onclick=\"sendCtrHome('E','E4','E4_b')\" ";

        /** 網路門市首頁_熱門商品_Tab4_更多 */
        public static final String HOME_HOT_TAB4_MORE = " onclick=\"sendCtrHome('E','E4','E4_c')\" ";

        /** 網路門市首頁_熱門商品_Tab5 */
        public static final String HOME_HOT_TAB5 = " onclick=\"sendCtrHome('E','E5')\" ";

        /** 網路門市首頁_熱門商品_Tab5_大圖 */
        public static final String HOME_HOT_TAB5_A = " onclick=\"sendCtrHome('E','E5','E5_a')\" ";

        /** 網路門市首頁_熱門商品_Tab5_小圖 */
        public static final String HOME_HOT_TAB5_B = " onclick=\"sendCtrHome('E','E5','E5_b')\" ";

        /** 網路門市首頁_熱門商品_Tab5_更多 */
        public static final String HOME_HOT_TAB5_MORE = " onclick=\"sendCtrHome('E','E5','E5_c')\" ";

        /** 網路門市首頁_活動情報區 */
        public static final String HOME_ACTIVITY_INFO = " onclick=\"sendCtrHome('S')\" ";

        /** add for show 個各館title */
        public static final String HEAD_TITLE = "headtitle";

        public static final String HEAD_CELLPHONE = "ctrCellphone";

        public static final String HEAD_RATE = "rate";

        public static final String HEAD_MSISDN = "msisdn";

        public static final String HEAD_CONTRACT_EXTENSION = "contract_extension";

        public static final String HEAD_NP = "np";

        public static final String HEAD_NET = "unlimitedWireless"; //寬頻服務

        public static final String HEAD_GROUP = "groupProducts"; //集團商品

    //購物車結帳流程
    /**驗證使用者頁*/
    public static final String BILLING_SHOPPING_CART_IDENTIFIED_USER = "identifiedUser";
    /**登入使用者資訊頁*/
    public static final String BILLING_SHOPPING_CART_MEMBER_INFORMATION = "memberInformation";
    /**取貨方式頁-宅配件*/
    public static final String BILLING_SHOPPING_CART_SELECT_DELITYPE_H = "selectDeliTypeH";
    /**取貨方式頁-門市件*/
    public static final String BILLING_SHOPPING_CART_SELECT_DELITYPE_S = "selectDeliTypeS";
    /**優惠折抵頁*/
    public static final String BILLING_SHOPPING_CART_PREFERENTIAL_DISCOUNT = "preferentialDiscount";
    /**申購完成頁*/
    public static final String BILLING_SHOPPING_CART_FINISH = "finish";

    //CallingCard結帳流程
    /**選擇卡別頁*/
    public static final String BILLING_CALLING_CARD_SELECT_CARDS = "selectCallingCard";
    /**驗證使用者頁*/
    public static final String BILLING_CALLING_CARD_IDENTIFIED_USER = "identifiedUser";
    /**登入使用者資訊頁*/
    public static final String BILLING_CALLING_CARD_MEMBER_INFORMATION = "memberInformation";
    /**契約條款頁*/
    public static final String BILLING_CALLING_CARD_AGREE_CONTRACT = "agreeContract";
    /**付款方式頁*/
    public static final String BILLING_CALLING_CARD_PAY_TYPE = "payType";
    /**申購完成頁*/
    public static final String BILLING_CALLING_CARD_FINISH = "finish";

    //大寬頻結帳流程
    /**驗證使用者頁*/
    public static final String BILLING_BIG_WAN_NEWVERIFIED_USER = "newVerifiedUser";
    /**驗證使用者頁-續約*/
    public static final String BILLING_BIG_WAN_REVERIFIED_USER = "reVerifiedUser";
    /**申購人資料頁*/
    public static final String BILLING_BIG_WAN_INPUT_APPLIED_DATA = "inputAppliedData";
    /**申購人資料頁-續約*/
    public static final String BILLING_BIG_WAN_LOYALTY_INPUT_APPLIED_DATA = "loyaltyInputAppliedData";
    /**契約條款頁*/
    public static final String BILLING_BIG_WAN_AGREE_CONTRACT = "agreeContract";
    /**取貨方式頁*/
    public static final String BILLING_BIG_WAN_DELI_TYPE = "deliType";
    /**收件人資料頁*/
    public static final String BILLING_BIG_WAN_PAY_TYPE = "payType";
    /**申購完成頁*/
    public static final String BILLING_BIG_WAN_FINISH = "finish";

    //集團商品館 CTR Value
    /** 集團商品館_首頁CTR{@value}。 */
    public static final String LAYOUT_BLOCK_GROUP = "groupProducts";
    /** 集團商品館_logo {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_LOGO = "A";
    /** 集團商品館_header {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_SITEMAP = "J";
    /** 集團商品館_導覽列 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_LOCATION_BAR = "Z";
    /** 集團商品館_location bar {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_QUICKLINK = "K";
    /** 集團商品_navigation bar {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_NAVIGATION_BAR = "Y";
    /** 集團商品館-右上搜尋功能列 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_CONTEXT_SEARCH = "L";
    /** 集團商品館-右上搜尋功能列-登入/出 {@value}。 */
    public static final String LAYOUT_TYPE2_GROUP_CONTEXT_SEARCH_LOGIN = "L1";
    /** 集團商品館-右上搜尋功能列-加入會員 {@value}。 */
    public static final String LAYOUT_TYPE2_GROUP_CONTEXT_SEARCH_ADD = "L2";
    /** 集團商品館-右上搜尋功能列-搜尋 {@value}。 */
    public static final String LAYOUT_TYPE2_GROUP_CONTEXT_SEARCH_SEARCH = "L3";
    /** 集團商品館_人氣商品 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_POPULAR_PRODUCT = "B";
    /** 集團商品館_優惠快遞 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_PREFERENTIAL_EXPRESS = "C";
    /** 集團商品館_中_焦點 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_FOCUS = "H";
    /** 集團商品_中_集團商品連結 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_M_PRODUCT = "M";
    /** 集團商品_中_集團商品連結_Seednet {@value}。 */
    public static final String LAYOUT_TYPE2_GROUP_M_SEEDNET = "M1";
    /** 集團商品_中_集團商品連結_spark {@value}。 */
    public static final String LAYOUT_TYPE2_GROUP_M_SPARK = "M2";
    /** 集團商品_右_市場訊息 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_RIGHT_TEXT = "I";
    /** 集團商品_右_最新活動 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_ACTIVITY = "N";
    /** 集團商品館_中_優鮮推薦 {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_RECOMMEND = "O";
    /** 集團商品館_footer {@value}。 */
    public static final String LAYOUT_TYPE_GROUP_FOOTER = "D";


    /** 寬頻服務館_首頁CTR {@value}。 */
    public static final String LAYOUT_BLOCK_NET = "unlimitedWireless";
    /** 寬頻服務館_logo {@value}。 */
    public static final String LAYOUT_TYPE_NET_LOGO = "A";
    /** 寬頻服務館_header {@value}。 */
    public static final String LAYOUT_TYPE_NET_SITEMAP = "J";
    /** 寬頻服務館_導覽列 {@value}。 */
    public static final String LAYOUT_TYPE_NET_LOCATION_BAR = "Z";
    /** 寬頻服務館_location bar {@value}。 */
    public static final String LAYOUT_TYPE_NET_QUICKLINK = "K";
    /** 寬頻服務館_navigation bar {@value}。 */
    public static final String LAYOUT_TYPE_NET_NAVIGATION_BAR = "Y";
    /** 寬頻服務館-右上搜尋功能列 {@value}。 */
    public static final String LAYOUT_TYPE_NET_CONTEXT_SEARCH = "L";
    /** 寬頻服務館-右上搜尋功能列-登入/出 {@value}。 */
    public static final String LAYOUT_TYPE2_NET_CONTEXT_SEARCH_LOGIN = "L1";
    /** 寬頻服務館-右上搜尋功能列-加入會員 {@value}。 */
    public static final String LAYOUT_TYPE2_NET_CONTEXT_SEARCH_ADD = "L2";
    /** 寬頻服務館-右上搜尋功能列-搜尋 {@value}。 */
    public static final String LAYOUT_TYPE2_NET_CONTEXT_SEARCH_SEARCH = "L3";
    /** 寬頻服務館_人氣商品 {@value}。 */
    public static final String LAYOUT_TYPE_NET_POPULAR_PRODUCT = "B";
    /** 寬頻服務館_優惠快遞 {@value}。 */
    public static final String LAYOUT_TYPE_NET_PREFERENTIAL_EXPRESS = "C";
    /** 寬頻服務館_馬上體驗 {@value}。 */
    public static final String LAYOUT_TYPE_NET_WIFI = "E";
    /** 寬頻服務館_連線測試 {@value}。 */
    public static final String LAYOUT_TYPE_NET_SPEED = "F";
    /** 寬頻服務館_收訊範圍查詢 {@value}。 */
    public static final String LAYOUT_TYPE_NET_SIGNAL = "G";
    /** 寬頻服務館_中_焦點 {@value}。 */
    public static final String LAYOUT_TYPE_NET_FOCUS = "H";
    /** 寬頻服務館_中_集團商品連結 {@value}。 */
    public static final String LAYOUT_TYPE_NET_M_PRODUCT = "M";
    /** 寬頻服務館_中_集團商品連結_Seednet {@value}。 */
    public static final String LAYOUT_TYPE2_NET_M_ACTION = "M1";
    /** 寬頻服務館_中_集團商品連結_spark {@value}。 */
    public static final String LAYOUT_TYPE2_NET_M_35 = "M2";
    /** 寬頻服務館_右_市場訊息 {@value}。 */
    public static final String LAYOUT_TYPE_NET_RIGHT_TEXT = "I";
    /** 寬頻服務館_右_最夯專區 {@value}。 */
    public static final String LAYOUT_TYPE_NET_BESTHOT = "N";
    /** 寬頻服務館_中_優鮮推薦 {@value}。 */
    public static final String LAYOUT_TYPE_NET_RECOMMEND = "O";
    /** 寬頻服務館_footer {@value}。 */
    public static final String LAYOUT_TYPE_NET_FOOTER = "D";

    /** MiniSite手機流程 {@value}。 */
    public static final String MiniSite_Decive = "MiniSite_Decive";
    /** MiniSite單通話流程 {@value}。 */
    public static final String MiniSite_Msisdn = "MiniSite_Msisdn";

    /** MiniSite手機流程_新申辦 {@value}。 */
    public static final String MiniSite_Decive_GA = "MiniSite_Decive_GA";
    /** MiniSite單通話流程_新申辦 {@value}。 */
    public static final String MiniSite_Msisdn_GA = "MiniSite_Msisdn_GA";

    /** MiniSite手機流程_門號可攜 {@value}。 */
    public static final String MiniSite_Decive_NP = "MiniSite_Decive_NP";
    /** MiniSite單通話流程_門號可攜 {@value}。 */
    public static final String MiniSite_Msisdn_NP = "MiniSite_Msisdn_NP";

    /** MiniSite手機流程_續約 {@value}。 */
    public static final String MiniSite_Decive_LY = "MiniSite_Decive_LY";
    /** MiniSite單通話流程_續約 {@value}。 */
    public static final String MiniSite_Msisdn_LY = "MiniSite_Msisdn_LY";

    /** MiniSite流程步驟_活動資費清單頁 {@value}。 */
    public static final String MiniSite_Step_Promo_List = "minisite_promotion_list";
    /** MiniSite流程步驟_活動設備清單頁 {@value}。 */
    public static final String MiniSite_Step_Device_List = "minisite_device_list";
    /** MiniSite流程步驟_四合一詳細頁 {@value}。 */
    public static final String MiniSite_Step_Device     = "minisite_select_rate_accessory_service";
    /** MiniSite流程步驟_門號頁 {@value}。 */
    public static final String MiniSite_Step_Msisdn     = "minisite_select_msisdn";
    /** MiniSite流程步驟_申辦人資料頁 {@value}。 */
    public static final String MiniSite_Step_Subscriber = "minisite_subscriber_data";
    /** MiniSite流程步驟_契約頁 {@value}。 */
    public static final String MiniSite_Step_Contract   = "minisite_read_agreement";


    /** Newstore流程步驟 - 1. 詳細頁 {@value} */
    public static final String NEWSTORE_STEP_SELECT_ORDER_TYPE = "SELECT_ORDER_TYPE";
    /** Newstore流程步驟 - 1. 詳細頁 {@value} */
    public static final String NEWSTORE_STEP_DETAIL     = "DETAIL";
    /** Newstore紅配綠流程步驟 - 1. 我要購買 {@value} */
    public static final String NEWSTORE_STEP_HSACT_BUY  = "HSACT_BUY";
    /** Newstore流程步驟 - 2. 四合一頁 {@value} */
    public static final String NEWSTORE_STEP_4IN1       = "4IN1";
    /** Newstore流程步驟 - 3. 門號頁 {@value} */
    public static final String NEWSTORE_STEP_MSISDN     = "MSISDN";
    /** Newstore流程步驟 - 4. 填寫資料頁 {@value} */
    public static final String NEWSTORE_STEP_SUBSCRIBER = "SUBSCRIBER";
    /** Newstore流程步驟 - 5. 確認頁 {@value} */
    public static final String NEWSTORE_STEP_CONFIRM    = "CONFIRM";
    /** Newstore流程步驟 - 6. 申購完成頁 {@value} */
    public static final String NEWSTORE_STEP_FINISH     = "FINISH";

    /** Newstore預約流程步驟 - 1. 我要預約 {@value} */
    public static final String NEWSTORE_STEP_PRE_BUY        = "PRE_BUY";
    /** Newstore預約流程步驟 - 2. 填寫資料 {@value} */
    public static final String NEWSTORE_STEP_PRE_SUBSCRIBER = "SUBSCRIBER";
    /** Newstore預約流程步驟 - 3. 預約完成 {@value} */
    public static final String NEWSTORE_STEP_PRE_FINISH     = "FINISH";

    /** Newstore新申辦搭手機流程 - 手機館 {@value} */
    public static final String NEWSTORE_NH_HANDSET   = "NH_HANDSET";
    /** Newstore新申辦搭手機流程 - 平板筆電館 {@value} */
    public static final String NEWSTORE_NH_TABLET    = "NH_TABLET";
    /** Newstore新申辦搭手機流程 - 門號攜碼館 {@value} */
    public static final String NEWSTORE_NH_MSISDN    = "NH_MSISDN";
    /** Newstore新申辦搭手機流程 - 資費館 {@value} */
    public static final String NEWSTORE_NH_RATEPLAN  = "NH_RATEPLAN";
    /** Newstore新申辦搭手機流程 - 其他 {@value} */
    public static final String NEWSTORE_NH_OTHER     = "NH_OTHER";

    /** Newstore新申辦單門號流程 - 門號攜碼館 {@value} */
    public static final String NEWSTORE_NC_MSISDN    = "NC_MSISDN";
    /** Newstore新申辦單門號流程 - 資費館 {@value} */
    public static final String NEWSTORE_NC_RATEPLAN  = "NC_RATEPLAN";
    /** Newstore新申辦單門號流程 - 其他 {@value} */
    public static final String NEWSTORE_NC_OTHER     = "NC_OTHER";
    /** Newstore新申辦單門號流程 - 合作網站活動(123自由專案) {@value} */
    public static final String NEWSTORE_NC_COBRANDER = "NC_COBRAND";

    /** Newstore攜碼搭手機流程 - 手機館 {@value} */
    public static final String NEWSTORE_PH_HANDSET   = "PH_HANDSET";
    /** Newstore攜碼搭手機流程 - 平板筆電館 {@value} */
    public static final String NEWSTORE_PH_TABLET    = "PH_TABLET";
    /** Newstore攜碼搭手機流程 - 門號攜碼館 {@value} */
    public static final String NEWSTORE_PH_MSISDN    = "PH_MSISDN";
    /** Newstore攜碼搭手機流程 - 資費館 {@value} */
    public static final String NEWSTORE_PH_RATEPLAN  = "PH_RATEPLAN";
    /** Newstore攜碼搭手機流程 - 其他 {@value} */
    public static final String NEWSTORE_PH_OTHER     = "PH_OTHER";

    /** Newstore攜碼單門號流程 - 門號攜碼館 {@value} */
    public static final String NEWSTORE_PC_MSISDN    = "PC_MSISDN";
    /** Newstore攜碼單門號流程 - 資費館 {@value} */
    public static final String NEWSTORE_PC_RATEPLAN  = "PC_RATEPLAN";
    /** Newstore攜碼單門號流程 - 其他 {@value} */
    public static final String NEWSTORE_PC_OTHER     = "PC_OTHER";
    /** Newstore攜碼單門號流程 - 合作網站活動(123自由專案) {@value} */
    public static final String NEWSTORE_PC_COBRANDER = "PC_COBRAND";

    /** Newstore續約搭手機流程 - 手機館 {@value} */
    public static final String NEWSTORE_LH_HANDSET   = "LH_HANDSET";
    /** Newstore續約搭手機流程 - 平板筆電館 {@value} */
    public static final String NEWSTORE_LH_TABLET    = "LH_TABLET";
    /** Newstore續約搭手機流程 - 續約館 {@value} */
    public static final String NEWSTORE_LH_LOYALTY   = "LH_LOYALTY";
    /** Newstore續約搭手機流程 - 其他 {@value} */
    public static final String NEWSTORE_LH_OTHER     = "LH_OTHER";

    /** Newstore續約單門號流程 - 續約館 {@value} */
    public static final String NEWSTORE_LC_LOYALTY   = "LC_LOYALTY";
    /** Newstore續約單門號流程 - 其他 {@value} */
    public static final String NEWSTORE_LC_OTHER     = "LC_OTHER";

    /** Newstore單買流程 - 單機配件館 {@value} */
    public static final String NEWSTORE_DA_ACCESSORY = "DA_ACCESSORY";
    /** Newstore單買流程 - 手機館 {@value} */
    public static final String NEWSTORE_DA_HANDSET   = "DA_HANDSET";
    /** Newstore單買流程 - 平板筆電館 {@value} */
    public static final String NEWSTORE_DA_TABLET    = "DA_TABLET";
    /** Newstore單買流程 - 其他 {@value} */
    public static final String NEWSTORE_DA_OTHER     = "DA_OTHER";

    /** Newstore單買流程 - 紅配綠組合商品活動 {@value} */
    public static final String NEWSTORE_DA_HSACT     = "DA_HSACT";

    /** Newstore流程 - 預約單 {@value} */
    public static final String NEWSTORE_DA_PRE       = "PRE";

	/** Newstore社群分享館別 - 首頁 {@value}       */
	public static final String NEWSTORE_SOCIAL_ENTRY_HOME         = "HOME";
	/** Newstore社群分享館別 - 手機館 {@value}     */
	public static final String NEWSTORE_SOCIAL_ENTRY_HANDSET      = "HANDSET";
	/** Newstore社群分享館別 - 平板.3C館 {@value}  */
	public static final String NEWSTORE_SOCIAL_ENTRY_TABLET       = "TABLET";
	/** Newstore社群分享館別 - 配件館 {@value}     */
	public static final String NEWSTORE_SOCIAL_ENTRY_ACCESSORY    = "ACCESSORY";
	/** Newstore社群分享館別 - 續約館 {@value}     */
	public static final String NEWSTORE_SOCIAL_ENTRY_LOYALTY      = "LOYALTY";
	/** Newstore社群分享館別 - 門號館 {@value}     */
	public static final String NEWSTORE_SOCIAL_ENTRY_MSISDN       = "MSISDN";
	/** Newstore社群分享館別 - 家用寬頻館 {@value} */
	public static final String NEWSTORE_SOCIAL_ENTRY_BROADBAND    = "BROADBAND";
	/** Newstore社群分享館別 - 國際電話館 {@value} */
	public static final String NEWSTORE_SOCIAL_ENTRY_CALLING_CARD = "CALLING_CARD";
	/** Newstore社群分享館別 - 資費館 {@value}     */
	public static final String NEWSTORE_SOCIAL_ENTRY_RATE_PLAN    = "RATE_PLAN";
	/** Newstore社群分享館別 - 促銷活動 {@value}   */
	public static final String NEWSTORE_SOCIAL_ENTRY_ACTIVITY     = "ACTIVITY";
	/** Newstore社群分享館別 - 紅配綠 {@value}     */
	public static final String NEWSTORE_SOCIAL_ENTRY_HSACT        = "HSACT";

    /** 小網流程 - 單買 {@value} */
    public static final String MOBILESTORE_DA       = "MOBILE_DA";
    /** 小網流程 - 續手機約 {@value} */
    public static final String MOBILESTORE_LH       = "MOBILE_LH";
    /** 小網流程 - 續通話約 {@value} */
    public static final String MOBILESTORE_LC       = "MOBILE_LC";
    /** 小網流程 - 新申辦手機(phase2) {@value} */
    public static final String MOBILESTORE_NH       = "MOBILE_NH";
    /** 小網流程 - 單辦通話(phase2) {@value} */
    public static final String MOBILESTORE_NC       = "MOBILE_NC";
    /** 小網流程 - 攜碼搭手機(phase2) {@value} */
    public static final String MOBILESTORE_PH       = "MOBILE_PH";
    /** 小網流程 - 攜碼(phase2) {@value} */
    public static final String MOBILESTORE_PC       = "MOBILE_PC";
    /** 小網流程 - 預約 {@value} */
    public static final String MOBILESTORE_PREORDER = "MOBILE_PREORDER";
    /** 小網流程 - 新申辦{@value} */
    public static final String MOBILESTORE_GA       = "MOBILE_GA";
    /** 小網流程 - 攜碼{@value} */
    public static final String MOBILESTORE_NP       = "MOBILE_NP";

    /** 小網流程 - 合作網站 - 新申辦單門號(123自由專案) {@value} */
    public static final String MOBILESTORE_NC_COBRANDER    = "MOBILE_NC_COBRAND";
    /** 小網流程 - 合作網站 - 攜碼單門號(123自由專案 ) {@value} */
    public static final String MOBILESTORE_PC_COBRANDER    = "MOBILE_PC_COBRAND";

    /** 小網步驟 - 單買手機/配件Button */
    public static final String MOBILESTORE_BUY_ALONE           = "BUY_ALONE";
    /** 小網步驟 - 我要續約Button */
    public static final String MOBILESTORE_BUY_LOYALTY         = "BUY_LOYALTY";
    /** 小網步驟 - 新申辦Button(phase2) */
    public static final String MOBILESTORE_BUY_GA              = "BUY_GA";
    /** 小網步驟 - 攜碼Button(phase2) */
    public static final String MOBILESTORE_BUY_NP              = "BUY_NP";
    /** 小網步驟 - 新申辦Button(phase2) */
    public static final String MOBILESTORE_BUY_NH              = "BUY_NH";
    /** 小網步驟 - 攜碼Button(phase2) */
    public static final String MOBILESTORE_BUY_PH              = "BUY_PH";
    /** 小網步驟 - 選擇申辦類型 */
    public static final String MOBILESTORE_SELECT_ORDER_TYPE   = "SELECT_ORDER_TYPE";
    /** 小網步驟 - 選方案及商品 */
    public static final String MOBILESTORE_4IN1                = "4IN1";
    /** 小網步驟 - 選門號 */
    public static final String MOBILESTORE_MSISDN              = "MSISDN";
    /** 小網步驟 - 填寫資料 */
    public static final String MOBILESTORE_SUBSCRIBER          = "SUBSCRIBER";
    /** 小網步驟 - 填寫資料_繼續1 */
    public static final String MOBILESTORE_SUBSCRIBER_CARRYON1 = "SUBSCRIBER_CARRYON1";
    /** 小網步驟 - 填寫資料_繼續2 */
    public static final String MOBILESTORE_SUBSCRIBER_CARRYON2 = "SUBSCRIBER_CARRYON2";
    /** 小網步驟 - 填寫資料_繼續3 */
    public static final String MOBILESTORE_SUBSCRIBER_CARRYON3 = "SUBSCRIBER_CARRYON3";
    /** 小網步驟 - 訂單確認 */
    public static final String MOBILESTORE_CONFIRM             = "CONFIRM";
    /** 小網步驟 - 申購完成 */
    public static final String MOBILESTORE_FINISH              = "FINISH";

    /** 小網訂單內容 - 有手機有配件 */
    public static final String MOBILESTORE_CHECKOUT_BOTH       = "1";
    /** 小網訂單內容 - 僅手機 */
    public static final String MOBILESTORE_CHECKOUT_HANDSET    = "2";
    /** 小網訂單內容 - 僅配件 */
    public static final String MOBILESTORE_CHECKOUT_ACCESSORY  = "3";
    /** 小網訂單內容 - 無(單辦門號) */
    public static final String MOBILESTORE_CHECKOUT_NONE       = "4";
    /** 小網訂單內容 - 門號**/
    public static final String MOBILESTORE_CHECKOUT_GA       = "5";
    /** 小網訂單內容 - 攜碼**/
    public static final String MOBILESTORE_CHECKOUT_NP       = "6";

    /** 小網預約步驟 - 我要預約Button */
    public static final String MOBILESTORE_BUY_PREORDER        = "BUY_PREORDER";
    /** 小網預約步驟 - 填寫資料 */
    public static final String MOBILESTORE_PREORDER_SUBSCRIBER = "SUBSCRIBER";
    /** 小網預約步驟 - 申購完成 */
    public static final String MOBILESTORE_PREORDER_FINISH     = "FINISH";

        // @(#) PUBLIC METHODS
    /**
     * Sets WebTrends corresponding query values defined in {@link Map} as the
     * attributes of the given {@link HttpServletRequest}.
     */
    public static void setWebTrendsAttributes (HttpServletRequest request, Map<String, String> layouts)  {
        for(Map.Entry<String, String> entry: layouts.entrySet())  {
                request.setAttribute(entry.getKey(), entry.getValue());
        }
    }

    /**
         * Sets WebTrends Content Group information to the {@link HttpServletRequest}.
         *
         * @param request the HTTP request used to set attributes
         * @param name WT.cg_n
         * @param subGroupName WT.cg_s
         */
        public static void setContentGroup (HttpServletRequest request, String name, String subGroupName)  {
                request.setAttribute(CG_N, name);
                request.setAttribute(CG_S, subGroupName);
                request.setAttribute(CG_SUB, CG_SUB_NA);
        }

        public static void setContentGroup (HttpServletRequest request, String groupName, String sGroupName, String subGroupName){
            request.setAttribute(CG_N, groupName);
            request.setAttribute(CG_S, sGroupName);
            request.setAttribute(CG_SUB, subGroupName);
        }

        /**
         * Sets WebTrends Scenario Analysis information to the {@link HttpServletRequest}.
         *
         * @param request the HTTP request used to set attributes
         * @param name WT.si_n
         * @param step WT.si_p
         */
        public static void setScenarioAnalysis (HttpServletRequest request, String name, String step)  {
                request.setAttribute(SI_N, name);
                request.setAttribute(SI_P, step);
        }
}
