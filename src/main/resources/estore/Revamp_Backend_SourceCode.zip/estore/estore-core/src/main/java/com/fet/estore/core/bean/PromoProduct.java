package com.fet.estore.core.bean;

import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-23
 * @description
 */
public class PromoProduct {

    private String title;

    private PromoProductMore more;

    private PromoProductTabs tabs;

    private List<List<Product>> tabContent;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public PromoProductMore getMore() {
        return more;
    }

    public void setMore(PromoProductMore more) {
        this.more = more;
    }

    public PromoProductTabs getTabs() {
        return tabs;
    }

    public void setTabs(PromoProductTabs tabs) {
        this.tabs = tabs;
    }

    public List<List<Product>> getTabContent() {
        return tabContent;
    }

    public void setTabContent(List<List<Product>> tabContent) {
        this.tabContent = tabContent;
    }
}
