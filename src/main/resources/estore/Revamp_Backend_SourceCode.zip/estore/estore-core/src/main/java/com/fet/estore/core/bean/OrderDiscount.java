package com.fet.estore.core.bean;

import java.io.Serializable;

public class OrderDiscount implements Serializable {

	private static final long serialVersionUID = 5150386379975190321L;
	private String name;
	private String fetNo;
	private Long amount;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	
}
