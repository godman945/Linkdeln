package com.fet.estore.core.bean;

import java.io.Serializable;

public class MsisdnGroupVO implements Serializable {

	private static final long serialVersionUID = 7658383526521378397L;
	private String text;
	private String link;
	private Integer number;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}

}
