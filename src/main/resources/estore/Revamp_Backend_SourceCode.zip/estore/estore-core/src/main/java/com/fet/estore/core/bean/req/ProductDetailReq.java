package com.fet.estore.core.bean.req;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-13
 * @description
 */
public class ProductDetailReq {

    /** 商品編號 */
    private String productId;

    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
}
