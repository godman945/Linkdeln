package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.List;

public class SocialVO {
	/**社群分享標題**/
	private String title;
	/**社群分享描述**/
	private String description;
	/**社群分享圖示**/
	private String imagePath;
	/**社群分享圖示for g+**/
	private List<String> gPlusimagePath;
	
	/** 小網分享URL */
	private String actUrl; 
	/** 小網活動抬頭 */
	private String actTitle;
	/** 小網看更多 */
	private boolean actSeemore;
	/** 小網分享設備清單 */
	private List<SocialHandsetVO> handsets = new ArrayList<SocialHandsetVO>();

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public List<String> getgPlusimagePath() {
		return gPlusimagePath;
	}

	public void setgPlusimagePath(List<String> gPlusimagePath) {
		this.gPlusimagePath = gPlusimagePath;
	}

	public String getActTitle() {
		return actTitle;
	}

	public void setActTitle(String actTitle) {
		this.actTitle = actTitle;
	}

	public boolean isActSeemore() {
		return actSeemore;
	}

	public void setActSeemore(boolean actSeemore) {
		this.actSeemore = actSeemore;
	}

	public List<SocialHandsetVO> getHandsets() {
		return handsets;
	}

	public void setHandsets(List<SocialHandsetVO> handsets) {
		this.handsets = handsets;
	}

	public String getActUrl() {
		return actUrl;
	}

	public void setActUrl(String actUrl) {
		this.actUrl = actUrl;
	}
}
