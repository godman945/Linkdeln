package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class PaymentVO extends PaymentBaseVO {
	private boolean hasCredential	   ;
	private String  orderType		   ;
	private String  msisdn             ;
	private String  promoName          ;
	private String  promoSubsidyDesc   ;
	private String  promoDesc          ;
	private String  productId          ;
	private String  productName        ;
	private Long    productPrice       ;
	private Long    prepaidPrice       ;
	private List<PaymentAccessoryVO> accs = new ArrayList<>();
	private List<PaymentDiscountVO> accDiscs = new ArrayList<>();
    private List<PaymentExtraVO> extras = new ArrayList<>();
    private List<PaymentDiscountVO> extraDiscs = new ArrayList<>();
    private List<PaymentDiscountVO> actDiscs = new ArrayList<>();
    private List<PaymentPremiumVO>  premiums = new ArrayList<>();
    private List<PaymentDiscountVO> premiumDiscs = new ArrayList<>();
	private boolean canHg              ;
	private boolean canCpn             ;
	private Long    hgExchPoint        ;
	private Long    hgExchPrice        ;
	private Long    hgPoints           ;
	private Long    hgDiscPrice        ;
	private Long    hgDiscPoint        ;
	private String  cpnSn              ;
	private String  cpnName            ;
	private Long    cpnDiscPrice       ;
	private List<String> gifts = new ArrayList<>();
	private Long    totalPrice         ;

	private List<String> deliTypes = new ArrayList<String>();
	private List<String> payTypes;
	
	private boolean creditHasInst;
	private Map<String, String> creditBanks = new TreeMap<>();
	private String  creditBank   ;
	private String  creditPAN    ;
	private String  creditM      ;
	private String  creditY      ;
	private String  creditPIN    ;
	private Integer creditYStart ;
	private Integer creditYEnd   ;
	private Map<String, List<Integer>> creditBankInsts = new LinkedHashMap<String, List<Integer>>();
	private List<PaymentCreditInstBankVO> creditInsts = new ArrayList<>();
	//給續約用的,最後付款頁已經知道是否是門市件,但是原本的程式沒有處理門市的邏輯
	private boolean storeDeliType = false;
	private boolean swipeCardRenew = false;
	private boolean swipeCardRenewProduct = false;

	
	public List<PaymentCreditInstBankVO> getCreditInstBanks() {
		List<PaymentCreditInstBankVO> descvos = new ArrayList<>();

		// build inst -> banks
		Map<Integer, Set<String>> instBanks = new TreeMap<>();
		for(Map.Entry<String, List<Integer>> bankidInsts : creditBankInsts.entrySet()) {
			String bankid = bankidInsts.getKey();
			List<Integer> insts = bankidInsts.getValue();
			for(Integer inst : insts) {
				if(inst == 1) continue;
				if(!instBanks.containsKey(inst)) instBanks.put(inst, new LinkedHashSet<>());
				instBanks.get(inst).add(bankid);
			}
		}

		for(Map.Entry<Integer, Set<String>> instBank : instBanks.entrySet()) {
			Integer inst = instBank.getKey();
			Set<String> banks = instBank.getValue();
			String[] bankarr = banks.toArray(new String[banks.size()]);
			String bank = bankarr.length > 0 ? bankarr[0] : null;
			Long instPrice = this.totalPrice != null ? this.totalPrice.longValue() / inst : null;

			PaymentCreditInstBankVO descvo = new PaymentCreditInstBankVO();
			
			descvo.setInst(inst);
			descvo.setBank(bank);
			descvo.setBanks(bankarr);
			descvo.setPrice(instPrice);
			descvos.add(descvo);
		}
		
		return descvos;
	}
	
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getPromoName() {
		return promoName;
	}

	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}

	public String getPromoSubsidyDesc() {
		return promoSubsidyDesc;
	}

	public void setPromoSubsidyDesc(String promoSubsidyDesc) {
		this.promoSubsidyDesc = promoSubsidyDesc;
	}

	public String getPromoDesc() {
		return promoDesc;
	}

	public void setPromoDesc(String promoDesc) {
		this.promoDesc = promoDesc;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Long getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Long productPrice) {
		this.productPrice = productPrice;
	}

	public Long getPrepaidPrice() {
		return prepaidPrice;
	}

	public void setPrepaidPrice(Long prepaidPrice) {
		this.prepaidPrice = prepaidPrice;
	}

	public boolean isCanHg() {
		return canHg;
	}

	public void setCanHg(boolean canHg) {
		this.canHg = canHg;
	}

	public boolean isCanCpn() {
		return canCpn;
	}

	public void setCanCpn(boolean canCpn) {
		this.canCpn = canCpn;
	}

	public Long getHgExchPoint() {
		return hgExchPoint;
	}

	public void setHgExchPoint(Long hgExchPoint) {
		this.hgExchPoint = hgExchPoint;
	}

	public Long getHgExchPrice() {
		return hgExchPrice;
	}

	public void setHgExchPrice(Long hgExchPrice) {
		this.hgExchPrice = hgExchPrice;
	}

	public Long getHgPoints() {
		return hgPoints;
	}

	public void setHgPoints(Long hgPoints) {
		this.hgPoints = hgPoints;
	}

	public Long getHgDiscPrice() {
		return hgDiscPrice;
	}

	public void setHgDiscPrice(Long hgDiscPrice) {
		this.hgDiscPrice = hgDiscPrice;
	}

	public String getCpnName() {
		return cpnName;
	}

	public void setCpnName(String cpnName) {
		this.cpnName = cpnName;
	}

	public String getCpnSn() {
		return cpnSn;
	}

	public void setCpnSn(String cpnSn) {
		this.cpnSn = cpnSn;
	}

	public Long getCpnDiscPrice() {
		return cpnDiscPrice;
	}

	public void setCpnDiscPrice(Long cpnDiscPrice) {
		this.cpnDiscPrice = cpnDiscPrice;
	}

	public List<String> getGifts() {
		return gifts;
	}

	public void setGifts(List<String> gifts) {
		this.gifts = gifts;
	}

	public Long getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}

	public List<PaymentExtraVO> getExtras() {
		return extras;
	}

	public void setExtras(List<PaymentExtraVO> extras) {
		this.extras = extras;
	}

	public boolean isCreditHasInst() {
		return creditHasInst;
	}

	public void setCreditHasInst(boolean creditHasInst) {
		this.creditHasInst = creditHasInst;
	}

	public String getCreditBank() {
		return creditBank;
	}

	public void setCreditBank(String creditBank) {
		this.creditBank = creditBank;
	}

	public String getCreditPAN() {
		return creditPAN;
	}

	public void setCreditPAN(String creditPAN) {
		this.creditPAN = creditPAN;
	}

	public String getCreditM() {
		return creditM;
	}

	public void setCreditM(String creditM) {
		this.creditM = creditM;
	}

	public String getCreditY() {
		return creditY;
	}

	public void setCreditY(String creditY) {
		this.creditY = creditY;
	}

	public String getCreditPIN() {
		return creditPIN;
	}

	public void setCreditPIN(String creditPIN) {
		this.creditPIN = creditPIN;
	}

	public Integer getCreditYStart() {
		return creditYStart;
	}

	public void setCreditYStart(Integer creditYStart) {
		this.creditYStart = creditYStart;
	}

	public Integer getCreditYEnd() {
		return creditYEnd;
	}

	public void setCreditYEnd(Integer creditYEnd) {
		this.creditYEnd = creditYEnd;
	}

	public Map<String, List<Integer>> getCreditBankInsts() {
		return creditBankInsts;
	}

	public void setCreditBankInsts(Map<String, List<Integer>> creditBankInsts) {
		this.creditBankInsts = creditBankInsts;
	}

	public List<PaymentCreditInstBankVO> getCreditInsts() {
		return creditInsts;
	}

	public void setCreditInsts(List<PaymentCreditInstBankVO> creditInsts) {
		this.creditInsts = creditInsts;
	}

	public List<String> getPayTypes() {
		return payTypes;
	}

	public void setPayTypes(List<String> payTypes) {
		this.payTypes = payTypes;
	}

	public Map<String, String> getCreditBanks() {
		return creditBanks;
	}

	public void setCreditBanks(Map<String, String> creditBanks) {
		this.creditBanks = creditBanks;
	}

	public Long getHgDiscPoint() {
		return hgDiscPoint;
	}

	public void setHgDiscPoint(Long hgDiscPoint) {
		this.hgDiscPoint = hgDiscPoint;
	}

	public List<PaymentDiscountVO> getExtraDiscs() {
		return extraDiscs;
	}

	public void setExtraDiscs(List<PaymentDiscountVO> extraDiscs) {
		this.extraDiscs = extraDiscs;
	}

	public List<PaymentDiscountVO> getActDiscs() {
		return actDiscs;
	}

	public void setActDiscs(List<PaymentDiscountVO> actDiscs) {
		this.actDiscs = actDiscs;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public List<String> getDeliTypes() {
		return deliTypes;
	}

	public void setDeliTypes(List<String> deliTypes) {
		this.deliTypes = deliTypes;
	}

	public boolean isHasCredential() {
		return hasCredential;
	}

	public void setHasCredential(boolean hasCredential) {
		this.hasCredential = hasCredential;
	}

	public List<PaymentDiscountVO> getPremiumDiscs() {
		return premiumDiscs;
	}

	public void setPremiumDiscs(List<PaymentDiscountVO> premiumDiscs) {
		this.premiumDiscs = premiumDiscs;
	}

	public List<PaymentPremiumVO> getPremiums() {
		return premiums;
	}

	public void setPremiums(List<PaymentPremiumVO> premiums) {
		this.premiums = premiums;
	}
	
	public List<PaymentAccessoryVO> getAccs() {
		return accs;
	}
	
	public void setAccs(List<PaymentAccessoryVO> accs) {
		this.accs = accs;
	}

	public List<PaymentDiscountVO> getAccDiscs() {
		return accDiscs;
	}

	public void setAccDiscs(List<PaymentDiscountVO> accDiscs) {
		this.accDiscs = accDiscs;
	}

	public boolean isStoreDeliType() {
		return storeDeliType;
	}

	public void setStoreDeliType(boolean storeDeliType) {
		this.storeDeliType = storeDeliType;
	}


	public boolean isSwipeCardRenew() {
		return swipeCardRenew;
	}


	public void setSwipeCardRenew(boolean swipeCardRenew) {
		this.swipeCardRenew = swipeCardRenew;
	}

	public boolean isSwipeCardRenewProduct() {
	    return swipeCardRenewProduct;
	}


	public void setSwipeCardRenewProduct(boolean swipeCardRenewProduct) {
	    this.swipeCardRenewProduct = swipeCardRenewProduct;
	}

}
