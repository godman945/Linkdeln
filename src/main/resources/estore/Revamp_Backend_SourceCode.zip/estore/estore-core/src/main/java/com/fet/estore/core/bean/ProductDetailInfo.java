package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

/**
 * 商品明細頁 - 商品明細頁初始化資訊
 *
 * @description
 * @author Ted.Hsieh
 * @date 2020-08-11
 */

public class ProductDetailInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 麵包屑 */
    private List<BreadCrumbs> breadcrumbs;
    /** 商品詳細資訊 */
    private ProductDetail productDetail;
    /** 商品介紹及規格 */
    private List<ProductDetailDesc> spec;
    /** 個人資訊 */
    private ProductDetailRenewalInfo renewalInfo;
    /** 是否為員工活動賣場 */
    private boolean isEmployeeAct;

    public List<BreadCrumbs> getBreadcrumbs() {
        return breadcrumbs;
    }

    public void setBreadcrumbs(List<BreadCrumbs> breadcrumbs) {
        this.breadcrumbs = breadcrumbs;
    }

    public ProductDetail getProductDetail() {
        return productDetail;
    }

    public void setProductDetail(ProductDetail productDetail) {
        this.productDetail = productDetail;
    }

    public  List<ProductDetailDesc> getSpec() {
        return spec;
    }

    public void setSpec( List<ProductDetailDesc> spec) {
        this.spec = spec;
    }

    public ProductDetailRenewalInfo getRenewalInfo() {
        return renewalInfo;
    }

    public void setRenewalInfo(ProductDetailRenewalInfo renewalInfo) {
        this.renewalInfo = renewalInfo;
    }

	public boolean getIsEmployeeAct() {
		return isEmployeeAct;
	}

	public void setIsEmployeeAct(boolean isEmployeeAct) {
		this.isEmployeeAct = isEmployeeAct;
	}
}
