package com.fet.estore.core.bean.vo.frontend.mobile;

public class AreaRgnVO {
	
	private String rgnCode;
	private String rgnName;

	public String getRgnCode() {
		return rgnCode;
	}

	public String getRgnName() {
		return rgnName;
	}

	public void setRgnCode(String rgnCode) {
		this.rgnCode = rgnCode;
	}

	public void setRgnName(String rgnName) {
		this.rgnName = rgnName;
	}


}
