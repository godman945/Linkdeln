package com.fet.estore.core.bean.po;

import com.fet.estore.core.model.ContentOffer;
import com.fet.estore.core.model.Datarate;
import com.fet.estore.core.model.Voicerate;
import org.hibernate.type.NumericBooleanType;

import java.io.Serializable;
import java.util.List;

/**
 * @author Dennis.Chen
 * @Date 2020-08-20
 */
public class PromotionPO implements Serializable {

    private static final long serialVersionUID = 1L;

    String oplSeq;
    String oplName; //User定義的促案名稱
    String recommendDesc;
    Long monthPrice; //月租費
    String bubbleText;
    String dataUsageAmount;
    String speedDesc;
    String voicePremium;
    String voicePremium2;
    String voicePremium3;
    String voicePremium4;
    String otherPremium;
    String noLimit; //是否吃到飽 Y/N
    String isRecommend; //是否為推薦資費
    Integer recommendSort; //推薦資費順序
    Integer limit; //促銷方案期數
    String promotionListId;
    String promoType;
    Voicerate voiceRate;
    Datarate dataRate;
    ContentOffer contentOffer;
    String isNpf4g;
    String isPos4g;
    String isNpf5g;
    String isPos5g;
    Long prepaymentPrice; //預繳款
    Long posPrice; //商品價格
    String is4gt5g;
    String isLoy5g;
    String isLoy4g;
    String pCode;
    String projectName; //ICE定義的促案名稱
    String fetNo; // 料號,給商品對促案用
    Boolean homeDeliverable; // 限宅配
    Boolean storeDeliverable; // 限門市

    public String getOplSeq() {
        return oplSeq;
    }

    public void setOplSeq(String oplSeq) {
        this.oplSeq = oplSeq;
    }

    public String getOplName() {
        return oplName;
    }

    public void setOplName(String oplName) {
        this.oplName = oplName;
    }

    public String getRecommendDesc() {
        return recommendDesc;
    }

    public void setRecommendDesc(String recommendDesc) {
        this.recommendDesc = recommendDesc;
    }

    public Long getMonthPrice() {
        return monthPrice;
    }

    public void setMonthPrice(Long monthPrice) {
        this.monthPrice = monthPrice;
    }

    public String getBubbleText() {
        return bubbleText;
    }

    public void setBubbleText(String bubbleText) {
        this.bubbleText = bubbleText;
    }

    public String getDataUsageAmount() {
        return dataUsageAmount;
    }

    public void setDataUsageAmount(String dataUsageAmount) {
        this.dataUsageAmount = dataUsageAmount;
    }

    public String getSpeedDesc() {
        return speedDesc;
    }

    public void setSpeedDesc(String speedDesc) {
        this.speedDesc = speedDesc;
    }

    public String getVoicePremium() {
        return voicePremium;
    }

    public void setVoicePremium(String voicePremium) {
        this.voicePremium = voicePremium;
    }

    public String getVoicePremium2() {
        return voicePremium2;
    }

    public void setVoicePremium2(String voicePremium2) {
        this.voicePremium2 = voicePremium2;
    }

    public String getVoicePremium3() {
        return voicePremium3;
    }

    public void setVoicePremium3(String voicePremium3) {
        this.voicePremium3 = voicePremium3;
    }

    public String getVoicePremium4() {
        return voicePremium4;
    }

    public void setVoicePremium4(String voicePremium4) {
        this.voicePremium4 = voicePremium4;
    }

    public String getOtherPremium() {
        return otherPremium;
    }

    public void setOtherPremium(String otherPremium) {
        this.otherPremium = otherPremium;
    }

    public String getNoLimit() {
        return noLimit;
    }

    public void setNoLimit(String noLimit) {
        this.noLimit = noLimit;
    }

    public String getIsRecommend() {
        return isRecommend;
    }

    public void setIsRecommend(String isRecommend) {
        this.isRecommend = isRecommend;
    }

    public Integer getRecommendSort() {
        return recommendSort;
    }

    public void setRecommendSort(Integer recommendSort) {
        this.recommendSort = recommendSort;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public String getPromotionListId() {
        return promotionListId;
    }

    public void setPromotionListId(String promotionListId) {
        this.promotionListId = promotionListId;
    }

    public String getPromoType() {
        return promoType;
    }

    public void setPromoType(String promoType) {
        this.promoType = promoType;
    }

    public Voicerate getVoiceRate() {
        return voiceRate;
    }

    public void setVoiceRate(Voicerate voiceRate) {
        this.voiceRate = voiceRate;
    }

    public Datarate getDataRate() {
        return dataRate;
    }

    public void setDataRate(Datarate dataRate) {
        this.dataRate = dataRate;
    }

    public ContentOffer getContentOffer() {
        return contentOffer;
    }

    public void setContentOffer(ContentOffer contentOffer) {
        this.contentOffer = contentOffer;
    }

    public String getIsNpf4g() {
        return isNpf4g;
    }

    public void setIsNpf4g(String isNpf4g) {
        this.isNpf4g = isNpf4g;
    }

    public String getIsPos4g() {
        return isPos4g;
    }

    public void setIsPos4g(String isPos4g) {
        this.isPos4g = isPos4g;
    }

    public String getIsNpf5g() {
        return isNpf5g;
    }

    public void setIsNpf5g(String isNpf5g) {
        this.isNpf5g = isNpf5g;
    }

    public String getIsPos5g() {
        return isPos5g;
    }

    public void setIsPos5g(String isPos5g) {
        this.isPos5g = isPos5g;
    }

    public Long getPrepaymentPrice() {
        return prepaymentPrice;
    }

    public void setPrepaymentPrice(Long prepaymentPrice) {
        this.prepaymentPrice = prepaymentPrice;
    }

    public Long getPosPrice() {
        return posPrice;
    }

    public void setPosPrice(Long posPrice) {
        this.posPrice = posPrice;
    }

	public String getIs4gt5g() {
		return is4gt5g;
	}

	public void setIs4gt5g(String is4gt5g) {
		this.is4gt5g = is4gt5g;
	}

	public String getIsLoy5g() {
		return isLoy5g;
	}

	public void setIsLoy5g(String isLoy5g) {
		this.isLoy5g = isLoy5g;
	}

	public String getIsLoy4g() {
		return isLoy4g;
	}

	public void setIsLoy4g(String isLoy4g) {
		this.isLoy4g = isLoy4g;
	}

	public String getpCode() {
		return pCode;
	}

	public void setpCode(String pCode) {
		this.pCode = pCode;
	}

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getFetNo() {
        return fetNo;
    }

    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }

    public Boolean getHomeDeliverable() {
        return homeDeliverable;
    }

    public void setHomeDeliverable(Boolean homeDeliverable) {
        this.homeDeliverable = homeDeliverable;
    }

    public Boolean getStoreDeliverable() {
        return storeDeliverable;
    }

    public void setStoreDeliverable(Boolean storeDeliverable) {
        this.storeDeliverable = storeDeliverable;
    }
}
