package com.fet.estore.core.bean.vo.common;

import java.util.List;

public class OnlineDealsVO {

	String title;
	List<OnlineDealsCardVO> cards;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<OnlineDealsCardVO> getCards() {
		return cards;
	}
	public void setCards(List<OnlineDealsCardVO> cards) {
		this.cards = cards;
	}
	
}
