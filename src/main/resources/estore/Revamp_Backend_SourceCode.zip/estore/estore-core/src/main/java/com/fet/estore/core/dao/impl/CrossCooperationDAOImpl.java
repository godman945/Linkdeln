package com.fet.estore.core.dao.impl;

import org.springframework.stereotype.Repository;

import com.fet.estore.core.dao.ICrossCooperationDAO;
import com.fet.estore.core.dao.base.impl.AbstractBaseDAO;
import com.fet.estore.core.model.CrossCooperation;

@Repository
public class CrossCooperationDAOImpl extends AbstractBaseDAO<CrossCooperation, String> implements ICrossCooperationDAO {


}
