package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

public class Address implements Serializable   {
	public static final String ADDRESS_TYPE_MERGE_ACCOUNT = "MERGE";
	public static final String ADDRESS_TYPE_APPLICANT = "APPLICANT";
	public static final String ADDRESS_TYPE_REGISTER = "REGISTER";
	public static final String ADDRESS_TYPE_BILL = "BILL";
	public static final String ADDRESS_TYPE_VAT = "VAT";
	public static final String ADDRESS_TYPE_DELIVERY = "DELIVERY";
	private String cityCode;
	private String areaCode;
	private String sixZipCode;
	private String textAddress;
	private String addressType;
	private String sameAs;
	
	public Address() {
		
	}
	
	public Address(String cityCode, String areaCode, String textAddress, String addressType, String sameAs){
		if(sameAs != null && !sameAs.equals(ADDRESS_TYPE_MERGE_ACCOUNT) 
				&& !sameAs.equals(ADDRESS_TYPE_APPLICANT) 
				&& !sameAs.equals(ADDRESS_TYPE_REGISTER) 
				&& !sameAs.equals(ADDRESS_TYPE_DELIVERY) 
				&& !sameAs.equals(ADDRESS_TYPE_BILL)
				&& !sameAs.equals(ADDRESS_TYPE_VAT)){
			throw new RuntimeException("Not support address type!");
		}
		
		this.cityCode = cityCode;
		this.areaCode = areaCode;
		this.textAddress = textAddress;
		this.addressType = addressType;
		this.sameAs = sameAs;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getSameAs() {
		return sameAs;
	}

	public void setSameAs(String sameAs) {
		this.sameAs = sameAs;
	}

	public String getTextAddress() {
		return textAddress;
	}

	public void setTextAddress(String textAddress) {
		this.textAddress = textAddress;
	}

	public String getSixZipCode() {
		return sixZipCode;
	}

	public void setSixZipCode(String sixZipCode) {
		this.sixZipCode = sixZipCode;
	}
}