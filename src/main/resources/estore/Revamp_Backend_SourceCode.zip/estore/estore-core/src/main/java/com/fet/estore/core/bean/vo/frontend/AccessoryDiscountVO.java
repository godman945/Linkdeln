/**
 * 配件優惠活動VO
 */
package com.fet.estore.core.bean.vo.frontend;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Brian  
 * 
 */
public class AccessoryDiscountVO {


	/** 活動圖檔-無圖片路徑預設值 */
	private static final String DEFAULTIMGPATH = "/newstore/img/shared/gifts_pics_03.jpg";
	/** 單買商品圖示路徑 */
	private static final String DA = "/newstore/img/shared/plan_icon_06.jpg";
	/** 宅配取貨圖示路徑 */
	private static final String HOME = "/newstore/img/shared/plan_icon_02.jpg";
	/** 料號(活動編號) */
	private String fetNo;
	/** 活動說明 */
	private String discountDesc;
	/** 圖檔路徑 */
	private String imagePath;
	/** 單買商品 */
	private String daPath = DA;
	/** 宅配取貨 */
	private String homePath = HOME;
	/** 活動說明 */
	private String displayName;
	
	private boolean overAll;
	private boolean accessoryActivity;
	
	public String getFetNo() {
		return fetNo;
	}

	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

	public String getDiscountDesc() {
		return discountDesc;
	}

	public void setDiscountDesc(String discountDesc) {
		this.discountDesc = discountDesc;
	}

	public String getImagePath() {
		String activityImagePath = this.DEFAULTIMGPATH;
		if(StringUtils.isNotBlank(this.imagePath)){
			activityImagePath = this.imagePath;
		}
		return activityImagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getDaPath() {
		return daPath;
	}

	public void setDaPath(String daPath) {
		this.daPath = daPath;
	}

	public String getHomePath() {
		return homePath;
	}

	public void setHomePath(String homePath) {
		this.homePath = homePath;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public boolean isOverAll() {
		return overAll;
	}

	public void setOverAll(boolean overAll) {
		this.overAll = overAll;
	}

	public boolean isAccessoryActivity() {
		return accessoryActivity;
	}

	public void setAccessoryActivity(boolean accessoryActivity) {
		this.accessoryActivity = accessoryActivity;
	}
	
}
