package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.bean.vo.IDiscountItem;

import java.util.ArrayList;
import java.util.List;

public class ActivityPremiumVO implements IDiscountItem {
	private Long    id            ;
    private String  fetNo         ; 
    private Integer prodtypeNo    ; 
    private Double  discountRation;
    private Integer discountAmount; 
    private Integer displayOrder  ; 
    private Integer groupNumber   ;
    private List<ActivityPremiumDiscountVO> discounts = new ArrayList<>();
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	public Integer getProdtypeNo() {
		return prodtypeNo;
	}
	public void setProdtypeNo(Integer prodtypeNo) {
		this.prodtypeNo = prodtypeNo;
	}
	public Integer getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(Integer discountAmount) {
		this.discountAmount = discountAmount;
	}
	public Integer getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}
	public Integer getGroupNumber() {
		return groupNumber;
	}
	public void setGroupNumber(Integer groupNumber) {
		this.groupNumber = groupNumber;
	}
	public Double getDiscountRation() {
		return discountRation;
	}
	public void setDiscountRation(Double discountRation) {
		this.discountRation = discountRation;
	}
	public List<ActivityPremiumDiscountVO> getDiscounts() {
		return discounts;
	}
	public void setDiscounts(List<ActivityPremiumDiscountVO> discounts) {
		this.discounts = discounts;
	}

	@Override
	public Long getAaiId() {
		return null;
	}
	@Override
	public String getCode() {
		return null;
	}
	@Override
	public Long getActivityId() {
		return null;
	}
	@Override
	public String getName() {
		return null;
	}
	@Override
	public Long getAmount() {
		return discountAmount != null ? discountAmount.longValue() : null;
	}
	@Override
	public Long getCouponId() {
		return null;
	}
	@Override
	public Long getOfferId() {
		return null;
	}
	@Override
	public Long getCostCenterId() {
		return null;
	}
	@Override
	public Double getDiscountRatio() {
		return discountRation;
	}
	@Override
	public Long getActualDiscountAmt() {
		return null;
	}
	@Override
	public String getDisplayGroup() {
		return null;
	}
	@Override
	public String getDiscountName() {
		return null;
	}
}
