package com.fet.estore.core.bean;


import com.fet.estore.core.enums.NavHelperEnum;

import java.io.Serializable;

public class NavigationHelper implements Serializable{

	private static final long serialVersionUID = -3506209191363232615L;

	NavHelperEnum navHelperEnum = NavHelperEnum.OTHER;

	public NavHelperEnum getNavHelperEnum() {
		return navHelperEnum;
	}
	public void setNavHelperEnum(NavHelperEnum navHelperEnum) {
		this.navHelperEnum = navHelperEnum;
	}
}
