/**
 * 
 */
package com.fet.estore.core.bean.vo.frontend;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Brian
 * 
 */
public class AccessoryDescriptionVO {
	
	/** 說明。 */
	private String brief;
	/** 規格。 */
	private String spec;
	/** 配件圖檔路徑1。 */
	private String pic1;
	/** 配件圖檔路徑2。 */
	private String pic2;
	/** 配件圖檔路徑3。 */
	private String pic3;
	/** 配件圖檔路徑4。 */
	private String pic4;
	/** 配件圖檔路徑5。 */
	private String pic5;
	/** 配件圖檔路徑6。 */
	private String pic6;
	/** 配件圖檔路徑7。 */
	private String pic7;
	/** 配件圖檔路徑8。 */
	private String pic8;
	/** 更多商品介紹 */
	private String detailLink;
	
	private String featureFlag;

	public String getBrief() {
		return brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public String getPic1() {
		return pic1;
	}

	public void setPic1(String pic1) {
		this.pic1 = pic1;
	}

	public String getPic2() {
		return pic2;
	}

	public void setPic2(String pic2) {
		this.pic2 = pic2;
	}

	public String getPic3() {
		return pic3;
	}

	public void setPic3(String pic3) {
		this.pic3 = pic3;
	}

	public String getPic4() {
		return pic4;
	}

	public void setPic4(String pic4) {
		this.pic4 = pic4;
	}

	public String getPic5() {
		return pic5;
	}

	public void setPic5(String pic5) {
		this.pic5 = pic5;
	}

	public String getPic6() {
		return pic6;
	}

	public void setPic6(String pic6) {
		this.pic6 = pic6;
	}

	public String getPic7() {
		return pic7;
	}

	public void setPic7(String pic7) {
		this.pic7 = pic7;
	}

	public String getPic8() {
		return pic8;
	}

	public void setPic8(String pic8) {
		this.pic8 = pic8;
	}

	public String getDetailLink() {
		return detailLink;
	}

	public void setDetailLink(String detailLink) {
		this.detailLink = detailLink;
	}

	public String getFeatureFlag() {
		featureFlag = "Y";
		if(StringUtils.isBlank(this.pic1) && StringUtils.isBlank(this.pic2) && 
			StringUtils.isBlank(this.pic3) && StringUtils.isBlank(this.pic4) &&
			StringUtils.isBlank(this.pic5) && StringUtils.isBlank(this.pic6) &&
			StringUtils.isBlank(this.pic7) && StringUtils.isBlank(this.pic8)){
			featureFlag = "N";
		}		
		return featureFlag;
	}

	public void setFeatureFlag(String featureFlag) {
		this.featureFlag = featureFlag;
	}

}
