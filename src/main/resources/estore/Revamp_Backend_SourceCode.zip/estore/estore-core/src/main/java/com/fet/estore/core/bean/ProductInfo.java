package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ProductInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 對應前端畫面分類 */
    public static final String PRODUCT_TYPE_PHONE = "PHONE";
    public static final String PRODUCT_TYPE_ACCESSORY = "ACCESSORY";
    public static final String PRODUCT_TYPE_SIMCARD = "SIMCARD";

    /** 商品詳細資訊 */
    private ProductDetail productDetail;
    /** 商品說明資訊(包含特色,說明和規格) */
    private List<ProductDetailDesc> description;

    public ProductDetail getProductDetail() {
        return productDetail;
    }

    public void setProductDetail(ProductDetail productDetail) {
        this.productDetail = productDetail;
    }

    public List<ProductDetailDesc> getDescription() {
        return description;
    }

    public void setDescription(List<ProductDetailDesc> description) {
        this.description = description;
    }
}
