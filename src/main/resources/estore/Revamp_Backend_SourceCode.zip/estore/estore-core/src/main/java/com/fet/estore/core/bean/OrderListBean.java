package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OrderListBean implements Serializable {

	private static final long serialVersionUID = 7103703049182246977L;
	private String apply_method;
	//方案資訊
	private OrderPlan plan;
	//產品資訊
	private OrderProduct product;
	private String identity_validation;
	private String input_validation;
	//門號資訊
	private OrderPhoneNumber phone_number;
	//折扣資訊
	private List<OrderDiscount> discounts;
	//所有折扣資訊
	private ArrayList<ArrayList<OrderDiscount>> allDiscount;
	//好禮資訊
	private List<OrderGift> gift;
	//贈品
	private List<OrderGift> freeGift;
	//加購資訊
	private List<OrderExtraProduct> extra_product;
	//放購物車商品
	private List<OrderProduct> products;
	private OrderCoupon coupon;
	private OrderHappygo happygo;
	/**門號得標費 */
	private Long auctionPrice;
	/** 總金額 */
	private Long coPrice;

	public String getApply_method() {
		return apply_method;
	}
	public void setApply_method(String apply_method) {
		this.apply_method = apply_method;
	}
	public OrderPlan getPlan() {
		return plan;
	}
	public void setPlan(OrderPlan plan) {
		this.plan = plan;
	}
	public OrderProduct getProduct() {
		return product;
	}
	public void setProduct(OrderProduct product) {
		this.product = product;
	}
	public String getIdentity_validation() {
		return identity_validation;
	}
	public void setIdentity_validation(String identity_validation) {
		this.identity_validation = identity_validation;
	}
	public String getInput_validation() {
		return input_validation;
	}
	public void setInput_validation(String input_validation) {
		this.input_validation = input_validation;
	}
	public OrderPhoneNumber getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(OrderPhoneNumber phone_number) {
		this.phone_number = phone_number;
	}
	public List<OrderGift> getGift() {
		return gift;
	}
	public void setGift(List<OrderGift> gift) {
		this.gift = gift;
	}
	public List<OrderExtraProduct> getExtra_product() {
		return extra_product;
	}
	public void setExtra_product(List<OrderExtraProduct> extra_product) {
		this.extra_product = extra_product;
	}
	public List<OrderProduct> getProducts() {
		return products;
	}
	public void setProducts(List<OrderProduct> products) {
		this.products = products;
	}
	public List<OrderDiscount> getDiscounts() {
		return discounts;
	}
	public void setDiscounts(List<OrderDiscount> discounts) {
		this.discounts = discounts;
	}
	public ArrayList<ArrayList<OrderDiscount>> getAllDiscount() {
		return allDiscount;
	}
	public void setAllDiscount(ArrayList<ArrayList<OrderDiscount>> allDiscount) {
		this.allDiscount = allDiscount;
	}
	public OrderCoupon getCoupon() {
		return coupon;
	}
	public void setCoupon(OrderCoupon coupon) {
		this.coupon = coupon;
	}
	public OrderHappygo getHappygo() {
		return happygo;
	}
	public void setHappygo(OrderHappygo happygo) {
		this.happygo = happygo;
	}
	public Long getCoPrice() {
		return coPrice;
	}
	public void setCoPrice(Long coPrice) {
		this.coPrice = coPrice;
	}
	public List<OrderGift> getFreeGift() {
		return freeGift;
	}
	public void setFreeGift(List<OrderGift> freeGift) {
		this.freeGift = freeGift;
	}
	public Long getAuctionPrice() {
		return auctionPrice;
	}
	public void setAuctionPrice(Long auctionPrice) {
		this.auctionPrice = auctionPrice;
	}
}
