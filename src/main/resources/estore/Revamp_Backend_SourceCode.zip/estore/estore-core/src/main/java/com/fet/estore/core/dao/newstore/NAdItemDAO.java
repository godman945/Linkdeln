package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.bean.vo.frontend.AdItemVO;
import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AdItem;

import java.util.List;

public interface NAdItemDAO extends BaseDAO<AdItem, Integer> {

	public List<AdItemVO> findAvailableAdItemByAdTabId(Integer adTabId, Integer maxItemSize, Boolean sortRandomly)throws Exception;

}
