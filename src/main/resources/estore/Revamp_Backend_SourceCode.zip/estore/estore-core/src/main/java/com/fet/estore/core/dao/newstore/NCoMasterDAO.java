package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CoDetail;
import com.fet.estore.core.model.CoMaster;
import com.fet.estore.core.bean.vo.CoMasterHandsetGroupVO;

/**
 * 暫存訂單DAO
 * @author Max Chen
 *
 */
public interface NCoMasterDAO extends BaseDAO<CoMaster, String>  {

	/**
	 * 取得未取消門號之訂單數量
	 * @param mdn
	 * @return
	 */
	public long getMsisdnCount(String mdn, int days);
	
	/**
	 * 依門號取得競標門號訂單
	 * @param mdn
	 * @return
	 */
	public boolean hasAuctionMsisdnCoMaster(String mdn);

	/**
	 * 累計成單量(累計成立訂單 - 累計取消訂單，以每日上午更新eStore only ATR量時起算)
	 * @param fetNo
	 * @param atrModifyTime
	 * @return
	 */
	public Long countCoMasterWithATRRule(String fetNo, String starDate, String endDate);

	public List<CoDetail> findCodetailsByCono(String cono);
}
