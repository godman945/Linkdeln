package com.fet.estore.core.bean.vo.omni;

public class MdmVO {
	
	
	/*
	  	<mdmInfo>
        <mdmId>a</mdmId> -> 5. Subsriber ContractComponent ID
        <mdmAccountId>aa</mdmAccountId> -> 3. Account Contract ID
        <mdmAccountComponentId>aa</mdmAccountComponentId> -> 4. Accont ContractComponent ID
        <mdmCustomerId>aa</mdmCustomerId> -> 1. Customer Contract ID
        <mdmCustomerComponentId>aa</mdmCustomerComponentId> -> 2. Customer ContractComponent ID
		</mdmInfo>
	 */
	
	
	private String subscriberContractComponentId;
	private String accountContractId;
	private String accountContractComponentId;
	private String customerContractId;
	private String customerContractConpomentId;
	private String partyId;
	
	public String getSubscriberContractComponentId() {
		return subscriberContractComponentId;
	}
	public void setSubscriberContractComponentId(String subscriberContractComponentId) {
		this.subscriberContractComponentId = subscriberContractComponentId;
	}
	public String getAccountContractId() {
		return accountContractId;
	}
	public void setAccountContractId(String accountContractId) {
		this.accountContractId = accountContractId;
	}
	public String getAccountContractComponentId() {
		return accountContractComponentId;
	}
	public void setAccountContractComponentId(String accountContractComponentId) {
		this.accountContractComponentId = accountContractComponentId;
	}
	public String getCustomerContractId() {
		return customerContractId;
	}
	public void setCustomerContractId(String customerContractId) {
		this.customerContractId = customerContractId;
	}
	public String getCustomerContractConpomentId() {
		return customerContractConpomentId;
	}
	public void setCustomerContractConpomentId(String customerContractConpomentId) {
		this.customerContractConpomentId = customerContractConpomentId;
	}
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("partyId=%s", partyId));
		sb.append(String.format(","));
		sb.append(String.format("subscriberContractComponentId=%s", subscriberContractComponentId));
		sb.append(String.format(","));
		sb.append(String.format("accountContractId=%s", accountContractId));
		sb.append(String.format(","));
		sb.append(String.format("accountContractComponentId=%s", accountContractComponentId));
		sb.append(String.format(","));
		sb.append(String.format("customerContractId=%s", customerContractId));
		sb.append(String.format(","));
		sb.append(String.format("customerContractConpomentId=%s", customerContractConpomentId));
		

		return sb.toString();
		
	}
}



