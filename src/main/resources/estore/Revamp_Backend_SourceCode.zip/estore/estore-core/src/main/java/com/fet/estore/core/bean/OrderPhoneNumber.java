package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class OrderPhoneNumber implements Serializable {

	private static final long serialVersionUID = -646386666846589115L;
	private String label;
	//手機號碼
	private String value;
	private String description;
	private Integer price;
	private List<String> tag;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public List<String> getTag() {
		return tag;
	}
	public void setTag(List<String> tag) {
		this.tag = tag;
	}
	
}
