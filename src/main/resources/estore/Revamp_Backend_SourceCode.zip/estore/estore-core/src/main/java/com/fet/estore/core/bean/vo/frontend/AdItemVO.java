package com.fet.estore.core.bean.vo.frontend;

import java.util.Date;

public class AdItemVO {

    private Integer id;
	private String title;
	private String imagePath;
	private Boolean onShelf;
	private Date startDate;
	private Date endDate;
	private String imageUrl;
	private String imageLinkMethod;
	private String content;
	private String content1;
	private String buttonUrl;
	private String buttonLinkMethod;
	private String buttonName;
	private String contentUrl;
	private String contentLinkMethod;
	private Boolean highlight;
	private Integer displayOrder;
	private String imagePath1;
	private String textOrImage;
	private String mobileImagePath;
	private String mobileImagePath1;
	private String mobileImageUrl;
	private String imageAlt;
	private String mobileImageAlt;
	private String mobileContentUrl;
	private String description1;
    private String description2;
    private String description3;
    private String buttonStyle;
    private String buttonStyle2;
    private String buttonName2;
    private String buttonUrl2;
    private String subTitle;
	 /** NDS獨家資費版型
     * 1L : 1大阪
     * 2S : 2小版
     * 1L2S : 1大2小
     * */
	private String format;
    private String color;
    private String clobContent;
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	 
	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	
    public Boolean getOnShelf() {
        return onShelf;
    }

    public void setOnShelf(Boolean onShelf) {
        this.onShelf = onShelf;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageLinkMethod() {
        return imageLinkMethod;
    }

    public void setImageLinkMethod(String imageLinkMethod) {
        this.imageLinkMethod = imageLinkMethod;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getButtonUrl() {
        return buttonUrl;
    }

    public void setButtonUrl(String buttonUrl) {
        this.buttonUrl = buttonUrl;
    }

    public String getButtonLinkMethod() {
        return buttonLinkMethod;
    }

    public void setButtonLinkMethod(String buttonLinkMethod) {
        this.buttonLinkMethod = buttonLinkMethod;
    }

    public String getButtonName() {
        return buttonName;
    }

    public void setButtonName(String buttonName) {
        this.buttonName = buttonName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

	public Integer getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}

	public String getContentUrl() {
		return contentUrl;
	}

	public void setContentUrl(String contentUrl) {
		this.contentUrl = contentUrl;
	}

	public Boolean getHighlight() {
		return highlight;
	}

	public void setHighlight(Boolean highlight) {
		this.highlight = highlight;
	}

	public String getContentLinkMethod() {
		return contentLinkMethod;
	}

	public void setContentLinkMethod(String contentLinkMethod) {
		this.contentLinkMethod = contentLinkMethod;
	}
	
	public String getImagePath1() {
		return imagePath1;
	}

	public void setImagePath1(String imagePath1) {
		this.imagePath1 = imagePath1;
	}

	public String getTextOrImage() {
		return textOrImage;
	}

	public void setTextOrImage(String textOrImage) {
		this.textOrImage = textOrImage;
	}

	public String getMobileImagePath() {
	    return mobileImagePath;
	}

	public void setMobileImagePath(String mobileImagePath) {
	    this.mobileImagePath = mobileImagePath;
	}

	public String getMobileImagePath1() {
		return mobileImagePath1;
	}

	public void setMobileImagePath1(String mobileImagePath1) {
		this.mobileImagePath1 = mobileImagePath1;
	}

	public String getMobileImageUrl() {
	    return mobileImageUrl;
	}

	public void setMobileImageUrl(String mobileImageUrl) {
	    this.mobileImageUrl = mobileImageUrl;
	}

	public String getImageAlt() {
		return imageAlt;
	}

	public String getMobileImageAlt() {
		return mobileImageAlt;
	}

	public void setImageAlt(String imageAlt) {
		this.imageAlt = imageAlt;
	}

	public void setMobileImageAlt(String mobileImageAlt) {
		this.mobileImageAlt = mobileImageAlt;
	}

	public String getMobileContentUrl() {
		return mobileContentUrl;
	}

	public void setMobileContentUrl(String mobileContentUrl) {
		this.mobileContentUrl = mobileContentUrl;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

	public String getClobContent() {
		return clobContent;
	}

	public void setClobContent(String clobContent) {
		this.clobContent = clobContent;
	}

	public String getContent1() {
		return content1;
	}

	public void setContent1(String content1) {
		this.content1 = content1;
	}

	public String getDescription1() {
		return description1;
	}

	public void setDescription1(String description1) {
		this.description1 = description1;
	}

	public String getDescription2() {
		return description2;
	}

	public void setDescription2(String description2) {
		this.description2 = description2;
	}

	public String getDescription3() {
		return description3;
	}

	public void setDescription3(String description3) {
		this.description3 = description3;
	}

	public String getButtonStyle() {
		return buttonStyle;
	}

	public void setButtonStyle(String buttonStyle) {
		this.buttonStyle = buttonStyle;
	}

	public String getButtonStyle2() {
		return buttonStyle2;
	}

	public void setButtonStyle2(String buttonStyle2) {
		this.buttonStyle2 = buttonStyle2;
	}

	public String getButtonName2() {
		return buttonName2;
	}

	public void setButtonName2(String buttonName2) {
		this.buttonName2 = buttonName2;
	}

	public String getButtonUrl2() {
		return buttonUrl2;
	}

	public void setButtonUrl2(String buttonUrl2) {
		this.buttonUrl2 = buttonUrl2;
	}

	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}
	
}
