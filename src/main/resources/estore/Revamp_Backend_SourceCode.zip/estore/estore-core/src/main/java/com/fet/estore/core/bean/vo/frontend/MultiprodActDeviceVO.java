package com.fet.estore.core.bean.vo.frontend;

import java.util.List;

public class MultiprodActDeviceVO {
    
    private Long id;
    
    private String deviceType;
    
    private String groupNumber;
    
    private long multiprodActItemId;
    
    private String handsetGroupId;
    
    private String accessoryGroupId;
    
    private List<HandsetGroupVO> handsetGroups;
    
    private List<AccessoryGroupVO> accessoryGroups;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public List<HandsetGroupVO> getHandsetGroups() {
        return handsetGroups;
    }

    public void setHandsetGroups(List<HandsetGroupVO> handsetGroups) {
        this.handsetGroups = handsetGroups;
    }

    public List<AccessoryGroupVO> getAccessoryGroups() {
        return accessoryGroups;
    }

    public void setAccessoryGroups(List<AccessoryGroupVO> accessoryGroups) {
        this.accessoryGroups = accessoryGroups;
    }

    public long getMultiprodActItemId() {
        return multiprodActItemId;
    }

    public void setMultiprodActItemId(long multiprodActItemId) {
        this.multiprodActItemId = multiprodActItemId;
    }

    public String getHandsetGroupId() {
        return handsetGroupId;
    }

    public void setHandsetGroupId(String handsetGroupId) {
        this.handsetGroupId = handsetGroupId;
    }

    public String getAccessoryGroupId() {
        return accessoryGroupId;
    }

    public void setAccessoryGroupId(String accessoryGroupId) {
        this.accessoryGroupId = accessoryGroupId;
    }
    
}
