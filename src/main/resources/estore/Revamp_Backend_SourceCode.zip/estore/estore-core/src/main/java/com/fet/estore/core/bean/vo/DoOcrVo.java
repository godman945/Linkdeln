package com.fet.estore.core.bean.vo;

public class DoOcrVo {
	private String applicantSecondId;
	private String ocrErrCode;
	private boolean result;
	private String errMsg;
	private String errCode;
	private String redirectUrl;
	private String allData;
	private String secondaryCredentialType;//二證判斷是駕照還是健保卡
	public String getOcrErrCode() {
		return ocrErrCode;
	}
	public void setOcrErrCode(String ocrErrCode) {
		this.ocrErrCode = ocrErrCode;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getRedirectUrl() {
		return redirectUrl;
	}
	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}
	public String getAllData() {
		return allData;
	}
	public void setAllData(String allData) {
		this.allData = allData;
	}
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getApplicantSecondId() {
		return applicantSecondId;
	}
	public void setApplicantSecondId(String applicantSecondId) {
		this.applicantSecondId = applicantSecondId;
	}
	public String getSecondaryCredentialType() {
		return secondaryCredentialType;
	}
	public void setSecondaryCredentialType(String secondaryCredentialType) {
		this.secondaryCredentialType = secondaryCredentialType;
	}
}
