package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class SearchData implements Serializable {

	private static final long serialVersionUID = -2656863222143150423L;
	private String title;
	private List<SearchDataList> list;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<SearchDataList> getList() {
		return list;
	}
	public void setList(List<SearchDataList> list) {
		this.list = list;
	}
	
}
