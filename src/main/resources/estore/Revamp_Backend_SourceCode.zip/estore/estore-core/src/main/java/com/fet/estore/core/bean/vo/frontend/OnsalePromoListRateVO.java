package com.fet.estore.core.bean.vo.frontend;

/**
 * 促案費率說明VO
 * @author Max Chen
 *
 */
public class OnsalePromoListRateVO {
	/** 語音資費CMSCode */
	private String vrCmsCode;
	/** 數據資費CMSCode */
	private String drCmsCode;
	
	
	public String getVrCmsCode() {
		return vrCmsCode;
	}
	public void setVrCmsCode(String vrCmsCode) {
		this.vrCmsCode = vrCmsCode;
	}
	public String getDrCmsCode() {
		return drCmsCode;
	}
	public void setDrCmsCode(String drCmsCode) {
		this.drCmsCode = drCmsCode;
	}
}
