package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.bean.vo.frontend.CurProductPromotionVO;

import java.util.List;

public interface ICurProductPromotionVODao extends BaseDAO<CurProductPromotionVO, String>{

    List<CurProductPromotionVO> getProduct(String categoryGroup);
}
