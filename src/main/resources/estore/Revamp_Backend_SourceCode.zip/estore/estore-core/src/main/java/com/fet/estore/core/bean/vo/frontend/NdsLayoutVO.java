package com.fet.estore.core.bean.vo.frontend;

public class NdsLayoutVO {
	
	private String id;
	private String groupId;
	private String displayName;
	private Long displayOrder;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getGroupId() {
		return groupId;
	}
	public String getDisplayName() {
		return displayName;
	}
	public Long getDisplayOrder() {
		return displayOrder;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public void setDisplayOrder(Long displayOrder) {
		this.displayOrder = displayOrder;
	}
	
}
