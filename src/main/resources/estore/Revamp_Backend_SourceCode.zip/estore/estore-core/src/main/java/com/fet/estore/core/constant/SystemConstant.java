package com.fet.estore.core.constant;

public abstract class SystemConstant implements java.io.Serializable{

	public static final String SESSION_EMP = "backendEmployee";
	public static final String SESSION_USER = "user";
	public static final String SESSION_COMASTER = "frontendCoMaster";
	
	/**
	 * E-Service UID(SSO)
	 */
	public final static String SESSION_ESERVICE_UID = "eserviceUid";
	public final static String SESSION_ESERVICE_MDN = "eserviceMdn";
	public final static String SESSION_ESERVICE_ROCID = "eserviceRocid";
	public final static String SESSION_ESERVICE_SKIPCAPTCHA = "skipCaptcha";
	
	public final static String SESSION_EVENT_ENTRANCE_QUERYSTR = "eventEntranceQs";
	
	/**
	 * 已完成訂單的User資料
	 */
	public static final String SESSION_FINISH_USER = "fuser";

	public static final String SESSION_CSP_USER = "CSPUser";

	public static final String SESSION_CSP_USER_PROFILE = "CSPUserProfile";

	public static final String SESSION_TWID_FAIL_COUNT = "twidFailCount";

    public static final String SESSION_TWID_OREDER_ID = "twidOrderId";

    /** 合作網站來源 */
    public static final String SESSION_COBRANDER_SOURCE = "cobranderSource";
    /** 合作網站活動 */
    public static final String SESSION_COBRANDER_ACTIVITY = "cobranderActivity";

	// 來源瀏覽器是否為行動裝置
    public final static String REQUESTATTR_ISMOBILE = "isMobile";

	//initial
    public static final String FAIL_REFUND_STATUS_R10001 = "R10001";

    //refund fail
    public static final String FAIL_REFUND_STATUS_R10002 ="R10002";

    //refund success
    public static final String FAIL_REFUND_STATUS_R10003 = "R10003";


	// subSystem: storeService method:PrintSAServlet
    public static final String FAIL_TYPE_C10001 = "C10001";

    //deductFromWallet
    public static final String FAIL_TYPE_DEDUCTFROMWALLET = "C10002";

    //deductFromCreditCard
    public static final String FAIL_TYPE_DEDUCTFROMCREDITCARD = "C10003";

    ////deductFromWallet fail
    public static final String FAIL_TYPE_DEDUCTFROMWALLET_FAIL = "C10004";

    //deductFromCreditCard
    public static final String FAIL_TYPE_DEDUCTFROMCREDITCARD_FAIL = "C10005";

    //get txid
    public static final String FAIL_TYPE_GET_TXID = "C10006";

  //get success
    public static final String FAIL_TYPE_SUCCESS = "C10007";

    //deductInventory
    public static final String FAIL_TYPE_DEDUCTINVENTORY = "C10010";
    //	**print SA form that access estoreService
	public static final String FAIL_TYPE_C10011 = "C10011";

	/** subSystem: sigService method:getSimDetail validate sim card no. */
	public static final String FAIL_TYPE_C10012 = "C10012";

	/** subSystem: iaService method:confirmOrder confirm order */
	public static final String FAIL_TYPE_C10013 = "C10013";

	/** subSystem: loyaltyService method:confirmOrder confirm order */
	public static final String FAIL_TYPE_C10014 = "C10014";

	/** subSystem:iaService method:cancelOrder cancel order */
	public static final String FAIL_TYPE_C10015 = "C10015";

	/** subSystem:mobileWalletService method:refund * refund */
	public static final String FAIL_TYPE_C10016 = "C10016";

	/** subSystem:loyaltyService method:cancelOrder  cancel order */
	public static final String FAIL_TYPE_C10017 = "C10017";
	/** unknown cause */
	public static final String IS_CANCEL_ORDER_N = "N";
	public static final String FAIL_TYPE_UNKNOWN = "C90001";

	/** NP Check Return code*/
	public static final String FAIL_TYPE_NP_VALIDATION_FAIL_UNKNOWN = "E00098";

	public static final String FAIL_TYPE_NP_VALIDATION_FAIL = "E00099";

	public static final String FAIL_TYPE_NP_VALIDATION_SUCCESS = "E00000";

	/** NP Check Return Message*/
	public static final String FAIL_TYPE_NP_VALIDATION_FAIL_MSG_0 = "請輸入欲攜碼之門號";

	public static final String FAIL_TYPE_NP_VALIDATION_FAIL_MSG_1 = "您所輸入的門號已經申請預購, 有相關問題請洽遠傳客服, 謝謝!";

	public static final String FAIL_TYPE_NP_VALIDATION_FAIL_MSG_2 = "請確認您所輸入的門號是否為非遠傳及原和信用戶, 謝謝!";

	public static final String FAIL_TYPE_NP_VALIDATION_FAIL_MSG_3 = "您所輸入的門號已經申請攜碼服務, 有相關問題請洽遠傳客服, 謝謝!";

	public static final String FAIL_TYPE_NP_VALIDATION_FAIL_MSG_4 = "您所輸入的門號已經申請攜碼服務, 有相關問題請洽遠傳客服, 謝謝!";

	public static final String FAIL_TYPE_NP_VALIDATION_FAIL_UNKNOWN_MSG = "未預期的錯誤:";

	public static final String FAIL_TYPE_NP_VALIDATION_SUCCESS_MSG = "SUCCESS";

	/** Preorder 驗證參數*/

	public static final String CHECK_RPEORDER_QUERY_TYPE_NP = "NP";

	public static final String CHECK_RPEORDER_QUERY_TYPE_NP1 = "NP1";

	public static final String CHECK_RPEORDER_QUERY_TYPE_LOY = "LOY";

	public static final String CHECK_RPEORDER_QUERY_TYPE_GA = "GA";

	/** cancel order is successful */
	public static final String IS_CANCEL_ORDER_Y = "Y";
	/** cancel order fail */

	public static final int DEFAULT_PAGESIZE=10;

	public static final String ONSALE = "onsale";

	public static final String VSACODE = "vasCode";
	
	/** 20200720 Dennis.Chen - API Return Message */
	public static final String API_SUCCESS = "SUCCESS";

	public static final String API_FAIL = "FAIL";
	
	/**
	 * 未上架
	 */
	public static final Boolean ONSALE_NONE = null;

	/**
	 * 已上架
	 */
	public static final Boolean ONSALE_YES = Boolean.TRUE;

	/**
	 * 已下架
	 */
	public static final Boolean ONSALE_NO = Boolean.FALSE;

	/** 是假3G*/
	public static final Boolean FAKE3G_YES=Boolean.TRUE;

	/** 不是假3G*/
	public static final Boolean FAKE3G_NO=Boolean.FALSE;

	/**
	 * 秘密賣場的申辦類型(co_type)
	 * added by Roil.Li 20200611
	 */
	public static final String ACT_ENTRY_ORDER_TYPE = "ACT_ENTRY_ORDER_TYPE";

	/**
	 * OTP回傳訊息
	 * added by Roil.Li 20200622
	 */
	public static final String OTP_MESSAGE = "OTP_MESSAGE";

	/**
	 * 通過OTP驗證FLAG
	 * added by Roil.Li 20200622
	 */
	public static final String PASS_OTP = "PASS_OTP";
	
	/**
	 * 線上申辦Title Worlding
	 * added by Dennis.Chen 20200716
	 */
	public static final String ONLINE_DEALS_TITLE = "線上申辦";
	
	public static final String AGENTCODE = "2801";
	
	public static final String DEALERCODE = "2801";
	
	public static final String IVRCODE = "2801";
	
	/**
	 * 找商品-手機列表 (活動廣告出現位置)
	 * added by Alex.Zhu 20200724
	 */
	public static final Integer[] AD_POSITION_PARAM = new Integer[] {3,5};
	
	/**
	 * 找商品-手機列表 -行銷標籤
	 * added by Alex.Zhu 20200724
	 */
	public static final String MARKETING_LABEL = "1";
	
	/**
	 * 找商品-手機列表 -商品屬性標籤
	 * added by Alex.Zhu 20200724
	 */
	public static final String ATTRIBUTE_LABEL = "2";
	
	/**
	 * 找商品-手機列表 -商品屬性標籤
	 * added by Alex.Zhu 20200724
	 */
	public static final int ATTRIBUTE_SHOW_FIND_PHONE_SIZE = 60;

	/**
	 * 找商品-您曾瀏覽過最多顯示12張
	 * added by Alex.Zhu 20200724
	 */
	public static final Integer BROWSED_MAX_SIZE = 12;
	
	/**
	 * 找商品頁 商品數清單最大商品筆數
	 * added by Phil.Lin 20200731
	 */
	public static final Integer FIND_PRODUCT_MAX_SIZE = 60;
	
	/**
	 * 找商品 categoryGroup(配件類)
	 * added by Alex.Zhu 20200731
	 */
	public static final String NEWSTORE_ACC = "NEWSTORE_ACC";
	
	/**
	 * 首頁 我想尋找區塊標題文字
	 * added by Alex.Zhu 20200731
	 */
	public static final String SEARCH_LINK_TITLE = "我想尋找";

	public static final String GREETING_URL_FMT = "<a href='%s'>%s</a>";

	public static final String GREETING_DEFAULT_CTA = "GREETING_DEFAULT_CTA";

	public static final String GREETING_DEFAULT_TEXT = "GREETING_DEFAULT_TEXT";

	public static final String GREETING_DEFAULT_URL = "GREETING_DEFAULT_URL";
	
	/**
	 * 首頁 您曾瀏覽過區塊標題文字
	 * added by Alex.Zhu 20200731
	 */
	public static final String BROWSE_HISTORY_TITLE = "您曾瀏覽過";

	/**
	 * 首頁 本周最熱門區塊標題文字
	 * added by Klyve.Zhu 20200805
	 */
	public static final String PROMO_PRODUCT_TITLE = "本周最熱門";

	/**
	 * 首頁 本周最熱門區塊導覽標題文字
	 * added by Klyve.Zhu 20200805
	 */
	public static final String PROMO_PRODUCT_NAVIGATION_TITLE = "看更多";

	/**
	 * 首頁 本周最熱門區塊Tab1標題文字
	 * added by Klyve.Zhu 20200805
	 */
	public static final String PROMO_PRODUCT_TAB1 = "iPhone手機";

	/**
	 * 首頁 本周最熱門區塊Tab1標題文字
	 * added by Klyve.Zhu 20200805
	 */
	public static final String PROMO_PRODUCT_TAB2 = "Android手機";

	/**
	 * 首頁 本周最熱門區塊Tab1標題文字
	 * added by Klyve.Zhu 20200805
	 */
	public static final String PROMO_PRODUCT_TAB3 = "穿戴裝置";

	/**
	 * 首頁 本周最熱門區塊Tab1標題文字
	 * added by Klyve.Zhu 20200805
	 */
	public static final String PROMO_PRODUCT_TAB4 = "拆封機";

	/**
	 * 首頁 本周最熱門區塊Tab1標題文字
	 * added by Klyve.Zhu 20200805
	 */
	public static final String PROMO_PRODUCT_TAB5 = "配件";

	/**
	 * 首頁 我想尋找區塊分類最大筆數
	 * added by Alex.Zhu 20200731
	 */
	public static final Integer SEARCH_LINK_MAX_TAB_SIZE = 4;
	
	/**
	 * 首頁 我想尋找區塊分類細項最大筆數
	 * added by Alex.Zhu 20200731
	 */
	public static final Integer SEARCH_LINK_MAX_ITEM_SIZE = 7;

	/**
	 * 定錨資費設定參數
	 * added by Roil.Li 20200804
	 */
	public static final String PRODUCT_ANCHORAGE_FEE = "PRODUCT_ANCHORAGE_FEE";

	/**
	 * 新申辦 流程ID 門號區塊
	 */
	public static final String SELECT_MSISDN_ID = "new-number";

	/**
	 * 新申辦 流程簡述 門號區塊
	 */
	public static final String SELECT_MSISDN_SLUG = "門號";

	/**
	 * 新申辦 流程標題 門號區塊
	 */
	public static final String SELECT_MSISDN_TITLE = "選擇門號";

	/**
	 * 新申辦 型別 門號區塊
	 */
	public static final String SELECT_MSISDN_TYPE = "radio-carousel";


	/**
	 * 新申辦 流程名稱 門號區塊
	 */
	public static final String SELECT_MSISDN_NAME = "phone_number";


	/**
	 * 新申辦 流程描述 門號區塊
	 */
	public static final String SELECT_MSISDN_DESCRIPTION = "選一個好門號給你好運氣";


	/**
	 * 新申辦 搜尋標籤 門號區塊
	 */
	public static final String SELECT_MSISDN_SEARCH_LABEL = "主題號碼";

	/**
	 * 新申辦 標籤清單 門號區塊
	 */
	public static final String[] SELECT_MSISDN_TAGS = new String[]{
			"免費門號", "黃金門號", "一路發168", "66大順", "幸福99", "Lucky77", "真愛520", "發發88", "123門號"
	};

    public static final Integer GOLDEN_MINSELECTIONFEE = 3000;

    public static final String GOLDEN_NUMBER_TAG = "黃金門號";

	public static final String FREE_NUMBER_TAG = "免費門號";

	public static final String THEME_NUMBER_TAG = "主題門號";
	
	/**
	 * 門號分類 - 頁面需求固定顯示數量
	 */;
	public static final Integer MSISDN_GROUP_SIZE = 5;

	/**
	 * 新申辦 流程標題 門號區塊
	 */;

	public static final int SELECT_MSISDN_PAGE_INIT_SIZE = 90;
	
	/**
	 * 商品明細頁-預約取貨驗證成功狀態
	 * added by Alex.Zhu 20200731
	 */
	public static final String RETURN_CODE_SUCCESS = "000";
	
	/**
	 * 商品明細頁-預約取貨驗證失敗狀態
	 * added by Alex.Zhu 20200731
	 */
	public static final String RETURN_CODE_FAIL = "001";
	
	/**
	 * 商品明細頁-贈品NUM 為 1
	 * added by Alex.Zhu 20200818
	 */
	public static final String GIFT_GROUP_NUMBER = "1";
	
	/**
	 * 商品明細頁-加購商品NUM 為 2
	 * added by Alex.Zhu 20200818
	 */
	public static final String EXTRA_BUY_GROUP_NUMBER = "2";
	
	/**
	 * 商品明細頁-一般賣場預設活動名稱
	 * added by Alex.Zhu 20200818
	 */
	public static final String NORMAL_ACT_ID = "NORMAL_ACT_ID";
	
	/**
	 * 商品明細頁-續約預設活動名稱
	 * added by Alex.Zhu 20200818
	 */
	public static final String NORMAL_ACT_ID_LY = "NORMAL_ACT_ID_LY";

	/**
	 * html target _self
	 * added by Roil.Li 2020-08-18
	 */
	public static final String HTML_TARGET_SELF = "_self";

	/**
	 * html target _blank
	 * added by Roil.Li 2020-08-18
	 */
	public static final String HTML_TARGET_BLANK = "_blank";

	/**
	 * @description 促案卡牌明細表格Title
	 * @author Dennis.Chen
	 * @date 2020-08-20
	 */
	public static final String TITLE_DATA_USAGE_AMOUNT = "上網傳輸量";

	/**
	 * @description PROPERTIES中記錄需要提醒九個月只能依證一門限制
	 * @author Dennis.Chen
	 * @date 2020-10-30
	 */
	public static final String ONCE_CONTRACT_9_MONTH = "ONCE_CONTRACT_9M";

	/**
	 * @description 促案貼標
	 * @author Dennis.Chen
	 * @date 2020-08-20
	 */
	public static final String TAG_FIVE_GEN = "5G";
	public static final String TAG_FOUR_GEN = "4.5G";
	public static final String TAG_NO_LIMIT = "吃到飽";
	public static final String TAG_RATEPLAN_UPPER_ONE_THUNSAND = "月付$1,000以上";
	public static final String TAG_RATEPLAN_MID = "月付$600-$999";
	public static final String TAG_RATEPLAN_LOWEST = "月付$599以下";
	public static final String TAG_UPPER_TEN_THUNSAND = "專案價萬元以上";
	public static final String TAG_LOWER_TEN_THUNSAND = "專案價萬元以下";
	public static final String TAG_ZERO = "專案價0元";
	public static final String TAG_RECOMMEND = "推薦資費";
	public static final String PROMO_MONTH_UNIT = "月租";
	
    /** 升級資費類型 - 一般資費 */
    public static final String LOYALTY_UPGRADE_TYPE_NORMAL = "NORMAL";
    /** 升級資費類型 - 價差資費 */
    public static final String LOYALTY_UPGRADE_TYPE_SPREAD = "SPREAD";
    /** 升級資費類型 - 指定資費 */
    public static final String LOYALTY_UPGRADE_TYPE_ASSIGN = "ASSIGN";
    
    public final static String IDENTITY_FRONT = "identity_image_1";
    public final static String IDENTITY_BACK = "identity_image_2";
    public final static String SECONDARY_FRONT = "secondary_card_1";
    public final static String SECONDARY_BACK = "secondary_card_2";
    public final static String STAFF_CREDENTIAL_ONE = "staff_card_1";
    public final static String STAFF_CREDENTIAL_TWO = "staff_card_2";
    public final static String STAFF_CREDENTIAL_THREE = "staff_card_3";
    public final static String STAFF_CREDENTIAL_FOUR = "staff_card_4";
    public final static String STAFF_CREDENTIAL_FIVE = "staff_card_5";
    public final static String STAFF_CREDENTIAL_SIX = "staff_card_6";
    public final static String STAFF_CREDENTIAL_SEVEN = "staff_card_7";
    public final static String STAFF_CREDENTIAL_EIGHT = "staff_card_8";
    public final static String STAFF_CREDENTIAL_NINE = "staff_card_9";
    public final static String STAFF_CREDENTIAL_TEN = "staff_card_10";
    public final static String STAFF_CREDENTIAL_ELEVEN = "staff_card_11";
    public final static String STAFF_CREDENTIAL_TWELVE = "staff_card_12";
    
    /** 續約大門驗證失敗對話框訊息設定，title:標題、content:對話框內文 */
    public final static String LY_LOGIN_CHECK_FAIL_MSG = "LY_LOGIN_CHECK_FAIL_MSG";
    /** 續約大門驗證失敗對話框按鈕及按鈕超連結，title:按鈕文字、content:按鈕超連結 */
    public final static String LY_LOGIN_CHECK_FAIL_BTN = "LY_LOGIN_CHECK_FAIL_BTN";

	/**
	 * @description 結帳取貨類型
	 * @author Dennis.Chen
	 * @date 2020-08-20
	 */
	/** 超商取貨 */
	public static final String DELIVERY_TYPE_CS = "1";
	/** 宅配取貨 */
	public static final String DELIVERY_TYPE_HOME = "2";
	/** 門市取貨 */
	public static final String DELIVERY_TYPE_CNC_STORE = "3";
	/** 門市取貨及付款 */
	public static final String DELIVERY_TYPE_STORE = "4";

	public static final String ESTORE_CHANNEL = "ESTORE";

	public static final String MOBILE_CHANNEL = "MOBILE";

	/**
	 * @description 繳款方式
	 * @author Dennis.Chen
	 * @date 2020-09-22
	 */
	/** 貨到付款 */
	public static final String PAY_TYPE_PAY_ON_ARRIVE = "1";
	/** 信用卡一次付清 */
	public static final String PAY_TYPE_CREDIT_ONE_TIME = "2";
	/** 信用卡分期付款 */
	public static final String PAY_TYPE_CREDIT_INSTALLMENT = "3";

	/**
	 * @description 發票資訊
	 * @author Dennis.Chen
	 * @date 2020-08-20
	 */
	/** 遠傳會員載具 */
	public static final String INVOICE_TYPE_CARRIER = "1";
	/** 電子發票-自然人憑證 CITIZEN_DIGITAL_CERTIFICATE*/
	public static final String INVOICE_TYPE_CGC = "2";
	/** 電子發票-手機條碼 */
	public static final String INVOICE_TYPE_PHONE_BAR_CODE = "3";
	/** 電子發票-捐贈*/
	public static final String INVOICE_TYPE_DONATE = "4";
	/** 紙本發票-三聯式*/
	public static final String INVOICE_TYPE_TRIPLE = "5";
	public static final String PROD_SORT_RECOMMEND   = "ndsRecommend";

	/**
	 * @description 3D驗證結果
	 * @author Dennis.Chen
	 * @date 2020-09-18
	 */
	/** 繳款成功 */
	public static final String RTN_CODE_THREE_3D_SUCCESS = "0000000000";
	public static final String ERR_MSG_THREE_3D_SYSTEM_ERROR = "3D驗證失敗";
	/** 繳款金額超過信用卡額度 */
	public static final String RTN_CODE_THREE_3D_EXCEED_CREDIT_LIMIT = "2050560004";
	public static final String ERR_MSG_THREE_3D_EXCEED_CREDIT_LIMIT = "很抱歉，繳款金額已超過信用卡額度。";
	/** 不合法的信用卡資訊 */
	public static final String RTN_CODE_THREE_3D_INVALID_REQ_INFO = "2050379998";
	public static final String ERR_MSG_THREE_3D_INVALID_REQ_INFO = "信用卡資訊不正確。";
	/** 信用卡其餘錯誤資訊 */
	public static final String ERR_MSG_THREE_3D_EMPTY_RESPONSE = "3D驗證失敗，請確認您的付款資訊是否正確。";

	/**
	 * @description 加值(VA Service)
	 * @author Dennis.Chen
	 * @date 2020-09-18
	 */
	/** 我同意收到遠傳寄送的各項優惠活動資訊代碼*/
	public static final String EXTRA_VA_SERVICE_EDM = "a001";
	/** Fetnet 會員 */
	public static final String EXTRA_VA_SERVICE_FETNET_MEMBER = "a008";

	/**
	 * @description TRANS TYPE
	 * @author Dennis.Chen
	 * @date 2020-09-24
	 */
	public static final String TRNAS_TYPE_POS4G = "POS4G";
	public static final String TRNAS_TYPE_POS5G = "POS5G";
	public static final String TRNAS_TYPE_NPF4G = "NPF4G";
	public static final String TRNAS_TYPE_NPF5G = "NPF5G";
	public static final String TRNAS_TYPE_LOY4G = "LOY4G";
	public static final String TRNAS_TYPE_LOY5G = "LOY5G";
	public static final String TRNAS_TYPE_4GT5G = "4GT5G";

	/**
	 * 首頁上方廣告限制6筆
	 * added by Roil.Li
	 * 2020-09-29
	 */
	public static final int INDEX_TOP_BANNER_MAX_AMOUNT = 6;

	/**
	 * @description 促案定錨中心
	 * @author Dennis.Chen
	 * @date 2020-10-21
	 */
	/** 預設長度*/
	public static final int PROMO_ANCHOR_DEFAULT_LENGTH = 5;
	/** 左右要取促案的長度*/
	public static final int PROMO_ANCHOR_SIDE_LENGTH = 2;
	/** 最小資費起點*/
	public static final int PROMO_ANCHOR_MIN_START = 0;
	/** 最小資費起終點*/
	public static final int PROMO_ANCHOR_MIN_END = 4;
	/** 最大資費起點*/
	public static final int PROMO_ANCHOR_MAX_START = 4;
	/** 最大資費終點*/
	public static final int PROMO_ANCHOR_MAX_END = 0;
	/** 促案G數*/
	public static final String PROMO_TYPE_FOUR_G = "4G";
	public static final String PROMO_TYPE_FIVE_G = "5G";

	/**
	 * @description 用戶CRM資料
	 * @author Dennis.Chen
	 * @date 20201023
	 */
	/** 用戶原促案G數*/
	public static final String CRM_PROMO_FIVE_GEN = "5";
	public static final String CRM_PROMO_FOUR_GEN = "4";

	/** 證件上傳時機*/
	public static final String CREDENTIAL_TYPE = "CREDENTIAL_TYPE";
	
	public static final String IDNUM1 = "IDNUM1";//身分證正面
	public static final String IDNUM2 = "IDNUM2";//身分證反面
	public static final String IDNUM31 = "IDNUM31";//駕照
	public static final String IDNUM41 = "IDNUM41";//健保卡
	public static final String IDNUM1OCRSN = "IDNUM1OCRSN";//身分證正面OCR流水號
	public static final String OCRSN = "OCRSN";//身分證正面OCR流水號
	public static final String CREDENTIALFILE1NO = "CREDENTIALFILE1NO";
	public static final String CREDENTIALFILE2NO = "CREDENTIALFILE2NO";
	public static final String CREDENTIALFILE3NO = "CREDENTIALFILE3NO";
	public static final String CREDENTIALFILE4NO = "CREDENTIALFILE4NO";
	public static final String CREDENTIALFILE5NO = "CREDENTIALFILE5NO";
	public static final String CREDENTIALFILE6NO = "CREDENTIALFILE6NO";
	public static final String CREDENTIALFILE7NO = "CREDENTIALFILE7NO";
	public static final String CREDENTIALFILE8NO = "CREDENTIALFILE8NO";
	public static final String CREDENTIALFILE9NO = "CREDENTIALFILE9NO";
	public static final String CREDENTIALFILE10NO = "CREDENTIALFILE10NO";
	public static final String CREDENTIALFILE11NO = "CREDENTIALFILE11NO";
	public static final String CREDENTIALFILE12NO = "CREDENTIALFILE12NO";
	public static final String CREDENTIALFILE13NO = "CREDENTIALFILE13NO";
	public static final String CREDENTIALFILE14NO = "CREDENTIALFILE14NO";
	public static final String CREDENTIALFILE15NO = "CREDENTIALFILE15NO";
	public static final String CREDENTIALFILE16NO = "CREDENTIALFILE16NO";
}




