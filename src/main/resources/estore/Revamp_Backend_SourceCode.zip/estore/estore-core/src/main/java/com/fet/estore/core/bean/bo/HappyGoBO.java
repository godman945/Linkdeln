package com.fet.estore.core.bean.bo;

import org.springframework.web.bind.annotation.RequestParam;

public class HappyGoBO {

    private String responseCode; // HappyGo狀態碼
    private String token;
    private String remainPoint; // 用戶HappyGo點數
    private String mpid;
    private String mpidCheckSum;
    private String date; // 日期
    private String time; // 時間
    private String orderType; // 申辦類型
    private String msisdn; // 門號
    private String msisdnId; // 門號ID
    private String errorMsg; // 錯誤訊息

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getRemainPoint() {
        return remainPoint;
    }

    public void setRemainPoint(String remainPoint) {
        this.remainPoint = remainPoint;
    }

    public String getMpid() {
        return mpid;
    }

    public void setMpid(String mpid) {
        this.mpid = mpid;
    }

    public String getMpidCheckSum() {
        return mpidCheckSum;
    }

    public void setMpidCheckSum(String mpidCheckSum) {
        this.mpidCheckSum = mpidCheckSum;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getMsisdnId() {
        return msisdnId;
    }

    public void setMsisdnId(String msisdnId) {
        this.msisdnId = msisdnId;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
}
