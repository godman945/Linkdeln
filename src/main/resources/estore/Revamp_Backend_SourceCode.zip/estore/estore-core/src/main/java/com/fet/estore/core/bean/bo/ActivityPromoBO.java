package com.fet.estore.core.bean.bo;

import java.util.List;

/**
 * @author Dennis.Chen
 * @Date 2020-09-28
 */
public class ActivityPromoBO {

    boolean isNormalAct; //是否為一般賣場
    boolean isEbu; //是否為EBU賣場
    List<String> activityPromoList; //秘密(活動)賣場可申辦之促案List
    long activityTargetNumber;

    public ActivityPromoBO(){
        super();
    }

    public ActivityPromoBO(boolean isNormalAct, boolean isEbu, List<String> activityPromoList){
        this.isNormalAct = isNormalAct;
        this.isEbu = isEbu;
        this.activityPromoList = activityPromoList;
    }

    public boolean isNormalAct() {
        return isNormalAct;
    }

    public void setNormalAct(boolean normalAct) {
        isNormalAct = normalAct;
    }

    public boolean isEbu() {
        return isEbu;
    }

    public void setEbu(boolean ebu) {
        isEbu = ebu;
    }

    public List<String> getActivityPromoList() {
        return activityPromoList;
    }

    public void setActivityPromoList(List<String> activityPromoList) {
        this.activityPromoList = activityPromoList;
    }

    public long getActivityTargetNumber() {
        return activityTargetNumber;
    }

    public void setActivityTargetNumber(long activityTargetNumber) {
        this.activityTargetNumber = activityTargetNumber;
    }
}
