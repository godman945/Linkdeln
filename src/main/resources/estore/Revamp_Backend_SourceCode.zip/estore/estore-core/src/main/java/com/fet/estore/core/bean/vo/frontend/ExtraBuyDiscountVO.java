package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.bean.vo.IDiscountItem;

public class ExtraBuyDiscountVO implements IDiscountItem {
	private Long id;
	private Long itemId;
	private String name;
	private String code;
	private String type;
	private Double share;
	private Long amount;
	private Long discAmount;
	private Double discRatio;
	private String displayGroup;

	public ExtraBuyDiscountVO() { }
	
	public ExtraBuyDiscountVO(Long itemId, Long id, String type, String name, String code, Double share, Long discAmount, Double discRatio, Long amount, String displayGroup) {
		this.itemId = itemId;
		this.id = id;
		this.name = name;
		this.code = code;
		this.type = type;
		this.share = share;
		this.amount = amount;
		this.discAmount = discAmount;
		this.discRatio = discRatio;
		this.displayGroup = displayGroup;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Double getShare() {
		return share;
	}
	public void setShare(Double share) {
		this.share = share;
	}
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public Long getDiscAmount() {
		return discAmount;
	}
	public void setDiscAmount(Long discAmount) {
		this.discAmount = discAmount;
	}
	public Double getDiscRatio() {
		return discRatio;
	}
	public void setDiscRatio(Double discRatio) {
		this.discRatio = discRatio;
	}
	public String getDisplayGroup() {
		return displayGroup;
	}
	public void setDisplayGroup(String displayGroup) {
		this.displayGroup = displayGroup;
	}

	@Override
	public Long getActivityId() {
		return null;
	}
	@Override
	public Long getCostCenterId() {
		return null;
	}
	@Override
	public Double getDiscountRatio() {
		return discRatio;
	}
	@Override
	public Long getActualDiscountAmt() {
		return amount;
	}
	@Override
	public Long getCouponId() {
		return null;
	}
	@Override
	public Long getAaiId() {
		return null;
	}
	@Override
	public String getFetNo() {
		return null;
	}
	@Override
	public Long getOfferId() {
		return null;
	}

	@Override
	public String getDiscountName() {
		return null;
	}
}
