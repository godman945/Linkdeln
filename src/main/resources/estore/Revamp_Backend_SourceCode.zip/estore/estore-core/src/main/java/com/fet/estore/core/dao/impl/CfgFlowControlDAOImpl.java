package com.fet.estore.core.dao.impl;

import com.fet.estore.core.dao.ICfgFlowControlDAO;
import com.fet.estore.core.dao.base.impl.AbstractBaseDAO;
import com.fet.estore.core.enums.FlowTypeEnum;
import com.fet.estore.core.model.CfgFlowControl;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.hibernate.type.Type;
import org.hibernate.type.YesNoType;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class CfgFlowControlDAOImpl extends AbstractBaseDAO<CfgFlowControl, Long> implements ICfgFlowControlDAO {

    public List<CfgFlowControl> findByFlowType(FlowTypeEnum flow) {
        StringBuilder sql = new StringBuilder();
        Map<String, Type> scalar = new HashMap<>();
        Map<String, Object> params = new HashMap<>();

        sql.append(" SELECT");
        sql.append("     ID id,");
        sql.append("     FLOW_TYPE flowType,");
        sql.append("     STEP_ID stepId,");
        sql.append("     STEP_FLOW stepFlow,");
        sql.append("     DECODE(COMPLETE_FLOW, 'Y', 'Y', 'N') completeFlow,");
        sql.append("     DECODE(FINISH_PAGE, 'Y', 'Y', 'N') finishPage");
        sql.append(" FROM");
        sql.append("     CFG_FLOW_CONTROL");
        sql.append(" WHERE");
        sql.append("     FLOW_TYPE = :flowType");
        params.put("flowType", flow.getFlowType());

        scalar.put("id", LongType.INSTANCE);
        scalar.put("flowType", StringType.INSTANCE);
        scalar.put("stepId", StringType.INSTANCE);
        scalar.put("stepFlow", StringType.INSTANCE);
        scalar.put("completeFlow", YesNoType.INSTANCE);
        scalar.put("finishPage", YesNoType.INSTANCE);

        return executeQuery(sql, scalar, params, CfgFlowControl.class);
    }
}
