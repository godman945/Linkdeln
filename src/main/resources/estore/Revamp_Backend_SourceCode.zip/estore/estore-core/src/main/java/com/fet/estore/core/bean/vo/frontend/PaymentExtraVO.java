package com.fet.estore.core.bean.vo.frontend;

public class PaymentExtraVO {
	private String  fetno;
	private String  type;
	private String  name;
	private Integer amount;
	private Integer maxAmount;
	private Long    totalPrice;
	private boolean hasAmount;
	private String productId;
	private Long    erpPrice;
	
	public String getFetno() {
		return fetno;
	}
	public void setFetno(String fetno) {
		this.fetno = fetno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public Integer getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(Integer maxAmount) {
		this.maxAmount = maxAmount;
	}
	public Long getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}
	public boolean isHasAmount() {
		return hasAmount;
	}
	public void setHasAmount(boolean hasAmount) {
		this.hasAmount = hasAmount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
}
