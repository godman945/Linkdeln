package com.fet.estore.core.bean.vo.frontend;

public class DigitalDataVO {

    /** Adobe Analytics 需求使用的物件 -- 結帳頁面和結帳完成頁面用 */

    /** 訂單完成狀態 */
    private String orderComplete;

    /** ecommerce資料 */
    private AAEcommerceVO ecommerce;

    public String getOrderComplete() {
        return orderComplete;
    }

    public void setOrderComplete(String orderComplete) {
        this.orderComplete = orderComplete;
    }

    public AAEcommerceVO getEcommerce() {
        return ecommerce;
    }

    public void setEcommerce(AAEcommerceVO ecommerce) {
        this.ecommerce = ecommerce;
    }

    @Override
    public String toString() {
        return "DigitalDataVO{" +
                "orderComplete='" + orderComplete + '\'' +
                ", ecommerce=" + ecommerce +
                '}';
    }
}
