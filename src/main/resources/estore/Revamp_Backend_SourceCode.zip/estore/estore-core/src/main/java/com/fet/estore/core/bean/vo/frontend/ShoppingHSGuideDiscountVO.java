package com.fet.estore.core.bean.vo.frontend;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 紅配綠活動折扣VO
 * @author Max Chen
 *
 */
public class ShoppingHSGuideDiscountVO {

	/** 折扣料號 */
	private String fetNo;
	/** 折扣數量 */
	private String amount;
	/** 折扣名稱 */
	private String name;
	/** 折扣代碼 */
	private String code;
	
	
	public String getFetNo() {
		return fetNo;
	}

	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
