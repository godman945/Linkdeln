package com.fet.estore.core.bean;

import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-16
 * @description
 */
public class GreetingBubbleIcons {

    private Greeting.Type type;

    private List<GreetingIcon> icons;

    public Greeting.Type getType() {
        return type;
    }

    public void setType(Greeting.Type type) {
        this.type = type;
    }

    public List<GreetingIcon> getIcons() {
        return icons;
    }

    public void setIcons(List<GreetingIcon> icons) {
        this.icons = icons;
    }
}
