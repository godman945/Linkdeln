package com.fet.estore.core.bean.vo.frontend;

import java.util.Date;

/**
 * 升轉加量促案VO
 * @author Terry Lu
 *
 */
public class UpgratePlusPromoListVO {
	
	/** 系統序號。 */
    private String seq;
    /** 促銷名稱。 */
    private String onsaleName;
    /** 是否為推薦促代。 */
    private String recommend;
    /** 主打活動促代名稱。 */
    private String recommendName;
    /** PROMO_LIST.ID*/
    private String promoListId;
    
    private String msisdnType;
	/** 是否合併語音數據 */
	private String isVD;
	/** 語音數據月租費 */
	private Long vdPrice;
	/** 語音月租費 */
	private Long voicePrice;
	/** 數據月租費 */
	private Long dataPrice;
	/** 方案期數 */
	private Integer limit;	
	/** 預繳金額 */
	private Long prepaidPrice;
	/** 結帳總金額 */
	private Long totalPrice;
	/** 折扣前分期期數 */
	private Integer orgInst;	
	/** 折扣前分期金額 */
	private Long orgInstPrice;
	/** 方案期數 */
	private Integer dlmt;
	
	private Boolean is3GT4G;
	private Boolean isLOY3G;
	private Boolean isLOY4G;
	private Boolean isNPF3G;
	private Boolean isNPF4G;
	private Boolean isPOS3G;
	private Boolean isPOS4G;

	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getOnsaleName() {
		return onsaleName;
	}
	public void setOnsaleName(String onsaleName) {
		this.onsaleName = onsaleName;
	}
	public String getRecommend() {
		return recommend;
	}
	public void setRecommend(String recommend) {
		this.recommend = recommend;
	}
	public String getRecommendName() {
		return recommendName;
	}
	public void setRecommendName(String recommendName) {
		this.recommendName = recommendName;
	}
	public String getPromoListId() {
		return promoListId;
	}
	public void setPromoListId(String promoListId) {
		this.promoListId = promoListId;
	}
	public String getMsisdnType() {
		return msisdnType;
	}
	public void setMsisdnType(String msisdnType) {
		this.msisdnType = msisdnType;
	}
	public String getIsVD() {
		return isVD;
	}
	public void setIsVD(String isVD) {
		this.isVD = isVD;
	}
	public Long getVdPrice() {
		return vdPrice;
	}
	public void setVdPrice(Long vdPrice) {
		this.vdPrice = vdPrice;
	}
	public Long getVoicePrice() {
		return voicePrice;
	}
	public void setVoicePrice(Long voicePrice) {
		this.voicePrice = voicePrice;
	}
	public Long getDataPrice() {
		return dataPrice;
	}
	public void setDataPrice(Long dataPrice) {
		this.dataPrice = dataPrice;
	}
	public Integer getLimit() {
		return limit;
	}
	public void setLimit(Integer limit) {
		this.limit = limit;
	}
	public Long getPrepaidPrice() {
		return prepaidPrice;
	}
	public void setPrepaidPrice(Long prepaidPrice) {
		this.prepaidPrice = prepaidPrice;
	}
	public Long getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Integer getOrgInst() {
		return orgInst;
	}
	public void setOrgInst(Integer orgInst) {
		this.orgInst = orgInst;
	}
	public Long getOrgInstPrice() {
		return orgInstPrice;
	}
	public void setOrgInstPrice(Long orgInstPrice) {
		this.orgInstPrice = orgInstPrice;
	}
	public Integer getDlmt() {
		return dlmt;
	}
	public void setDlmt(Integer dlmt) {
		this.dlmt = dlmt;
	}
	public Boolean getIs3GT4G() {
		return is3GT4G;
	}
	public void setIs3GT4G(Boolean is3gt4g) {
		is3GT4G = is3gt4g;
	}
	public Boolean getIsLOY3G() {
		return isLOY3G;
	}
	public void setIsLOY3G(Boolean isLOY3G) {
		this.isLOY3G = isLOY3G;
	}
	public Boolean getIsLOY4G() {
		return isLOY4G;
	}
	public void setIsLOY4G(Boolean isLOY4G) {
		this.isLOY4G = isLOY4G;
	}
	public Boolean getIsNPF3G() {
		return isNPF3G;
	}
	public void setIsNPF3G(Boolean isNPF3G) {
		this.isNPF3G = isNPF3G;
	}
	public Boolean getIsNPF4G() {
		return isNPF4G;
	}
	public void setIsNPF4G(Boolean isNPF4G) {
		this.isNPF4G = isNPF4G;
	}
	public Boolean getIsPOS3G() {
		return isPOS3G;
	}
	public void setIsPOS3G(Boolean isPOS3G) {
		this.isPOS3G = isPOS3G;
	}
	public Boolean getIsPOS4G() {
		return isPOS4G;
	}
	public void setIsPOS4G(Boolean isPOS4G) {
		this.isPOS4G = isPOS4G;
	}
	
}
