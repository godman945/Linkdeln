package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class GiftModalBean implements Serializable {

	private static final long serialVersionUID = 3828996785359385773L;
	private String title;
	private List<Object> content;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<Object> getContent() {
		return content;
	}
	public void setContent(List<Object> content) {
		this.content = content;
	}

}
