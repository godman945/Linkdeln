package com.fet.estore.core.bean.req;

import java.io.Serializable;
import java.util.List;
import com.fet.estore.core.enums.AccSearchMethodEnum;

public class ProductListReq implements Serializable{

	private static final long serialVersionUID = 951658054074274681L;
	
	/** true:單機、false:搭門號 */
	private Boolean type;
	/** 廠牌 */
	private String brand;
	/** 配件搜尋排序方式 */
	private AccSearchMethodEnum accSearchMethod;
	/** 關鍵字 */
	private String keyword;
	/** 主分類 */
	private String categoryGroup;
	/** 次分類 */
	private String category;
	/** 起始筆數 */
	private Integer startIndex;
	/** 撈取筆數 */
	private Integer querySize;

	public ProductListReq() {
		super();
		accSearchMethod = AccSearchMethodEnum.DEFAULT_WITH_STICKY;
	}
	
	public ProductListReq(
			Boolean type,
			String brand,
			String recommand,
			String keyword,
			String category) {
		super();
		
		this.type = type;
		this.brand = brand;
		this.keyword = keyword;
		this.category = category;
		this.accSearchMethod = AccSearchMethodEnum.findByIdStr(recommand);

	}
	
	public Boolean getType() {
		return type;
	}

	public void setType(Boolean type) {
		this.type = type;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public AccSearchMethodEnum getAccSearchMethod() {
	    if (accSearchMethod == null) {
	    	return AccSearchMethodEnum.DEFAULT_WITH_STICKY;
	    }
		return accSearchMethod;
	}

	public void setAccSearchMethod(AccSearchMethodEnum accSearchMethod) {
		this.accSearchMethod = accSearchMethod;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getStartIndex() {
		return startIndex;
	}

	public ProductListReq setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
		return this;
	}

	public Integer getQuerySize() {
		return querySize;
	}

	public ProductListReq setQuerySize(Integer querySize) {
		this.querySize = querySize;
		return this;
	}

	/** 此 Function 是給前端塞資料自動轉換為搜尋方式 Enum 使用 */
	public void setRecommand(String recommand) {
		this.accSearchMethod = AccSearchMethodEnum.findByIdStr(recommand);
	}

	public String getCategoryGroup() {
		return categoryGroup;
	}

	public ProductListReq setCategoryGroup(String categoryGroup) {
		this.categoryGroup = categoryGroup;
		return this;
	}
}
