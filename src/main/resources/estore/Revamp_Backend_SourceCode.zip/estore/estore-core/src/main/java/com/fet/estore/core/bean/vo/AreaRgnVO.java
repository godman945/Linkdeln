package com.fet.estore.core.bean.vo;

import java.io.Serializable;

import com.fet.estore.core.model.AreaCity;

public class AreaRgnVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4622633117713119040L;
	private String seq;
	private String rgnCode;
	private String rgnName;
	private Boolean shippingArea;

	public String getRgnCode() {
		return rgnCode;
	}

	public String getRgnName() {
		return rgnName;
	}

	public void setRgnCode(String rgnCode) {
		this.rgnCode = rgnCode;
	}

	public void setRgnName(String rgnName) {
		this.rgnName = rgnName;
	}

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public Boolean getShippingArea() {
		return shippingArea;
	}

	public void setShippingArea(Boolean shippingArea) {
		this.shippingArea = shippingArea;
	}
	
}
