package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

public class BrowseHistory implements Serializable {

	private static final long serialVersionUID = -246224871877077574L;
	private String title;
	private List<Product> cards;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<Product> getCards() {
		return cards;
	}
	public void setCards(List<Product> cards) {
		this.cards = cards;
	}

}
