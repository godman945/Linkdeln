package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.ActivityPageFlowLog;

public interface NActivityPageFlowLogDAO extends BaseDAO<ActivityPageFlowLog, Long> {

}
