package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.Date;

public class ProductBean implements Serializable {

	private static final long serialVersionUID = 7602772842685738157L;
	
	private String checkAtr;
	private String isPreSubscribe;
	private String sellType;
	private Date unavailableEndTime;
	private Date unavailableStartTime;
	private String newAtrStatus;
	private String allowPickUp;
	private String reservation;
	private String checkLocalAtr;
	private String localAtrStatus;
	private Date checkLocalAtrEndTime;
	private Date checkLocalAtrStartTime;
	private String isUnavailableInfo;
	private String atrStatus;
	private String fetNo;
	
	public String getCheckAtr() {
		return checkAtr;
	}
	public void setCheckAtr(String checkAtr) {
		this.checkAtr = checkAtr;
	}
	public String getIsPreSubscribe() {
		return isPreSubscribe;
	}
	public void setIsPreSubscribe(String isPreSubscribe) {
		this.isPreSubscribe = isPreSubscribe;
	}
	public String getSellType() {
		return sellType;
	}
	public void setSellType(String sellType) {
		this.sellType = sellType;
	}
	public Date getUnavailableEndTime() {
		return unavailableEndTime;
	}
	public void setUnavailableEndTime(Date unavailableEndTime) {
		this.unavailableEndTime = unavailableEndTime;
	}
	public Date getUnavailableStartTime() {
		return unavailableStartTime;
	}
	public void setUnavailableStartTime(Date unavailableStartTime) {
		this.unavailableStartTime = unavailableStartTime;
	}
	public String getNewAtrStatus() {
		return newAtrStatus;
	}
	public void setNewAtrStatus(String newAtrStatus) {
		this.newAtrStatus = newAtrStatus;
	}
	public String getAllowPickUp() {
		return allowPickUp;
	}
	public void setAllowPickUp(String allowPickUp) {
		this.allowPickUp = allowPickUp;
	}
	public String getReservation() {
		return reservation;
	}
	public void setReservation(String reservation) {
		this.reservation = reservation;
	}
	public String getCheckLocalAtr() {
		return checkLocalAtr;
	}
	public void setCheckLocalAtr(String checkLocalAtr) {
		this.checkLocalAtr = checkLocalAtr;
	}
	public String getLocalAtrStatus() {
		return localAtrStatus;
	}
	public void setLocalAtrStatus(String localAtrStatus) {
		this.localAtrStatus = localAtrStatus;
	}
	public Date getCheckLocalAtrEndTime() {
		return checkLocalAtrEndTime;
	}
	public void setCheckLocalAtrEndTime(Date checkLocalAtrEndTime) {
		this.checkLocalAtrEndTime = checkLocalAtrEndTime;
	}
	public Date getCheckLocalAtrStartTime() {
		return checkLocalAtrStartTime;
	}
	public void setCheckLocalAtrStartTime(Date checkLocalAtrStartTime) {
		this.checkLocalAtrStartTime = checkLocalAtrStartTime;
	}
	public String getIsUnavailableInfo() {
		return isUnavailableInfo;
	}
	public void setIsUnavailableInfo(String isUnavailableInfo) {
		this.isUnavailableInfo = isUnavailableInfo;
	}
	public String getAtrStatus() {
		return atrStatus;
	}
	public void setAtrStatus(String atrStatus) {
		this.atrStatus = atrStatus;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	
}
