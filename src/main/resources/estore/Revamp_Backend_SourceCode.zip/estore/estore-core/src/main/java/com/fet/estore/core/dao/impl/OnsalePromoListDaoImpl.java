package com.fet.estore.core.dao.impl;

import com.fet.estore.core.bean.bo.ActivityPromoBO;
import com.fet.estore.core.bean.bo.FindProductBO;
import com.fet.estore.core.bean.bo.LyPromoBO;
import com.fet.estore.core.bean.po.PromotionPO;
import com.fet.estore.core.constant.SystemConstant;
import com.fet.estore.core.dao.IOnsalePromotListDao;
import com.fet.estore.core.dao.base.impl.AbstractBaseDAO;
import com.fet.estore.core.enums.OrderTypeEnum;
import com.fet.estore.core.model.ContentOffer;
import com.fet.estore.core.model.Datarate;
import com.fet.estore.core.model.OnsalePromoList;
import com.fet.estore.core.model.Voicerate;
import com.fet.estore.core.util.LogUtil;
import com.fet.estore.core.util.StringUtil;
import org.hibernate.SQLQuery;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BooleanType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.NumericBooleanType;
import org.hibernate.type.StringType;
import org.hibernate.type.Type;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Dennis.Chen
 * @date 2020-08-19
 */
@Repository
public class OnsalePromoListDaoImpl extends AbstractBaseDAO<OnsalePromoList, String> implements IOnsalePromotListDao {

    /**
     * 1. 檢查該促案是否上架 OPL.ONSALE=Y，是否簽核通過OPL.SIGN4ONSALE=Y
     * 2. 不可為多主商品促案 OPL.IS_MULTIPROD=N or null
     * 3. 須為User設定的上架時間區間內 OPL.ONSALE_DATE、OPL.OFF_DATE
     * 4. 須為ICE設定的上架時間區間內 PL.BEGINDATE、PL.ENDDATE
     * 5. 販售類型 SALE_TYPE 須符合設定，參考OrderTypeEnum.SaleType
     * 6. OPL.V_VOICEGROUP(語音群組)不得為空
     * 7. GA、NP時, 語音不得為空
     * 8. 依據GA、NP流程判斷PL的設定(EX. GA時 -> PL.IS_POS4G=Y OR PL.IS_POS5G=Y)
     * 9. 判斷可遞送產品的方式 OPL.IS_HOME_DELIVERABLE、OPL.IS_STORE_DELIVERABLE
     * 10. 方案期數 PL.LIMIT、PL.DATA_LIMIT兩者取最大值
     * 11. 推薦資費Flag 需 IS_RECOMMEND == 1 且 在推薦期間內
     * 12. RECOMMEND_SORT 需 IS_RECOMMEND == 1 且 在推薦期間內，否則為null
     * @param orderType 訂單流程(NC、NH、PC、PH)
     * @param fetNo 產品料號
     * @param deliveryType 遞送方式
     * @param lyPromoBO 續約情境下撈促案所需資料
     * @param activityPromoBO 活動相關設定(是否為一般賣場、是否為EBU賣場、活動賣場可申辦之促案SEQ清單)
     * @return List<PromotionPO>
     * @author Dennis.Chen
     * @date 2020-08-19
     */
    public List<PromotionPO> getProductPromo(OrderTypeEnum orderType, String fetNo, Map<String, Boolean> deliveryType, LyPromoBO lyPromoBO, ActivityPromoBO activityPromoBO) {

        Boolean isHome = deliveryType.get("IS_HOME");
        Boolean isStore = deliveryType.get("IS_STORE");

        Map<String, Object> sqlParams = new HashMap<String, Object>();

        //1. 建立SQL
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT OPL.SEQ oplSeq,                                        \n");
        sb.append("       OPL.ONSALE_NAME oplName,                               \n");
        sb.append("       OPL.RECOMMEND_DESC recommendDesc,                      \n");
        sb.append("       OPL.MONTH_PRICE monthPrice,                            \n");
        sb.append("       OPL.BUBBLE_TEXT bubbleText,                            \n");
        sb.append("       OPL.DATA_USAGE_AMOUNT dataUsageAmount,                 \n");
        sb.append("       OPL.SPEED_DESC speedDesc,                              \n");
        sb.append("       OPL.VOICE_PREMIUM voicePremium,                        \n");
        sb.append("       OPL.VOICE_PREMIUM2 voicePremium2,                      \n");
        sb.append("       OPL.VOICE_PREMIUM3 voicePremium3,                      \n");
        sb.append("       OPL.VOICE_PREMIUM4 voicePremium4,                      \n");
        sb.append("       OPL.OTHER_PREMIUM otherPremium,                        \n");
        sb.append("       OPL.NO_LIMIT noLimit,                                  \n");
        sb.append("       OPL.PCODE pCode,                                  	 \n");
        sb.append("       CASE WHEN OPL.IS_RECOMMEND = 1                         \n");
        sb.append("             AND SYSDATE BETWEEN RECOMMEND_START_TIME         \n");
        sb.append("                         AND RECOMMEND_END_TIME               \n");
        sb.append("            THEN 'Y' ELSE 'N'                                 \n");
        sb.append("       END AS isRecommend,                                    \n");
        sb.append("       CASE WHEN OPL.IS_RECOMMEND = 1                         \n");
        sb.append("             AND SYSDATE BETWEEN RECOMMEND_START_TIME         \n");
        sb.append("                         AND RECOMMEND_END_TIME               \n");
        sb.append("            THEN OPL.RECOMMEND_SORT ELSE NULL                 \n");
        sb.append("       END AS recommendSort,                                  \n");
        sb.append("       CASE WHEN PL.LIMIT >= PL.DATA_LIMIT                    \n");
        sb.append("            THEN PL.LIMIT ELSE PL.DATA_LIMIT                  \n");
        sb.append("       END AS limit,                                          \n");
        sb.append("       PL.id promotionListId,                                 \n");
        sb.append("       PL.promo_type promoType,                               \n");
        sb.append("       PL.IS_NPF4G isNpf4g,                                   \n");
        sb.append("       PL.IS_POS4G isPos4g,                                   \n");
        sb.append("       PL.IS_NPF5G isNpf5g,                                   \n");
        sb.append("       PL.IS_POS5G isPos5g,                                   \n");
        sb.append("       PL.PREPAYMENT_PRICE prepaymentPrice,                   \n");
        sb.append("       PL.PROJECT_NAME projectName,                           \n");
        sb.append("       POS.PRICE posPrice,                                    \n");
        sb.append("       {contentOffer.*},                                      \n");
        sb.append("       {voiceRate.*},                                         \n");
        sb.append("       {dataRate.*}                                           \n");
        sb.append("   FROM ONSALE_PROMO_LIST OPL,                                \n");
        sb.append("        VOICERATE voiceRate,                                  \n");
        sb.append("        DATARATE dataRate,                                    \n");
        sb.append("        CONTENTOFFER contentOffer,                            \n");
        sb.append("        CONTENT_PROMO_MAPPING CPM,                            \n");
        sb.append("        PROMOTION_LIST PL,                                    \n");
        sb.append("        PRODUCT PROD,                                         \n");
        sb.append("        (SELECT P.*                                           \n");
        sb.append("           FROM POS P                                         \n");
        sb.append("          WHERE P.PRODNO = :fetNo) POS                        \n");
        sb.append("  WHERE OPL.promotion_list_id = pl.ID                         \n");
        sb.append("     AND OPL.POS_PCODE = POS.PROMOTION_ID                     \n");
        sb.append("     AND OPL.V_OFFERID = voiceRate.V_OFFERID(+)               \n");
        sb.append("     AND OPL.D_OFFERID = dataRate.D_OFFERID(+)                \n");
        sb.append("     AND OPL.PROMOTION_LIST_ID = CPM.PCODE(+)                 \n");
        sb.append("     AND CPM.C_OFFERID = contentOffer.C_OFFERID(+)	         \n");
        sb.append("     AND OPL.P_PREPAIDNO = PROD.FET_NO(+)                     \n");
        sb.append("     AND OPL.V_VOICEGROUP IS NOT NULL                         \n");
        sb.append("     AND OPL.ONSALE = 'Y'                                     \n");
        sb.append("     AND voiceRate.ONSALE = 'Y' AND voiceRate.ES_PRODUCT = 'Y'\n");
        sb.append("     AND dataRate.ONSALE = 'Y' AND dataRate.SIGN4ONSALE = 'Y' \n");
        sb.append("     AND OPL.SIGN4ONSALE = 'Y'                                \n");
        sb.append("     AND (OPL.IS_MULTIPROD = 'N' OR OPL.IS_MULTIPROD IS NULL) \n");
        sb.append("     AND (SYSDATE BETWEEN OPL.ONSALE_DATE AND OPL.OFF_DATE)   \n");
        sb.append("     AND (TRUNC(SYSDATE) BETWEEN PL.BEGINDATE AND PL.ENDDATE) \n");
        sb.append("     AND OPL.SALE_TYPE IN (:saleType)                         \n");

        //1-1. 判斷流程
        sb.append("AND(	\n");
        if ("GA".equals(orderType.getFlow())) {
            sb.append("PL.IS_POS4G = 'Y' OR PL.IS_POS5G = 'Y'");
        }else if ("NP".equals(orderType.getFlow())) {
            sb.append("PL.IS_NPF4G = 'Y' OR PL.IS_NPF5G = 'Y'");
        }else if ("LY".equals(orderType.getFlow()) && lyPromoBO != null ) {
            //若用戶原促案為5G則不撈取LOY4G、4GT5G之促案
            if(StringUtil.equals(SystemConstant.CRM_PROMO_FIVE_GEN, lyPromoBO.getUserGeneration())){
                sb.append("PL.IS_LOY5G = 'Y'");
            }else{
                sb.append("PL.IS_LOY4G = 'Y' OR PL.IS_LOY5G = 'Y' OR PL.IS_4GT5G = 'Y'");
            }
        }
        sb.append(") \n");

        //1-2. 判斷宅配/門市
        sb.append("AND (1=0 \n");
        if (isHome) sb.append("OR OPL.IS_HOME_DELIVERABLE = 1  \n");
        if (isStore) sb.append("OR OPL.IS_STORE_DELIVERABLE = 1 \n");
        sb.append(") \n");

        //1-3. 指定撈取PROMOTION_LIST ID(Ex.續約)
        if (lyPromoBO != null && lyPromoBO.getPromotionIdList() != null && lyPromoBO.getPromotionIdList().size() > 0){
            List<String> promotionIdList = lyPromoBO.getPromotionIdList();
            int round = promotionIdList.size() / 1000 + (promotionIdList.size() % 1000 > 0 ? 1 : 0);
            sb.append("AND (1=0 \n");
            for(int i = 0; i < round; i++) {
                String promoIds = promotionIdList.stream()
                                                 .skip(i*1000)
                                                 .limit(1000)
                                                 .collect(Collectors.joining("','", "OR PL.ID IN ('", "')"));
                sb.append(promoIds);
            }
            sb.append(") \n");
        }

        //1-4. 處理活動相關判斷
		if(activityPromoBO != null) {
			if (activityPromoBO.isNormalAct()) {
				//1-4-1. 一般賣場，促案ACTIVITY_ONLY不可等於Y
				sb.append("AND OPL.ACTIVITY_ONLY != 'Y' \n");

                //1-4-2. 一般賣場排序順位: 是否為推薦資費 > 推薦資費順序 > 資費金額
                sb.append("ORDER BY isRecommend DESC, recommendSort ASC, monthPrice ASC");

			} else {
				List<String> activityPromoList = activityPromoBO.getActivityPromoList();

				//1-4-1. 活動賣場，若該活動賣場為EBU專屬，則只撈取EBU促案
				sb.append("AND NVL(OPL.iS_EBU, 'N') = :isEbu \n");
				sqlParams.put("isEbu", activityPromoBO.isEbu() ? "Y" : "N");

				//1-4-2. 撈取活動賣場所設定開賣的促案
				if (activityPromoList != null && activityPromoList.size() > 0) {
					sb.append("AND OPL.SEQ IN (:activityPromoList) \n");
					sqlParams.put("activityPromoList", activityPromoList);
				}
			}
		}

        //2. 放入Query參數值
        sqlParams.put("fetNo", fetNo);
        sqlParams.put("saleType", orderType.getSaleType().split(","));

        //3. 執行SQL
        NativeQuery query = this.getSessionFactory().getCurrentSession().createNativeQuery(sb.toString());
        query.addScalar("oplSeq", StringType.INSTANCE);
        query.addScalar("oplName", StringType.INSTANCE);
        query.addScalar("recommendDesc", StringType.INSTANCE);
        query.addScalar("monthPrice", LongType.INSTANCE);
        query.addScalar("bubbleText", StringType.INSTANCE);
        query.addScalar("dataUsageAmount", StringType.INSTANCE);
        query.addScalar("speedDesc", StringType.INSTANCE);
        query.addScalar("voicePremium", StringType.INSTANCE);
        query.addScalar("voicePremium2", StringType.INSTANCE);
        query.addScalar("voicePremium3", StringType.INSTANCE);
        query.addScalar("voicePremium4", StringType.INSTANCE);
        query.addScalar("otherPremium", StringType.INSTANCE);
        query.addScalar("noLimit", StringType.INSTANCE);
        query.addScalar("isRecommend", StringType.INSTANCE);
        query.addScalar("recommendSort", IntegerType.INSTANCE);
        query.addScalar("limit", IntegerType.INSTANCE);
        query.addScalar("promotionListId", StringType.INSTANCE);
        query.addScalar("promoType", StringType.INSTANCE);
        query.addEntity("contentOffer", ContentOffer.class);
        query.addEntity("voiceRate", Voicerate.class);
        query.addEntity("dataRate", Datarate.class);
        query.addScalar("isNpf4g", StringType.INSTANCE);
        query.addScalar("isPos4g", StringType.INSTANCE);
        query.addScalar("isNpf5g", StringType.INSTANCE);
        query.addScalar("isPos5g", StringType.INSTANCE);
        query.addScalar("prepaymentPrice", LongType.INSTANCE);
        query.addScalar("posPrice", LongType.INSTANCE);
        query.addScalar("pCode", StringType.INSTANCE);
        query.addScalar("projectName", StringType.INSTANCE);
        query.setProperties(sqlParams);
        List<PromotionPO> result = query.unwrap(NativeQueryImpl.class)
                                  .setResultTransformer(Transformers.aliasToBean(PromotionPO.class))
                                  .list();

        return result;
    }
    
    @Override
    public List<PromotionPO> getPromotions(OrderTypeEnum orderType, LyPromoBO lyPromoBO, ActivityPromoBO activityPromoBO) {
    	StringBuilder sb = new StringBuilder();
		sb.append("SELECT OPL.SEQ oplSeq,                                        \n");
		sb.append("       OPL.ONSALE_NAME oplName,                               \n");
        sb.append("       CASE WHEN OPL.IS_RECOMMEND = 1                         \n");
        sb.append("             AND SYSDATE BETWEEN RECOMMEND_START_TIME         \n");
        sb.append("                         AND RECOMMEND_END_TIME               \n");
        sb.append("            THEN 'Y' ELSE 'N'                                 \n");
        sb.append("       END AS isRecommend,                                    \n");
        sb.append("       CASE WHEN OPL.IS_RECOMMEND = 1                         \n");
        sb.append("             AND SYSDATE BETWEEN RECOMMEND_START_TIME         \n");
        sb.append("                         AND RECOMMEND_END_TIME               \n");
        sb.append("            THEN OPL.RECOMMEND_SORT ELSE NULL                 \n");
        sb.append("       END AS recommendSort,                                  \n");
        sb.append("       CASE WHEN PL.LIMIT >= PL.DATA_LIMIT                    \n");
        sb.append("            THEN PL.LIMIT ELSE PL.DATA_LIMIT                  \n");
        sb.append("       END AS limit,                                          \n");
        sb.append("       {contentOffer.*},                                      \n");
        sb.append("       {voiceRate.*},                                         \n");
        sb.append("       {dataRate.*},                                          \n");
		sb.append("       PL.id promotionListId,                                 \n");
		sb.append("       PL.promo_type promoType,                               \n");
		sb.append("       OPL.MONTH_PRICE monthPrice,                            \n");
		sb.append("       PL.IS_LOY4G isLoy4g,                                   \n");
		sb.append("       PL.IS_NPF4G isNpf4g,                                   \n");
		sb.append("       PL.IS_POS4G isPos4g,                                   \n");
		sb.append("       PL.IS_4GT5G is4gt5g,                                   \n");
		sb.append("       PL.IS_LOY5G isLoy5g,                                   \n");
		sb.append("       PL.IS_NPF5G isNpf5g,                                   \n");
		sb.append("       PL.IS_POS5G isPos5g,                                   \n");
        sb.append("       PL.PROJECT_NAME projectName,                           \n");
		sb.append("       OPL.RECOMMEND_DESC recommendDesc,                      \n");
		sb.append("       OPL.DATA_USAGE_AMOUNT  dataUsageAmount ,               \n");
		sb.append("       OPL.SPEED_DESC  speedDesc,                             \n");
		sb.append("       OPL.VOICE_PREMIUM  voicePremium,                       \n");
		sb.append("       OPL.VOICE_PREMIUM2 voicePremium2,                      \n");
		sb.append("       OPL.VOICE_PREMIUM3 voicePremium3,                      \n");
		sb.append("       OPL.VOICE_PREMIUM4 voicePremium4,                      \n");
		sb.append("       OPL.OTHER_PREMIUM  otherPremium,                       \n");
		sb.append("       OPL.NO_LIMIT       noLimit,                            \n");
		sb.append("       PL.PREPAYMENT_PRICE prepaymentPrice, 				     \n");
		sb.append("       OPL.BUBBLE_TEXT    bubbleText,                         \n");
        sb.append("       OPL.PCODE pCode                                    	 \n");
		sb.append("   FROM ONSALE_PROMO_LIST OPL,                                \n");
		sb.append("        VOICERATE         voiceRate,                          \n");
		sb.append("        DATARATE          dataRate,                           \n");
		sb.append("        CONTENTOFFER      contentOffer,                       \n");
		sb.append("        CONTENT_PROMO_MAPPING    CPM,                         \n");
		sb.append("        PROMOTION_LIST    PL,                                 \n");
		sb.append("        PRODUCT           PROD                                \n");
		sb.append("  WHERE OPL.promotion_list_id = PL.ID                         \n");
		sb.append("     AND OPL.V_VOICEGROUP IS NOT NULL                         \n");
        sb.append("     AND voiceRate.ONSALE = 'Y' AND voiceRate.ES_PRODUCT = 'Y'\n");
        sb.append("     AND dataRate.ONSALE = 'Y' AND dataRate.SIGN4ONSALE = 'Y' \n");
		sb.append("     AND OPL.PROMOTION_LIST_ID = CPM.PCODE(+)                 \n");
		sb.append("     AND OPL.D_OFFERID = dataRate.D_OFFERID(+)                \n");
		sb.append("     AND OPL.V_OFFERID = voiceRate.V_OFFERID(+)               \n");
		sb.append("     AND OPL.P_PREPAIDNO = PROD.FET_NO(+)                     \n");
		sb.append("     AND CPM.C_OFFERID = contentOffer.C_OFFERID(+)	         \n");
		sb.append("     AND OPL.ONSALE = 'Y'                                     \n");
		sb.append("     AND OPL.SIGN4ONSALE = 'Y'                                \n");
		sb.append("     AND (OPL.IS_MULTIPROD = 'N' or OPL.IS_MULTIPROD IS NULL) \n");
		sb.append("     AND (SYSDATE BETWEEN OPL.ONSALE_DATE AND OPL.OFF_DATE)   \n");
		sb.append("     AND (TRUNC(SYSDATE) BETWEEN PL.BEGINDATE AND PL.ENDDATE) \n");
		sb.append("     AND OPL.SALE_TYPE IN (:st)                               \n");

        //1-2. 判斷宅配/門市
        sb.append("AND (1=0 \n");
        sb.append("OR OPL.IS_HOME_DELIVERABLE = 1  \n");
        if ("LY".equals(orderType.getFlow())) sb.append("OR OPL.IS_STORE_DELIVERABLE = 1 \n");
        sb.append(") \n");
		sb.append(" AND(	\n");
		if ("GA".equals(orderType.getFlow())) {
           sb.append("PL.IS_POS4G = 'Y' OR PL.IS_POS5G = 'Y'");
        }else if ("NP".equals(orderType.getFlow())) {
           sb.append("PL.IS_NPF4G = 'Y' OR PL.IS_NPF5G = 'Y'");
        }else if ("LY".equals(orderType.getFlow()) && lyPromoBO != null ) {
            //若用戶原促案為5G則不撈取LOY4G、4GT5G之促案
            if(StringUtil.equals(SystemConstant.CRM_PROMO_FIVE_GEN, lyPromoBO.getUserGeneration())){
                sb.append("PL.IS_LOY5G = 'Y'");
            }else{
                sb.append("PL.IS_LOY4G = 'Y' OR PL.IS_LOY5G = 'Y' OR PL.IS_4GT5G = 'Y'");
            }
        }
	    sb.append(") \n");

	    //1-3. 指定撈取PROMOTION_LIST ID(Ex.續約)
        if (lyPromoBO != null && lyPromoBO.getPromotionIdList() != null && lyPromoBO.getPromotionIdList().size() > 0){
            List<String> promotionIdList = lyPromoBO.getPromotionIdList();
            int round = promotionIdList.size() / 1000 + (promotionIdList.size() % 1000 > 0 ? 1 : 0);
            sb.append("AND (1=0 \n");
            for(int i = 0; i < round; i++) {
                String promoIds = promotionIdList.stream()
                                                 .skip(i*1000)
                                                 .limit(1000)
                                                 .collect(Collectors.joining("','", "OR PL.ID IN ('", "')"));
                sb.append(promoIds);
            }
            sb.append(") \n");
        }
		Map<String, Object> params = new HashMap<String, Object>();

        //1-4. 處理活動相關判斷
		if(activityPromoBO != null) {
			if (activityPromoBO.isNormalAct()) {
				//1-4-1. 一般賣場，促案ACTIVITY_ONLY不可等於Y
				sb.append("AND OPL.ACTIVITY_ONLY != 'Y' \n");
                //1-4-2. 一般賣場排序順位: 是否為推薦資費 > 推薦資費順序 > 資費金額
                sb.append("ORDER BY isRecommend DESC, recommendSort ASC, monthPrice ASC");
			} else {
				List<String> activityPromoList = activityPromoBO.getActivityPromoList();

				//1-4-1. 活動賣場，若該活動賣場為EBU專屬，則只撈取EBU促案
				sb.append("AND NVL(OPL.iS_EBU, 'N') = :isEbu \n");
				params.put("isEbu", activityPromoBO.isEbu() ? "Y" : "N");

				//1-4-2. 撈取活動賣場所設定開賣的促案
				if (activityPromoList != null && activityPromoList.size() > 0) {
					sb.append("AND OPL.SEQ IN (:activityPromoList) \n");
					params.put("activityPromoList", activityPromoList);
				}
			}
		}
		
        NativeQuery query = this.getSessionFactory().getCurrentSession().createNativeQuery(sb.toString());
        query.addScalar("oplSeq", StringType.INSTANCE);
        query.addScalar("oplName", StringType.INSTANCE);
		query.addEntity("contentOffer", ContentOffer.class);
        query.addEntity("voiceRate", Voicerate.class);
        query.addEntity("dataRate", Datarate.class);
		query.addScalar("limit", IntegerType.INSTANCE);
		query.addScalar("promotionListId", StringType.INSTANCE);
		query.addScalar("promoType", StringType.INSTANCE);
		query.addScalar("monthPrice", LongType.INSTANCE);
		query.addScalar("isLoy4g", StringType.INSTANCE);
		query.addScalar("isNpf4g", StringType.INSTANCE);
		query.addScalar("isPos4g", StringType.INSTANCE);
		query.addScalar("is4gt5g", StringType.INSTANCE);
		query.addScalar("isLoy5g", StringType.INSTANCE);
		query.addScalar("isNpf5g", StringType.INSTANCE);
		query.addScalar("isPos5g", StringType.INSTANCE);
		query.addScalar("recommendDesc", StringType.INSTANCE);
		query.addScalar("dataUsageAmount", StringType.INSTANCE);
		query.addScalar("speedDesc", StringType.INSTANCE);
		query.addScalar("voicePremium", StringType.INSTANCE);
		query.addScalar("voicePremium2", StringType.INSTANCE);
		query.addScalar("voicePremium3", StringType.INSTANCE);
		query.addScalar("voicePremium4", StringType.INSTANCE);
		query.addScalar("otherPremium", StringType.INSTANCE);
		query.addScalar("noLimit", StringType.INSTANCE);
		query.addScalar("prepaymentPrice", LongType.INSTANCE);
		query.addScalar("bubbleText", StringType.INSTANCE);
		query.addScalar("isRecommend", StringType.INSTANCE);
		query.addScalar("recommendSort", IntegerType.INSTANCE);
        query.addScalar("pCode", StringType.INSTANCE);
        query.addScalar("projectName", StringType.INSTANCE);
        
        params.put("st", orderType.getSaleType().split(","));
		query.setProperties(params);
        List<PromotionPO> result = query.unwrap(NativeQueryImpl.class)
                .setResultTransformer(Transformers.aliasToBean(PromotionPO.class))
                .list();
        
        return result;
    }
    
	/**
	 * 1. 檢查該促案是否上架 OPL.ONSALE=Y，是否簽核通過OPL.SIGN4ONSALE=Y
	 * 2. 不可為多主商品促案 OPL.IS_MULTIPROD=N or null
	 * 3. 須為User設定的上架時間區間內 OPL.ONSALE_DATE、OPL.OFF_DATE
	 * 4. 須為ICE設定的上架時間區間內 PL.BEGINDATE、PL.ENDDATE
	 * 5. 販售類型 SALE_TYPE 須符合設定，參考OrderTypeEnum.SaleType
	 * 6. OPL.V_VOICEGROUP(語音群組)不得為空
	 * 7. GA、NP時, 語音不得為空
	 * 8. 依據GA、NP流程判斷PL的設定(EX. GA時 -> PL.IS_POS4G=Y OR PL.IS_POS5G=Y)
	 * 9. 方案期數 PL.LIMIT、PL.DATA_LIMIT兩者取最大值
	 * 10. 推薦資費Flag 需 IS_RECOMMEND == 1 且 在推薦期間內
	 * 11. RECOMMEND_SORT 需 IS_RECOMMEND == 1 且 在推薦期間內，否則為null
	 * @param orderType 訂單流程(NC、NH、PC、PH)
	 * @param promotionList 指定要撈取的促案(Ex.續約)
	 * @return List<PromotionPO>
	 * @author Dennis.Chen
	 * @date 2020-08-19
	 */
	public List<PromotionPO> getPromotions(OrderTypeEnum orderType, List<String> promotionList) {
	
	    Map<String, Object> sqlParams = new HashMap<String, Object>();
	
	    //1. 建立SQL
	    StringBuilder sb = new StringBuilder();
	    sb.append("SELECT OPL.SEQ oplSeq,                                        \n");
	    sb.append("       OPL.ONSALE_NAME oplName,                               \n");
	    sb.append("       OPL.RECOMMEND_DESC recommendDesc,                      \n");
	    sb.append("       OPL.MONTH_PRICE monthPrice,                            \n");
	    sb.append("       OPL.BUBBLE_TEXT bubbleText,                            \n");
	    sb.append("       OPL.DATA_USAGE_AMOUNT dataUsageAmount,                 \n");
	    sb.append("       OPL.SPEED_DESC speedDesc,                              \n");
	    sb.append("       OPL.VOICE_PREMIUM voicePremium,                        \n");
	    sb.append("       OPL.VOICE_PREMIUM2 voicePremium2,                      \n");
	    sb.append("       OPL.VOICE_PREMIUM3 voicePremium3,                      \n");
	    sb.append("       OPL.VOICE_PREMIUM4 voicePremium4,                      \n");
	    sb.append("       OPL.OTHER_PREMIUM otherPremium,                        \n");
	    sb.append("       OPL.NO_LIMIT noLimit,                                  \n");
        sb.append("       CASE WHEN opl.IS_RECOMMEND = 1                         \n");
        sb.append("             AND SYSDATE BETWEEN RECOMMEND_START_TIME         \n");
        sb.append("                         AND RECOMMEND_END_TIME               \n");
        sb.append("            THEN 'Y' ELSE 'N'                                 \n");
        sb.append("       END AS isRecommend,                                    \n");
        sb.append("       CASE WHEN opl.IS_RECOMMEND = 1                         \n");
        sb.append("             AND SYSDATE BETWEEN RECOMMEND_START_TIME         \n");
        sb.append("                         AND RECOMMEND_END_TIME               \n");
        sb.append("            THEN opl.RECOMMEND_SORT ELSE NULL                 \n");
        sb.append("       END AS recommendSort,                                  \n");
        sb.append("       CASE WHEN PL.LIMIT >= PL.DATA_LIMIT                    \n");
        sb.append("            THEN PL.LIMIT ELSE PL.DATA_LIMIT                  \n");
        sb.append("       END AS limit,                                          \n");
        sb.append("       PL.id promotionListId,                                 \n");
        sb.append("       PL.promo_type promoType,                               \n");
        sb.append("       PL.IS_NPF4G isNpf4g,                                   \n");
        sb.append("       PL.IS_POS4G isPos4g,                                   \n");
        sb.append("       PL.IS_NPF5G isNpf5g,                                   \n");
        sb.append("       PL.IS_POS5G isPos5g,                                   \n");
        sb.append("       PL.PREPAYMENT_PRICE prepaymentPrice,                   \n");
        sb.append("       {contentOffer.*}                                       \n");
        sb.append("   FROM ONSALE_PROMO_LIST OPL,                                \n");
        sb.append("        VOICERATE voiceRate,                                  \n");
        sb.append("        DATARATE dataRate,                                    \n");
        sb.append("        CONTENTOFFER contentOffer,                            \n");
        sb.append("        CONTENT_PROMO_MAPPING CPM,                            \n");
        sb.append("        PROMOTION_LIST PL,                                    \n");
        sb.append("        PRODUCT PROD                                          \n");
        sb.append("  WHERE OPL.promotion_list_id = pl.ID                         \n");
        sb.append("     AND OPL.V_OFFERID = voiceRate.V_OFFERID(+)               \n");
        sb.append("     AND OPL.D_OFFERID = dataRate.D_OFFERID(+)                \n");
        sb.append("     AND OPL.PROMOTION_LIST_ID = CPM.PCODE(+)                 \n");
        sb.append("     AND CPM.C_OFFERID = contentOffer.C_OFFERID(+)	         \n");
        sb.append("     AND OPL.P_PREPAIDNO = PROD.FET_NO(+)                     \n");
        sb.append("     AND OPL.V_VOICEGROUP IS NOT NULL                         \n");
        sb.append("     AND OPL.ONSALE = 'Y'                                     \n");
        sb.append("     AND voiceRate.ONSALE = 'Y' and voiceRate.ES_PRODUCT = 'Y'\n");
        sb.append("     AND dataRate.ONSALE = 'Y' and dataRate.SIGN4ONSALE = 'Y' \n");
        sb.append("     AND OPL.SIGN4ONSALE = 'Y'                                \n");
        sb.append("     AND (OPL.IS_MULTIPROD = 'N' or OPL.IS_MULTIPROD IS NULL) \n");
        sb.append("     AND (SYSDATE BETWEEN OPL.ONSALE_DATE AND OPL.OFF_DATE)   \n");
        sb.append("     AND (TRUNC(SYSDATE) BETWEEN PL.BEGINDATE AND PL.ENDDATE) \n");
        sb.append("     AND OPL.SALE_TYPE IN (:saleType)                         \n");
        sb.append("     AND OPL.ACTIVITY_ONLY != 'Y'                             \n");


        //1-1. 判斷流程
        sb.append("AND(	\n");
        if ("GA".equals(orderType.getFlow())) {
            sb.append("PL.IS_POS4G = 'Y' OR PL.IS_POS5G = 'Y'");
        }else if ("NP".equals(orderType.getFlow())) {
            sb.append("PL.IS_NPF4G = 'Y' OR PL.IS_NPF5G = 'Y'");
        }else if ("LY".equals(orderType.getFlow())) {
            sb.append("PL.IS_LOY4G = 'Y' OR PL.IS_LOY5G = 'Y'");
        }
        sb.append(") \n");

        //1-3. 指定撈取PROMOTION_LIST ID(Ex.續約)
        if (promotionList != null && promotionList.size() > 0){
            int round = promotionList.size() / 1000 + (promotionList.size() % 1000 > 0 ? 1 : 0);
            sb.append("AND (1=0 \n");
            for(int i = 0; i < round; i++) {
                String promoIds = promotionList.stream()
                        .skip(i*1000)
                        .limit(1000)
                        .collect(Collectors.joining("','", "OR PL.ID IN ('", "')"));
                sb.append(promoIds);
            }
            sb.append(") \n");
        }

        //2. 放入Query參數值
        sqlParams.put("saleType", orderType.getSaleType().split(","));

        //3. 執行SQL
        NativeQuery query = this.getSessionFactory().getCurrentSession().createNativeQuery(sb.toString());
        query.addScalar("oplSeq", StringType.INSTANCE);
        query.addScalar("oplName", StringType.INSTANCE);
        query.addScalar("recommendDesc", StringType.INSTANCE);
        query.addScalar("monthPrice", LongType.INSTANCE);
        query.addScalar("bubbleText", StringType.INSTANCE);
        query.addScalar("dataUsageAmount", StringType.INSTANCE);
        query.addScalar("speedDesc", StringType.INSTANCE);
        query.addScalar("voicePremium", StringType.INSTANCE);
        query.addScalar("voicePremium2", StringType.INSTANCE);
        query.addScalar("voicePremium3", StringType.INSTANCE);
        query.addScalar("voicePremium4", StringType.INSTANCE);
        query.addScalar("otherPremium", StringType.INSTANCE);
        query.addScalar("noLimit", StringType.INSTANCE);
        query.addScalar("isRecommend", StringType.INSTANCE);
        query.addScalar("recommendSort", IntegerType.INSTANCE);
        query.addScalar("limit", IntegerType.INSTANCE);
        query.addScalar("promotionListId", StringType.INSTANCE);
        query.addScalar("promoType", StringType.INSTANCE);
        query.addEntity("contentOffer", ContentOffer.class);
        query.addScalar("isNpf4g", StringType.INSTANCE);
        query.addScalar("isPos4g", StringType.INSTANCE);
        query.addScalar("isNpf5g", StringType.INSTANCE);
        query.addScalar("isPos5g", StringType.INSTANCE);
        query.addScalar("prepaymentPrice", LongType.INSTANCE);
        query.setProperties(sqlParams);
        List<PromotionPO> result = query.unwrap(NativeQueryImpl.class)
                                        .setResultTransformer(Transformers.aliasToBean(PromotionPO.class))
                                        .list();

        return result;
    }

	@Override
	public Map<String, String> getOnsalePromoListDataByPcode(String pcode, List<String> outputColumns) {
		
		Map<String, String> res = new HashMap<String,String>();
		Map<String, StringType> scalarMap = new HashMap<String, StringType>();
		Map<String, String> paramMap = new HashMap<String,String>();
		StringBuilder sb = new StringBuilder();
		
		if (outputColumns == null || outputColumns.isEmpty()) {
			return res;
		}
		
		sb.append("SELECT '1'");
		
		outputColumns.stream().forEach(column->{
			sb.append(",\n");
			sb.append(column);
			scalarMap.put(column, StringType.INSTANCE);
		});
		
		sb.append(" FROM ONSALE_PROMO_LIST WHERE PCODE = :pcode");
		paramMap.put("pcode", pcode);
		
		NativeQuery query = this.getSessionFactory().getCurrentSession().createNativeQuery(sb.toString());
		

		if (scalarMap != null) {
			scalarMap.forEach((k,v)->query.addScalar(k,v));
		}
		
		if (scalarMap != null) {
			query.setProperties(paramMap);
		}
		
		List<Map<String, String>> qryRes = query.unwrap(NativeQueryImpl.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).list();
		
		if (qryRes == null && qryRes.isEmpty()) {
			return res;
		} else {
			return (Map<String, String>) qryRes.get(0);
		}
		
	}

    /**
     * 取得促案限定料號
     * @param oplIds
     * @return
     */
    @Override
    public Map<String, Set<String>> findPromoProdMap(List<String> oplIds) {
        Map<String, Set<String>> promoProds = new LinkedHashMap<String, Set<String>>();
        if(oplIds == null || oplIds.isEmpty()) return promoProds;

        StringBuilder sb = new StringBuilder();
        sb.append(" select distinct oph.onsale_promo_list_id,    ");
        sb.append("        p.fet_no                              ");
        sb.append("    from onsale_promo_handset oph,            ");
        sb.append("         product p                            ");
        sb.append("   where oph.onsale_promo_list_id in (:opls)  ");
        sb.append("     and oph.handset_group_id = p.product_id  ");

        SQLQuery qry = this.getSessionFactory().getCurrentSession().createSQLQuery(sb.toString());
        qry.addScalar("onsale_promo_list_id", StringType.INSTANCE);
        qry.addScalar("fet_no"              , StringType.INSTANCE);
        qry.setParameterList("opls", oplIds);

        List<Object[]> list = qry.list();
        for(Object[] objArr : list) {
            String oplid = objArr[ 0] != null && objArr[ 0] instanceof String ? (String) objArr[ 0] : null;
            String fetno = objArr[ 1] != null && objArr[ 1] instanceof String ? (String) objArr[ 1] : null;

            if(!promoProds.containsKey(oplid)) promoProds.put(oplid, new HashSet<String>());
            promoProds.get(oplid).add(fetno);
        }

        return promoProds;
    }

    /**
     * 取得商品關聯促案(可查多個商品)
     * @param fetNos
     * @param findProductBO
     * @return
     */
    public List<PromotionPO> getProductsRelatedPromo(List<String> fetNos, FindProductBO findProductBO, ActivityPromoBO activityPromoBO) {
        OrderTypeEnum orderType = findProductBO.getOrderType();
        if (orderType != null && !orderType.hasDev()) {
            LogUtil.warn("非搭商品賣場進來撈促案，程式邏輯上可能需要盤點");
            return new ArrayList<>();
        }

        //1. 建立SQL
        Map<String, Object> params = new HashMap<>();
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT OPL.SEQ oplSeq,                                        \n");
        sql.append("       OPL.ONSALE_NAME oplName,                               \n");
        sql.append("       OPL.MONTH_PRICE monthPrice,                            \n");
        sql.append("       OPL.PCODE pCode,                                       \n");
        sql.append("       OPL.IS_HOME_DELIVERABLE homeDeliverable,               \n");
        sql.append("       OPL.IS_STORE_DELIVERABLE storeDeliverable,             \n");
        sql.append("       PL.id promotionListId,                                 \n");
        sql.append("       PL.promo_type promoType,                               \n");
        sql.append("       PL.PREPAYMENT_PRICE prepaymentPrice,                   \n");
        sql.append("       PL.PROJECT_NAME projectName,                           \n");
        sql.append("       PL.IS_POS4G isPos4g,                                   \n");
        sql.append("       PL.IS_POS5G isPos5g,                                   \n");
        sql.append("       PL.IS_NPF4G isNpf4g,                                   \n");
        sql.append("       PL.IS_NPF5G isNpf5g,                                   \n");
        sql.append("       PL.IS_LOY4G isLoy4g,                                   \n");
        sql.append("       PL.IS_LOY5G isLoy5g,                                   \n");
        sql.append("       PL.IS_4GT5G is4gt5g,                                   \n");
        sql.append("       POS.PRICE posPrice,                                    \n");
        sql.append("       POS.PRODNO fetNo                                       \n");
        sql.append("   FROM ONSALE_PROMO_LIST OPL,                                \n");
        sql.append("        VOICERATE voiceRate,                                  \n");
        sql.append("        DATARATE dataRate,                                    \n");
        sql.append("        PROMOTION_LIST PL,                                    \n");
        sql.append("        PRODUCT PROD,                                         \n");
        sql.append("        (SELECT P.*                                           \n");
        sql.append("           FROM POS P                                         \n");
        sql.append("          WHERE P.PRODNO IN (:fetNos)) POS                    \n");
        sql.append("  WHERE OPL.promotion_list_id = pl.ID                         \n");
        sql.append("     AND OPL.POS_PCODE = POS.PROMOTION_ID                     \n");
        sql.append("     AND OPL.V_OFFERID = voiceRate.V_OFFERID(+)               \n");
        sql.append("     AND OPL.D_OFFERID = dataRate.D_OFFERID(+)                \n");
        sql.append("     AND OPL.P_PREPAIDNO = PROD.FET_NO(+)                     \n");
        sql.append("     AND OPL.V_VOICEGROUP IS NOT NULL                         \n");
        sql.append("     AND OPL.ONSALE = 'Y'                                     \n");
        sql.append("     AND voiceRate.ONSALE = 'Y' AND voiceRate.ES_PRODUCT = 'Y'\n");
        sql.append("     AND dataRate.ONSALE = 'Y' AND dataRate.SIGN4ONSALE = 'Y' \n");
        sql.append("     AND OPL.SIGN4ONSALE = 'Y'                                \n");
        sql.append("     AND (OPL.IS_MULTIPROD = 'N' OR OPL.IS_MULTIPROD IS NULL) \n");
        sql.append("     AND (SYSDATE BETWEEN OPL.ONSALE_DATE AND OPL.OFF_DATE)   \n");
        sql.append("     AND (TRUNC(SYSDATE) BETWEEN PL.BEGINDATE AND PL.ENDDATE) \n");


        //1-1. 判斷流程
        if(orderType != null) {
            sql.append("AND(	\n");
            if ("GA".equals(orderType.getFlow())) {
                sql.append("PL.IS_POS4G = 'Y' OR PL.IS_POS5G = 'Y'");
            } else if ("NP".equals(orderType.getFlow())) {
                sql.append("PL.IS_NPF4G = 'Y' OR PL.IS_NPF5G = 'Y'");
            } else if ("LY".equals(orderType.getFlow())) {
                // 如果查無續約促案就需顯示GA/NP促案專案價，所以續約一起查出再由程式判斷
                sql.append("PL.IS_LOY4G = 'Y' OR PL.IS_LOY5G = 'Y' OR PL.IS_4GT5G = 'Y'");
                sql.append(" OR PL.IS_POS4G = 'Y' OR PL.IS_POS5G = 'Y'");
                sql.append(" OR PL.IS_NPF4G = 'Y' OR PL.IS_NPF5G = 'Y'");
            }
            sql.append(") \n");
            sql.append("     AND OPL.SALE_TYPE IN (:saleType)                         \n");
            params.put("saleType", orderType.getSaleType().split(","));
        }

        //1-2. 處理活動相關判斷
        if(activityPromoBO != null) {
            if (activityPromoBO.isNormalAct()) {
                //1-2-1. 一般賣場，促案ACTIVITY_ONLY不可等於Y
                sql.append("AND OPL.ACTIVITY_ONLY != 'Y' \n");

            } else {
                List<String> activityPromoList = activityPromoBO.getActivityPromoList();

                //1-2-1. 活動賣場，若該活動賣場為EBU專屬，則只撈取EBU促案
                sql.append("AND NVL(OPL.iS_EBU, 'N') = :isEbu \n");
                params.put("isEbu", activityPromoBO.isEbu() ? "Y" : "N");

                //1-2-2. 撈取活動賣場所設定開賣的促案
                if (activityPromoList != null && activityPromoList.size() > 0) {
                    sql.append("AND OPL.SEQ IN (:activityPromoList) \n");
                    params.put("activityPromoList", activityPromoList);
                }
            }
        }

        //2. 放入Query參數值
        params.put("fetNos", fetNos);

        Map<String, Type> scalar = new HashMap<>();
        scalar.put("oplSeq", StringType.INSTANCE);
        scalar.put("oplName", StringType.INSTANCE);
        scalar.put("monthPrice", LongType.INSTANCE);
        scalar.put("promotionListId", StringType.INSTANCE);
        scalar.put("promoType", StringType.INSTANCE);
        scalar.put("prepaymentPrice", LongType.INSTANCE);
        scalar.put("posPrice", LongType.INSTANCE);
        scalar.put("pCode", StringType.INSTANCE);
        scalar.put("projectName", StringType.INSTANCE);
        scalar.put("fetNo", StringType.INSTANCE);
        scalar.put("homeDeliverable", NumericBooleanType.INSTANCE);
        scalar.put("storeDeliverable", NumericBooleanType.INSTANCE);
        scalar.put("isPos4g", StringType.INSTANCE);
        scalar.put("isPos5g", StringType.INSTANCE);
        scalar.put("isNpf4g", StringType.INSTANCE);
        scalar.put("isNpf5g", StringType.INSTANCE);
        scalar.put("isLoy4g", StringType.INSTANCE);
        scalar.put("isLoy5g", StringType.INSTANCE);
        scalar.put("is4gt5g", StringType.INSTANCE);

        return executeQuery(sql, scalar, params, PromotionPO.class);
    }
	
}
