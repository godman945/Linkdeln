package com.fet.estore.core.bean;

import java.util.List;

public class ActivityInitRes {

    private boolean hasCoupon;
    private boolean hasNameList;
    private String nameListColumn;
    private boolean couponRegisterDemand;
	private String lightboxTitle1;
	private String lightboxTitle2;
	private List<String> orderTypeList;
	private String activityOrderType;
	// 是否為員工續約賣場
	private boolean isEmployeeAct;
	private boolean isEbu;

	public boolean isHasCoupon() {
		return hasCoupon;
	}
	public void setHasCoupon(boolean hasCoupon) {
		this.hasCoupon = hasCoupon;
	}
	public boolean isHasNameList() {
		return hasNameList;
	}
	public void setHasNameList(boolean hasNameList) {
		this.hasNameList = hasNameList;
	}
	public String getNameListColumn() {
		return nameListColumn;
	}
	public void setNameListColumn(String nameListColumn) {
		this.nameListColumn = nameListColumn;
	}
	public boolean getCouponRegisterDemand() {
		return couponRegisterDemand;
	}
	public void setCouponRegisterDemand(boolean couponRegisterDemand) {
		this.couponRegisterDemand = couponRegisterDemand;
	}
	public String getLightboxTitle1() {
		return lightboxTitle1;
	}
	public void setLightboxTitle1(String lightboxTitle1) {
		this.lightboxTitle1 = lightboxTitle1;
	}
	public String getLightboxTitle2() {
		return lightboxTitle2;
	}
	public void setLightboxTitle2(String lightboxTitle2) {
		this.lightboxTitle2 = lightboxTitle2;
	}
	public List<String> getOrderTypeList() {
		return orderTypeList;
	}
	public void setOrderTypeList(List<String> orderTypeList) {
		this.orderTypeList = orderTypeList;
	}
	public boolean isEbu() {
		return isEbu;
	}
	public void setEbu(boolean ebu) {
		isEbu = ebu;
	}
	public String getActivityOrderType() {
		return activityOrderType;
	}
	public void setActivityOrderType(String activityOrderType) {
		this.activityOrderType = activityOrderType;
	}
	public boolean getIsEmployeeAct() {
		return isEmployeeAct;
	}
	public void setIsEmployeeAct(boolean isEmployeeAct) {
		this.isEmployeeAct = isEmployeeAct;
	}
}
