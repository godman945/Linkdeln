package com.fet.estore.core.bean.req;

public class CredentialSubmitReq {
	private boolean uploadLater;
	private String staffType;
	private boolean isHealthIdCard;
	public boolean getUploadLater() {
		return uploadLater;
	}

	public void setUploadLater(boolean uploadLater) {
		this.uploadLater = uploadLater;
	}

	public String getStaffType() {
		return staffType;
	}

	public void setStaffType(String staffType) {
		this.staffType = staffType;
	}

	public boolean getIsHealthIdCard() {
		return isHealthIdCard;
	}

	public void setIsHealthIdCard(boolean isHealthIdCard) {
		this.isHealthIdCard = isHealthIdCard;
	}

}
