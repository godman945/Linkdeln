package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.CurPersonalGreeting;

public interface ICurPersonalGreetingDao extends BaseDAO<CurPersonalGreeting, String>{
}
