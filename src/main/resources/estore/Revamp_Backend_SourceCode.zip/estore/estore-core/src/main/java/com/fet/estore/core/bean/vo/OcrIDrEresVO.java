package com.fet.estore.core.bean.vo;

import com.fet.estore.core.bean.vo.frontend.Address;

public class OcrIDrEresVO implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;

	/**
	 * 辨識任務代號，8 碼日期+7 碼流水
	號 共 15 碼，例：201702020000001 此參數目前不建議使用 
	 */
	String ocrSN;
	
	/**
	 * 判斷是否有錯誤或權限不足或是
	該資料不存在的代碼
	 */
	String errorCode;
	 
	  
	/**
	 * 判斷證件類別（附表 IDR 證件種類
	代碼及名稱對照） 
	傳回證件名稱
	 */
	String idType; 
	
	IdNum1 idNum1 = new IdNum1();
	
	IdNum2 idNum2 = new IdNum2();
	
	IdNum31 idNum31 = new IdNum31();
	
	IdNum41 idNum41 = new IdNum41();
	
	Address ocrVailAddr = new Address();
	

	public String getOcrSN() {
		return ocrSN;
	}
	public void setOcrSN(String ocrSN) {
		this.ocrSN = ocrSN;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public IdNum1 getIdNum1() {
		return idNum1;
	}
	public void setIdNum1(IdNum1 idNum1) {
		this.idNum1 = idNum1;
	}
	public IdNum2 getIdNum2() {
		return idNum2;
	}
	public void setIdNum2(IdNum2 idNum2) {
		this.idNum2 = idNum2;
	}
	public IdNum31 getIdNum31() {
		return idNum31;
	}
	public void setIdNum31(IdNum31 idNum31) {
		this.idNum31 = idNum31;
	}
	public IdNum41 getIdNum41() {
		return idNum41;
	}
	public void setIdNum41(IdNum41 idNum41) {
		this.idNum41 = idNum41;
	}
	public Address getOcrVailAddr() {
		return ocrVailAddr;
	}
	public void setOcrVailAddr(Address ocrVailAddr) {
		this.ocrVailAddr = ocrVailAddr;
	}




	//身分證正面 
	public class IdNum1 implements java.io.Serializable {
		
		private static final long serialVersionUID = 1L;
		/**
		 * 身份證號
		 */
		String id; 
		
		/**
		 * 姓名
		 */
		String name;
		
		/**
		 * 生日
		 */
		String birthday;    
		
		/**
		 * 發行日期
		 */
		String issuedDate; 
		
		/**
		 * 發行狀態 
		換、補、初 
		換發傳回換、補發傳回
		補、初發傳回初 
		 */
		String issuedStatus;  
		
		
		/**
		 * 發行狀態 換發、補發、初發 
		 */
		String issuedStatusFull;
		
		/**
		 *  發行城市 身份證正面的發照城市
		 */
		String issuedCity;
		
		/**
		 * 性別
		 */
		String sex;
		
		/**
		 * 生日八碼數字 19781005
		 */
		String birthdayYyyymmdd;
		
		//解析身分證(ISSUED_DATE)與駕照(ISSUED_DATE)、行照(REGISTRATION_DATE)的發證日期轉換八個數字 YYYYMMDD 
		/**
		 * 發證日期八碼數字 19781005 
		 */
		String issuedateYyyymmdd;

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getBirthday() {
			return birthday;
		}

		public void setBirthday(String birthday) {
			this.birthday = birthday;
		}

		public String getIssuedDate() {
			return issuedDate;
		}

		public void setIssuedDate(String issuedDate) {
			this.issuedDate = issuedDate;
		}

		public String getIssuedStatus() {
			return issuedStatus;
		}

		public void setIssuedStatus(String issuedStatus) {
			this.issuedStatus = issuedStatus;
		}

		public String getIssuedStatusFull() {
			return issuedStatusFull;
		}

		public void setIssuedStatusFull(String issuedStatusFull) {
			this.issuedStatusFull = issuedStatusFull;
		}

		public String getIssuedCity() {
			return issuedCity;
		}

		public void setIssuedCity(String issuedCity) {
			this.issuedCity = issuedCity;
		}

		public String getSex() {
			return sex;
		}

		public void setSex(String sex) {
			this.sex = sex;
		}

		public String getBirthdayYyyymmdd() {
			return birthdayYyyymmdd;
		}

		public void setBirthdayYyyymmdd(String birthdayYyyymmdd) {
			this.birthdayYyyymmdd = birthdayYyyymmdd;
		}

		public String getIssuedateYyyymmdd() {
			return issuedateYyyymmdd;
		}

		public void setIssuedateYyyymmdd(String issuedateYyyymmdd) {
			this.issuedateYyyymmdd = issuedateYyyymmdd;
		}
		
		
	}
	//身分證反面
	public class IdNum2 implements java.io.Serializable {
		
		private static final long serialVersionUID = 1L;
		/**
		 * 序號
		 */
		String sn; 
		
		/**
		 * 配偶
		 */
		String spouse;  
		
		/**
		 * 父親
		 */
		String father;   
		     
		/**
		 * 母親
		 */
		String mother;
		
		/**
		 *  地址 完整的住址
		 */
		String address;
		
		/**
		 *  出生地 
		 */
		String birthPlace;
		
		/**
		 * 役別
		 */
		String military;
		
		/**
		 * 條碼  
		 */
		String barcode;
		
		//依據(ADDRESS)取得的地址,解析該地址切段擴充的欄位 
		/**
		 * 第一段縣市地址 
		身份證反面、中華民國
		駕照(新版)、中華民國
		汽車行車執照、中華民
		國機車行車執照的縣市 
		 */
		String address1st; 
		/**
		 * 第二段鄉鎮市區地址 
		身份證反面、中華民國
		駕照(新版)、中華民國
		汽車行車執照、中華民
		國機車行車執照的鄉鎮
		市區 
		 */
		String address2nd; 
		/**
		 * 第三段除縣市及鄉鎮市區外的地
		址 
		身份證反面、中華民國
		駕照(新版)、中華民國
		汽車行車執照、中華民
		國機車行車執照中除了
		縣市及鄉鎮市區外的地
		址 
		 */
		String address3rd; 
		
		
		
		//依據(ADDRESS)取得的地址,解析該地址切段擴充的欄位 
		
		/**
		 *  縣市 內容將含縣、市等字樣
		 */
		String addressSplit1; 
		
		/**
		 *  鄉鎮市區 內容將含鄉、鎮、市、
		區等字樣 
		 */
		String addressSplit2;
		
		
		/**
		 *  里
		 */
		String addressSplit3;   
		
		/**
		 *  鄰
		 */
		String addressSplit4;   
		/**
		 *  村
		 */
		String addressSplit5;   
		
		/**
		 *  路
		 */
		String addressSplit6;   
		
		/**
		 *  街
		 */
		String addressSplit7;   
		/**
		 *  大道
		 */
		String addressSplit8;   
		
		/**
		 *  段
		 */
		String addressSplit9;   
		/**
		 *  巷
		 */
		String addressSplit10;   
		/**
		 *  弄 
		 */
		String addressSplit11;  
		/**
		 *  號
		 */
		String addressSplit12;   
		/**
		 *  之
		 */
		String addressSplit13;   
		/**
		 *  樓
		 */
		String addressSplit14;   
		/**
		 *  室 
		 */
		String addressSplit15;  
		/**
		 * 地方名 例: 後窟潭
		 */
		String addressSplit16;
		public String getSn() {
			return sn;
		}
		public void setSn(String sn) {
			this.sn = sn;
		}
		public String getSpouse() {
			return spouse;
		}
		public void setSpouse(String spouse) {
			this.spouse = spouse;
		}
		public String getFather() {
			return father;
		}
		public void setFather(String father) {
			this.father = father;
		}
		public String getMother() {
			return mother;
		}
		public void setMother(String mother) {
			this.mother = mother;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getBirthPlace() {
			return birthPlace;
		}
		public void setBirthPlace(String birthPlace) {
			this.birthPlace = birthPlace;
		}
		public String getMilitary() {
			return military;
		}
		public void setMilitary(String military) {
			this.military = military;
		}
		public String getBarcode() {
			return barcode;
		}
		public void setBarcode(String barcode) {
			this.barcode = barcode;
		}
		public String getAddress1st() {
			return address1st;
		}
		public void setAddress1st(String address1st) {
			this.address1st = address1st;
		}
		public String getAddress2nd() {
			return address2nd;
		}
		public void setAddress2nd(String address2nd) {
			this.address2nd = address2nd;
		}
		public String getAddress3rd() {
			return address3rd;
		}
		public void setAddress3rd(String address3rd) {
			this.address3rd = address3rd;
		}
		public String getAddressSplit1() {
			return addressSplit1;
		}
		public void setAddressSplit1(String addressSplit1) {
			this.addressSplit1 = addressSplit1;
		}
		public String getAddressSplit2() {
			return addressSplit2;
		}
		public void setAddressSplit2(String addressSplit2) {
			this.addressSplit2 = addressSplit2;
		}
		public String getAddressSplit3() {
			return addressSplit3;
		}
		public void setAddressSplit3(String addressSplit3) {
			this.addressSplit3 = addressSplit3;
		}
		public String getAddressSplit4() {
			return addressSplit4;
		}
		public void setAddressSplit4(String addressSplit4) {
			this.addressSplit4 = addressSplit4;
		}
		public String getAddressSplit5() {
			return addressSplit5;
		}
		public void setAddressSplit5(String addressSplit5) {
			this.addressSplit5 = addressSplit5;
		}
		public String getAddressSplit6() {
			return addressSplit6;
		}
		public void setAddressSplit6(String addressSplit6) {
			this.addressSplit6 = addressSplit6;
		}
		public String getAddressSplit7() {
			return addressSplit7;
		}
		public void setAddressSplit7(String addressSplit7) {
			this.addressSplit7 = addressSplit7;
		}
		public String getAddressSplit8() {
			return addressSplit8;
		}
		public void setAddressSplit8(String addressSplit8) {
			this.addressSplit8 = addressSplit8;
		}
		public String getAddressSplit9() {
			return addressSplit9;
		}
		public void setAddressSplit9(String addressSplit9) {
			this.addressSplit9 = addressSplit9;
		}
		public String getAddressSplit10() {
			return addressSplit10;
		}
		public void setAddressSplit10(String addressSplit10) {
			this.addressSplit10 = addressSplit10;
		}
		public String getAddressSplit11() {
			return addressSplit11;
		}
		public void setAddressSplit11(String addressSplit11) {
			this.addressSplit11 = addressSplit11;
		}
		public String getAddressSplit12() {
			return addressSplit12;
		}
		public void setAddressSplit12(String addressSplit12) {
			this.addressSplit12 = addressSplit12;
		}
		public String getAddressSplit13() {
			return addressSplit13;
		}
		public void setAddressSplit13(String addressSplit13) {
			this.addressSplit13 = addressSplit13;
		}
		public String getAddressSplit14() {
			return addressSplit14;
		}
		public void setAddressSplit14(String addressSplit14) {
			this.addressSplit14 = addressSplit14;
		}
		public String getAddressSplit15() {
			return addressSplit15;
		}
		public void setAddressSplit15(String addressSplit15) {
			this.addressSplit15 = addressSplit15;
		}
		public String getAddressSplit16() {
			return addressSplit16;
		}
		public void setAddressSplit16(String addressSplit16) {
			this.addressSplit16 = addressSplit16;
		}
		
		
		
		
		
	}
	//中華民國駕照 (新版) 
	public class IdNum31 implements java.io.Serializable {
		
		private static final long serialVersionUID = 1L;
		/**
		 * 身份證號
		 */
		String id;
		/**
		 * 序號
		 */
		String sn;
		/**
		 * 姓名
		 */
		String name;
		/**
		 *  地址 完整的住址
		 */
		String address;
		/**
		 * 生日
		 */
		String birthday;
		/**
		 * 發行日期
		 */
		String issuedDate;    
		
		/**
		 *  到期日期 
		 */
		String expiryDate;
		
		/**
		 * 性別
		 */
		String sex;
		/**
		 * 車輛類別  
		 */
		String category; 
		
		/**
		 * 附加條件
		 */
		String condition;
		/**
		 *  縣市 內容將含縣、市等字樣
		 */
		String addressSplit1; 
		
		/**
		 *  鄉鎮市區 內容將含鄉、鎮、市、
		區等字樣 
		 */
		String addressSplit2;
		
		
		/**
		 *  里
		 */
		String addressSplit3;   
		
		/**
		 *  鄰
		 */
		String addressSplit4;   
		/**
		 *  村
		 */
		String addressSplit5;   
		
		/**
		 *  路
		 */
		String addressSplit6;   
		
		/**
		 *  街
		 */
		String addressSplit7;   
		/**
		 *  大道
		 */
		String addressSplit8;   
		
		/**
		 *  段
		 */
		String addressSplit9;   
		/**
		 *  巷
		 */
		String addressSplit10;   
		/**
		 *  弄 
		 */
		String addressSplit11;  
		/**
		 *  號
		 */
		String addressSplit12;   
		/**
		 *  之
		 */
		String addressSplit13;   
		/**
		 *  樓
		 */
		String addressSplit14;   
		/**
		 *  室 
		 */
		String addressSplit15;  
		/**
		 * 地方名 例: 後窟潭
		 */
		String addressSplit16;
		
		/**
		 * 發證日期八碼數字 19781005 
		 */
		String issuedateYyyymmdd;
		
		/**
		 * 生日八碼數字 19781005
		 */
		String birthdayYyyymmdd;
		
		/**
		 * 第一段縣市地址 
		身份證反面、中華民國
		駕照(新版)、中華民國
		汽車行車執照、中華民
		國機車行車執照的縣市 
		 */
		String address1st; 
		/**
		 * 第二段鄉鎮市區地址 
		身份證反面、中華民國
		駕照(新版)、中華民國
		汽車行車執照、中華民
		國機車行車執照的鄉鎮
		市區 
		 */
		String address2nd; 
		/**
		 * 第三段除縣市及鄉鎮市區外的地
		址 
		身份證反面、中華民國
		駕照(新版)、中華民國
		汽車行車執照、中華民
		國機車行車執照中除了
		縣市及鄉鎮市區外的地
		址 
		 */
		String address3rd;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getSn() {
			return sn;
		}
		public void setSn(String sn) {
			this.sn = sn;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getBirthday() {
			return birthday;
		}
		public void setBirthday(String birthday) {
			this.birthday = birthday;
		}
		public String getIssuedDate() {
			return issuedDate;
		}
		public void setIssuedDate(String issuedDate) {
			this.issuedDate = issuedDate;
		}
		public String getExpiryDate() {
			return expiryDate;
		}
		public void setExpiryDate(String expiryDate) {
			this.expiryDate = expiryDate;
		}
		public String getSex() {
			return sex;
		}
		public void setSex(String sex) {
			this.sex = sex;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public String getCondition() {
			return condition;
		}
		public void setCondition(String condition) {
			this.condition = condition;
		}
		public String getAddressSplit1() {
			return addressSplit1;
		}
		public void setAddressSplit1(String addressSplit1) {
			this.addressSplit1 = addressSplit1;
		}
		public String getAddressSplit2() {
			return addressSplit2;
		}
		public void setAddressSplit2(String addressSplit2) {
			this.addressSplit2 = addressSplit2;
		}
		public String getAddressSplit3() {
			return addressSplit3;
		}
		public void setAddressSplit3(String addressSplit3) {
			this.addressSplit3 = addressSplit3;
		}
		public String getAddressSplit4() {
			return addressSplit4;
		}
		public void setAddressSplit4(String addressSplit4) {
			this.addressSplit4 = addressSplit4;
		}
		public String getAddressSplit5() {
			return addressSplit5;
		}
		public void setAddressSplit5(String addressSplit5) {
			this.addressSplit5 = addressSplit5;
		}
		public String getAddressSplit6() {
			return addressSplit6;
		}
		public void setAddressSplit6(String addressSplit6) {
			this.addressSplit6 = addressSplit6;
		}
		public String getAddressSplit7() {
			return addressSplit7;
		}
		public void setAddressSplit7(String addressSplit7) {
			this.addressSplit7 = addressSplit7;
		}
		public String getAddressSplit8() {
			return addressSplit8;
		}
		public void setAddressSplit8(String addressSplit8) {
			this.addressSplit8 = addressSplit8;
		}
		public String getAddressSplit9() {
			return addressSplit9;
		}
		public void setAddressSplit9(String addressSplit9) {
			this.addressSplit9 = addressSplit9;
		}
		public String getAddressSplit10() {
			return addressSplit10;
		}
		public void setAddressSplit10(String addressSplit10) {
			this.addressSplit10 = addressSplit10;
		}
		public String getAddressSplit11() {
			return addressSplit11;
		}
		public void setAddressSplit11(String addressSplit11) {
			this.addressSplit11 = addressSplit11;
		}
		public String getAddressSplit12() {
			return addressSplit12;
		}
		public void setAddressSplit12(String addressSplit12) {
			this.addressSplit12 = addressSplit12;
		}
		public String getAddressSplit13() {
			return addressSplit13;
		}
		public void setAddressSplit13(String addressSplit13) {
			this.addressSplit13 = addressSplit13;
		}
		public String getAddressSplit14() {
			return addressSplit14;
		}
		public void setAddressSplit14(String addressSplit14) {
			this.addressSplit14 = addressSplit14;
		}
		public String getAddressSplit15() {
			return addressSplit15;
		}
		public void setAddressSplit15(String addressSplit15) {
			this.addressSplit15 = addressSplit15;
		}
		public String getAddressSplit16() {
			return addressSplit16;
		}
		public void setAddressSplit16(String addressSplit16) {
			this.addressSplit16 = addressSplit16;
		}
		public String getIssuedateYyyymmdd() {
			return issuedateYyyymmdd;
		}
		public void setIssuedateYyyymmdd(String issuedateYyyymmdd) {
			this.issuedateYyyymmdd = issuedateYyyymmdd;
		}
		public String getAddress1st() {
			return address1st;
		}
		public void setAddress1st(String address1st) {
			this.address1st = address1st;
		}
		public String getAddress2nd() {
			return address2nd;
		}
		public void setAddress2nd(String address2nd) {
			this.address2nd = address2nd;
		}
		public String getAddress3rd() {
			return address3rd;
		}
		public void setAddress3rd(String address3rd) {
			this.address3rd = address3rd;
		}
		public String getBirthdayYyyymmdd() {
			return birthdayYyyymmdd;
		}
		public void setBirthdayYyyymmdd(String birthdayYyyymmdd) {
			this.birthdayYyyymmdd = birthdayYyyymmdd;
		}
		
		
		
	}
	//台灣健保卡
	public class IdNum41 implements java.io.Serializable {
		
		private static final long serialVersionUID = 1L;
		/**
		 * 身份證號
		 */
		String id;
		/**
		 * 序號
		 */
		String sn;
		/**
		 * 姓名
		 */
		String name;
		
		/**
		 * 生日
		 */
		String birthday;
		/**
		 * 生日八碼數字 19781005
		 */
		String birthdayYyyymmdd;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getSn() {
			return sn;
		}
		public void setSn(String sn) {
			this.sn = sn;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getBirthday() {
			return birthday;
		}
		public void setBirthday(String birthday) {
			this.birthday = birthday;
		}
		public String getBirthdayYyyymmdd() {
			return birthdayYyyymmdd;
		}
		public void setBirthdayYyyymmdd(String birthdayYyyymmdd) {
			this.birthdayYyyymmdd = birthdayYyyymmdd;
		}
		
	}
	
}
