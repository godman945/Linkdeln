package com.fet.estore.core.bean.req;

public class CreateShopeeOrderReq {

	/** 加密訂單編號 */
	private String cono;

	public String getCono() {
		return cono;
	}

	public void setCono(String cono) {
		this.cono = cono;
	}
}
