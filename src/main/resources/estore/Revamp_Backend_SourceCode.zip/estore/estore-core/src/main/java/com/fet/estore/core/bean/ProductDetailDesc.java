package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ProductDetailDesc implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 商品介紹頁面區塊標題 */
    private String key;
    /** 商品介紹頁面區塊內容 */
    private List<?> value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public List<?> getValue() {
        return value;
    }

    public void setValue(List<?> value) {
        this.value = value;
    }
}
