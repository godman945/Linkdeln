package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-09-04
 * @description
 */
public class ActivityBean implements Serializable {

    private Long activityId;

    private String orderType;

    public Long getActivityId() {
        return activityId;
    }
    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }
    public String getOrderType() {
        return orderType;
    }
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
}
