package com.fet.estore.core.bean.vo.frontend;


/**
 * 活動促案VO
 * @author Max Chen
 *
 */
public class ActivityRateplanGroupVO {

	/** 識別值 */
	private Long id;

	/** 促貸圖片 */
	private String imagePath;
	
	/** 促貸Title */
	private String title;	
	
	/** 活動敘述 */
	private String priceTitle;	
		
	/** 活動價格 */
	private Long price;
	
	/** 訂單型態 */
	private String[] orderTypes;

	/** 小網圖片 */
	private String mobileImagePath;
	
	/** 小網抬頭 */
	private String mobileTitle;
	
	/** 小網描述 */
	private String mobileDescription;
	
	/** 版型:長型或方型 **/
    private String format;
    
    /** 左上方錦旗文字**/
    private String leftUpperText;
    
    /** 按鈕文字**/
    private String submitButtonText;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPriceTitle() {
		return priceTitle;
	}

	public void setPriceTitle(String priceTitle) {
		this.priceTitle = priceTitle;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public String[] getOrderTypes() {
		return orderTypes;
	}

	public void setOrderTypes(String[] orderType) {
		this.orderTypes = orderType;
	}

	public String getMobileImagePath() {
		return mobileImagePath;
	}

	public void setMobileImagePath(String mobileImagePath) {
		this.mobileImagePath = mobileImagePath;
	}

	public String getMobileTitle() {
		return mobileTitle;
	}

	public void setMobileTitle(String mobileTitle) {
		this.mobileTitle = mobileTitle;
	}

	public String getMobileDescription() {
		return mobileDescription;
	}

	public void setMobileDescription(String mobileDescription) {
		this.mobileDescription = mobileDescription;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getLeftUpperText() {
		return leftUpperText;
	}

	public void setLeftUpperText(String leftUpperText) {
		this.leftUpperText = leftUpperText;
	}

	public String getSubmitButtonText() {
		return submitButtonText;
	}

	public void setSubmitButtonText(String submitButtonText) {
		this.submitButtonText = submitButtonText;
	}
}
