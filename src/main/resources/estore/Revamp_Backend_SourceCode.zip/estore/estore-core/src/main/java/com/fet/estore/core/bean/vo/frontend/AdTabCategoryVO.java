/**
 * 頁籤分類設定檔
 */
package com.fet.estore.core.bean.vo.frontend;

/**
 * @author Brian
 * 
 */
public class AdTabCategoryVO {

	/** 頁籤編號 */
	private String adTabId;
	/** 分類編號 */
	private String categoryId;


	public String getAdTabId() {
		return adTabId;
	}

	public void setAdTabId(String adTabId) {
		this.adTabId = adTabId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

}