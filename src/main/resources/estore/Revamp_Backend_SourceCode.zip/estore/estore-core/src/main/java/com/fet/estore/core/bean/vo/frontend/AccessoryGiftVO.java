package com.fet.estore.core.bean.vo.frontend;

import com.fet.estore.core.bean.vo.IDiscountItem;

/**
 * 配件贈品VO
 * @author Max Chen
 *
 */
public class AccessoryGiftVO implements IDiscountItem {
	private String giftName;
	private String giftProdId;
	private String accProdId;
	
	public String getGiftName() {
		return giftName;
	}
	public void setGiftName(String	giftName) {
		this.giftName = giftName;
	}
	public String getGiftProdId() {
		return giftProdId;
	}
	public void setGiftProdId(String giftProdId) {
		this.giftProdId = giftProdId;
	}
	public String getAccProdId() {
		return accProdId;
	}
	public void setAccProdId(String accProdId) {
		this.accProdId = accProdId;
	}

	@Override
	public Long getAaiId() {
		return null;
	}

	@Override
	public String getCode() {
		return giftProdId;
	}

	@Override
	public String getFetNo() {
		return giftProdId;
	}

	@Override
	public Long getActivityId() {
		return null;
	}

	@Override
	public String getName() {
		return giftName;
	}

	@Override
	public Long getAmount() {
		return null;
	}

	@Override
	public Long getCouponId() {
		return null;
	}

	@Override
	public Long getOfferId() {
		return null;
	}

	@Override
	public Long getCostCenterId() {
		return null;
	}

	@Override
	public Double getDiscountRatio() {
		return null;
	}

	@Override
	public Long getActualDiscountAmt() {
		return null;
	}

	@Override
	public String getDisplayGroup() {
		return null;
	}
	@Override
	public String getDiscountName() {
		return null;
	}
}
