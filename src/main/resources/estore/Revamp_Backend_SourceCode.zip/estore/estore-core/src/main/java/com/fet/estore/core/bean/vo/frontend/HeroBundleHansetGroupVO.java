package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

public class HeroBundleHansetGroupVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7229294298084504236L;

	private Long heroBundleId;
	private String productId;
	/**申辦流程 */
	private String coType;
	/**標題1 */
	private String title1;
	/**標題2 */
	private String title2;
	/**內容1 */
	private String content1;
	/**內容2 */
	private String content2;
	/**內容3 */
	private String content3;
	/**內容4 */
	private String content4;
	/**內容5 */
	private String content5;
	/**圖檔路徑 */
	private String promotionImagePath;
	/**上架促代ID */
	private String onsalePromoListId;
	/** title1 highlight */
	private String title1Highlight;
	/** title2 highlight */
	private String title2Highlight;
	
	private String[] heroBundleContents;
	
	private String promoType;
	
	public Long getHeroBundleId() {
		return heroBundleId;
	}
	public void setHeroBundleId(Long heroBundleId) {
		this.heroBundleId = heroBundleId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getCoType() {
		return coType;
	}
	public void setCoType(String coType) {
		this.coType = coType;
	}
	public String getTitle1() {
		return title1;
	}
	public void setTitle1(String title1) {
		this.title1 = title1;
	}
	public String getTitle2() {
		return title2;
	}
	public void setTitle2(String title2) {
		this.title2 = title2;
	}
	public String getContent1() {
		return content1;
	}
	public void setContent1(String content1) {
		this.content1 = content1;
	}
	public String getContent2() {
		return content2;
	}
	public void setContent2(String content2) {
		this.content2 = content2;
	}
	public String getPromotionImagePath() {
		return promotionImagePath;
	}
	public void setPromotionImagePath(String promotionImagePath) {
		this.promotionImagePath = promotionImagePath;
	}
	public String getOnsalePromoListId() {
		return onsalePromoListId;
	}
	public void setOnsalePromoListId(String onsalePromoListId) {
		this.onsalePromoListId = onsalePromoListId;
	}
	public String getContent3() {
		return content3;
	}
	public void setContent3(String content3) {
		this.content3 = content3;
	}
	public String getContent4() {
		return content4;
	}
	public void setContent4(String content4) {
		this.content4 = content4;
	}
	public String getContent5() {
		return content5;
	}
	public void setContent5(String content5) {
		this.content5 = content5;
	}
	public String getTitle1Highlight() {
		return title1Highlight;
	}
	public void setTitle1Highlight(String title1Highlight) {
		this.title1Highlight = title1Highlight;
	}
	public String getTitle2Highlight() {
		return title2Highlight;
	}
	public void setTitle2Highlight(String title2Highlight) {
		this.title2Highlight = title2Highlight;
	}
	public String[] getHeroBundleContents() {
		heroBundleContents = new String[]{this.content1,this.content2,this.content3,this.content4,this.content5};
		return heroBundleContents;
	}
	public void setHeroBundleContents(String[] heroBundleContents) {
		this.heroBundleContents = heroBundleContents;
	}
	public String getPromoType() {
		return promoType;
	}
	public void setPromoType(String promoType) {
		this.promoType = promoType;
	}
	
	
}
