package com.fet.estore.core.bean.vo;

import java.util.List;

/**
 * @Description 促案VO，前端所需欄位
 * @author Dennis.Chen
 * @date 2020-08-19
 */
public class OnsalePromoVO {

    String oplSeq; //OPL SEQ 欄位
    String promotionListId; //OPL PROMOTION_LIST_ID 欄位
    String ribbon; //卡牌左上標籤
    String value; //促案縮寫
    String unit; //月租
    Long price; //月租費
    Long prepay; //預繳款
    String month; //合約期數
    String note; //推薦備註
    String generation; // G數
    String interVoice; //網外通話(VoicePremium)
    String outerVoice; //網內通話(VoicePremium2)
    String cityVoice; //市話
    Long posPrice; //商品專案價
    Long discountPrice; //折扣後價格
    String dataUsageAmount; //上網用量
    String voicePremium; //語音優惠(VoicePremium4)
    String otherPremium; //活動優惠
    String isRecommend; //是否為推薦資費
    Integer recommendSort; //推薦資費順序
    List<String> tag; //搜尋用貼標
    List<ContentOfferVO> contentOfferList; //C約
    String pCode; //促案代碼
    Long actPromoSort; //活動促案順序
    boolean isAnchorCenter; //是否為定錨的中心點，若為true則該卡牌需在畫面中央
    String oplName; //User定義的促案名稱
    boolean isNotify; //是否需跳出提醒(例如九個月一證促案須提醒)
    String projectName; //ICE定義的促案名稱
    String voiceRateId;
    String dataRateId;

    public String getOplSeq() {
        return oplSeq;
    }

    public void setOplSeq(String oplSeq) {
        this.oplSeq = oplSeq;
    }

    public String getPromotionListId() {
        return promotionListId;
    }

    public void setPromotionListId(String promotionListId) {
        this.promotionListId = promotionListId;
    }

    public String getRibbon() {
        return ribbon;
    }

    public void setRibbon(String ribbon) {
        this.ribbon = ribbon;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public Long getPrepay() {
        return prepay;
    }

    public void setPrepay(Long prepay) {
        this.prepay = prepay;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public String getInterVoice() {
        return interVoice;
    }

    public void setInterVoice(String interVoice) {
        this.interVoice = interVoice;
    }

    public String getOuterVoice() {
        return outerVoice;
    }

    public void setOuterVoice(String outerVoice) {
        this.outerVoice = outerVoice;
    }

    public String getCityVoice() {
        return cityVoice;
    }

    public void setCityVoice(String cityVoice) {
        this.cityVoice = cityVoice;
    }

    public Long getPosPrice() {
        return posPrice;
    }

    public void setPosPrice(Long posPrice) {
        this.posPrice = posPrice;
    }

    public Long getDiscountPrice() {
        return discountPrice;
    }

    public void setDiscountPrice(Long discountPrice) {
        this.discountPrice = discountPrice;
    }

    public String getDataUsageAmount() {
        return dataUsageAmount;
    }

    public void setDataUsageAmount(String dataUsageAmount) {
        this.dataUsageAmount = dataUsageAmount;
    }

    public String getVoicePremium() {
        return voicePremium;
    }

    public void setVoicePremium(String voicePremium) {
        this.voicePremium = voicePremium;
    }

    public String getOtherPremium() {
        return otherPremium;
    }

    public void setOtherPremium(String otherPremium) {
        this.otherPremium = otherPremium;
    }

    public String getIsRecommend() {
        return isRecommend;
    }

    public void setIsRecommend(String isRecommend) {
        this.isRecommend = isRecommend;
    }

    public Integer getRecommendSort() {
        return recommendSort;
    }

    public void setRecommendSort(Integer recommendSort) {
        this.recommendSort = recommendSort;
    }

    public List<String> getTag() {
        return tag;
    }

    public void setTag(List<String> tag) {
        this.tag = tag;
    }

    public List<ContentOfferVO> getContentOfferList() {
        return contentOfferList;
    }

    public void setContentOfferList(List<ContentOfferVO> contentOfferList) {
        this.contentOfferList = contentOfferList;
    }

	public String getpCode() {
		return pCode;
	}

	public void setpCode(String pCode) {
		this.pCode = pCode;
	}

    public Long getActPromoSort() {
        return actPromoSort;
    }

    public void setActPromoSort(Long actPromoSort) {
        this.actPromoSort = actPromoSort;
    }

    public boolean isAnchorCenter() {
        return isAnchorCenter;
    }

    public void setAnchorCenter(boolean anchorCenter) {
        isAnchorCenter = anchorCenter;
    }

    public String getOplName() {
        return oplName;
    }

    public void setOplName(String oplName) {
        this.oplName = oplName;
    }

    public boolean isNotify() {
        return isNotify;
    }

    public void setNotify(boolean notify) {
        isNotify = notify;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getVoiceRateId() {
        return voiceRateId;
    }

    public void setVoiceRateId(String voiceRateId) {
        this.voiceRateId = voiceRateId;
    }

    public String getDataRateId() {
        return dataRateId;
    }

    public void setDataRateId(String dataRateId) {
        this.dataRateId = dataRateId;
    }
}
