package com.fet.estore.core.bean.bo;

import com.fet.estore.core.enums.OrderTypeEnum;
import com.fet.estore.core.model.Activity;
import com.fet.estore.core.util.StringUtil;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-20
 * @description
 */
public class ShoppingResultBO {

    /** 訂單類型*/
    private OrderTypeEnum orderType;
    /** 原價 */
    private Long totalErpPrice = 0L;
    /** 折扣價 */
    private Long totalDiscPrice = 0L;
    /** 折扣金額 */
    private Long totalDiscAmount = 0L;
    /** 可折抵金額 */
    private Long totalCanDiscPrice = 0L;
    /** 預繳金額 */
    private Long prepaidPrice;
    /** 門號競標得標價 */
    private Long auctionPrice;
    /** 運費 */
    private Long shipmentPrice;
    /** 有折HappyGo */
    private boolean hasHg;
    /** 是否為組合折扣活動 */
    private boolean isHsAct;
    /** 組合折扣活動ID */
    private Long mpActId;
    /** 組合折扣活動折扣金額 */
    private Long totalHSDiscAmount;
    /** 銷售通道 */
    private String channel;

    private String[] productIds;

    private String[] accessoryIds;

    /**
     * 推算出來的價格
     */
    private Long cpnDiscPrice;

    private Long[] hgDiscountData;

    /** 儲存之計算BO */
    /** 所有商品 */
    private List<ShoppingResultProductBO> productBOs = new ArrayList<>();

    private List<ShoppingResultDiscountBO> discountBOs = new ArrayList<>();

    private List<ShoppingResultAwardBO> offerAwards  = new ArrayList<>();
    private List<ShoppingResultAwardBO> giftAwards   = new ArrayList<>();
    private List<ShoppingResultAwardBO> couponAwards = new ArrayList<>();

    private List<ShoppingResultMultiSetBO> multiSetBOs = new ArrayList<>();

    private List<String> couponErrorMsg;


    public OrderTypeEnum getOrderType() {
        return orderType;
    }
    public void setOrderType(OrderTypeEnum orderType) {
        this.orderType = orderType;
    }
    public Long getTotalErpPrice() {
        return totalErpPrice;
    }
    public void setTotalErpPrice(Long totalErpPrice) {
        this.totalErpPrice = totalErpPrice;
    }
    public Long getTotalDiscPrice() {
        return totalDiscPrice;
    }
    public void setTotalDiscPrice(Long totalDiscPrice) {
        this.totalDiscPrice = totalDiscPrice;
    }
    public Long getTotalDiscAmount() {
        return totalDiscAmount;
    }
    public void setTotalDiscAmount(Long totalDiscAmount) {
        this.totalDiscAmount = totalDiscAmount;
    }
    public Long getTotalCanDiscPrice() {
        return totalCanDiscPrice;
    }
    public void setTotalCanDiscPrice(Long totalCanDiscPrice) {
        this.totalCanDiscPrice = totalCanDiscPrice;
    }
    public Long getPrepaidPrice() {
        return prepaidPrice;
    }
    public void setPrepaidPrice(Long prepaidPrice) {
        this.prepaidPrice = prepaidPrice;
    }
    public Long getAuctionPrice() {
        return auctionPrice;
    }
    public void  setAuctionPrice(Long auctionPrice) {
        this.auctionPrice = auctionPrice;
    }
    public Long getShipmentPrice() {
        return shipmentPrice;
    }
    public void setShipmentPrice(Long shipmentPrice) {
        this.shipmentPrice = shipmentPrice;
    }
    public boolean isHasHg() {
        return hasHg;
    }
    public void setHasHg(boolean hasHg) {
        this.hasHg = hasHg;
    }
    public boolean isHsAct() {
        return isHsAct;
    }
    public void setHsAct(boolean hsAct) {
        isHsAct = hsAct;
    }
    public Long getMpActId() {
        return mpActId;
    }
    public void setMpActId(Long mpActId) {
        this.mpActId = mpActId;
    }
    public Long getTotalHSDiscAmount() {
        return totalHSDiscAmount;
    }
    public void setTotalHSDiscAmount(Long totalHSDiscAmount) {
        this.totalHSDiscAmount = totalHSDiscAmount;
    }

    public void add(ShoppingResultProductBO productBO) {
        productBOs.add(productBO);
    }
    public List<ShoppingResultProductBO> getProductBOs() {
        return productBOs;
    }
    public void setProductBOs(List<ShoppingResultProductBO> productBOs) {
        this.productBOs = productBOs;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }
    public List<ShoppingResultAwardBO> getOfferAwards() {
        return offerAwards;
    }
    public void setOfferAwards(List<ShoppingResultAwardBO> offerAwards) {
        this.offerAwards = offerAwards;
    }
    public List<ShoppingResultAwardBO> getGiftAwards() {
        return giftAwards;
    }
    public void setGiftAwards(List<ShoppingResultAwardBO> giftAwards) {
        this.giftAwards = giftAwards;
    }
    public List<ShoppingResultAwardBO> getCouponAwards() {
        return couponAwards;
    }
    public void setCouponAwards(List<ShoppingResultAwardBO> couponAwards) {
        this.couponAwards = couponAwards;
    }
    public void add(ShoppingResultDiscountBO discountBO) {
        this.discountBOs.add(discountBO);
    }
    public void addAll(List<ShoppingResultDiscountBO> discountBOs) {
        this.discountBOs.addAll(discountBOs);
    }
    public List<ShoppingResultMultiSetBO> getMultiSetBOs() {
        return multiSetBOs;
    }
    public void setMultiSetBOs(List<ShoppingResultMultiSetBO> multiSetBOs) {
        this.multiSetBOs = multiSetBOs;
    }
    public List<ShoppingResultDiscountBO> getDiscountBOs() {
        return discountBOs;
    }
    public List<String> getCouponErrorMsg() {
        return couponErrorMsg;
    }
    public void setCouponErrorMsg(List<String> couponErrorMsg) {
        this.couponErrorMsg = couponErrorMsg;
    }

    /**
     * 取得Coupon折扣金額
     * @return
     */
    public Long getCouponDiscountPrice() {
        Long cpnDiscPrice = 0L;
        for(ShoppingResultProductBO prod : productBOs) {
            for(ShoppingResultDiscountBO prodDisc : prod.getDiscounts()) {
                if(!ShoppingResultDiscountBO.TYPE_COUPON.equals(prodDisc.getType())) continue;
                cpnDiscPrice += prodDisc.getActualDiscountAmt();
            }
        }
        return cpnDiscPrice;
    }

    /**
     * 取得HappyGO折扣金額/點數
     * @return LONG [金額, 點數]
     */
    public Long[] getHgDiscountData() {
        Long hgDiscPrice = 0L;
        Long hgDiscPoints = 0L;
        for(ShoppingResultDiscountBO disc : discountBOs) {
            if(!ShoppingResultDiscountBO.TYPE_HG.equals(disc.getType())) continue;
            hgDiscPrice += disc.getActualDiscountAmt();
            hgDiscPoints += disc.getHgActPoints();
        }
        return new Long[] {hgDiscPrice, hgDiscPoints};
    }

    /**
     * 取得所有商品原價
     * @return
     */
    public Map<String, Long> getERPPriceByFetno() {
        Map<String, Long> erpPrices = new HashMap<String, Long>();
        for(ShoppingResultProductBO prod : productBOs) {
            String fetNo = prod.getFetNo();
            Long erpPrice = prod.getErpPrice();
            erpPrices.put(fetNo, erpPrice);
        }
        return erpPrices;
    }

    /**
     * 取得所有商品優惠價
     * @return
     */
    public Map<String, Long> getDiscountPriceByFetno() {
        Map<String, Long> discPrices = new HashMap<>();
        for(ShoppingResultProductBO prod : productBOs) {
            String fetNo = prod.getFetNo();
            Long discPrice = prod.getDiscPrice();
            discPrices.put(fetNo, discPrice);
        }
        return discPrices;
    }

    /**
     * 取得所有商品單機優惠價
     * @return
     */
    public Map<String, Long> getDaDiscountPriceByFetno() {
        Map<String, Long> discPrices = new HashMap<String, Long>();
        for(ShoppingResultProductBO prod : productBOs) {
            String fetNo = prod.getFetNo();
            Long discPrice = prod.getDaDiscPrice();
            discPrices.put(fetNo, discPrice);
        }
        return discPrices;
    }

    /** 取得各贈品清單 */
    public List<ShoppingResultAwardBO> getAwards(String awardType) {
        switch (awardType) {
            case "ALL":
                return getAllAwards();
            case Activity.AWARD_ITEM_AWARD_TYPE_COUPON:
                return getCouponAwards();
            case Activity.AWARD_ITEM_AWARD_TYPE_GIFT:
                return getGiftAwards();
            case Activity.AWARD_ITEM_AWARD_TYPE_OFFER:
                return getOfferAwards();
            default:
                return new ArrayList<>();

        }
    }

    public List<ShoppingResultAwardBO> getAllAwards(){
        List<ShoppingResultAwardBO> result = new ArrayList<>();
        result.addAll(couponAwards);
        result.addAll(giftAwards);
        result.addAll(offerAwards);
        for (ShoppingResultProductBO productBO : productBOs) {
            result.addAll(productBO.getCouponAwards());
            result.addAll(productBO.getGiftAwards());
            result.addAll(productBO.getOfferAwards());
        }
        result.sort(new AwardComparator());
        return result;
    }

    public List<ShoppingResultAwardBO> getAllCouponAwards() {
        List<ShoppingResultAwardBO> result = new ArrayList<>();
        result.addAll(couponAwards);
        for (ShoppingResultProductBO productBO : productBOs) {
            result.addAll(productBO.getCouponAwards());
        }
        result.sort(new AwardComparator());
        return result;
    }

    public List<ShoppingResultAwardBO> getAllGiftAwards() {
        List<ShoppingResultAwardBO> result = new ArrayList<>();
        result.addAll(giftAwards);
        for (ShoppingResultProductBO productBO : productBOs) {
            result.addAll(productBO.getGiftAwards());
        }
        result.sort(new AwardComparator());
        return result;
    }

    public List<ShoppingResultAwardBO> getAllOfferAwards() {
        List<ShoppingResultAwardBO> result = new ArrayList<>();
        result.addAll(offerAwards);
        for (ShoppingResultProductBO productBO : productBOs) {
            result.addAll(productBO.getOfferAwards());
        }
        result.sort(new AwardComparator());
        return result;
    }

    /**
     * 贈品清單排序類別
     * @author Max Chen
     */
    private static class AwardComparator implements Comparator<ShoppingResultAwardBO> {
        private String orderPattern = "";
        AwardComparator() {
            String[] tpOrderArr = {
                    Activity.AWARD_ITEM_AWARD_TYPE_GIFT,
                    Activity.AWARD_ITEM_AWARD_TYPE_COUPON,
                    Activity.AWARD_ITEM_AWARD_TYPE_OFFER
            };
            StringBuilder sb = new StringBuilder();
            for(String tpOrder : tpOrderArr) {
                sb.append(String.format("[%s]", tpOrder));
            }
            orderPattern = sb.toString();
        }

        public int compare(ShoppingResultAwardBO d1, ShoppingResultAwardBO d2) {
            String t1 = String.format("[%s]", (d1.getType() != null ? d1.getType() : ""));
            String t2 = String.format("[%s]", (d2.getType() != null ? d2.getType() : ""));

            int idx1 = orderPattern.indexOf(t1);
            int idx2 = orderPattern.indexOf(t2);
            if(idx1 == -1) idx1 = Integer.MAX_VALUE;
            if(idx2 == -1) idx2 = Integer.MAX_VALUE;

            return idx1 - idx2;
        }
    }

    /** 取得所有折扣清單, 但包含指定折扣, 及排除部份折扣 (指定折扣優先) */
    // 原getAllDiscounts
    public List<ShoppingResultDiscountBO> getDiscounts(String[] includeTypes, String[] excludeTypes) {
        List<ShoppingResultDiscountBO> discs = getDiscounts("ALL");
        boolean hasIncl = includeTypes != null && includeTypes.length > 0;
        boolean hasExcl = excludeTypes != null && excludeTypes.length > 0;

        List<ShoppingResultDiscountBO> partialDiscs = new ArrayList<>();
        for(ShoppingResultDiscountBO disc : discs) {
            String type = disc.getType();
            if(hasIncl && !StringUtil.isInList(includeTypes, type)) continue;
            if(hasExcl &&  StringUtil.isInList(excludeTypes, type)) continue;
            partialDiscs.add(disc);
        }
        return partialDiscs;
    }

    /** 取得各折扣清單 */
    private List<ShoppingResultDiscountBO> getDiscounts(String discType) {
        List<ShoppingResultDiscountBO> discs = new ArrayList<>();
        if(discType == null) return discs;

        for(ShoppingResultDiscountBO disc : discountBOs) {
            String type = disc.getType();
            Long actDisc = disc.getActualDiscountAmt();
            boolean isCpn = ShoppingResultDiscountBO.TYPE_COUPON.equals(type);
            if(actDisc == null || (actDisc == 0L && !isCpn))
                continue;
            if(discType.equals(type) || "ALL".equals(discType)) {
                discs.add(disc);
            }
        }

        // 組合活動折扣
        for(ShoppingResultMultiSetBO bos : multiSetBOs) {
            List<ShoppingResultDiscountBO> setdiscs = bos.getDiscounts();
            for(ShoppingResultDiscountBO disc : setdiscs) {
                Long actDisc = disc.getActualDiscountAmt();
                if(actDisc == null || actDisc == 0L) continue;
                discs.add(disc);
            }
        }

        String[] mpTypes = new String[] {ShoppingResultDiscountBO.TYPE_MP_ACT_FIXED,
                ShoppingResultDiscountBO.TYPE_MP_ACT_MARKUP,
                ShoppingResultDiscountBO.TYPE_MP_ACT_RATIO,
                ShoppingResultDiscountBO.TYPE_MP_ACT_PLUS };

        for(ShoppingResultProductBO prod : productBOs) {
            for(ShoppingResultDiscountBO disc : prod.getDiscounts()) {
                String type = disc.getType();
                Long actDisc = disc.getActualDiscountAmt();
                if(actDisc == null || actDisc == 0L) continue;
                if(StringUtil.isInList(mpTypes, type)) continue; // 略過組合活動
                if(discType.equals(type) || "ALL".equals(discType)) discs.add(disc);
            }
        }
        // 依特定折扣排序
        discs.sort(new DiscountComparator());
        return discs;
    }

    /**
     * 折扣清單排序類別
     * @author Max Chen
     */
    private class DiscountComparator implements Comparator<ShoppingResultDiscountBO> {
        private String orderPattern = "";
        public DiscountComparator() {
            String[] tpOrderArr = {
                    ShoppingResultDiscountBO.TYPE_OVERALL_HG    ,
                    ShoppingResultDiscountBO.TYPE_OVERALL_ACC   ,
                    ShoppingResultDiscountBO.TYPE_ACC_ACT       ,
                    ShoppingResultDiscountBO.TYPE_MP_DISC_FIXED ,
                    ShoppingResultDiscountBO.TYPE_MP_DISC_MARKUP,
                    ShoppingResultDiscountBO.TYPE_MP_DISC_RATIO ,
                    ShoppingResultDiscountBO.TYPE_MP_ACT_FIXED  ,
                    ShoppingResultDiscountBO.TYPE_MP_ACT_MARKUP ,
                    ShoppingResultDiscountBO.TYPE_MP_ACT_RATIO  ,
                    ShoppingResultDiscountBO.TYPE_MP_ACT_PLUS   ,
                    ShoppingResultDiscountBO.TYPE_EB            ,
                    ShoppingResultDiscountBO.TYPE_ACT           ,
                    ShoppingResultDiscountBO.TYPE_COUPON        ,
                    ShoppingResultDiscountBO.TYPE_HG
            };
            StringBuilder sb = new StringBuilder();
            for(String tpOrder : tpOrderArr) sb.append(String.format("[%s]", tpOrder));
            orderPattern = sb.toString();
        }

        public int compare(ShoppingResultDiscountBO d1, ShoppingResultDiscountBO d2) {
            String t1 = String.format("[%s]", (d1.getType() != null ? d1.getType() : ""));
            String t2 = String.format("[%s]", (d2.getType() != null ? d2.getType() : ""));

            int idx1 = orderPattern.indexOf(t1);
            int idx2 = orderPattern.indexOf(t2);
            if(idx1 == -1) idx1 = Integer.MAX_VALUE;
            if(idx2 == -1) idx2 = Integer.MAX_VALUE;

            return idx1 - idx2;
        }
    }
}
