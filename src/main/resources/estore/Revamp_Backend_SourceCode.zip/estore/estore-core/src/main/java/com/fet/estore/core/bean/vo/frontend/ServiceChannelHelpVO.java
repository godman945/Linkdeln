package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceChannelHelpVO implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4934930041445566945L;
	
	/** 是否為App導購 */
	private boolean appFlow;
    private String orderChannel;
    
	public boolean isAppFlow() {
		return appFlow;
	}
	public void setAppFlow(boolean appFlow) {
		this.appFlow = appFlow;
	}
	public String getOrderChannel() {
		return orderChannel;
	}
	public void setOrderChannel(String orderChannel) {
		this.orderChannel = orderChannel;
	}
    
}
