package com.fet.estore.core.bean.vo.frontend;

/**
 * 前台WebTrends的value object。
 *
 */
public class WebTrendsVO {

    // Channel Id
    private String dcsChannelId;

    // ContentGroup 內容群組
    private String wtCgn;
    private String wtCgs;
    private String wtCgsub;
    private String wtCgsub2;
    private String wtCgsub3;

    // Flow 流程步驟
    /** 流程 */
    private String wtSin;
    /** 步驟 */
    private String wtSip;

    // CSPUser 登入使用者資訊(member.dat)
    private boolean wtHasCSPUser;
    /** 會員UID */
    private String wtDcsvid;
    /** 性別;教育程度;地區;職業;收入 */
    private String wtSeg1;
    /** 識別會員(0:NonSIM/1: SIM) */
    private String wtSeg2;
    /** 年齡 */
    private String wtSeg3;
    /** 是否VIP */
    private String wtSeg4;
    /** VIP等級 */
    private String wtSeg5;

    // Billing 申購完成資料(scenario.dat)
    private boolean wtDone;
    private String wtTxe;
    /** 商品編號 */
    private String wtPnSku;
    /** 商品名稱 */
    private String wtPn;
    /** 付款方式 */
    private String wtTxt;
    /** 商品數量 */
    private String wtTxu;
    /** 商品金額 */
    private String wtTxs;
    /** 訂單編號 */
    private String wtTxi;
    /** 訂單成立日期(mm/dd/yyyy) */
    private String wtTxid;
    /** 訂單成立時間(hh:mm:ss) */
    private String wtTxit;
    /** 商品類別名稱 */
    private String wtPncg;

    public String getDcsChannelId() {
        return dcsChannelId;
    }
    public void setDcsChannelId(String dcsChannelId) {
        this.dcsChannelId = dcsChannelId;
    }
    public String getWtCgn() {
        return wtCgn;
    }
    public void setWtCgn(String wtCgn) {
        this.wtCgn = wtCgn;
    }
    public String getWtCgs() {
        return wtCgs;
    }
    public void setWtCgs(String wtCgs) {
        this.wtCgs = wtCgs;
    }
    public String getWtCgsub() {
        return wtCgsub;
    }
    public void setWtCgsub(String wtCgsub) {
        this.wtCgsub = wtCgsub;
    }
    public String getWtCgsub2() {
        return wtCgsub2;
    }
    public void setWtCgsub2(String wtCgsub2) {
        this.wtCgsub2 = wtCgsub2;
    }
    public String getWtCgsub3() {
        return wtCgsub3;
    }
    public void setWtCgsub3(String wtCgsub3) {
        this.wtCgsub3 = wtCgsub3;
    }
    public String getWtSin() {
        return wtSin;
    }
    public void setWtSin(String wtSin) {
        this.wtSin = wtSin;
    }
    public String getWtSip() {
        return wtSip;
    }
    public void setWtSip(String wtSip) {
        this.wtSip = wtSip;
    }
    public boolean isWtHasCSPUser() {
        return wtHasCSPUser;
    }
    public void setWtHasCSPUser(boolean wtHasCSPUser) {
        this.wtHasCSPUser = wtHasCSPUser;
    }
    public String getWtDcsvid() {
        return wtDcsvid;
    }
    public void setWtDcsvid(String wtDcsvid) {
        this.wtDcsvid = wtDcsvid;
    }
    public String getWtSeg1() {
        return wtSeg1;
    }
    public void setWtSeg1(String wtSeg1) {
        this.wtSeg1 = wtSeg1;
    }
    public String getWtSeg2() {
        return wtSeg2;
    }
    public void setWtSeg2(String wtSeg2) {
        this.wtSeg2 = wtSeg2;
    }
    public String getWtSeg3() {
        return wtSeg3;
    }
    public void setWtSeg3(String wtSeg3) {
        this.wtSeg3 = wtSeg3;
    }
    public String getWtSeg4() {
        return wtSeg4;
    }
    public void setWtSeg4(String wtSeg4) {
        this.wtSeg4 = wtSeg4;
    }
    public String getWtSeg5() {
        return wtSeg5;
    }
    public void setWtSeg5(String wtSeg5) {
        this.wtSeg5 = wtSeg5;
    }
    public boolean isWtDone() {
        return wtDone;
    }
    public void setWtDone(boolean wtDone) {
        this.wtDone = wtDone;
    }
    public String getWtTxe() {
        return wtTxe;
    }
    public void setWtTxe(String wtTxe) {
        this.wtTxe = wtTxe;
    }
    public String getWtPnSku() {
        return wtPnSku;
    }
    public void setWtPnSku(String wtPnSku) {
        this.wtPnSku = wtPnSku;
    }
    public String getWtPn() {
        return wtPn;
    }
    public void setWtPn(String wtPn) {
        this.wtPn = wtPn;
    }
    public String getWtTxt() {
        return wtTxt;
    }
    public void setWtTxt(String wtTxt) {
        this.wtTxt = wtTxt;
    }
    public String getWtTxu() {
        return wtTxu;
    }
    public void setWtTxu(String wtTxu) {
        this.wtTxu = wtTxu;
    }
    public String getWtTxs() {
        return wtTxs;
    }
    public void setWtTxs(String wtTxs) {
        this.wtTxs = wtTxs;
    }
    public String getWtTxi() {
        return wtTxi;
    }
    public void setWtTxi(String wtTxi) {
        this.wtTxi = wtTxi;
    }
    public String getWtTxid() {
        return wtTxid;
    }
    public void setWtTxid(String wtTxid) {
        this.wtTxid = wtTxid;
    }
    public String getWtTxit() {
        return wtTxit;
    }
    public void setWtTxit(String wtTxit) {
        this.wtTxit = wtTxit;
    }
    public String getWtPncg() {
        return wtPncg;
    }
    public void setWtPncg(String wtPncg) {
        this.wtPncg = wtPncg;
    }
}
