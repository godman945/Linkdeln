package com.fet.estore.core.dao.newstore;

import java.util.List;

import com.fet.estore.core.bean.BreadCrumbs;
import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.enums.BreadcrumsEnum;
import com.fet.estore.core.model.CoHistory;

public interface ICfgBreadCrumbsDao extends BaseDAO<CoHistory, String>{
	
	public List<BreadCrumbs> getBreadCrumbs(BreadcrumsEnum breadcrum);
}
