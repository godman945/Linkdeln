package com.fet.estore.core.bean.vo.frontend;

import java.util.ArrayList;
import java.util.List;

/**
 * 折扣計算結果 - 商品結果VO
 * @author Max Chen
 *
 */
public class DiscountResultProductVO {

	/** 組合活動群組ID */
	private int grp;
	/** 料號 */
	private String fetNo;
	/** 商品ID */
	private String productId;
	/** (群組內)序號 */
	private int sn;
	/** 是否為配件 */
	private boolean isAcc;
	/** 是否被歸到組合商品 */
	private boolean inSet;
	/** 加價購折扣ID */
	private Long mpDiscId;
	
	/** 原價 */
	private Long erpPrice;
	/** 折扣價 */
	private Long discPrice;
	/** 折扣金額 */
	private Long discAmount;
	
	/** 名稱 */
	private String name;
	
	/** 群組名稱 */
	private String grpName;
	
	/** 單機優惠價 */
	private Long daDiscPrice;
	
	/** 是否NDS加價購 */
	private boolean isExtraBuy;
	/** NDS加價購ID */
	private Integer extraBuyId;
	/** NDS加價購項目ID */
	private Integer extraBuyItemId;
	/** NDS加價購類別 */
	private String extraBuyType;
	/** NDS加價購數量*/
	private Integer extraBuyQty;
	
	/** 專屬優惠ID */
	private Long premiumId;
	/** 專屬優惠群組(1:必選/2:可選) */
	private Integer premiumGroup;
	
	private List<DiscountResultDiscountVO> discounts = new ArrayList<DiscountResultDiscountVO>();
		
	private List<DiscountResultAwardVO> offerAwards  = new ArrayList<DiscountResultAwardVO>();
	private List<DiscountResultAwardVO> giftAwards   = new ArrayList<DiscountResultAwardVO>();
	private List<DiscountResultAwardVO> couponAwards = new ArrayList<DiscountResultAwardVO>();

	public int getGrp() {
		return grp;
	}

	public void setGrp(int grp) {
		this.grp = grp;
	}

	public String getFetNo() {
		return fetNo;
	}

	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

	public int getSn() {
		return sn;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public Long getErpPrice() {
		return erpPrice;
	}

	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}

	public Long getDiscPrice() {
		return discPrice;
	}

	public void setDiscPrice(Long discPrice) {
		this.discPrice = discPrice;
	}

	public Long getDiscAmount() {
		return discAmount;
	}

	public void setDiscAmount(Long discAmount) {
		this.discAmount = discAmount;
	}

	public List<DiscountResultDiscountVO> getDiscounts() {
		return discounts;
	}

	public void setDiscounts(List<DiscountResultDiscountVO> discounts) {
		this.discounts = discounts;
	}
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public boolean isAcc() {
		return isAcc;
	}

	public void setAcc(boolean isAcc) {
		this.isAcc = isAcc;
	}

	public boolean isInSet() {
		return inSet;
	}

	public void setInSet(boolean inSet) {
		this.inSet = inSet;
	}

	public Long getMpDiscId() {
		return mpDiscId;
	}

	public void setMpDiscId(Long mpDiscId) {
		this.mpDiscId = mpDiscId;
	}

	public Long getDaDiscPrice() {
		return daDiscPrice;
	}

	public void setDaDiscPrice(Long daDiscPrice) {
		this.daDiscPrice = daDiscPrice;
	}

	public List<DiscountResultAwardVO> getOfferAwards() {
		return offerAwards;
	}

	public void setOfferAwards(List<DiscountResultAwardVO> offerAwards) {
		this.offerAwards = offerAwards;
	}

	public List<DiscountResultAwardVO> getGiftAwards() {
		return giftAwards;
	}

	public void setGiftAwards(List<DiscountResultAwardVO> giftAwards) {
		this.giftAwards = giftAwards;
	}

	public List<DiscountResultAwardVO> getCouponAwards() {
		return couponAwards;
	}

	public void setCouponAwards(List<DiscountResultAwardVO> couponAwards) {
		this.couponAwards = couponAwards;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGrpName() {
		return grpName;
	}

	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}

	public boolean isExtraBuy() {
		return isExtraBuy;
	}

	public void setExtraBuy(boolean isExtraBuy) {
		this.isExtraBuy = isExtraBuy;
	}

	public Integer getExtraBuyId() {
		return extraBuyId;
	}

	public void setExtraBuyId(Integer extraBuyId) {
		this.extraBuyId = extraBuyId;
	}

	public Integer getExtraBuyItemId() {
		return extraBuyItemId;
	}

	public void setExtraBuyItemId(Integer extraBuyItemId) {
		this.extraBuyItemId = extraBuyItemId;
	}

	public String getExtraBuyType() {
		return extraBuyType;
	}

	public void setExtraBuyType(String extraBuyType) {
		this.extraBuyType = extraBuyType;
	}

	public Integer getExtraBuyQty() {
		return extraBuyQty;
	}

	public void setExtraBuyQty(Integer extraBuyQty) {
		this.extraBuyQty = extraBuyQty;
	}

	public Long getPremiumId() {
		return premiumId;
	}

	public void setPremiumId(Long premiumId) {
		this.premiumId = premiumId;
	}

	public Integer getPremiumGroup() {
		return premiumGroup;
	}

	public void setPremiumGroup(Integer premiumGroup) {
		this.premiumGroup = premiumGroup;
	}
}
