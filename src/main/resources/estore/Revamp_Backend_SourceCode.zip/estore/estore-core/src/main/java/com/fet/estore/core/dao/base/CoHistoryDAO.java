package com.fet.estore.core.dao.base;

import com.fet.estore.core.model.CoHistory;

public interface CoHistoryDAO  extends BaseDAO<CoHistory, String> {

}
