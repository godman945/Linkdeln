package com.fet.estore.core.bean;

import java.io.Serializable;

public class OrderCompleteRes implements Serializable {

	private static final long serialVersionUID = 4254740828770847389L;
	
	private String orderType;
	/** 訂單資訊，結帳流程使用 */
	private OrderInfo order;
	private OrderListBean Cart;
	/** 手機保險金額 */
	private Integer premium;
	
	public OrderListBean getCart() {
		return Cart;
	}
	public void setCart(OrderListBean cart) {
		Cart = cart;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public OrderInfo getOrder() {
		return order;
	}
	public void setOrder(OrderInfo order) {
		this.order = order;
	}
	public Integer getPremium() {
		return premium;
	}
	public void setPremium(Integer premium) {
		this.premium = premium;
	}
	
}
