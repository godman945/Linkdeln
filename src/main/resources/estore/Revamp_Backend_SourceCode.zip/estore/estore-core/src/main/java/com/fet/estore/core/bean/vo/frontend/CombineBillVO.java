package com.fet.estore.core.bean.vo.frontend;

import java.util.Date;

/**
 * 合併帳單VO
 * @author Max Chen
 *
 */
public class CombineBillVO {
	/** 門號 */
	private String mdn;	
	/** 姓名 */
	private String name;
	/** 身分證 */
	private String rocId;
	/** 生日 */
	private Date birthday;
	/** 帳單類型 */
	private String billTp;
	
	/** 帳單地址 - 郵遞區號 */
	private String billAddrZipCode;
	/** 帳單地址 - 縣市ID */
	private String billAddrCityCode;
	/** 帳單地址 - 鄉鎮ID */
	private String billAddrTownSeq;
	/** 帳單地址 - 郵遞區號 */
	private String billAddrTail;
	
	/** 戶籍地址 - 郵遞區號 */
	private String houseAddrZipCode;
	/** 戶籍地址 - 縣市ID */
	private String houseAddrCityCode;
	/** 戶籍地址 - 鄉鎮ID */
	private String houseAddrTownSeq;
	/** 戶籍地址 - 地址 */
	private String houseAddrTail;
	
	/** 電子郵件 */
	private String email;


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRocId() {
		return rocId;
	}

	public void setRocId(String rocId) {
		this.rocId = rocId;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getBillTp() {
		return billTp;
	}

	public void setBillTp(String billTp) {
		this.billTp = billTp;
	}

	public String getBillAddrZipCode() {
		return billAddrZipCode;
	}

	public void setBillAddrZipCode(String billAddrZipCode) {
		this.billAddrZipCode = billAddrZipCode;
	}

	public String getBillAddrCityCode() {
		return billAddrCityCode;
	}

	public void setBillAddrCityCode(String billAddrCityCode) {
		this.billAddrCityCode = billAddrCityCode;
	}

	public String getBillAddrTownSeq() {
		return billAddrTownSeq;
	}

	public void setBillAddrTownSeq(String billAddrTownSeq) {
		this.billAddrTownSeq = billAddrTownSeq;
	}

	public String getBillAddrTail() {
		return billAddrTail;
	}

	public void setBillAddrTail(String billAddrTail) {
		this.billAddrTail = billAddrTail;
	}

	public String getHouseAddrZipCode() {
		return houseAddrZipCode;
	}

	public void setHouseAddrZipCode(String houseAddrZipCode) {
		this.houseAddrZipCode = houseAddrZipCode;
	}

	public String getHouseAddrCityCode() {
		return houseAddrCityCode;
	}

	public void setHouseAddrCityCode(String houseAddrCityCode) {
		this.houseAddrCityCode = houseAddrCityCode;
	}

	public String getHouseAddrTownSeq() {
		return houseAddrTownSeq;
	}

	public void setHouseAddrTownSeq(String houseAddrTownSeq) {
		this.houseAddrTownSeq = houseAddrTownSeq;
	}

	public String getHouseAddrTail() {
		return houseAddrTail;
	}

	public void setHouseAddrTail(String houseAddrTail) {
		this.houseAddrTail = houseAddrTail;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMdn() {
		return mdn;
	}

	public void setMdn(String mdn) {
		this.mdn = mdn;
	}
}
