package com.fet.estore.core.bean.vo.frontend;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fet.estore.core.bean.vo.OcrIDrEresVO;
import com.fet.estore.core.bean.vo.crm.ANoteVO;
import com.fet.estore.core.bean.vo.crm.CrmVO;
import com.fet.estore.core.util.LogUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderHelperVO implements Serializable, Cloneable {

	/** 升級資費類型 - 一般資費 */
	public static final String LOYALTY_UPGRADE_TYPE_NORMAL = "NORMAL";
	/** 升級資費類型 - 價差資費 */
	public static final String LOYALTY_UPGRADE_TYPE_SPREAD = "SPREAD";
	/** 升級資費類型 - 指定資費 */
	public static final String LOYALTY_UPGRADE_TYPE_ASSIGN = "ASSIGN";
	
	private static final long serialVersionUID = -5005160257022632890L;
	private String preSelectedHandsetGroupId;
	private String preSelectedOnsalePromoListId;
	private String preSelectedOrderType;
	private String preSelctedCouponSerial;
	private Long preSelectedActivityId;
	private Integer preselectedHandsetGroupAmt;
	private boolean isRegisterActivity;
	
	private String happyGoRocId;
	
	private CrmVO crmVO;
	
	/**
	 * 館別進入點
	 */
	private EntryPointEnum entryPoint;
	/** 館別第二層進入點 */
	private Integer entryNavigationId;
	private String orderType;
	private Long activityId;
	/**
	 * 使用於活動商品麵包屑版型D跟活動資費麵包屑版型E
	 */
	private String activityStep;
	private String onsalePromoListId;
	private String voiceRateId;
	private String dataRateId;
	/**
	 *新約選擇的門號ID 
	 */
	private String msisdnId;
	/**
	 * 門號可攜或續約原有門號
	 */
	private String msisdn;
	private int selectionFee;
	private boolean registerDemandActivity;
	private Long activityCouponId;
	private String loyaltyToken;
	private String npCompanyCode;
	
	private String applicantName;
	private String applicantRocId;
	private String applicantEmail;
	private Date applicantBirthday;
	private String applicantSecondIdType;
	private String applicantSecondId;
	private String telPrefix1;
	private String tel1;
	private String telPrefix2;
	private String tel2;
	private Long oldBillingTypeId;
	private Long newBillingTypeId;
	private boolean isMergeBill;
	private String mergeBillMsisdn;
	
	private List<String> extraVaServiceIds = new ArrayList<String>();
	private String deliveryType;
	private String deliTime;
	
	private String receiverName;
	private String receiverRocId;
	private String receiverTelPrefix1;
	private String receiverTel1;
	private String receiverTelPrefix2;
	private String receiverTel2;
	
	private String storeReceiverName;
	private String storeReceiverRocId;
	private String storeTelPrefix1;
	private String storeTel1;
	private String storeTelPrefix2;
	private String storeTel2;
	private String cityId;
	private String storeId;
	
	private String gender;
	private boolean isInvoiceDemand;
	private String vatNo;
	private String vatTitle;
	/**
	 *收件人同申辦人
	 */
	private boolean addOnReceiver;
	
	/**
	 * 是否可代收(1:是  2:否)
	 */
	private String deliAlt;

	private String redeemCouponSerial;
	
	private String redeemCouponPassword;
	
	private Long hgRedeemPoint;
	
	private Long hgRedeemPrice;
	
	private String hgToken;
	
	private String hgTotalPoint;
	
	private Long hgRedeemId;
	
	private boolean happyGoRedeemed;
	
	private String orderNumber;
	
	private boolean clickFinish;
	
	private boolean orderSustained;
	
	private boolean cart;
	
	private boolean acceptSms;
	
	private String callingcardTicket;
	
	private String exitMsg;
	
	private String packageBrowsingStatisticId;
	
	//用作輔助coupon或其它折抵之用,可知道設備剩多少金額可折抵
	private Long leftPriceToDiscountForDevice = 0L;
	//用作輔助coupon或其它折抵之用,可知道配件剩多少金額可折抵
	private Long leftPriceToDiscountForAccessory = 0L;
	
	//紅配綠活動ID
	private Long mpActivityId;
	/**電子發票載具類別**/
	private String einvoiceDeviceType;
	/**電子發票載具代碼**/
	private String einvoiceDeviceId;
	/**電子發票愛心捐贈碼**/
	private String donateUnitId;
	/**電子發票愛心捐贈單位**/
	private String donateUnitName;
	/**電子發票類別**/
	private String invoiceType;
	
	private String uid;
	
	/** */
	private String preorderNo;
	
	/** 是否為小網 */
	private boolean isMobileWeb;
	
	private boolean webtrendRecorded;
	/** happy go 改版識別ID */
	private String mpid;
	/** happy go 改版識別ID檢核碼 */
	private String mpidCheckSum;
	/** happy go 改版兌換時間 */
	private Date hgRedeemTime;
	
	/** 是否為App導購 */
	private boolean appFlow;
	/** 訊息來源 */
    private String recommendSource;
	/** 訊息來源資料 */
    private String recommendDesc;
	/** 企業客戶統編資料 */
    private String mvpnVatNo;
    /** 企業客戶資料 */
    private String mvpnStr;
    
    /** VIP LOYALTY */
    private boolean isPassVipLoyalty;

    /** 門號競標 */
    private String auctionMsisdn;
    private Integer auctionActivityId;
    private String auctionRocId;
    private Integer auctionPrice;
    
    /** 資費升級類型 */
    private String upgradeType;
    
    /** 網路涵蓋率 */
    private Boolean netCoverRate;
    
    /**
     * CPS門號
     */
    private String cspMsisdn;
    
    private String appSource;

    private String o2oOrderId;
    
    private String subscriberId;
    /**是否為資費試用**/
    private String trial;
    /**資費試用RocId**/
    private String ncRocId;
    /** 是否同意電信費用及小額付費帳單合併 */
    private String paymentConsolidation;
    /** 取得小額帳單資料錯誤訊息 */
    private String paymentConsolidationError;
    /**指定名單式ID*/
    private Long nameListId;
    /**發證日期*/
    private Date idCardDate;
    /**發證地點*/
    private String idCardCity;
    /**領補換類別*/
    private String idCardType;
    //多主商品
    /**是否為多主商品**/
    private boolean isMultiprod;  
    /**多主商品 id**/
    private String multiprodId;
    /** 多主商品群組1, 群組2的 proudct id**/
    private List<String> productIds;
    /** 多主商品群組1, 群組2的fet no**/
    private List<String> fetNos;
    /**多主商品指定名單式ID*/
    private Long multiprodNameListId;
     /**版型A,B,C id**/
	private String minisiteActivityId;

    private String mdmAccountId;
    private String mdmSubscriberId;
    private String mdmCustomerId;
    private boolean ly3to4;
    
    private ANoteVO aNoteVO;
    private Long prepaymentPrice;
    
    private boolean addAnoteSuccess = false;
    private boolean addGiftRedeem = false;
    
    private String transBpid =  java.util.UUID.randomUUID().toString();

	/**markup product begin**/
	Map<String, List<ProductHelperVO>> masterProductMap = new HashMap<String, List<ProductHelperVO>>();
	Map<String, List<ProductHelperVO>> slaveProductMap = new HashMap<String, List<ProductHelperVO>>();
	
	//是否3轉4平轉
	private boolean isNba324;
	//3轉4平轉需要simcard no
	private String simcardNo;
	//是否為聯名卡
	private boolean isCobranding;
    // NEIL Project
    /** 是否為NEIL平台訂單 **/
    private boolean neilOrder = false;
    /** NEIL平台訂單編號 **/
    private String neilCono;
    /**是否同意加速退貨辦理**/
    private boolean agreeReturnSpeedup;
    
    private String loyaltyRecordId;
    
    private int installments;
    
    private String creditCardNo;
    
    private String sid;
    
    private String npxCono;
    
    private String npxTxid;
    
    private String dspUserProfileUuid;
    
    
    private String jsonString;
    //phase 2
    private String deliTel;
    private boolean regAsBill;
    private boolean regAsAddr;
    private String vatTp;
    private boolean agreeContract;
    private String backFromUri;
    private String orderChannel;
    private String lastPaymentMethod;
    private String lastPaymentMethodAns;
    
    private String cohOrderId;
    private String cohTxid;
    
    private String credentialFile1No;
    private String credentialFile2No;
    private String credentialFile3No;
    private String credentialFile4No;
    

    private String csStoreCvsid;
    private String csStoreCvsname;
    private String csStoreNo;
    private String csStoreName;
    private String csStoreTel;
    private String csStoreAddress;
    private String csStoreAreaCode;
    
    private String extraService;

    /**是否為資費自由選**/
    private boolean isSelfHelpingPromotion = false;

    private String selfHelpingPromotionName;
    /** 資費自由選  D_OFFERID**/
    private String selfHelpingPromotion1;
    /** 資費自由選  ONNET_OFFERID**/
    private String selfHelpingPromotion2;
    /** 資費自由選  OFFNET_OFFERID**/
    private String selfHelpingPromotion3;
    
    private String fridayOrderType;
    
    private String fridayOrderNo;
    
    private boolean isFirday = false;
    
    //驗證碼
    private String captcha;
    
    //CR2019028
    private String rId;
    private String clickId;
    private boolean isFromMarketAmerica;
    
    private boolean isEbu;
    
    private boolean isInsurance;

    private Boolean cncDeliveryOrder;


    private boolean isPremium;
    
    private String premiumTitle;
    
    private Integer premiumBuyCount;
    
    private Map<Long, Integer> premiumGroup1 = new LinkedHashMap<>();
    private Map<Long, Integer> premiumGroup2 = new LinkedHashMap<>();
    
    //2019/07/30 add EBU證件上傳
    
    //企業客戶身分別（1=員工、2=員工父母、3=員工配偶、4=員工子女、5=員工公婆與祖父母、6=其他）
    private String ebuSubscriberType;
    
    //員工證件
    private String credentialFile5No;
    
    //親屬證明文件
    private List<String> credentialFile6No;
    
    private String ebuVatNo;
    private String ebuVatTitle;
    private String ebuRecomName;
    private String ebuRecomMsisdn;
    
    //app 上傳證照的唯一值
    private String uploadImagePageSidByAPP;
    
    private String host;
    private String xff;
    

    /** 證件上傳頁 ocr內容**/
    private OcrIDrEresVO ocrIDrEresVO;
    /** 證件上傳頁 ocr 的 識別值**/
    private List<String> ocrSn;
    /** 證件上傳頁 是否延遲上傳**/
    private String delayChoose;
    /** 資料填寫頁 簽名方式**/
    private String ApplicantSignType;

	/** 2020/01/03 add 帳單地址是否為外島、離島 */
	private Boolean isOffshoreIsland;

    
	/** 2020/03/12 add 是否要驗證九個月一證一號 */
	private Boolean isCheckOnceContract9M;

	/** 2020-04-06 Ted.Hsieh 新增 c約(contentOffer)的ID清單 */
	private List<String> contentOfferIdList;
	/** 2020-04-08 Roil.Li 5G需求新增 促案類型(Ex. POS5G, NPF5G...) */
	private String transType;
	/**
	 * 2020/05/12 add 成單時要寫回上傳頁面當時取的useOcr及credentialType
	 */
	private Map<String, String> ocrAttrMap;
    
	public List<MarkupProductVO> getMarkupProducts(){
		List<MarkupProductVO> markupProducts = new ArrayList<MarkupProductVO>();
		Set<String> keys = this.masterProductMap.keySet();
		for(String key : keys){
			MarkupProductVO markupProduct = new MarkupProductVO();
			markupProduct.setMasterProducts(this.masterProductMap.get(key));
			markupProduct.setSlaveProducts(this.slaveProductMap.get(key));
			markupProduct.setUuid(key);
			
			markupProducts.add(markupProduct);
		}
		return markupProducts;
	}
	
	public List<ProductHelperVO> getNoneMarkupHandset(){
		List<ProductHelperVO> productHelperVOs = new ArrayList<ProductHelperVO>();
		List<IdAndQuantityPairHelper> pairs = this.getHandsetGroup();
		for(IdAndQuantityPairHelper pair :pairs){
			if(pair.getUuid() == null){
				ProductHelperVO productHelperVO = new ProductHelperVO();
				productHelperVO.setFetNo(pair.getId());
				productHelperVO.setGroupNumber(pair.getGroupNumber());
				productHelperVO.setMarkupProduct(false);
				productHelperVO.setQuantity(pair.getQuantity());
				productHelperVOs.add(productHelperVO);
			}
		}
		return productHelperVOs;
	}
	
	public List<ProductHelperVO> getNoneMarkupAccessory(){
		List<ProductHelperVO> productHelperVOs = new ArrayList<ProductHelperVO>();
		
		Set<String> keys = this.accessoryMap.keySet();
		for(String key : keys){
			if(!key.contains("_")){
				ProductHelperVO myProductHelperVO = this.accessoryMap.get(key);
				
				ProductHelperVO productHelperVO = new ProductHelperVO();
				productHelperVO.setFetNo(myProductHelperVO.getFetNo());
				productHelperVO.setGroupNumber(myProductHelperVO.getGroupNumber());
				productHelperVO.setMarkupProduct(false);
				productHelperVO.setQuantity(myProductHelperVO.getQuantity());
				productHelperVOs.add(productHelperVO);
			}
		}
		return productHelperVOs;
	}
	
	/**markup product end**/
	
	public void resetHappyGo(){
		this.hgRedeemId = null;
		this.hgRedeemPrice = null;
		this.hgToken = null;
		this.hgTotalPoint = null;
		this.hgRedeemPoint = null;
		this.setHappyGoRedeemed(false);
	}
	
	private List<Address> addresses = new ArrayList<Address>();
	
	public void setApplicantAddress(String cityCode, String areaCode, String textAddress, String sameAs){
		for(Address address : this.addresses){
			if(Address.ADDRESS_TYPE_APPLICANT.equals(address.getAddressType())){
				this.addresses.remove(address);
				break;
			}
		}
		Address address = new Address(cityCode, areaCode, textAddress, Address.ADDRESS_TYPE_APPLICANT, sameAs);
		this.addresses.add(address);
	}
	
	public Address getApplicantAddress(){
		return this.getAddress(Address.ADDRESS_TYPE_APPLICANT);
	}
	
	public void removeApplicantAddress(){
		this.removeAddress(Address.ADDRESS_TYPE_APPLICANT);
	}
	
	public void setRegisterAddress(String cityCode, String areaCode, String textAddress, String sameAs){
		for(Address address : this.addresses){
			if(Address.ADDRESS_TYPE_REGISTER.equals(address.getAddressType())){
				this.addresses.remove(address);
				break;
			}
		}
		Address address = new Address(cityCode, areaCode, textAddress, Address.ADDRESS_TYPE_REGISTER, sameAs);
		this.addresses.add(address);
	}
	
	public Address getRegisterAddress(){
		return this.getAddress(Address.ADDRESS_TYPE_REGISTER);
	}
	
	public void removeRegisterAddress(){
		this.removeAddress(Address.ADDRESS_TYPE_REGISTER);
	}
	
	public void setDeliAddress(String cityCode, String areaCode, String textAddress, String sameAs){
		for(Address address : this.addresses){
			if(Address.ADDRESS_TYPE_DELIVERY.equals(address.getAddressType())){
				this.addresses.remove(address);
				break;
			}
		}
		Address address = new Address(cityCode, areaCode, textAddress, Address.ADDRESS_TYPE_DELIVERY, sameAs);
		this.addresses.add(address);
	}
	
	public Address getDeliAddress(){
		return this.getAddress(Address.ADDRESS_TYPE_DELIVERY);
	}
	
	public void removeDeliAddress(){
		this.removeAddress(Address.ADDRESS_TYPE_DELIVERY);
	}
	
	public void setBillAddress(String cityCode, String areaCode, String textAddress, String sameAs){
		for(Address address : this.addresses){
			if(Address.ADDRESS_TYPE_BILL.equals(address.getAddressType())){
				this.addresses.remove(address);
				break;
			}
		}
		Address address = new Address(cityCode, areaCode, textAddress, Address.ADDRESS_TYPE_BILL, sameAs);
		this.addresses.add(address);
	}
	
	public Address getBillAddress(){
		return this.getAddress(Address.ADDRESS_TYPE_BILL);
	}
	
	public void removeBillAddress(){
		this.removeAddress(Address.ADDRESS_TYPE_BILL);
	}
	
	public void setVatAddress(String cityCode, String areaCode, String textAddress, String sameAs){
		Address address = new Address(cityCode, areaCode, textAddress, Address.ADDRESS_TYPE_VAT, sameAs);
		this.addresses.add(address);
	}
	
	public Address getVatAddress(){
		return this.getAddress(Address.ADDRESS_TYPE_VAT);
	}
	
	public void removeVatAddress(){
		this.removeAddress(Address.ADDRESS_TYPE_VAT);
	}
	
	private void removeAddress(String addressType){
		for(int i=0; i< addresses.size(); i++){
			if(addresses.get(i).getAddressType().equals(addressType)){
				this.addresses.remove(i);
				break;
			}
		}
	}
	
	private Address getAddress(String addressType){
		for(int i=0; i< addresses.size(); i++){
			if(addresses.get(i).getAddressType().equals(addressType)){
				return this.addresses.get(i);
			}
		}
		
		return null;
	}
	
	List<String> addtionPurchaseFetNos = new ArrayList<String>();
	
	List<String> vaServices = new ArrayList<String>();
	
	public void addVaServiceId(String vaServiceId){
		this.vaServices.add(vaServiceId);
	}
	
	public void removeVaServiceId(String vaServiceId){
		for(int i=0; i<this.vaServices.size(); i++){
			if(vaServiceId.equals(this.vaServices.get(i))){
				this.vaServices.remove(i);
				break;
			}
		}
	}
	
	public void removeAllVaService(){
		this.vaServices.removeAll(this.vaServices);
	}
	
	public void addAdditionPurchase(String fetNo){
		this.addtionPurchaseFetNos.add(fetNo);
	}
	
	public void removeAdditionPurchase(String fetNo){
		for(int i=0; i<this.addtionPurchaseFetNos.size(); i++){
			if(fetNo.equals(this.addtionPurchaseFetNos.get(i))){
				this.addtionPurchaseFetNos.remove(i);
				break;
			}
		}
	}
	
	public void removeAllAdditionPurchase(){
		this.addtionPurchaseFetNos.removeAll(this.addtionPurchaseFetNos);
	}
	
	public List<IdAndQuantityPairHelper> getHandsetGroup(){
		List<IdAndQuantityPairHelper> handsetGroups = new ArrayList<IdAndQuantityPairHelper>();
		Set<String> keys = this.handsetGroupMap.keySet();
		for(String key: keys){
			IdAndQuantityPairHelper pair = new IdAndQuantityPairHelper();
			
			String fetNo = null;
			if(key.indexOf("_") >= 0){
				fetNo = key.substring(0, key.indexOf("_"));
			}else{
				fetNo = key;
			}
			
			ProductHelperVO vo = this.handsetGroupMap.get(key);
			
			boolean createNewVO = true;
			for(IdAndQuantityPairHelper myPair : handsetGroups){
				if(myPair.getId().equals(fetNo)){
					myPair.setQuantity(myPair.getQuantity() + vo.getQuantity());
					createNewVO = false;
					break;
				}
			}
			if(!createNewVO){
				break;
			}
			pair.setId(fetNo);
			pair.setQuantity(vo.getQuantity());
			pair.setUuid(vo.getUuid());
			pair.setMarkupProduct(vo.isMarkupProduct());
			pair.setMpActivityId(vo.getMpActivityId());
			pair.setMpActivityProductDiscountId(vo.getMpActivityProductDiscountId());
			pair.setGroupNumber(vo.getGroupNumber());
			handsetGroups.add(pair);
		}
		return handsetGroups;
	}
	
	public List<IdAndQuantityPairHelper> getAccessory(){
		List<IdAndQuantityPairHelper> accessories = new ArrayList<IdAndQuantityPairHelper>();
		Set<String> keys = this.accessoryMap.keySet();
		for(String key: keys){
			IdAndQuantityPairHelper pair = new IdAndQuantityPairHelper();
			
			String fetNo = null;
			if(key.indexOf("_") >= 0){
				fetNo = key.substring(0, key.indexOf("_"));
			}else{
				fetNo = key;
			}
			ProductHelperVO vo = this.accessoryMap.get(key);
			
			boolean createNewPairVO = true;
			for(IdAndQuantityPairHelper myPair : accessories){
				if(myPair.getId().equals(fetNo)){
					myPair.setQuantity(myPair.getQuantity() + vo.getQuantity());
					createNewPairVO = false;
					break;
				}
			}
			if(!createNewPairVO){
				break;
			}
			
			
			pair.setId(fetNo);
			pair.setQuantity(vo.getQuantity());
			pair.setUuid(vo.getUuid());
			pair.setMarkupProduct(vo.isMarkupProduct());
			pair.setMpActivityId(vo.getMpActivityId());
			pair.setMpActivityProductDiscountId(vo.getMpActivityProductDiscountId());
			pair.setGroupNumber(vo.getGroupNumber());
			accessories.add(pair);
		}
		return accessories;
	}
	
	public List<IdAndQuantityPairHelper> getCallingCard(){
		List<IdAndQuantityPairHelper> callingCards = new ArrayList<IdAndQuantityPairHelper>();
		Set<String> keys = this.callingCardMap.keySet();
		for(String key : keys){
			IdAndQuantityPairHelper pair = new IdAndQuantityPairHelper();
			pair.setId(key);
			pair.setQuantity(this.callingCardMap.get(key));
			callingCards.add(pair);
		}
		
		return callingCards;
	}
	
	private Map<String, ProductHelperVO> handsetGroupMap = new LinkedHashMap<String, ProductHelperVO>();
	
	public void addHandsetGroup(String handsetGroupFetNo, Integer quantity){

		this.addHandsetGroup(handsetGroupFetNo, quantity, 0);
	}
	
	public void addHandsetGroup(String handsetGroupFetNo, Integer quantity, int groupNumber){
		ProductHelperVO vo = new ProductHelperVO();
		vo.setFetNo(handsetGroupFetNo);
		vo.setQuantity(quantity);
		vo.setProductType(ProductHelperVO.PRODUCT_TYPE_HANDSET);
		vo.setGroupNumber(groupNumber);
		this.handsetGroupMap.put(handsetGroupFetNo, vo);
	}
	
	/**
	 * 
	 * @param handsetGroupFetNo	手機料號
	 * @param quantity	數量
	 * @param uuid	加價購群組ID
	 * @param mpActivityId	加價購活動ID(將來可能廢止使用)
	 * @param groupNumber	紅配綠群組編號(0:非紅配綠,1:第一群,2:第二群)
	 */
	public void addHandsetGroup(String handsetGroupFetNo, Integer quantity, String uuid, Long mpActivityId, int groupNumber){
		ProductHelperVO vo = new ProductHelperVO();
		/*
		String fetNo = null;
		if(handsetGroupFetNo.indexOf("_") >= 0){
			fetNo = handsetGroupFetNo.substring(0, handsetGroupFetNo.indexOf("_"));
		}else{
			fetNo = handsetGroupFetNo;
		}
		*/
		

		String key = uuid == null ? handsetGroupFetNo : String.format("%s_%s", handsetGroupFetNo, uuid);
		
		vo.setFetNo(handsetGroupFetNo);
		vo.setQuantity(quantity);
		vo.setProductType(ProductHelperVO.PRODUCT_TYPE_HANDSET);
		vo.setUuid(uuid);
		vo.setMarkupProduct(mpActivityId == null ? false : true);
		//String key = handsetGroupFetNo;//fetNo_uuid
		this.handsetGroupMap.put(key, vo);
		
		
//		if(mpActivityId != null ){
			List<ProductHelperVO> masterProducts = null;
			if(this.masterProductMap.containsKey(uuid)){
				masterProducts = this.masterProductMap.get(uuid);
			}else{
				masterProducts = new ArrayList<ProductHelperVO>();
			}
			
			ProductHelperVO myVo = new ProductHelperVO();
			myVo.setFetNo(handsetGroupFetNo);
			myVo.setQuantity(quantity);
			myVo.setProductType(ProductHelperVO.PRODUCT_TYPE_HANDSET);
			myVo.setUuid(uuid);
			myVo.setMarkupProduct(mpActivityId == null ? false : true);
			masterProducts.add(myVo);
			
			this.masterProductMap.put(uuid, masterProducts);
//		}
		
	}
	
	public void addHandsetGroup(String handsetGroupFetNo, Integer quantity, String uuid, Long mpActivityId){
		this.addHandsetGroup(handsetGroupFetNo, quantity, uuid, mpActivityId, 0);
	}
	
	public void addHandsetGroup(String handsetGroupFetNo, Integer quantity, Long mpActivityId, int groupNumber){
		this.addHandsetGroup(handsetGroupFetNo, quantity, null, mpActivityId, groupNumber);
	}
	
	/**
	 * 移除OrderHelperVO設備
	 * @param accessoryFetNo(如果是一般商品,格式是fetNo;如果是加價購商品,格式是fetNo_uuid)
	 */
	public void removeHandsetGroup(String handsetGroupFetNo){
		this.removeHandsetGroup(handsetGroupFetNo, null);
	}
	
	public void removeHandsetGroup(String handsetGroupFetNo, String uuid){
		String key = uuid == null? handsetGroupFetNo : String.format("%s_%s", handsetGroupFetNo, uuid);
		if(this.handsetGroupMap.containsKey(key)){
			if(uuid != null){
				this.removeMarkupProductForHandset(handsetGroupFetNo, uuid);
				//刪除此uuid下加購的配件
				this.removeAccessoryByUuid(uuid);
			}
			this.handsetGroupMap.remove(key);
		}
	}
	
	public void removeAccessoryByUuid(String uuid){
		List<String> keysToRemove = new ArrayList<String>();
		for(String key : this.accessoryMap.keySet()){
			if(key.contains(uuid)){
				keysToRemove.add(key);
			}
		}
		
		for(String key : keysToRemove){
			this.accessoryMap.remove(key);
		}
	}
	
	private void removeMarkupProductForHandset(String fetNo, String uuid){
		if(this.masterProductMap.containsKey(uuid)){
			this.masterProductMap.remove(uuid);
			this.slaveProductMap.remove(uuid);
		}
	}
	
	private void removeMarkupProductForAccessory(String fetNo, String uuid){
		//ProductHelperVO productHelperVO = this.accessoryMap.get(accessoryGroupFetNo);
		//if(productHelperVO.getUuid() != null){
		//配件加購配件時,因為masterProductMap裡放的可能是配件而不是手機
		//因此要先到masterProductMap看看有沒有加價購主商品是配件的資料
		if(this.masterProductMap.containsKey(uuid)){
			List<ProductHelperVO> vos = this.masterProductMap.get(uuid);
			for(ProductHelperVO vo : vos){
				if(vo.getFetNo().equals(fetNo)){
					this.masterProductMap.remove(uuid);
					break;
				}
			}
		}

		
		if(this.slaveProductMap.containsKey(uuid)){
				List<ProductHelperVO> vos = this.slaveProductMap.get(uuid);
				for(ProductHelperVO vo : vos){
					if(vo.getFetNo().equals(fetNo)){
						vos.remove(vo);
						if(vos.size() == 0){
							this.slaveProductMap.remove(uuid);
							
							//加購商品已經全數移除,原本在handsetGroupMap中的key值是fetNo_uuid
							//要改成只剩下fetNo
							this.resetHandsetGroupMapKey(uuid);
							//加購商品已經全數移除,原本的加價購不存在了,
							//所以把加價購的主商品從masterProductMap中移除
							
							
							//kevin 2013/07/29,在移除「配件加購配件」的時候，如果移掉的是被加購的配件，而且被加購的商品都已移除完畢，
							//在masterProductMap中的主商品（配件），要把uuid拿掉，換成以自己的料號做為key值的一個entry
							List<ProductHelperVO> myVos = this.masterProductMap.get(uuid);
							for(ProductHelperVO myVo : myVos){
								if(myVo.getProductType().equals(ProductHelperVO.PRODUCT_TYPE_ACCESSORY)){
									this.resetAccessoryMapKey(uuid);
									break;
								}
							}
							
							
							this.masterProductMap.remove(uuid);
						}
						break;
					}
				}
			}
		//}
	}
	
	private void resetHandsetGroupMapKey(String uuid){
		Set<String> keys = this.handsetGroupMap.keySet();
		List<String> keysToRemove = new ArrayList<String>();
		
		
		for(String key : keys){
			if(key.contains(uuid)){
				keysToRemove.add(key);
			}
		}
		
		for(String key: keysToRemove){
			ProductHelperVO productHelperVO = handsetGroupMap.get(key);
			//先把key值(fetNo_uuid)移除
			handsetGroupMap.remove(key);
			//再重新以fetNo當key值
			productHelperVO.setUuid(null);
			handsetGroupMap.put(productHelperVO.getFetNo(), productHelperVO);
		}
	}
	
	private void resetAccessoryMapKey(String uuid){
		Set<String> keys = this.accessoryMap.keySet();
		List<String> keysToRemove = new ArrayList<String>();
		//這邊是補漏洞用的，只針對配件加購配件中，屬於主商品的項目，進行移除uuid動作，其它不管
		for(String key : keys){
			if(key.contains(uuid)){
				ProductHelperVO productHelperVO = this.accessoryMap.get(key);
				if(productHelperVO.getProductType().equals(ProductHelperVO.PRODUCT_TYPE_ACCESSORY) 
						&& productHelperVO.isMaster() == true){
					keysToRemove.add(key);
				}
			}
		}
		
		for(String key : keysToRemove){
			ProductHelperVO productHelperVO = this.accessoryMap.get(key);
			this.accessoryMap.remove(key);
			productHelperVO.setUuid(null);
			accessoryMap.put(productHelperVO.getFetNo(), productHelperVO);
		}
	}
	
	public void removeMarkupProduct(String uuid){		
		removeMarkupProductForHandset(null, uuid);
	}
	
	public void removeAllHandsetGroup(){
		for(String key : this.handsetGroupMap.keySet()){
			if(this.handsetGroupMap.get(key).getUuid() != null){
				String fetNo = key.substring(0, key.indexOf("_"));
				this.removeMarkupProductForHandset(fetNo, key);
			}
		}
		this.handsetGroupMap.clear();
	}
	
	private Map<String, Integer> callingCardMap = new HashMap<String, Integer>();
	
	public void addCallingCard(String callingCardId, Integer quantity){
		this.callingCardMap.put(callingCardId, quantity);
	}
	
	public void removeCallingCard(String callingCardId){
		if(this.callingCardMap.containsKey(callingCardId)){
			this.callingCardMap.remove(callingCardId);
		}
	}
	
	public void removeAllCallingCard(){
		this.callingCardMap.clear();
	}
	
	public void changeAmountHandsetGroup(String fetNo, Integer amount){
		this.changeAmountHandsetGroup(fetNo, null, amount);
	}
	
	public void changeAmountHandsetGroup(String fetNo, String uuid, Integer amount){
		String key = uuid == null ? fetNo : String.format("%s_%s", fetNo, uuid);
		if(fetNo == null || !handsetGroupMap.containsKey(key)) return;
		ProductHelperVO vo = handsetGroupMap.get(key);
		vo.setQuantity(amount);
		
		//更改存放加價購商品map的資料
		if(this.masterProductMap.containsKey(uuid)){
			List<ProductHelperVO> vos = this.masterProductMap.get(uuid);
			for(ProductHelperVO myVo : vos){
				if(myVo.getFetNo().equals(fetNo)){
					myVo.setQuantity(amount);
				}
			}
		}
	}
	
	public void changeAmountAccessory(String fetNo, Integer amount){
		this.changeAmountAccessory(fetNo, null, amount);
	}
	
	public void changeAmountAccessory(String fetNo, String uuid, Integer amount){
		String key = uuid == null ? fetNo : String.format("%s_%s", fetNo, uuid);
		if(fetNo == null || !accessoryMap.containsKey(key)) return;
		ProductHelperVO vo = accessoryMap.get(key);
		vo.setQuantity(amount);
		accessoryMap.put(key, vo);
		
		//更改存放加價購商品map的資料
		//配件加價購,配件有可能在主適品中
		if(this.masterProductMap.containsKey(uuid)){
			List<ProductHelperVO> vos = this.masterProductMap.get(uuid);
			for(ProductHelperVO myVo : vos){
				if(myVo.getFetNo().equals(fetNo)){
					myVo.setQuantity(amount);
					break;
				}
			}
		}
		
		if(this.slaveProductMap.containsKey(uuid)){
			List<ProductHelperVO> vos = this.slaveProductMap.get(uuid);
			for(ProductHelperVO myVo : vos){
				if(myVo.getFetNo().equals(fetNo)){
					myVo.setQuantity(amount);
					break;
				}
			}
		}
	}
	
	Map<String, ProductHelperVO> accessoryMap = new LinkedHashMap<String, ProductHelperVO>();
	
	public void addAccessory(String accessoryFetNo, Integer quantity){
		this.addAccessory(accessoryFetNo, quantity, 0);
	}
	
	public void addAccessory(String accessoryFetNo, Integer quantity, int groupNumber){
		ProductHelperVO vo = new ProductHelperVO();
		vo.setFetNo(accessoryFetNo);
		vo.setQuantity(quantity);
		vo.setProductType(ProductHelperVO.PRODUCT_TYPE_ACCESSORY);
		vo.setGroupNumber(groupNumber);
		this.accessoryMap.put(accessoryFetNo, vo);
	}
	
	public void addAccessory(String accessoryFetNo, Integer quantity, String uuid, Long mpActivityId, Long mpActivityProductDiscountId, boolean isMaster){
		ProductHelperVO vo = new ProductHelperVO();
		/*
		String fetNo = null;
		if(accessoryFetNo.indexOf("_") >= 0){
			fetNo = accessoryFetNo.substring(0, accessoryFetNo.indexOf("_"));
		}else{
			fetNo = accessoryFetNo;
		}
		*/
		String key = uuid == null ? accessoryFetNo : String.format("%s_%s", accessoryFetNo, uuid);
		
		vo.setFetNo(accessoryFetNo);
		vo.setQuantity(quantity);
		vo.setProductType(ProductHelperVO.PRODUCT_TYPE_ACCESSORY);
		vo.setUuid(uuid);
		vo.setMarkupProduct(mpActivityId == null ? false : true);
		vo.setMpActivityId(mpActivityId);
		vo.setMpActivityProductDiscountId(mpActivityProductDiscountId);
		vo.setMaster(isMaster);
		this.accessoryMap.put(key, vo);
		
		if(uuid != null){
			//revamp2.2,加價購可以是手機加購配件,也可以是配件加購配件
			//所以配件也可能被放到masterProductMap之中
			List<ProductHelperVO> slaveOrMasterProducts = null;
			if(isMaster){
				if(this.masterProductMap.containsKey(uuid)){
					slaveOrMasterProducts = this.masterProductMap.get(uuid);
				}else{
					slaveOrMasterProducts = new ArrayList<ProductHelperVO>();
				}
			}else{
				if(this.slaveProductMap.containsKey(uuid)){
					slaveOrMasterProducts = this.slaveProductMap.get(uuid);
				}else{
					slaveOrMasterProducts = new ArrayList<ProductHelperVO>();
				}
			}
			
			ProductHelperVO myVo = new ProductHelperVO();
			myVo.setFetNo(accessoryFetNo);
			myVo.setQuantity(quantity);
			myVo.setUuid(uuid);
			myVo.setMaster(isMaster);
			myVo.setProductType(ProductHelperVO.PRODUCT_TYPE_ACCESSORY);
			myVo.setMarkupProduct(mpActivityId == null ? false : true);
			myVo.setMpActivityId(mpActivityId);
			myVo.setMpActivityProductDiscountId(mpActivityProductDiscountId);
			slaveOrMasterProducts.add(myVo);
			
			if(isMaster){
				this.masterProductMap.put(uuid, slaveOrMasterProducts);
			}else{
				this.slaveProductMap.put(uuid, slaveOrMasterProducts);
			}
		}
	}
	
	public void addAccessory(String accessoryFetNo, Integer quantity, String uuid, Long mpActivityId, Long mpActivityProductDiscountId ){
		this.addAccessory(accessoryFetNo, quantity, uuid, mpActivityId, mpActivityProductDiscountId, false);
	}
	
	/**
	 * 移除OrderHelperVO配件
	 * @param accessoryFetNo(如果是一般商品,格式是fetNo;如果是加價購商品,格式是fetNo_uuid)
	 */
	public void removeAccessory(String accessoryFetNo){
		this.removeAccessory(accessoryFetNo, null);
	}
	
	public void removeAccessory(String accessoryFetNo, String uuid){
		String key = uuid == null? accessoryFetNo : String.format("%s_%s", accessoryFetNo, uuid);
		if(this.accessoryMap.containsKey(key)){
			//清除加購物件
			if(uuid != null){
				removeMarkupProductForAccessory(accessoryFetNo, uuid);
				
				ProductHelperVO productHelperVO = accessoryMap.get(key);
				//如果是配件加價購配件,且移除的是主商品,把被價加價購的所有附屬商品移除
				if(productHelperVO.isMaster() == true){
					this.removeAccessoryByUuid(uuid);
				}else{
					this.accessoryMap.remove(key);
				}
			}else{
				this.accessoryMap.remove(key);
			}
		}
	}
	
	public void removeAllAccessory(){
		for(String key : this.accessoryMap.keySet()){
			if(this.accessoryMap.get(key).getUuid() != null){
				String fetNo = key.substring(0, key.indexOf("_"));
				this.removeMarkupProductForAccessory(fetNo, key);
			}
		}
		this.accessoryMap.clear();
	}
	
	public void populateHandsetAndAccessoryFromShoppingCart(CartHelperVO cartVO){
		this.removeAllHandsetGroup();
		this.removeAllAccessory();
		List<CartItemHelperVO> cartItems = cartVO.getItems();
		for(CartItemHelperVO item : cartItems) {
			String fetNo = item.getFetNo();
			Integer qty = item.getAmount();
			String uuid = item.getUuid();
			boolean withFirstFetNo = item.getFirstFetNo() != null && item.getFirstFetNo().length()>0 ? false : true;
			Long mpActivityId = item.getMpActivityId();
			Long mpActivityProductDiscountId = item.getMpActivityProductDiscountId();
			boolean isAcc = item.isAcc();
			if(!isAcc) {
				if(uuid!=null){
					this.addHandsetGroup(fetNo, qty, uuid, null);
				}else{
					this.addHandsetGroup(fetNo, qty);
				}
			} else {
				if(uuid!=null){
					this.addAccessory(fetNo, qty, uuid, mpActivityId, mpActivityProductDiscountId, withFirstFetNo);
				}else{
					this.addAccessory(fetNo, qty);
				}
			}						
		}
	}
	
	public void addExtraBuy(String fetNo, int quantity, String type, int extraBuyId, int extraBuyItemId) {
		
		if(!"HANDSET".equals(type) && !"ACCESSORY".equals(type)) {
			throw new RuntimeException(String.format("Not supported type: %s", type));
		}
		JSONObject jsonObject = null;
		if(this.jsonString == null) {
			jsonObject = JSONObject.fromObject(this);
		}else {
			jsonObject = JSONObject.fromObject(this.jsonString);
		}

		JSONObject extraBuyMap = new JSONObject();
		extraBuyMap.put("fetNo", fetNo);
		extraBuyMap.put("quantity", String.valueOf(quantity));
		extraBuyMap.put("type", type);
		extraBuyMap.put("extraBuyId", String.valueOf(extraBuyId));
		extraBuyMap.put("extraBuyItemId", String.valueOf(extraBuyItemId));
		
		Object testObject = jsonObject.get("extraBuy");
		JSONArray extraBuyArray = null;
		if(!(testObject instanceof JSONArray)){
			extraBuyArray = new JSONArray();
		}else {
			extraBuyArray = (JSONArray)testObject;
		}
		
		extraBuyArray.add(extraBuyMap);
		
		jsonObject.put("extraBuy", extraBuyArray);
		
		this.jsonString = jsonObject.toString();
	}
	
	public void updateExtraBuy(String fetNo, int quantity, String type) {
		JSONArray extraBuyArray = this.getExtraBuy();
		boolean updateOK = false;
		for(Object object  : extraBuyArray) {
			JSONObject map = (JSONObject)object;
			String myFetNo = map.get("fetNo").toString();
			String myType = map.get("type").toString();
			
			if(myFetNo.equals(fetNo) && myType.equals(type)) {
				if(quantity == 0) {
					extraBuyArray.remove(object);
					updateOK = true;
					break;
				}else {
					map.put("quantity", quantity);
				}
				updateOK = true;
				break;
			}
		}
		
		if(!updateOK) {
			throw new RuntimeException("Nothing updated!");
		}
		
		JSONObject jsonObject = JSONObject.fromObject(this.jsonString);
		jsonObject.put("extraBuy", extraBuyArray);
		this.jsonString = jsonObject.toString();
	}
	
	public void removeExtraBuy() {
		JSONObject jsonObject = JSONObject.fromObject(this.jsonString);
		if(jsonObject == null || jsonObject.isNullObject() || !jsonObject.has("extraBuy")) { return; }
		jsonObject.remove("extraBuy");
		this.jsonString = jsonObject.toString();
	}
	
	public JSONArray getExtraBuy() {
		if(this.jsonString == null) {
			return new JSONArray();
		}
		
		JSONObject jsonObject = JSONObject.fromObject(this.jsonString);
		
		
		Object testObject = jsonObject.get("extraBuy");
		if(!(testObject instanceof JSONArray)) {
			return new JSONArray();
		}else {
			return jsonObject.getJSONArray("extraBuy");
		}
		
	}
	
	public Map<String, ProductHelperVO> getAccessoryMap() {
		return accessoryMap;
	}

	public void setAccessoryMap(Map<String, ProductHelperVO> accessoryMap) {
		this.accessoryMap = accessoryMap;
	}

	public Long getActivityId() {
		return activityId;
	}

	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	public String getActivityStep() {
		return activityStep;
	}

	public void setActivityStep(String activityStep) {
		this.activityStep = activityStep;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public List<String> getAddtionPurchaseFetNos() {
		return addtionPurchaseFetNos;
	}

	public void setAddtionPurchaseFetNos(List<String> addtionPurchaseFetNos) {
		this.addtionPurchaseFetNos = addtionPurchaseFetNos;
	}

	public Date getApplicantBirthday() {
		return applicantBirthday;
	}

	public void setApplicantBirthday(Date applicantBirthday) {
		this.applicantBirthday = applicantBirthday;
	}

	public String getApplicantEmail() {
		return applicantEmail;
	}

	public void setApplicantEmail(String applicantEmail) {
		this.applicantEmail = applicantEmail;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getApplicantRocId() {
		return applicantRocId;
	}

	public void setApplicantRocId(String applicantRocId) {
		this.applicantRocId = applicantRocId;
	}

	public String getApplicantSecondId() {
		return applicantSecondId;
	}

	public void setApplicantSecondId(String applicantSecondId) {
		this.applicantSecondId = applicantSecondId;
	}

	public String getApplicantSecondIdType() {
		return applicantSecondIdType;
	}

	public void setApplicantSecondIdType(String applicantSecondIdType) {
		this.applicantSecondIdType = applicantSecondIdType;
	}

	public String getDataRateId() {
		return dataRateId;
	}

	public void setDataRateId(String dataRateId) {
		this.dataRateId = dataRateId;
	}

	public String getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	public List<String> getExtraVaServiceIds() {
		return extraVaServiceIds;
	}

	public void setExtraVaServiceIds(List<String> extraVaServiceIds) {
		this.extraVaServiceIds = extraVaServiceIds;
	}

	public Map<String, ProductHelperVO> getHandsetGroupMap() {
		return handsetGroupMap;
	}

	public void setHandsetGroupMap(Map<String, ProductHelperVO> handsetGroupMap) {
		this.handsetGroupMap = handsetGroupMap;
	}

	public String getMsisdnId() {
		return msisdnId;
	}

	public void setMsisdnId(String msisdnId) {
		this.msisdnId = msisdnId;
	}

	public String getOnsalePromoListId() {
		return onsalePromoListId;
	}

	public void setOnsalePromoListId(String onsalePromoListId) {
		this.onsalePromoListId = onsalePromoListId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public Long getPreSelectedActivityId() {
		return preSelectedActivityId;
	}

	public void setPreSelectedActivityId(Long preSelectedActivityId) {
		this.preSelectedActivityId = preSelectedActivityId;
	}

	public String getPreSelectedHandsetGroupId() {
		return preSelectedHandsetGroupId;
	}

	public void setPreSelectedHandsetGroupId(String preSelectedHandsetGroupId) {
		this.preSelectedHandsetGroupId = preSelectedHandsetGroupId;
	}

	public String getPreSelectedOnsalePromoListId() {
		return preSelectedOnsalePromoListId;
	}

	public void setPreSelectedOnsalePromoListId(String preSelectedOnsalePromoListId) {
		this.preSelectedOnsalePromoListId = preSelectedOnsalePromoListId;
	}

	public String getPreSelectedOrderType() {
		return preSelectedOrderType;
	}

	public void setPreSelectedOrderType(String preSelectedOrderType) {
		this.preSelectedOrderType = preSelectedOrderType;
	}

	public String getTel1() {
		return tel1;
	}

	public void setTel1(String tel1) {
		this.tel1 = tel1;
	}

	public String getTel2() {
		return tel2;
	}

	public void setTel2(String tel2) {
		this.tel2 = tel2;
	}

	public String getTelPrefix1() {
		return telPrefix1;
	}

	public void setTelPrefix1(String telPrefix1) {
		this.telPrefix1 = telPrefix1;
	}

	public String getTelPrefix2() {
		return telPrefix2;
	}

	public void setTelPrefix2(String telPrefix2) {
		this.telPrefix2 = telPrefix2;
	}

	public List<String> getVaServices() {
		return vaServices;
	}

	public void setVaServices(List<String> vaServices) {
		this.vaServices = vaServices;
	}

	public String getVoiceRateId() {
		return voiceRateId;
	}

	public void setVoiceRateId(String voiceRateId) {
		this.voiceRateId = voiceRateId;
	}

	public boolean isMergeBill() {
		return isMergeBill;
	}

	public void setMergeBill(boolean isMergeBill) {
		this.isMergeBill = isMergeBill;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getStoreReceiverName() {
		return storeReceiverName;
	}

	public void setStoreReceiverName(String storeReceiverName) {
		this.storeReceiverName = storeReceiverName;
	}

	public String getStoreReceiverRocId() {
		return storeReceiverRocId;
	}

	public void setStoreReceiverRocId(String storeReceiverRocId) {
		this.storeReceiverRocId = storeReceiverRocId;
	}

	public String getStoreTel1() {
		return storeTel1;
	}

	public void setStoreTel1(String storeTel1) {
		this.storeTel1 = storeTel1;
	}

	public String getStoreTel2() {
		return storeTel2;
	}

	public void setStoreTel2(String storeTel2) {
		this.storeTel2 = storeTel2;
	}

	public String getStoreTelPrefix1() {
		return storeTelPrefix1;
	}

	public void setStoreTelPrefix1(String storeTelPrefix1) {
		this.storeTelPrefix1 = storeTelPrefix1;
	}

	public String getStoreTelPrefix2() {
		return storeTelPrefix2;
	}

	public void setStoreTelPrefix2(String storeTelPrefix2) {
		this.storeTelPrefix2 = storeTelPrefix2;
	}

	public String getPreSelctedCouponSerial() {
		return preSelctedCouponSerial;
	}

	public void setPreSelctedCouponSerial(String preSelctedCouponSerial) {
		this.preSelctedCouponSerial = preSelctedCouponSerial;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean isAddOnReceiver() {
		return addOnReceiver;
	}

	public void setAddOnReceiver(boolean addOnReceiver) {
		this.addOnReceiver = addOnReceiver;
	}

	public boolean isInvoiceDemand() {
		return isInvoiceDemand;
	}

	public void setInvoiceDemand(boolean isInvoiceDemand) {
		this.isInvoiceDemand = isInvoiceDemand;
	}

	public String getVatNo() {
		return vatNo;
	}

	public void setVatNo(String vatNo) {
		this.vatNo = vatNo;
	}

	public String getVatTitle() {
		return vatTitle;
	}

	public void setVatTitle(String vatTitle) {
		this.vatTitle = vatTitle;
	}

	public boolean isRegisterDemandActivity() {
		return registerDemandActivity;
	}

	public void setRegisterDemandActivity(boolean registerDemandActivity) {
		this.registerDemandActivity = registerDemandActivity;
	}

	public Long getActivityCouponId() {
		return activityCouponId;
	}

	public void setActivityCouponId(Long activityCouponId) {
		this.activityCouponId = activityCouponId;
	}

	public EntryPointEnum getEntryPoint() {
		return entryPoint;
	}

	public void setEntryPoint(EntryPointEnum entryPoint) {
		this.entryPoint = entryPoint;
	}

	public int getSelectionFee() {
		return selectionFee;
	}

	public void setSelectionFee(int selectionFee) {
		this.selectionFee = selectionFee;
	}

	public Integer getPreselectedHandsetGroupAmt() {
		return preselectedHandsetGroupAmt;
	}

	public void setPreselectedHandsetGroupAmt(Integer preselectedHandsetGroupAmt) {
		this.preselectedHandsetGroupAmt = preselectedHandsetGroupAmt;
	}

	public boolean isRegisterActivity() {
		return isRegisterActivity;
	}

	public void setRegisterActivity(boolean isRegisterActivity) {
		this.isRegisterActivity = isRegisterActivity;
	}

	public String getLoyaltyToken() {
		return loyaltyToken;
	}

	public void setLoyaltyToken(String loyaltyToken) {
		this.loyaltyToken = loyaltyToken;
	}

	public String getMergeBillMsisdn() {
		return mergeBillMsisdn;
	}

	public void setMergeBillMsisdn(String mergeBillMsisdn) {
		this.mergeBillMsisdn = mergeBillMsisdn;
	}

	public void setNewBillingTypeId(Long newBillingTypeId) {
		this.newBillingTypeId = newBillingTypeId;
	}

	public void setOldBillingTypeId(Long oldBillingTypeId) {
		this.oldBillingTypeId = oldBillingTypeId;
	}

	public Long getNewBillingTypeId() {
		return newBillingTypeId;
	}

	public Long getOldBillingTypeId() {
		return oldBillingTypeId;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getNpCompanyCode() {
		return npCompanyCode;
	}

	public void setNpCompanyCode(String npCompanyCode) {
		this.npCompanyCode = npCompanyCode;
	}

	public Integer getEntryNavigationId() {
		return entryNavigationId;
	}

	public void setEntryNavigationId(Integer entryNavigationId) {
		this.entryNavigationId = entryNavigationId;
	}

	public String getDeliAlt() {
		return deliAlt;
	}

	public void setDeliAlt(String deliAlt) {
		this.deliAlt = deliAlt;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getReceiverRocId() {
		return receiverRocId;
	}

	public void setReceiverRocId(String receiverRocId) {
		this.receiverRocId = receiverRocId;
	}

	public String getReceiverTel1() {
		return receiverTel1;
	}

	public void setReceiverTel1(String receiverTel1) {
		this.receiverTel1 = receiverTel1;
	}

	public String getReceiverTel2() {
		return receiverTel2;
	}

	public void setReceiverTel2(String receiverTel2) {
		this.receiverTel2 = receiverTel2;
	}

	public String getReceiverTelPrefix1() {
		return receiverTelPrefix1;
	}

	public void setReceiverTelPrefix1(String receiverTelPrefix1) {
		this.receiverTelPrefix1 = receiverTelPrefix1;
	}

	public String getReceiverTelPrefix2() {
		return receiverTelPrefix2;
	}

	public void setReceiverTelPrefix2(String receiverTelPrefix2) {
		this.receiverTelPrefix2 = receiverTelPrefix2;
	}

	public String getDeliTime() {
		return deliTime;
	}

	public void setDeliTime(String deliTime) {
		this.deliTime = deliTime;
	}

	public String getRedeemCouponSerial() {
		return redeemCouponSerial;
	}

	public void setRedeemCouponSerial(String redeemCouponSerial) {
		this.redeemCouponSerial = redeemCouponSerial;
	}

	public Long getHgRedeemPoint() {
		return hgRedeemPoint;
	}

	public void setHgRedeemPoint(Long hgRedeemPoint) {
		this.hgRedeemPoint = hgRedeemPoint;
	}

	public String getHgToken() {
		return hgToken;
	}

	public void setHgToken(String hgToken) {
		this.hgToken = hgToken;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public boolean isClickFinish() {
		return clickFinish;
	}

	public void setClickFinish(boolean clickFinish) {
		this.clickFinish = clickFinish;
	}

	public boolean isOrderSustained() {
		return orderSustained;
	}

	public void setOrderSustained(boolean orderSustained) {
		this.orderSustained = orderSustained;
	}

	public Long getHgRedeemPrice() {
		return hgRedeemPrice;
	}

	public void setHgRedeemPrice(Long hgRedeemPrice) {
		this.hgRedeemPrice = hgRedeemPrice;
	}

	public String getHgTotalPoint() {
		return hgTotalPoint;
	}

	public void setHgTotalPoint(String hgTotalPoint) {
		this.hgTotalPoint = hgTotalPoint;
	}

	public boolean isHappyGoRedeemed() {
		return happyGoRedeemed;
	}

	public void setHappyGoRedeemed(boolean happyGoRedeemed) {
		this.happyGoRedeemed = happyGoRedeemed;
	}

	public Long getHgRedeemId() {
		return hgRedeemId;
	}

	public void setHgRedeemId(Long hgRedeemId) {
		this.hgRedeemId = hgRedeemId;
	}

	public boolean isCart() {
		return cart;
	}

	public void setCart(boolean cart) {
		this.cart = cart;
	}

	public OrderHelperVO cloneVO() { 
		try { 
			// call clone in Object. 
			return (OrderHelperVO) super.clone(); 
		} catch(CloneNotSupportedException e) { 
			LogUtil.error("Cloning not allowed.");
			LogUtil.error(e);
			//System.out.println("Cloning not allowed."); 
			//e.printStackTrace();
			return this; 
		} 
	}
	
	public void combineVO(CrmVO crmVO){
		this.crmVO.setAccountID(crmVO.getAccountID());
		this.crmVO.setSubscriberID(crmVO.getSubscriberID());
		this.crmVO.setCustomerID(crmVO.getCustomerID());
	}

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public boolean isAcceptSms() {
		return acceptSms;
	}

	public void setAcceptSms(boolean acceptSms) {
		this.acceptSms = acceptSms;
	}

	public String getCallingcardTicket() {
		return callingcardTicket;
	}

	public void setCallingcardTicket(String callingcardTicket) {
		this.callingcardTicket = callingcardTicket;
	} 

	public String getExitMsg() {
		return exitMsg;
	}

	public void setExitMsg(String exitMsg) {
		this.exitMsg = exitMsg;
	}

	public String getHappyGoRocId() {
		return happyGoRocId;
	}

	public void setHappyGoRocId(String happyGoRocId) {
		this.happyGoRocId = happyGoRocId;
	}

	public String getPackageBrowsingStatisticId() {
		return packageBrowsingStatisticId;
	}

	public void setPackageBrowsingStatisticId(String packageBrowsingStatisticId) {
		this.packageBrowsingStatisticId = packageBrowsingStatisticId;
	}

	public String getRedeemCouponPassword() {
		return redeemCouponPassword;
	}

	public void setRedeemCouponPassword(String redeemCouponPassword) {
		this.redeemCouponPassword = redeemCouponPassword;
	}
	
	public Long getLeftPriceToDiscountForAccessory() {
		return leftPriceToDiscountForAccessory;
	}
	
	public void setLeftPriceToDiscountForAccessory(
			Long leftPriceToDiscountForAccessory) {
		this.leftPriceToDiscountForAccessory = leftPriceToDiscountForAccessory;
	}
	
	public Long getLeftPriceToDiscountForDevice() {
		return leftPriceToDiscountForDevice;
	}
	
	public void setLeftPriceToDiscountForDevice(Long leftPriceToDiscountForDevice) {
		this.leftPriceToDiscountForDevice = leftPriceToDiscountForDevice;
	}
	
	public Long getMpActivityId() {
		return mpActivityId;
	}
	
	public void setMpActivityId(Long mpActivityId) {
		this.mpActivityId = mpActivityId;
	}

	public String getEinvoiceDeviceType() {
		return einvoiceDeviceType;
	}

	public void setEinvoiceDeviceType(String einvoiceDeviceType) {
		this.einvoiceDeviceType = einvoiceDeviceType;
	}

	public String getEinvoiceDeviceId() {
		return einvoiceDeviceId;
	}

	public void setEinvoiceDeviceId(String einvoiceDeviceId) {
		this.einvoiceDeviceId = einvoiceDeviceId;
	}

	public String getDonateUnitId() {
		return donateUnitId;
	}

	public void setDonateUnitId(String donateUnitId) {
		this.donateUnitId = donateUnitId;
	}

	public String getDonateUnitName() {
		return donateUnitName;
	}

	public void setDonateUnitName(String donateUnitName) {
		this.donateUnitName = donateUnitName;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	} 

	public String getPreorderNo() {
		return preorderNo;
	}

	public void setPreorderNo(String preorderNo) {
		this.preorderNo = preorderNo;
	}

	public boolean isMobileWeb() {
		return isMobileWeb;
	}

	public void setMobileWeb(boolean isMobileWeb) {
		this.isMobileWeb = isMobileWeb;
	} 
	
	public boolean isWebtrendRecorded() {
		return webtrendRecorded;
	}

	public void setWebtrendRecorded(boolean webtrendRecorded) {
		this.webtrendRecorded = webtrendRecorded;
	}

	public boolean isAppFlow() {
		return appFlow;
	}

	public void setAppFlow(boolean appFlow) {
		this.appFlow = appFlow;
	}

	public String getRecommendSource() {
		return recommendSource;
	}

	public void setRecommendSource(String recommendSource) {
		this.recommendSource = recommendSource;
	}

	public String getRecommendDesc() {
		return recommendDesc;
	}

	public void setRecommendDesc(String recommendDesc) {
		this.recommendDesc = recommendDesc;
	}

	public String getMpid() {
		return mpid;
	}

	public void setMpid(String mpid) {
		this.mpid = mpid;
	}

	public String getMpidCheckSum() {
		return mpidCheckSum;
	}

	public void setMpidCheckSum(String mpidCheckSum) {
		this.mpidCheckSum = mpidCheckSum;
	}

	public Date getHgRedeemTime() {
		return hgRedeemTime;
	}

	public void setHgRedeemTime(Date hgRedeemTime) {
		this.hgRedeemTime = hgRedeemTime;
	}

	public boolean isPassVipLoyalty() {
		return isPassVipLoyalty;
	}

	public void setPassVipLoyalty(boolean isPassVipLoyalty) {
		this.isPassVipLoyalty = isPassVipLoyalty;
	}

	public Boolean getNetCoverRate() {
		return netCoverRate;
	}

	public void setNetCoverRate(Boolean netCoverRate) {
		this.netCoverRate = netCoverRate;
	}
	
	public String getCspMsisdn() {
		return cspMsisdn;
	}

	public void setCspMsisdn(String cspMsisdn) {
		this.cspMsisdn = cspMsisdn;
	}

	public String getAuctionMsisdn() {
		return auctionMsisdn;
	}

	public void setAuctionMsisdn(String auctionMsisdn) {
		this.auctionMsisdn = auctionMsisdn;
	}

	public Integer getAuctionActivityId() {
		return auctionActivityId;
	}

	public void setAuctionActivityId(Integer auctionActivityId) {
		this.auctionActivityId = auctionActivityId;
	}

	public String getAuctionRocId() {
		return auctionRocId;
	}

	public void setAuctionRocId(String auctionRocId) {
		this.auctionRocId = auctionRocId;
	}

	public Integer getAuctionPrice() {
		return auctionPrice;
	}

	public void setAuctionPrice(Integer auctionPrice) {
		this.auctionPrice = auctionPrice;
	}

	public String getUpgradeType() {
		return upgradeType;
	}

	public void setUpgradeType(String upgradeType) {
		this.upgradeType = upgradeType;
	}

	public String getAppSource() {
		return appSource;
	}

	public void setAppSource(String appSource) {
		this.appSource = appSource;
	}

	public String getMvpnVatNo() {
		return mvpnVatNo;
	}

	public void setMvpnVatNo(String mvpnVatNo) {
		this.mvpnVatNo = mvpnVatNo;
	}

	public String getMvpnStr() {
		return mvpnStr;
	}

	public void setMvpnStr(String mvpnStr) {
		this.mvpnStr = mvpnStr;
	}

	public String getO2oOrderId() {
		return o2oOrderId;
	}

	public void setO2oOrderId(String o2oOrderId) {
		this.o2oOrderId = o2oOrderId;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getTrial() {
		return trial;
	}

	public void setTrial(String trial) {
		this.trial = trial;
	}

	public String getNcRocId() {
		return ncRocId;
	}

	public void setNcRocId(String ncRocId) {
		this.ncRocId = ncRocId;
	}

    public String getPaymentConsolidation() {
        return paymentConsolidation;
    }

    public void setPaymentConsolidation(String paymentConsolidation) {
        this.paymentConsolidation = paymentConsolidation;
    }

	public String getPaymentConsolidationError() {
        return paymentConsolidationError;
    }

    public void setPaymentConsolidationError(String paymentConsolidationError) {
        this.paymentConsolidationError = paymentConsolidationError;
    }

    public Long getNameListId() {
		return nameListId;
	}

	public void setNameListId(Long nameListId) {
		this.nameListId = nameListId;
	}

    public Date getIdCardDate() {
        return idCardDate;
    }

    public void setIdCardDate(Date idCardDate) {
        this.idCardDate = idCardDate;
    }

    public String getIdCardCity() {
        return idCardCity;
    }

    public void setIdCardCity(String idCardCity) {
        this.idCardCity = idCardCity;
    }

    public String getIdCardType() {
        return idCardType;
    }

    public void setIdCardType(String idCardType) {
        this.idCardType = idCardType;
    }

	public boolean isMultiprod() {
		return isMultiprod;
	}

	public void setMultiprod(boolean isMultiprod) {
		this.isMultiprod = isMultiprod;
	}

	public String getMultiprodId() {
		return multiprodId;
	}

	public void setMultiprodId(String multiprodId) {
		this.multiprodId = multiprodId;
	}

	public List<String> getProductIds() {
		return productIds;
	}

	public void setProductIds(List<String> productIds) {
		this.productIds = productIds;
	}

	public List<String> getFetNos() {
		return fetNos;
	}

	public void setFetNos(List<String> fetNos) {
		this.fetNos = fetNos;
	}

	public CrmVO getCrmVO() {
		return crmVO;
	}

	public void setCrmVO(CrmVO crmVO) {
		this.crmVO = crmVO;
	}
	
	public Long getMultiprodNameListId() {
		return multiprodNameListId;
	}

	public void setMultiprodNameListId(Long multiprodNameListId) {
		this.multiprodNameListId = multiprodNameListId;
	}

	public String getMinisiteActivityId() {
		return minisiteActivityId;
	}

	public void setMinisiteActivityId(String minisiteActivityId) {
		this.minisiteActivityId = minisiteActivityId;
	}
	
	public String getMdmAccountId() {
		return mdmAccountId;
	}

	public void setMdmAccountId(String mdmAccountId) {
		this.mdmAccountId = mdmAccountId;
	}

	public String getMdmSubscriberId() {
		return mdmSubscriberId;
	}

	public void setMdmSubscriberId(String mdmSubscriberId) {
		this.mdmSubscriberId = mdmSubscriberId;
	}

	public String getMdmCustomerId() {
		return mdmCustomerId;
	}

	public void setMdmCustomerId(String mdmCustomerId) {
		this.mdmCustomerId = mdmCustomerId;
	}

	public boolean isLy3to4() {
		return ly3to4;
	}

	public void setLy3to4(boolean ly3to4) {
		this.ly3to4 = ly3to4;
	}

	public ANoteVO getaNoteVO() {
		return aNoteVO;
	}

	public void setaNoteVO(ANoteVO aNoteVO) {
		this.aNoteVO = aNoteVO;
	}

	public boolean isAddAnoteSuccess() {
		return addAnoteSuccess;
	}

	public void setAddAnoteSuccess(boolean addAnoteSuccess) {
		this.addAnoteSuccess = addAnoteSuccess;
	}

	public boolean isAddGiftRedeem() {
		return addGiftRedeem;
	}

	public void setAddGiftRedeem(boolean addGiftRedeem) {
		this.addGiftRedeem = addGiftRedeem;
	}

	public String getTransBpid() {
		return transBpid;
	}

	public void setTransBpid(String transBpid) {
		this.transBpid = transBpid;
	}
	
	public Long getPrepaymentPrice() {
		return prepaymentPrice;
	}

	public void setPrepaymentPrice(Long prepaymentPrice) {
		this.prepaymentPrice = prepaymentPrice;
	}

	public boolean isNba324() {
		return isNba324;
	}

	public void setNba324(boolean isNba324) {
		this.isNba324 = isNba324;
	}

	public String getSimcardNo() {
		return simcardNo;
	}

	public void setSimcardNo(String simcardNo) {
		this.simcardNo = simcardNo;
	}

	public boolean isCobranding() {
		return isCobranding;
	}

	public void setCobranding(boolean isCobranding) {
		this.isCobranding = isCobranding;
	}
	
    public boolean isNeilOrder() {
        return neilOrder;
    }

    public void setNeilOrder(boolean neilOrder) {
        this.neilOrder = neilOrder;
    }

    public String getNeilCono() {
        return neilCono;
    }

    public void setNeilCono(String neilCono) {
        this.neilCono = neilCono;
    }

	public boolean isAgreeReturnSpeedup() {
		return agreeReturnSpeedup;
	}

	public void setAgreeReturnSpeedup(boolean agreeReturnSpeedup) {
		this.agreeReturnSpeedup = agreeReturnSpeedup;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getLoyaltyRecordId() {
		return loyaltyRecordId;
	}

	public void setLoyaltyRecordId(String loyaltyRecordId) {
		this.loyaltyRecordId = loyaltyRecordId;
	}

	public int getInstallments() {
		return installments;
	}

	public void setInstallments(int installments) {
		this.installments = installments;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public String getNpxCono() {
		return npxCono;
	}

	public void setNpxCono(String npxCono) {
		this.npxCono = npxCono;
	}

	public String getNpxTxid() {
		return npxTxid;
	}

	public void setNpxTxid(String npxTxid) {
		this.npxTxid = npxTxid;
	}

	public Map<String, Integer> getCallingCardMap() {
		return callingCardMap;
	}

	public void setCallingCardMap(Map<String, Integer> callingCardMap) {
		this.callingCardMap = callingCardMap;
	}

	public String getJsonString() {
		return jsonString;
	}

	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}
	
	//phase 2
	public String getDeliTel() {
		return deliTel;
	}

	public void setDeliTel(String deliTel) {
		this.deliTel = deliTel;
	}

	public boolean isRegAsBill() {
		return regAsBill;
	}

	public boolean isRegAsAddr() {
		return regAsAddr;
	}

	public void setRegAsBill(boolean regAsBill) {
		this.regAsBill = regAsBill;
	}

	public void setRegAsAddr(boolean regAsAddr) {
		this.regAsAddr = regAsAddr;
	}

	public String getVatTp() {
		return vatTp;
	}

	public void setVatTp(String vatTp) {
		this.vatTp = vatTp;
	}

	public boolean isAgreeContract() {
		return agreeContract;
	}

	public void setAgreeContract(boolean agreeContract) {
		this.agreeContract = agreeContract;
	}

	public String getBackFromUri() {
		return backFromUri;
	}

	public void setBackFromUri(String backFromUri) {
		this.backFromUri = backFromUri;
	}

	public String getDspUserProfileUuid() {
		return dspUserProfileUuid;
	}

	public void setDspUserProfileUuid(String dspUserProfileUuid) {
		this.dspUserProfileUuid = dspUserProfileUuid;
	}

	public String getOrderChannel() {
		return orderChannel;
	}

	public void setOrderChannel(String orderChannel) {
		this.orderChannel = orderChannel;
	}

	public String getLastPaymentMethodAns() {
		return lastPaymentMethodAns;
	}

	public void setLastPaymentMethodAns(String lastPaymentMethodAns) {
		this.lastPaymentMethodAns = lastPaymentMethodAns;
	}

	public String getLastPaymentMethod() {
		return lastPaymentMethod;
	}

	public void setLastPaymentMethod(String lastPaymentMethod) {
		this.lastPaymentMethod = lastPaymentMethod;
	}

	public String getCohTxid() {
		return cohTxid;
	}

	public void setCohTxid(String cohTxid) {
		this.cohTxid = cohTxid;
	}

	public String getCredentialFile1No() {
		return credentialFile1No;
	}

	public void setCredentialFile1No(String credentialFile1No) {
		this.credentialFile1No = credentialFile1No;
	}

	public String getCredentialFile2No() {
		return credentialFile2No;
	}

	public void setCredentialFile2No(String credentialFile2No) {
		this.credentialFile2No = credentialFile2No;
	}

	public String getCredentialFile3No() {
		return credentialFile3No;
	}

	public void setCredentialFile3No(String credentialFile3No) {
		this.credentialFile3No = credentialFile3No;
	}

	public String getCredentialFile4No() {
		return credentialFile4No;
	}

	public void setCredentialFile4No(String credentialFile4No) {
		this.credentialFile4No = credentialFile4No;
	}

	public String getCohOrderId() {
		return cohOrderId;
	}

	public void setCohOrderId(String cohOrderId) {
		this.cohOrderId = cohOrderId;
	}

	public String getCsStoreCvsid() {
		return csStoreCvsid;
	}

	public String getCsStoreCvsname() {
		return csStoreCvsname;
	}

	public String getCsStoreNo() {
		return csStoreNo;
	}

	public String getCsStoreName() {
		return csStoreName;
	}

	public String getCsStoreTel() {
		return csStoreTel;
	}

	public String getCsStoreAddress() {
		return csStoreAddress;
	}

	public void setCsStoreCvsid(String csStoreCvsid) {
		this.csStoreCvsid = csStoreCvsid;
	}

	public void setCsStoreCvsname(String csStoreCvsname) {
		this.csStoreCvsname = csStoreCvsname;
	}

	public void setCsStoreNo(String csStoreNo) {
		this.csStoreNo = csStoreNo;
	}

	public void setCsStoreName(String csStoreName) {
		this.csStoreName = csStoreName;
	}

	public void setCsStoreTel(String csStoreTel) {
		this.csStoreTel = csStoreTel;
	}

	public void setCsStoreAddress(String csStoreAddress) {
		this.csStoreAddress = csStoreAddress;
	}

	public String getExtraService() {
		return extraService;
	}

	public void setExtraService(String extraService) {
		this.extraService = extraService;
	}

    public boolean isSelfHelpingPromotion() {
        return isSelfHelpingPromotion;
    }

    public String getSelfHelpingPromotionName() {
        return selfHelpingPromotionName;
    }

    public String getSelfHelpingPromotion1() {
        return selfHelpingPromotion1;
    }

    public String getSelfHelpingPromotion2() {
        return selfHelpingPromotion2;
    }

    public String getSelfHelpingPromotion3() {
        return selfHelpingPromotion3;
    }

    public void setSelfHelpingPromotion(boolean isSelfHelpingPromotion) {
        this.isSelfHelpingPromotion = isSelfHelpingPromotion;
    }

    public void setSelfHelpingPromotionName(String selfHelpingPromotionName) {
        this.selfHelpingPromotionName = selfHelpingPromotionName;
    }

    public void setSelfHelpingPromotion1(String selfHelpingPromotion1) {
        this.selfHelpingPromotion1 = selfHelpingPromotion1;
    }

    public void setSelfHelpingPromotion2(String selfHelpingPromotion2) {
        this.selfHelpingPromotion2 = selfHelpingPromotion2;
    }

    public void setSelfHelpingPromotion3(String selfHelpingPromotion3) {
        this.selfHelpingPromotion3 = selfHelpingPromotion3;
    }

	public String getCsStoreAreaCode() {
		return csStoreAreaCode;
	}

	public void setCsStoreAreaCode(String csStoreAreaCode) {
		this.csStoreAreaCode = csStoreAreaCode;
	}


	public Boolean getCncDeliveryOrder() {
		return cncDeliveryOrder;
	}


	public void setCncDeliveryOrder(Boolean cncDeliveryOrder) {
		this.cncDeliveryOrder = cncDeliveryOrder;
	}    
	
	
    
	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}
	
	public String getCaptcha() {
		return captcha;
	}
	
	public String getrId() {
		return rId;
	}

	public void setrId(String rId) {
		this.rId = rId;
	}

	public String getClickId() {
		return clickId;
	}

	public void setClickId(String clickId) {
		this.clickId = clickId;
	}

	public boolean isFromMarketAmerica() {
		return isFromMarketAmerica;
	}

	public void setFromMarketAmerica(boolean isFromMarketAmerica) {
		this.isFromMarketAmerica = isFromMarketAmerica;
	}
	
	public boolean getIsFirday() {
		return isFirday;
	}
	
	public void setIsFirday(boolean isFirday) {
		this.isFirday = isFirday;
	}
	
	public String getFridayOrderType() {
		return fridayOrderType;
	}
	
	public void setFridayOrderType(String fridayOrderType) {
		this.fridayOrderType = fridayOrderType;
	}
	
	public String getFridayOrderNo() {
		return fridayOrderNo;
	}
	public void setFridayOrderNo(String fridayOrderNo) {
		this.fridayOrderNo = fridayOrderNo;
	}

	public boolean isEbu() {
		return isEbu;
	}

	public void setEbu(boolean isEbu) {
		this.isEbu = isEbu;
	}

	public boolean isInsurance() {
		return isInsurance;
	}

	public void setInsurance(boolean isInsurance) {
		this.isInsurance = isInsurance;
	}

	public boolean isPremium() {
		return isPremium;
	}

	public void setPremium(boolean isPremium) {
		this.isPremium = isPremium;
	}

	public String getPremiumTitle() {
		return premiumTitle;
	}

	public void setPremiumTitle(String premiumTitle) {
		this.premiumTitle = premiumTitle;
	}

	public Integer getPremiumBuyCount() {
		return premiumBuyCount;
	}

	public void setPremiumBuyCount(Integer premiumBuyCount) {
		this.premiumBuyCount = premiumBuyCount;
	}
	

	public Map<Long, Integer> getPremiumGroup1() {
		return premiumGroup1;
	}

	public void setPremiumGroup1(Map<Long, Integer> premiumGroup1) {
		this.premiumGroup1 = premiumGroup1;
	}

	public Map<Long, Integer> getPremiumGroup2() {
		return premiumGroup2;
	}

	public void setPremiumGroup2(Map<Long, Integer> premiumGroup2) {
		this.premiumGroup2 = premiumGroup2;
	}

	public String getEbuSubscriberType() {
		return ebuSubscriberType;
	}

	public void setEbuSubscriberType(String ebuSubscriberType) {
		this.ebuSubscriberType = ebuSubscriberType;
	}

	public String getCredentialFile5No() {
		return credentialFile5No;
	}

	public void setCredentialFile5No(String credentialFile5No) {
		this.credentialFile5No = credentialFile5No;
	}

	public List<String> getCredentialFile6No() {
		return credentialFile6No;
	}

	public void setCredentialFile6No(List<String> credentialFile6No) {
		this.credentialFile6No = credentialFile6No;
	}

	public String getEbuVatNo() {
		return ebuVatNo;
	}

	public void setEbuVatNo(String ebuVatNo) {
		this.ebuVatNo = ebuVatNo;
	}

	public String getEbuVatTitle() {
		return ebuVatTitle;
	}

	public void setEbuVatTitle(String ebuVatTitle) {
		this.ebuVatTitle = ebuVatTitle;
	}

	public String getEbuRecomName() {
		return ebuRecomName;
	}

	public void setEbuRecomName(String ebuRecomName) {
		this.ebuRecomName = ebuRecomName;
	}

	public String getEbuRecomMsisdn() {
		return ebuRecomMsisdn;
	}

	public void setEbuRecomMsisdn(String ebuRecomMsisdn) {
		this.ebuRecomMsisdn = ebuRecomMsisdn;
	}

	public String getUploadImagePageSidByAPP() {
		return uploadImagePageSidByAPP;
	}

	public void setUploadImagePageSidByAPP(String uploadImagePageSidByAPP) {
		this.uploadImagePageSidByAPP = uploadImagePageSidByAPP;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getXff() {
		return xff;
	}

	public void setXff(String xff) {
		this.xff = xff;
	}


	public OcrIDrEresVO getOcrIDrEresVO() {
		return ocrIDrEresVO;
	}

	public void setOcrIDrEresVO(OcrIDrEresVO ocrIDrEresVO) {
		this.ocrIDrEresVO = ocrIDrEresVO;
	}

	public List<String> getOcrSn() {
		return ocrSn;
	}

	public void setOcrSn(List<String> ocrSn) {
		this.ocrSn = ocrSn;
	}

	public String getDelayChoose() {
		return delayChoose;
	}

	public void setDelayChoose(String delayChoose) {
		this.delayChoose = delayChoose;
	}

	public String getApplicantSignType() {
		return ApplicantSignType;
	}

	public void setApplicantSignType(String applicantSignType) {
		ApplicantSignType = applicantSignType;
	}

	public Boolean getIsOffshoreIsland() {
		return isOffshoreIsland;
	}

	public void setIsOffshoreIsland(Boolean isOffshoreIsland) {
		this.isOffshoreIsland = isOffshoreIsland;
	}

	public Boolean getIsCheckOnceContract9M() {
		return isCheckOnceContract9M;
	}

	public void setIsCheckOnceContract9M(Boolean isCheckOnceContract9M) {
		this.isCheckOnceContract9M = isCheckOnceContract9M;
	}

	public List<String> getContentOfferIdList() {
		return contentOfferIdList;
	}

	public void setContentOfferIdList(List<String> contentOfferIdList) {
		this.contentOfferIdList = contentOfferIdList;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}
	
	public Map<String, String> getOcrAttrMap() {
	    return ocrAttrMap;
	}

	public void setOcrAttrMap(Map<String, String> ocrAttrMap) {
	    this.ocrAttrMap = ocrAttrMap;
	}
}
