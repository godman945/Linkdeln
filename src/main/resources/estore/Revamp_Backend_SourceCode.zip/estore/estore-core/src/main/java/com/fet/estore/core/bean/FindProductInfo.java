package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

/**
 * 找商品資料結構
 * 
 * @description
 * @author Alex.Zhu
 * @date 2020-07-10
 */
public class FindProductInfo implements Serializable {
	
	private static final long serialVersionUID = 1L;
	/** 探索區塊 */
	private SearchList searchList;
	/** 廠牌下拉選單 */
	private BrandList brandList;
	/** 麵包屑資訊 add by Phil.Lin 20200727*/
	private List<BreadCrumbs> breadcrumbs;
	/** 常見問題 add by Klyve.Chen 20200818*/
	private List<FaqItem> faqItems;

	public SearchList getSearchList() {
		return searchList;
	}
	public void setSearchList(SearchList searchList) {
		this.searchList = searchList;
	}
	public BrandList getBrandList() {
		return brandList;
	}
	public void setBrandList(BrandList brandList) {
		this.brandList = brandList;
	}
	public List<BreadCrumbs> getBreadcrumbs() {
		return breadcrumbs;
	}
	public void setBreadcrumbs(List<BreadCrumbs> breadcrumbs) {
		this.breadcrumbs = breadcrumbs;
	}
	public List<FaqItem> getFaqItems() {
		return faqItems;
	}
	public void setFaqItems(List<FaqItem> faqItems) {
		this.faqItems = faqItems;
	}
}
