package com.fet.estore.core.bean;

public class IdNum41 implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	/**
	 * 身份證號
	 */
	String id;
	/**
	 * 序號
	 */
	String sn;
	/**
	 * 姓名
	 */
	String name;
	
	/**
	 * 生日
	 */
	String birthday;
	/**
	 * 生日八碼數字 19781005
	 */
	String birthdayYyyymmdd;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getBirthdayYyyymmdd() {
		return birthdayYyyymmdd;
	}
	public void setBirthdayYyyymmdd(String birthdayYyyymmdd) {
		this.birthdayYyyymmdd = birthdayYyyymmdd;
	}
	
}
