package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * 商品別名VO
 * 
 * @author samho
 */
public class DeviceAliasUrlVO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7326905986016604061L;

	/** 商品編號 */
	private String productId;
	
	/** 商品類別群組名稱 */
	private String categoryGroupName;
	
	/** 商品別名 */
	private String aliasUrl;
	
	/**
	 * 預設建構子。
	 */
	public DeviceAliasUrlVO() {
		super();
	}
	
	/**
	 * 建構子。
	 * @param productId 商品編號。
	 * @param categoryGroupName 商品類別群組名稱。
	 * @param aliasUrl 商品別名。
	 */
	public DeviceAliasUrlVO(String productId, String categoryGroupName, String aliasUrl) {
		super();
		this.productId = productId;
		this.categoryGroupName = categoryGroupName;
		this.aliasUrl = aliasUrl;
	}

	/**
	 * 取得productId。
	 *
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * 設定productId。
	 *
	 * @param productId 欲設定的productId。
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * 取得categoryGroupName。
	 *
	 * @return the categoryGroupName
	 */
	public String getCategoryGroupName() {
		return categoryGroupName;
	}

	/**
	 * 設定categoryGroupName。
	 *
	 * @param categoryGroupName 欲設定的categoryGroupName。
	 */
	public void setCategoryGroupName(String categoryGroupName) {
		this.categoryGroupName = categoryGroupName;
	}

	/**
	 * 取得aliasUrl。
	 *
	 * @return the aliasUrl
	 */
	public String getAliasUrl() {
		return aliasUrl;
	}

	/**
	 * 設定aliasUrl。
	 *
	 * @param aliasUrl 欲設定的aliasUrl。
	 */
	public void setAliasUrl(String aliasUrl) {
		this.aliasUrl = aliasUrl;
	}

	/** 
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object other) {
		if (this == other) {
			return true;
		}
 		
		if (!(other instanceof DeviceAliasUrlVO)) {
			return false;
		}
		
		DeviceAliasUrlVO castOther = (DeviceAliasUrlVO) other;
		
		return new EqualsBuilder()
				.append(productId, castOther.productId)
				.append(categoryGroupName, castOther.categoryGroupName)
				.append(aliasUrl, castOther.aliasUrl)
				.isEquals();
	}

	/** 
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return new HashCodeBuilder()
				.append(productId)
				.append(categoryGroupName)
				.append(aliasUrl)
				.toHashCode();
	}

	/** 
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this).appendSuper(super.toString())
				.append("productId", productId)
				.append("categoryGroupName", categoryGroupName)
				.append("aliasUrl", aliasUrl)
				.toString();
	}
}
