package com.fet.estore.core.bean;

import java.io.Serializable;
import java.util.List;

import com.fet.estore.core.bean.vo.AccessoryVO;

public class AccessoryInfo implements Serializable {

	private static final long serialVersionUID = -2491099045856992929L;
	
	private List<AccessoryVO> accessoryVO;
	
	/** 麵包屑資訊 */
	private List<BreadCrumbs> breadcrumbs;

	public List<AccessoryVO> getAccessoryVO() {
		return accessoryVO;
	}

	public void setAccessoryVO(List<AccessoryVO> accessoryVO) {
		this.accessoryVO = accessoryVO;
	}

	public List<BreadCrumbs> getBreadcrumbs() {
		return breadcrumbs;
	}

	public void setBreadcrumbs(List<BreadCrumbs> breadcrumbs) {
		this.breadcrumbs = breadcrumbs;
	}

}
