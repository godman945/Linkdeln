package com.fet.estore.core.bean.bo;

/**
 * @description 商品遞送條件
 * @author Dennis.Chen
 * @Date 2020-08-18
 */
public class DeliveryTypeBO {

    boolean isHome;  //宅配
    boolean isStore; //門市取貨

    public boolean isHome() {
        return isHome;
    }

    public void setHome(boolean home) {
        isHome = home;
    }

    public boolean isStore() {
        return isStore;
    }

    public void setStore(boolean store) {
        isStore = store;
    }
}
