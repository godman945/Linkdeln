package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

import com.fet.estore.core.util.StringUtil;

public class HandsetRankingVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	/** 商品編號 */
	private String productId;
	/** 手機型號 */
	private String modelName;
	/** 說明小標題 */
	private String viewTitle;
	/** 簡要說明 */
	private String viewDesc;
	/** 最低價格。 */
	private Long lowestPrice;
	/** 續約最低價格。 */
	private Long lyLowestPrice;
	/** 顯示的圖片路徑 */
	private String imagePath;
	/** 顯示的圖片路徑(小網用) */
	private String mImagePath;
	/** 顯示的圖片路徑(小網用熱銷排行榜要使用大圖) */
	private String lImagePath;
	/** 廠牌 */
	private String brand;
	/** 手機、平板筆電別名 */
	private String handsetAliasUrl;
	/** 配件別名 */
	private String accessoryAliasUrl;
	/** 小網 熱銷商品 左上的促銷文字 */
	private String promotionWording;
	/** 小網 熱銷商品 補充文字 */
	private String mobileOtherDesc;
	
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getViewTitle() {
		return viewTitle;
	}
	public void setViewTitle(String viewTitle) {
		this.viewTitle = viewTitle;
	}
	public String getViewDesc() {
		return viewDesc;
	}
	public void setViewDesc(String viewDesc) {
		this.viewDesc = viewDesc;
	}
	public Long getLowestPrice() {
		return lowestPrice;
	}
	public void setLowestPrice(Long lowestPrice) {
		this.lowestPrice = lowestPrice;
	}
	public Long getLyLowestPrice() {
		return lyLowestPrice;
	}
	public void setLyLowestPrice(Long lyLowestPrice) {
		this.lyLowestPrice = lyLowestPrice;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getHandsetAliasUrl() {
		return handsetAliasUrl;
	}
	public void setHandsetAliasUrl(String handsetAliasUrl) {
		this.handsetAliasUrl = handsetAliasUrl;
	}
	public String getAccessoryAliasUrl() {
		return accessoryAliasUrl;
	}
	public void setAccessoryAliasUrl(String accessoryAliasUrl) {
		this.accessoryAliasUrl = accessoryAliasUrl;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getmImagePath() {
		return mImagePath;
	}
	public void setmImagePath(String mImagePath) {
		this.mImagePath = mImagePath;
	}
	
	public String getlImagePath() {
		return lImagePath;
	}
	public void setlImagePath(String lImagePath) {
		this.lImagePath = lImagePath;
	}
	public String getPromotionWording() {
		return promotionWording;
	}
	public void setPromotionWording(String promotionWording) {
		this.promotionWording = promotionWording;
	}
	/**
	 * 用於畫面輸出，有出 <br/> 的wording
	 * @return
	 */
	public String getPromotionWordingLineBreak() {
		return StringUtil.getPromotionWordingLineBreak(promotionWording);
	}
	
	public String getMobileOtherDesc() {
		return mobileOtherDesc;
	}
	public void setMobileOtherDesc(String mobileOtherDesc) {
		this.mobileOtherDesc = mobileOtherDesc;
	}
	@Override
	public String toString() {
		return "HandsetRankingVO [productId=" + productId + ", modelName="
				+ modelName + ", viewTitle=" + viewTitle + ", viewDesc="
				+ viewDesc + ", lowestPrice=" + lowestPrice
				+ ", lyLowestPrice=" + lyLowestPrice + ", imagePath="
				+ imagePath + ", mImagePath=" + mImagePath + ", brand=" + brand
				+ ", handsetAliasUrl=" + handsetAliasUrl
				+ ", accessoryAliasUrl=" + accessoryAliasUrl
				+ ", promotionWording=" + promotionWording
				+ ", mobileOtherDesc=" + mobileOtherDesc + "]";
	}
	
	
}	
