package com.fet.estore.core.bean.vo.crm;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ANoteVO implements Serializable {

	private DynamicANoteVO dynamicANoteVO;
	
	private GiftRedeemOmniVO giftRedeemOmniVO;
	
	private IcePromotionANoteVO icePromotionANoteVO;
	
	private String masterPromoId;
	
	private String rpPromoId;
	
	private String rcPromoId;
	
	public ANoteVO(DynamicANoteVO dynamicANoteVO){
		this.dynamicANoteVO = dynamicANoteVO;
	}
	
	public ANoteVO(GiftRedeemOmniVO giftRedeemOmniVO){
		this.giftRedeemOmniVO = giftRedeemOmniVO;
	}
	
	public ANoteVO(IcePromotionANoteVO icePromotionANoteVO){
		this.icePromotionANoteVO = icePromotionANoteVO;
	}
	
	public ANoteVO(DynamicANoteVO dynamicANoteVO, GiftRedeemOmniVO giftRedeemOmniVO, IcePromotionANoteVO icePromotionANoteVO){
		this.dynamicANoteVO = dynamicANoteVO;
		this.giftRedeemOmniVO = giftRedeemOmniVO;
		this.icePromotionANoteVO = icePromotionANoteVO;
	}
	
	
	public String getANote(){
		
		
		  StringBuilder masterAnote = new StringBuilder();
          StringBuilder rpAnote = new StringBuilder();
          StringBuilder rcAnote = new StringBuilder();
		
		
		 for(String key : this.getANoteMap().keySet()){
         	
			 
			 
			 if(key.equals(this.getMasterPromoId())){
         		if(masterAnote.length() > 0){
         			masterAnote.append("\r\n");
         		}
         		masterAnote.append(this.getANoteMap().get(key));
         	}


     		if(key.equals(this.getRpPromoId())){
     			if(rpAnote.length() > 0){
     				rpAnote.append("\r\n");
     			}
     			rpAnote.append(this.getANoteMap().get(key));
     		}

     		if(key.equals(this.getRcPromoId())){
     			if(rcAnote.length() > 0){
     				rcAnote.append("\r\n");
     			}
     			rcAnote.append(this.getANoteMap().get(key));
     		}
         }
         //master anote,把bundle,rp,rc的Anote都組合起來
         //rp,rc的Anote也要各自傳送
         if(masterAnote.length() > 0 || rpAnote.length() > 0 || rcAnote.length() > 0){
        	
         	if(rpAnote.length() > 0){
         		if(masterAnote.length() > 0) {
         			masterAnote.append("\r\n");
         		}
         		masterAnote.append(rpAnote.toString());
         	}
         	
         	if( rcAnote.length() > 0){
         		if(masterAnote.length() > 0) {
         			masterAnote.append("\r\n");
         		}
         		masterAnote.append(rcAnote.toString());
         	}
         }

		
		return masterAnote.toString();
		
		
		/*
		Map<String, String> aNote = new HashMap<String, String>();
		Set<String> keys = this.icePromotionANoteVO.getAllANote().keySet();
		StringBuilder sb1  = new StringBuilder();
		StringBuilder sb2  = new StringBuilder();
		StringBuilder sb3  = new StringBuilder();
		
		for(String key : keys){
			StringBuilder sb = new StringBuilder();
			String icePromotionANote = this.icePromotionANoteVO.getANote(key);
			String dynamicANote = dynamicANoteVO.getANote(key);
			String giftRedeemANote = giftRedeemOmniVO.getANote(key);
			
			
			
			
			
			if(giftRedeemANote != null){
				sb.append(giftRedeemANote);
				sb1.append(giftRedeemANote);
			}
			
			if(icePromotionANote != null){
				sb.append(icePromotionANote);
				sb2.append(icePromotionANote);
			}
			
			if(dynamicANote != null){
				sb.append(dynamicANote);
				sb3.append(dynamicANote);
			}
//			if(sb.length() > 0){
//				aNote.put(key, sb.toString());
//			}
			
		}
		
		//return aNote;
		StringBuilder totalANote = new StringBuilder();
		if(sb1.length() > 0){
			totalANote.append(sb1.toString());
		}
		
		if(sb2.length() > 0){
			if(totalANote.length() > 0){
				totalANote.append("\r\n");
			}
			totalANote.append(sb2.toString());
		}
		
		if(sb3.length() > 0){
			if(totalANote.length() > 0){
				totalANote.append("\r\n");
			}
			totalANote.append(sb3.toString());
		}
		
		
		
		return totalANote.toString();
		*/
	}
	
	
	
	public Map<String, String> getANoteMap(){
		Map<String, String> aNote = new HashMap<String, String>();
		Set<String> keys = this.icePromotionANoteVO.getAllANote().keySet();
		StringBuilder sb1  = new StringBuilder();
		StringBuilder sb2  = new StringBuilder();
		StringBuilder sb3  = new StringBuilder();
		//這個呼叫已經把重複的值濾掉了
		Map<String, String> dynamicAnoteMap = dynamicANoteVO.getAllANote();
		for(String key : keys){
			StringBuilder sb = new StringBuilder();
			String icePromotionANote = this.icePromotionANoteVO.getANote(key);
			//dynamic anote有內容重複問題,要另外處理
			//String dynamicANote = dynamicANoteVO.getANote(key);
			String giftRedeemANote = giftRedeemOmniVO.getANote(key);

			if(giftRedeemANote != null){
				if(sb.length() > 0) {
					sb.append("\r\n");
				}
				sb.append(giftRedeemANote);
			}
			
			if(icePromotionANote != null){
				if(sb.length() > 0) {
					sb.append("\r\n");
				}
				sb.append(icePromotionANote);
			}
			//dynamic anote有內容重複問題,要另外處理
			if(dynamicAnoteMap.get(key) != null){
				if(sb.length() > 0) {
					sb.append("\r\n");
				}
				sb.append(dynamicAnoteMap.get(key));
			}
			if(sb.length() > 0){
				aNote.put(key, sb.toString());
			}			
		}
		return aNote;
	}
	
	
	
	
	//campaign code	:	gift code 
	public Map<String, String> getGiftRedeemCode(){
		return this.giftRedeemOmniVO.getAllReemCode();
	}
	
	public String getPrepaymentCode(){
		return this.giftRedeemOmniVO.getPrepaymentCode();
	}
	
	public Long getPrepaymentPrice(){
		return this.giftRedeemOmniVO.getPrepaymentPrice();
	}
	
	public String getPrepaymentPromotionId(){
		return this.giftRedeemOmniVO.getPrepaymentPromotionId();
	}
	
	public String getPrepaymentPromotionType(){
		return this.giftRedeemOmniVO.getPrepaymentPromotionType();
	}

	public String getPrepaymentFetno(){
		return this.giftRedeemOmniVO.getPrepaymentFetno();
	}
	public Long getSubsidyPrice(){
		return giftRedeemOmniVO.getSubsidyPrice();
	}
	
	public String getPrepaymentName(){
		return giftRedeemOmniVO.getPrepaymentName();
	}
	
	public DynamicANoteVO getDynamicANoteVO() {
		return dynamicANoteVO;
	}

	public void setDynamicANoteVO(DynamicANoteVO dynamicANoteVO) {
		this.dynamicANoteVO = dynamicANoteVO;
	}

	public GiftRedeemOmniVO getGiftRedeemOmniVO() {
		return giftRedeemOmniVO;
	}

	public void setGiftRedeemOmniVO(GiftRedeemOmniVO giftRedeemOmniVO) {
		this.giftRedeemOmniVO = giftRedeemOmniVO;
	}

	public IcePromotionANoteVO getIcePromotionANoteVO() {
		return icePromotionANoteVO;
	}

	public void setIcePromotionANoteVO(IcePromotionANoteVO icePromotionANoteVO) {
		this.icePromotionANoteVO = icePromotionANoteVO;
	}

	public String getMasterPromoId() {
		return masterPromoId;
	}

	public void setMasterPromoId(String masterPromoId) {
		this.masterPromoId = masterPromoId;
	}

	public String getRpPromoId() {
		return rpPromoId;
	}

	public void setRpPromoId(String rpPromoId) {
		this.rpPromoId = rpPromoId;
	}

	public String getRcPromoId() {
		return rcPromoId;
	}

	public void setRcPromoId(String rcPromoId) {
		this.rcPromoId = rcPromoId;
	}
	
	
	
	
}
