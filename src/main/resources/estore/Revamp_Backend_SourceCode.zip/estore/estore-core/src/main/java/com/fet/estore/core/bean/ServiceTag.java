package com.fet.estore.core.bean;

import java.io.Serializable;

/**
 * 首頁 - 看看大家都搜什麽 標籤
 * 
 * @description
 * @author Phil.lin
 * @date 2020-07-10
 */
public class ServiceTag implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1828758322435958732L;
	
	/** 名稱 */
	private String name;
	/** URL */
	private String link;
	/** A 標籤的 target */
	private String target;
	
	public ServiceTag() {
		super();
	}
	
	public ServiceTag(String name, String link, String target) {
		super();
		this.name = name;
		this.link = link;
		switch(target) {
		default:
		case "SELF":
			this.target = "_self";
			break;
		case "NEW":
			this.target = "_blank";
			break;
		}
		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}
	
}
