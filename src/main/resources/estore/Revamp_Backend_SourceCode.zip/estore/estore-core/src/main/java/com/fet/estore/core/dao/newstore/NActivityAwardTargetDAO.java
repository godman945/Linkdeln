package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.ActivityAwardTarget;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 活動贈品限制條件DAO
 * @author Max Chen
 *
 */
public interface NActivityAwardTargetDAO extends BaseDAO<ActivityAwardTarget, Long>  {
	
	/**
	 * 是否為有效申辦類別
	 * @param id
	 * @return
	 */
	public boolean isValidOrderType(Long id, String orderType);
	
	/**
	 * 取得活動限制條件
	 * @param id
	 * @return
	 */
	public Map<String, Set<String>> findTargetsByActivityId(Long id);

	/**
	 * 最得遞送方式
	 * @param id
	 * @return
	 */
	public List<ActivityAwardTarget> findDeliveryTypeByActivityId(Long id);
	
	/**
	 * 取得申辦類別
	 * @param activityId
	 * @return
	 */
	public String findOrderTypeByActivityIdAndLy(Long activityId);

	/**
	 * 取得對應activityTarget Device的數量
	 * @param activityId 活動Id
	 * @return
	 */
	public long findCountOfDeviceById(Long activityId);
}
