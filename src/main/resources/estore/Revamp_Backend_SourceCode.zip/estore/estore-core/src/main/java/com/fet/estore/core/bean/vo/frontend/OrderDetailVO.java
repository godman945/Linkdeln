package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * 申購完成頁顯示畫面資料的物件紀錄。
 *
 * @version $Id: OrderDetailVO.java,v 1.0.1.1, 2017-09-18 06:27:11Z, Russell Lee$
 */
@SuppressWarnings("serial")
public class OrderDetailVO implements Serializable{
	
	/** 商品 {@value} */
	public static final String PRODUCT_TYPE_NAME_PRODUCT = "商品";
	/** 費率 {@value} */
	public static final String PRODUCT_TYPE_NAME_VOICE = "費率";
	/** 門號 {@value} */
	public static final String PRODUCT_TYPE_NAME_MSISDN = "門號";
	/** 結標價格 {@value} */
	public static final String PRODUCT_TYPE_NAME_AUCTION = "得標費";
	/** 配件 {@value} */
	public static final String PRODUCT_TYPE_NAME_ACCESSORY = "配件";
	/** 贈品 {@value} */
	public static final String PRODUCT_TYPE_NAME_GIFT = "贈品";
	/** 商品折扣 {@value} */
	public static final String PRODUCT_TYPE_NAME_DISCOUNT = "商品折扣";
	/** 帳單回饋 {@value} */
	public static final String PRODUCT_TYPE_NAME_OFFER = "帳單回饋";
	/** 贈送的優惠券 {@value} */
	public static final String PRODUCT_TYPE_NAME_COUPON = "優惠券贈送";
	/** 使用的優惠券 {@value} */
	public static final String PRODUCT_TYPE_NAME_USECOUPON = "優惠券折抵";
	/** 使用的快樂購點數 {@value} */
	public static final String PRODUCT_TYPE_NAME_HAPPYGO = "快樂購點數";
	/** 單買配件運費 {@value} */
	public static final String PRODUCT_TYPE_NAME_SHIPMENT_FEE = "運費";
	
	public static final String PRODUCT_TYPE_NAME_EXTRA_BUY = "加購";
	
	//nds add
	/** 專案商品 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_PROJECT_PRODUCT = "專案商品";
	/** 資費方案 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_VOICE = "資費方案";
	/** 申辦門號 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_MSISDN = "申辦門號";
	/** 門號得標費 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_AUCTION = "門號得標費";
	/** 門號選號費 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_SELECTION_FEE = "門號選號費";
	/** 加購商品 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_EXTRA_BUY = "加購商品";
	/** 優惠券 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_COUPON = "優惠券";
	/** 證件上傳狀態 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_STATUS = "證件上傳狀態";
	/** 預繳金額 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_PREPAID_PRICE = "預繳金額";
	/** 專屬加購 {@value} */
	public static final String NDS_PRODUCT_TYPE_NAME_PREMIUM = "專屬加購";
	
	/**例如商品、費率、門號...*/
	private String productTypeName;
	/** 商品名稱 */
	private String productName;
	/** 備註 */
	private String  memo;
	/** 商品單價 */
	private Long money;
	/** 商品單價 */
	private Long erpPrice;
	/** 數量 **/
	private Integer amount;
	/** 產品類別 */
	private String prodtypeno;
	/** 產品類別 vue 用代碼*/
	private String prodtypenoStr;
	/** 顯示順序 */
	private int orderby;
	
	/** 商品圖檔 */
	private String productImagePath;
	
	private String fetNo;
	/**calling car 使用*/
	private String faceValue;
	
	private List<OrderDetailVO> orderDetailVOs = new ArrayList<OrderDetailVO>();
	
	//預設資料欄位1欄
	private int rowNumber = 1;
	/**多主商品組別**/
	private String groupNumber;
	
	private String couponSireal;
	/** NDS加購 */
	private Boolean extraBuy;
	
	private String productId;
	
	private boolean canInsurance;
	
	private Boolean premium;
	
	private Long insurancePrice;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}
	/**
	 * @see #productTypeName
	 */
	public String getProductTypeName() {
		return productTypeName;
	}
	public void setProductTypeName(String productTypeName) {
		this.productTypeName = productTypeName;
	}
	/**
	 * @see #productName
	 */
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @see #memo
	 */
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	/**
	 * @see #money
	 */
	public Long getMoney() {
		return money;
	}
	public void setMoney(Long money) {
		this.money = money;
	}
	/**
	 * @see #prodtypeno
	 */
	public String getProdtypeno() {
		return prodtypeno;
	}
	public void setProdtypeno(String prodtypeno) {
		this.prodtypeno = prodtypeno;
	}
	public String getProdtypenoStr() {
		return prodtypenoStr;
	}
	public void setProdtypenoStr(String prodtypenoStr) {
		this.prodtypenoStr = prodtypenoStr;
	}
	/**
	 * @see #orderby
	 */
	public int getOrderby() {
		return orderby;
	}
	public void setOrderby(int orderby) {
		this.orderby = orderby;
	}
	/**
	 * @see #amount
	 */
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	
	public String getMoneyStr() {
		return getNumberFormat(getMoney());
	}
	public String getFaceValue() {
		return faceValue;
	}
	public void setFaceValue(String faceValue) {
		this.faceValue = faceValue;
	}
	public int getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
	public List<OrderDetailVO> getOrderDetailVOs() {
		return orderDetailVOs;
	}
	public void setOrderDetailVOs(List<OrderDetailVO> orderDetailVOs) {
		this.orderDetailVOs = orderDetailVOs;
	}
	public String getProductImagePath() {
		return productImagePath;
	}
	public void setProductImagePath(String productImagePath) {
		this.productImagePath = productImagePath;
	}
	public String getGroupNumber() {
		return groupNumber;
	}
	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}
	public String getCouponSireal() {
		return couponSireal;
	}
	public void setCouponSireal(String couponSireal) {
		this.couponSireal = couponSireal;
	}	
	public String getNumberFormat(long price) {
		NumberFormat nf = NumberFormat.getInstance();
		return nf.format(price);
	}
	public Boolean getExtraBuy() {
		return extraBuy;
	}
	public void setExtraBuy(Boolean extraBuy) {
		this.extraBuy = extraBuy;
	}
	public Long getErpPrice() {
		return erpPrice;
	}
	public void setErpPrice(Long erpPrice) {
		this.erpPrice = erpPrice;
	}
	public boolean isCanInsurance() {
		return canInsurance;
	}
	public void setCanInsurance(boolean canInsurance) {
		this.canInsurance = canInsurance;
	}
	public Boolean getPremium() {
		return premium;
	}
	public void setPremium(Boolean premium) {
		this.premium = premium;
	}
	public Long getInsurancePrice() {
		return insurancePrice;
	}
	public void setInsurancePrice(Long insurancePrice) {
		this.insurancePrice = insurancePrice;
	}
}
