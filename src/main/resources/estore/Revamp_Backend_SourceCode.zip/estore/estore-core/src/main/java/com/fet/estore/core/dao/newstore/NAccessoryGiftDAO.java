package com.fet.estore.core.dao.newstore;

import java.util.List;
import java.util.Map;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.AccessoryGift;
import com.fet.estore.core.model.AccessoryGiftId;
import com.fet.estore.core.bean.vo.frontend.AccessoryGiftVO;

/**
 * 配件贈品DAO
 * @author chpechen
 *
 */
public interface NAccessoryGiftDAO extends BaseDAO<AccessoryGift, AccessoryGiftId> {
	
	/**
	 * 取得配件贈品
	 * @param accIds
	 * @return
	 */
	public Map<String, List<AccessoryGiftVO>> findAccessoryGift(String[] accIds);
}
