package com.fet.estore.core.constant;

public class OnSaleConstants {

	
	/**
	 * 未上架
	 */
	public static final Boolean ONSALE_NONE = null;
	
	/**
	 * 已上架
	 */
	public static final Boolean ONSALE_YES = Boolean.TRUE;
	
	/**
	 * 已下架
	 */
	public static final Boolean ONSALE_NO = Boolean.FALSE;
	
	
	/**
	 * 無
	 */
	public static final String SIGN4ONSALE_NONE = null;
	
	/**
	 * 待審核
	 */
	public static final String SIGN4ONSALE_PENDING = "I";
	
	/**
	 * 已通過
	 */
	public static final String SIGN4ONSALE_PASS = "Y";
	
	/**
	 * 不通過
	 */
	public static final String SIGN4ONSALE_REJECT = "N";
	
	
	/**
	 * 獨賣件
	 */
	public static final Boolean EXCLUSIVE_YES = Boolean.TRUE;;
	
	/**
	 * 預購件
	 */
	public static final Boolean PRE_ORDER_YES = Boolean.TRUE;;
}
