package com.fet.estore.core.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * @author Klyve.Chen
 * @version 創建時間: 2020-07-23
 * @description
 */
public class PromoProductTabs {

    private String name;

    @JsonProperty("default")
    private int defaultNum;

    private List<PromoProductTabsObj> list;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDefaultNum() {
        return defaultNum;
    }

    public void setDefaultNum(int defaultNum) {
        this.defaultNum = defaultNum;
    }

    public List<PromoProductTabsObj> getList() {
        return list;
    }

    public void setList(List<PromoProductTabsObj> list) {
        this.list = list;
    }
}
