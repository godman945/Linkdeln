
package com.fet.estore.core.bean.bo;

import com.fet.estore.core.bean.vo.frontend.CouponRedeemTargetVO;

import java.util.HashSet;
import java.util.Set;


/**
 * 將CouponRedeemTicket取回後, 對該商品的coupon可以對應哪些類型的統合
 *
 * @author Klyve.Chen
 * @version 創建時間: 2020-08-22
 * @description
 */
public class CouponRedeemBO {

    public static final String REDEEM_TARGET_TYPE_ORDER_TYPE = "ORDER_TYPE";
    public static final String REDEEM_TARGET_TYPE_DEVICE = "DEVICE";
    public static final String REDEEM_TARGET_TYPE_PROMOTION = "PROMOTION";
    public static final String REDEEM_TARGET_TYPE_DELIVERY_TYPE = "DELIVERY_TYPE";
    public static final String REDEEM_TARGET_TYPE_ACCESSORY = "ACCESSORY";

    private boolean allOrderType = true;
    private boolean allDeviceType = true;
    private boolean allPromotionType = true;
    private boolean allDeliveryType = true;
    private boolean allAccessoryType = true;

    private Set<String> orderTypeIds = new HashSet<String>(){{add("ALL");}};
    private Set<String> deviceTypeIds = new HashSet<String>(){{add("ALL");}};
    private Set<String> promotionTypeIds = new HashSet<String>(){{add("ALL");}};
    private Set<String> deliveryTypeIds = new HashSet<String>(){{add("ALL");}};
    private Set<String> accessoryTypeIds = new HashSet<String>(){{add("ALL");}};

    public CouponRedeemBO(Set<CouponRedeemTargetVO> targets) {
        for (CouponRedeemTargetVO target : targets) {
            String type = target.getType();
            String targetId = target.getTargetId();
            if (targetId == null)
                continue;
            switch (type) {
                case REDEEM_TARGET_TYPE_ORDER_TYPE:
                    this.orderTypeIds.remove("ALL");
                    this.orderTypeIds.add(targetId);
                case REDEEM_TARGET_TYPE_DEVICE:
                    this.deviceTypeIds.remove("ALL");
                    this.deviceTypeIds.add(targetId);
                case REDEEM_TARGET_TYPE_PROMOTION:
                    this.promotionTypeIds.remove("ALL");
                    this.promotionTypeIds.add(targetId);
                case REDEEM_TARGET_TYPE_DELIVERY_TYPE:
                    this.deliveryTypeIds.remove("ALL");
                    this.deliveryTypeIds.add(targetId);
                case REDEEM_TARGET_TYPE_ACCESSORY:
                    this.accessoryTypeIds.remove("ALL");
                    this.accessoryTypeIds.add(targetId);
            }
        }
    }

    public boolean isAllOrderType() {
        return allOrderType;
    }
    public boolean isAllDeviceType() {
        return allDeviceType;
    }
    public boolean isAllPromotionType() {
        return allPromotionType;
    }
    public boolean isAllDeliveryType() {
        return allDeliveryType;
    }
    public boolean isAllAccessoryType() {
        return allAccessoryType;
    }
    public Set<String> getOrderTypeIds() {
        return orderTypeIds;
    }
    public Set<String> getDeviceTypeIds() {
        return deviceTypeIds;
    }
    public Set<String> getPromotionTypeIds() {
        return promotionTypeIds;
    }
    public Set<String> getDeliveryTypeIds() {
        return deliveryTypeIds;
    }
    public Set<String> getAccessoryTypeIds() {
        return accessoryTypeIds;
    }
}