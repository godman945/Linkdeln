package com.fet.estore.core.bean;

import java.io.Serializable;

public class SearchDataList implements Serializable {

	private static final long serialVersionUID = -7857879510491461393L;
	/** 顯示文字 */
	private String text;
	/** 網址 URL */
	private String link;
	
	/**目前由前台塞值
	private String target;
	private String icon;
	*/
	
	public SearchDataList() {
		super();
	}
	public SearchDataList(String text,String link) {
		super();
		this.text = text;
		this.link = link;
	}
	
	public String getText() {
		return text;
	}    
	public void setText(String text) {
		this.text = text;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
//	public String getTarget() {
//		return target;
//	}
//	public void setTarget(String target) {
//		this.target = target;
//	}
//	public String getIcon() {
//		return icon;
//	}
//	public void setIcon(String icon) {
//		this.icon = icon;
//	}
	
}
