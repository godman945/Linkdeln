package com.fet.estore.core.dao.newstore;

import com.fet.estore.core.dao.base.BaseDAO;
import com.fet.estore.core.model.ContentPromoMapping;
import com.fet.estore.core.model.ContentPromoMappingId;

import java.util.List;

public interface NContentPromoMappingDAO extends BaseDAO<ContentPromoMapping, ContentPromoMappingId> {

    /**
     * 用PK查詢資料
     * @param contentPromoMappingId
     * @return
     */
    public List<ContentPromoMapping> findByIds(ContentPromoMappingId contentPromoMappingId);
}
