package com.fet.estore.core.bean.vo.frontend;

/**
 * 
 * @author antonis Chen
 *
 */
public class MinisiteActivityVO {
	
	private Long id;
	private Long activityId;
	private String activityUrl;
	private String activityUrlType;
	private Boolean isBandFilter;
	private Boolean isBrandFilter;
	private Boolean isCategoryFilter;
	private Boolean isEstoreChannel;
	private Boolean isMobileChannel;
	private Boolean isPriceFilter;
	private java.util.Date offDate;
	private Boolean onsale;
	private java.util.Date onsaleDate;
	private String remark;
	private String seoDescription;
	private String seoKeywords;
	private String seoTitle;
	private String shareDescription;
	private String shareImagePath;
	private String shareTitle;
	private String templateType;
	private String title;
	private String bannerTitle;
	private String adImagePath;
	private String mobileImagePath;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getSeoDescription() {
		return seoDescription;
	}
	public void setSeoDescription(String seoDescription) {
		this.seoDescription = seoDescription;
	}
	public String getSeoKeywords() {
		return seoKeywords;
	}
	public void setSeoKeywords(String seoKeywords) {
		this.seoKeywords = seoKeywords;
	}
	public String getSeoTitle() {
		return seoTitle;
	}
	public void setSeoTitle(String seoTitle) {
		this.seoTitle = seoTitle;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAdImagePath() {
		return adImagePath;
	}
	public void setAdImagePath(String adImagePath) {
		this.adImagePath = adImagePath;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getActivityUrl() {
		return activityUrl;
	}
	public void setActivityUrl(String activityUrl) {
		this.activityUrl = activityUrl;
	}
	public String getActivityUrlType() {
		return activityUrlType;
	}
	public void setActivityUrlType(String activityUrlType) {
		this.activityUrlType = activityUrlType;
	}
	public Boolean getIsBandFilter() {
		return isBandFilter;
	}
	public void setIsBandFilter(Boolean isBandFilter) {
		this.isBandFilter = isBandFilter;
	}
	public Boolean getIsBrandFilter() {
		return isBrandFilter;
	}
	public void setIsBrandFilter(Boolean isBrandFilter) {
		this.isBrandFilter = isBrandFilter;
	}
	public Boolean getIsCategoryFilter() {
		return isCategoryFilter;
	}
	public void setIsCategoryFilter(Boolean isCategoryFilter) {
		this.isCategoryFilter = isCategoryFilter;
	}
	public Boolean getIsEstoreChannel() {
		return isEstoreChannel;
	}
	public void setIsEstoreChannel(Boolean isEstoreChannel) {
		this.isEstoreChannel = isEstoreChannel;
	}
	public Boolean getIsMobileChannel() {
		return isMobileChannel;
	}
	public void setIsMobileChannel(Boolean isMobileChannel) {
		this.isMobileChannel = isMobileChannel;
	}
	public Boolean getIsPriceFilter() {
		return isPriceFilter;
	}
	public void setIsPriceFilter(Boolean isPriceFilter) {
		this.isPriceFilter = isPriceFilter;
	}
	public java.util.Date getOffDate() {
		return offDate;
	}
	public void setOffDate(java.util.Date offDate) {
		this.offDate = offDate;
	}
	public Boolean getOnsale() {
		return onsale;
	}
	public void setOnsale(Boolean onsale) {
		this.onsale = onsale;
	}
	public java.util.Date getOnsaleDate() {
		return onsaleDate;
	}
	public void setOnsaleDate(java.util.Date onsaleDate) {
		this.onsaleDate = onsaleDate;
	}
	public String getShareDescription() {
		return shareDescription;
	}
	public void setShareDescription(String shareDescription) {
		this.shareDescription = shareDescription;
	}
	public String getShareImagePath() {
		return shareImagePath;
	}
	public void setShareImagePath(String shareImagePath) {
		this.shareImagePath = shareImagePath;
	}
	public String getShareTitle() {
		return shareTitle;
	}
	public void setShareTitle(String shareTitle) {
		this.shareTitle = shareTitle;
	}
	public String getTemplateType() {
		return templateType;
	}
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
	public String getBannerTitle() {
		return bannerTitle;
	}
	public void setBannerTitle(String bannerTitle) {
		this.bannerTitle = bannerTitle;
	}
	public String getMobileImagePath() {
		return mobileImagePath;
	}
	public void setMobileImagePath(String mobileImagePath) {
		this.mobileImagePath = mobileImagePath;
	}
	
	
}
