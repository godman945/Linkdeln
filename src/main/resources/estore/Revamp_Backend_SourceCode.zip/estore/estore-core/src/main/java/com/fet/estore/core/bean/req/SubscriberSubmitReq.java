package com.fet.estore.core.bean.req;

public class SubscriberSubmitReq {
	private boolean isCombine;
	private String combineMsisdn;
	private String combineRocId;
	private String subName;
	private String subRocId;
	private String subBirth;
	private String subSecTp;
	private String subSecId;
	private String subRegAddrCity;
	private String subRegAddrTown;
	private String subAddress;
	private String subEmail;
	private String subCellphone;
	private String recommend;
	private String recommendCode;
	private boolean subNameModified;
	private boolean subRocIdModified;
	private boolean subBirthModified;
	private boolean subSecIdModified;
	private boolean subRegAddrCityModified;
	private boolean subRegAddrTownModified;
	private boolean subAddressModified;
	private boolean subEmailModified;
	private boolean subCellphoneModified;
	private String ebuSubscriberType;
	private String ebuVatNo;
	private String ebuVatTitle;
	private String ebuRecomName;
	private String ebuRecomMsisdn;
		
	public boolean getIsCombine() {
		return isCombine;
	}

	public void setIsCombine(boolean isCombine) {
		this.isCombine = isCombine;
	}

	public String getSubName() {
		return subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	public String getSubRocId() {
		return subRocId;
	}

	public void setSubRocId(String subRocId) {
		this.subRocId = subRocId;
	}

	public String getSubSecTp() {
		return subSecTp;
	}

	public void setSubSecTp(String subSecTp) {
		this.subSecTp = subSecTp;
	}

	public String getSubSecId() {
		return subSecId;
	}

	public void setSubSecId(String subSecId) {
		this.subSecId = subSecId;
	}

	public String getSubRegAddrCity() {
		return subRegAddrCity;
	}

	public void setSubRegAddrCity(String subRegAddrCity) {
		this.subRegAddrCity = subRegAddrCity;
	}

	public String getSubRegAddrTown() {
		return subRegAddrTown;
	}

	public void setSubRegAddrTown(String subRegAddrTown) {
		this.subRegAddrTown = subRegAddrTown;
	}

	public String getSubAddress() {
		return subAddress;
	}

	public void setSubAddress(String subAddress) {
		this.subAddress = subAddress;
	}

	public String getSubEmail() {
		return subEmail;
	}

	public void setSubEmail(String subEmail) {
		this.subEmail = subEmail;
	}

	public void setCombine(boolean isCombine) {
		this.isCombine = isCombine;
	}

	public String getCombineMsisdn() {
		return combineMsisdn;
	}

	public void setCombineMsisdn(String combineMsisdn) {
		this.combineMsisdn = combineMsisdn;
	}

	public String getCombineRocId() {
		return combineRocId;
	}

	public void setCombineRocId(String combineRocId) {
		this.combineRocId = combineRocId;
	}

	public String getSubCellphone() {
		return subCellphone;
	}

	public void setSubCellphone(String subCellphone) {
		this.subCellphone = subCellphone;
	}

	public String getRecommend() {
		return recommend;
	}

	public void setRecommend(String recommend) {
		this.recommend = recommend;
	}

	public String getRecommendCode() {
		return recommendCode;
	}

	public void setRecommendCode(String recommendCode) {
		this.recommendCode = recommendCode;
	}

	public String getSubBirth() {
		return subBirth;
	}

	public void setSubBirth(String subBirth) {
		this.subBirth = subBirth;
	}

	public boolean getSubNameModified() {
		return subNameModified;
	}

	public void setSubNameModified(boolean subNameModified) {
		this.subNameModified = subNameModified;
	}

	public boolean getSubRocIdModified() {
		return subRocIdModified;
	}

	public void setSubRocIdModified(boolean subRocIdModified) {
		this.subRocIdModified = subRocIdModified;
	}

	public boolean getSubBirthModified() {
		return subBirthModified;
	}

	public void setSubBirthModified(boolean subBirthModified) {
		this.subBirthModified = subBirthModified;
	}

	public boolean getSubSecIdModified() {
		return subSecIdModified;
	}

	public void setSubSecIdModified(boolean subSecIdModified) {
		this.subSecIdModified = subSecIdModified;
	}

	public boolean getSubRegAddrCityModified() {
		return subRegAddrCityModified;
	}

	public void setSubRegAddrCityModified(boolean subRegAddrCityModified) {
		this.subRegAddrCityModified = subRegAddrCityModified;
	}

	public boolean getSubRegAddrTownModified() {
		return subRegAddrTownModified;
	}

	public void setSubRegAddrTownModified(boolean subRegAddrTownModified) {
		this.subRegAddrTownModified = subRegAddrTownModified;
	}

	public boolean getSubAddressModified() {
		return subAddressModified;
	}

	public void setSubAddressModified(boolean subAddressModified) {
		this.subAddressModified = subAddressModified;
	}

	public String getEbuSubscriberType() {
		return ebuSubscriberType;
	}

	public void setEbuSubscriberType(String ebuSubscriberType) {
		this.ebuSubscriberType = ebuSubscriberType;
	}

	public String getEbuVatNo() {
		return ebuVatNo;
	}

	public void setEbuVatNo(String ebuVatNo) {
		this.ebuVatNo = ebuVatNo;
	}

	public String getEbuVatTitle() {
		return ebuVatTitle;
	}

	public void setEbuVatTitle(String ebuVatTitle) {
		this.ebuVatTitle = ebuVatTitle;
	}

	public String getEbuRecomName() {
		return ebuRecomName;
	}

	public void setEbuRecomName(String ebuRecomName) {
		this.ebuRecomName = ebuRecomName;
	}

	public String getEbuRecomMsisdn() {
		return ebuRecomMsisdn;
	}

	public void setEbuRecomMsisdn(String ebuRecomMsisdn) {
		this.ebuRecomMsisdn = ebuRecomMsisdn;
	}

	public boolean getSubEmailModified() {
		return subEmailModified;
	}

	public void setSubEmailModified(boolean subEmailModified) {
		this.subEmailModified = subEmailModified;
	}

	public boolean getSubCellphoneModified() {
		return subCellphoneModified;
	}

	public void setSubCellphoneModified(boolean subCellphoneModified) {
		this.subCellphoneModified = subCellphoneModified;
	}

}
