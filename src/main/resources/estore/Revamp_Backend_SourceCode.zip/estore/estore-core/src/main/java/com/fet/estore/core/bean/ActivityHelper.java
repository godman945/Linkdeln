package com.fet.estore.core.bean;


import java.io.Serializable;

public class ActivityHelper implements Serializable{

	private static final long serialVersionUID = -3506209191363232615L;

	private String rId;

    private String clickId;

	private Long activityId;

	private Long preselectedActivityId;

	private String preselectedOrderType;

	private String orderType;

	private String handsetProductId;

	private String onsalePromoListId;

	private Long couponId;

	// 原RedeemCouponSerial
	private String couponSn;

	// 原RedeemCouponPassword
	private String couponPwd;

	private String eserviceUid;

	private String captcha;

	//以下為額外做的flag 基本上由activity來 不是用BeanUtil直接copy
	private Boolean ebu;

	private Boolean insurance;

	private Boolean premium;

	private String premiumTitle;

	private Integer premiumBuyCount;

	private Boolean mayann;

	private String packageBrowsingStatisticId;

	private Boolean registerActivity;

    /**是否為資費自由選**/
    private boolean isSelfHelpingPromotion = false;

    private String selfHelpingPromotionName;
    /** 資費自由選  D_OFFERID**/
    private String selfHelpingPromotion1;
    /** 資費自由選  ONNET_OFFERID**/
    private String selfHelpingPromotion2;
    /** 資費自由選  OFFNET_OFFERID**/
    private String selfHelpingPromotion3;

    /** Friday*/
    private boolean friday;

    private String fridayOrderType;

    private String fridayOrderNo;

    private String orderChannel;

    //　離開訊息　應該可以刪掉　整個activity只有七筆有這個
    private String exitMsg;

    private boolean cobranding;


    /** 用來判斷下面的流程　*/
    private boolean daAcc;

    private boolean dev;

    private boolean hasCoupon;

    private Boolean nameList;

	private String preSelctedCouponSerial;

	private Long preSelectedActivityId;

    private Long nameListId;

    private String nameListColumn;

    private String lightboxTitle1;

    private String lightboxTitle2;

    private String authCode;

    private String authSerialNo;

    private boolean isEmployeeAct;

    private boolean checkNameListSucceed;
    /** 續約名單制活動賣場 flag */
    private boolean renewAuthenticated;
    /** 續約名單制活動 證號 */
    private String lyRocId;
    /** 續約名單制活動 門號 */
    private String lyMsisdn;

    private boolean couponRegisterDemand;

	public String getrId() {
		return rId;
	}
	public void setrId(String rId) {
		this.rId = rId;
	}
	public String getClickId() {
		return clickId;
	}
	public void setClickId(String clickId) {
		this.clickId = clickId;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
    public Long getPreselectedActivityId() {
        return preselectedActivityId;
    }
    public void setPreselectedActivityId(Long preselectedActivityId) {
        this.preselectedActivityId = preselectedActivityId;
    }
    public String getPreselectedOrderType() {
        return preselectedOrderType;
    }
    public void setPreselectedOrderType(String preselectedOrderType) {
        this.preselectedOrderType = preselectedOrderType;
    }
    public String getHandsetProductId() {
        return handsetProductId;
    }
    public void setHandsetProductId(String handsetProductId) {
        this.handsetProductId = handsetProductId;
    }
    public String getOnsalePromoListId() {
        return onsalePromoListId;
    }
    public void setOnsalePromoListId(String onsalePromoListId) {
        this.onsalePromoListId = onsalePromoListId;
    }
    public Long getCouponId() {
        return couponId;
    }
    public void setCouponId(Long couponId) {
        this.couponId = couponId;
    }
    public String getRedeemCouponSn() {
        return couponSn;
    }
    public void setRedeemCouponSn(String couponSn) {
        this.couponSn = couponSn;
    }
    public String getRedeemCouponPwd() {
        return couponPwd;
    }
    public void setRedeemCouponPwd(String couponPwd) {
        this.couponPwd = couponPwd;
    }
    public String getEserviceUid() {
        return eserviceUid;
    }
    public void setEserviceUid(String eserviceUid) {
        this.eserviceUid = eserviceUid;
    }
    public String getCaptcha() {
        return captcha;
    }
    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }
    public Boolean isEbu() {
        return ebu != null && ebu;
    }
    public Boolean getEbu() {
        return ebu;
    }
    public void setEbu(Boolean ebu) {
        this.ebu = ebu;
    }
    public Boolean isInsurance() {
        return insurance != null && insurance;
    }
    public Boolean getInsurance() {
        return insurance;
    }
    public void setInsurance(Boolean insurance) {
        this.insurance = insurance;
    }
    public Boolean isPremium() {
        return premium != null && premium;
    }
    public Boolean getPremium() {
        return premium;
    }
    public void setPremium(Boolean premium) {
        this.premium = premium;
    }
    public String getPremiumTitle() {
        return premiumTitle;
    }
    public void setPremiumTitle(String premiumTitle) {
        this.premiumTitle = premiumTitle;
    }
    public Integer getPremiumBuyCount() {
        return premiumBuyCount;
    }
    public void setPremiumBuyCount(Integer premiumBuyCount) {
        this.premiumBuyCount = premiumBuyCount;
    }
    public Boolean isMayann() {
        return mayann != null && mayann;
    }
    public Boolean getMayann() {
        return mayann;
    }
    public void setMayann(Boolean mayann) {
        this.mayann = mayann;
    }
    public boolean isSelfHelpingPromotion() {
        return isSelfHelpingPromotion;
    }
    public void setSelfHelpingPromotion(boolean selfHelpingPromotion) {
        isSelfHelpingPromotion = selfHelpingPromotion;
    }
    public String getSelfHelpingPromotion1() {
        return selfHelpingPromotion1;
    }
    public void setSelfHelpingPromotion1(String selfHelpingPromotion1) {
        this.selfHelpingPromotion1 = selfHelpingPromotion1;
    }
    public String getSelfHelpingPromotion2() {
        return selfHelpingPromotion2;
    }
    public void setSelfHelpingPromotion2(String selfHelpingPromotion2) {
        this.selfHelpingPromotion2 = selfHelpingPromotion2;
    }
    public String getSelfHelpingPromotion3() {
        return selfHelpingPromotion3;
    }
    public void setSelfHelpingPromotion3(String selfHelpingPromotion3) {
        this.selfHelpingPromotion3 = selfHelpingPromotion3;
    }
    public String getPackageBrowsingStatisticId() {
        return packageBrowsingStatisticId;
    }
    public void setPackageBrowsingStatisticId(String packageBrowsingStatisticId) {
        this.packageBrowsingStatisticId = packageBrowsingStatisticId;
    }
    public boolean isFriday() {
        return friday;
    }
    public void setFriday(boolean friday) {
        this.friday = friday;
    }
    public String getFridayOrderType() {
        return fridayOrderType;
    }
    public void setFridayOrderType(String fridayOrderType) {
        this.fridayOrderType = fridayOrderType;
    }
    public String getFridayOrderNo() {
        return fridayOrderNo;
    }
    public void setFridayOrderNo(String fridayOrderNo) {
        this.fridayOrderNo = fridayOrderNo;
    }
    public boolean isDaAcc() {
        return daAcc;
    }
    public void setDaAcc(boolean daAcc) {
        this.daAcc = daAcc;
    }
    public boolean hasDev() {
	    return handsetProductId != null;
    }
    public Boolean isRegisterActivity() {
        return registerActivity;
    }
    public Boolean getRegisterActivity() {
        return registerActivity;
    }
    public void setRegisterActivity(Boolean registerActivity) {
        this.registerActivity = registerActivity;
    }
    public String getExitMsg() {
        return exitMsg;
    }
    public void setExitMsg(String exitMsg) {
        this.exitMsg = exitMsg;
    }
    public String getOrderChannel() {
        return orderChannel;
    }
    public void setOrderChannel(String orderChannel) {
        this.orderChannel = orderChannel;
    }
    public boolean getCobranding() {
        return cobranding;
    }
    public void setCobranding(boolean cobranding) {
        this.cobranding = cobranding;
    }
    public boolean isDev() {
        return dev;
    }
    public void setDev(boolean dev) {
        this.dev = dev;
    }
    public boolean isHasCoupon() {
        return hasCoupon;
    }
    public void setHasCoupon(boolean hasCoupon) {
        this.hasCoupon = hasCoupon;
    }
    public Boolean getNameList() {
        return nameList;
    }
    public void setNameList(Boolean nameList) {
        this.nameList = nameList;
    }
	public String getPreSelctedCouponSerial() {
		return preSelctedCouponSerial;
	}
	public void setPreSelctedCouponSerial(String preSelctedCouponSerial) {
		this.preSelctedCouponSerial = preSelctedCouponSerial;
	}
	public Long getPreSelectedActivityId() {
		return preSelectedActivityId;
	}
	public void setPreSelectedActivityId(Long preSelectedActivityId) {
		this.preSelectedActivityId = preSelectedActivityId;
	}
    public Long getNameListId() {
        return nameListId;
    }
    public void setNameListId(Long nameListId) {
        this.nameListId = nameListId;
    }
    public boolean hasNameList() {
	    return nameList != null ? nameList : false;
    }
    public String getNameListColumn() {
        return nameListColumn;
    }
    public void setNameListColumn(String nameListColumn) {
        this.nameListColumn = nameListColumn;
    }
    public String getLightboxTitle1() {
        return lightboxTitle1;
    }
    public void setLightboxTitle1(String lightboxTitle1) {
        this.lightboxTitle1 = lightboxTitle1;
    }
    public String getLightboxTitle2() {
        return lightboxTitle2;
    }
    public void setLightboxTitle2(String lightboxTitle2) {
        this.lightboxTitle2 = lightboxTitle2;
    }
    public String getAuthCode() {
        return authCode;
    }
    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }
    public String getAuthSerialNo() {
        return authSerialNo;
    }
    public void setAuthSerialNo(String authSerialNo) {
        this.authSerialNo = authSerialNo;
    }
    public boolean isCheckNameListSucceed() {
        return checkNameListSucceed;
    }
    public void setCheckNameListSucceed(boolean checkNameListSucceed) {
        this.checkNameListSucceed = checkNameListSucceed;
    }
    public boolean isRenewAuthenticated() {
        return renewAuthenticated;
    }
    public void setRenewAuthenticated(boolean renewAuthenticated) {
        this.renewAuthenticated = renewAuthenticated;
    }
    public String getLyRocId() {
        return lyRocId;
    }
    public void setLyRocId(String lyRocId) {
        this.lyRocId = lyRocId;
    }
    public String getLyMsisdn() {
        return lyMsisdn;
    }
    public void setLyMsisdn(String lyMsisdn) {
        this.lyMsisdn = lyMsisdn;
    }
    public boolean isCouponRegisterDemand() {
        return couponRegisterDemand;
    }
    public void setCouponRegisterDemand(boolean couponRegisterDemand) {
        this.couponRegisterDemand = couponRegisterDemand;
    }
    public boolean isEmployeeAct() {
        return isEmployeeAct;
    }
    public void setEmployeeAct(boolean employeeAct) {
        isEmployeeAct = employeeAct;
    }
}
