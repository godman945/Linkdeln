/**
 * $Id: NBaseDAO.java,v 1.0, 2017-05-16 11:04:24Z, Evan Tung$
 * Copyright (c) 2007-2008 Stark Technology	Inc. All Rights	Reserved.
 */
package	com.fet.estore.core.dao.newstore;

import java.io.Serializable;
import java.util.List;

/**
 * Data	access object (DAO)	for	domain model
 *
 * @version		$Id: NBaseDAO.java,v 1.0, 2017-05-16 11:04:24Z, Evan Tung$
 */
public interface NBaseDAO<T,	ID extends Serializable>  {

	boolean	exists (ID id);

	T findById(ID id);

	void save(T	entity);

	void saveAll(List<T> entities);

	void delete(T entity);

	void deleteAll(List<T> entities);

	void deleteById(ID id);

	List<T>	findAll();

	T merge(T entity);

	void attachDirty(T entity);

	void attachClean(T entity);

	void evict(T entity);

	void update(T entity);
	
	/**
	 * 以物件識別取得物件。
	 * @param ids 物件識別陣列
	 * @return 對應物件
	 */
	List<T> findByIds(List<ID> ids);
}