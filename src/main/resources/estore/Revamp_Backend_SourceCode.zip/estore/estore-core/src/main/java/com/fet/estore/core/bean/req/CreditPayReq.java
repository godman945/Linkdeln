package com.fet.estore.core.bean.req;

/**
 * @description 信用卡繳款Request Object
 * @author Dennis.Chen
 * @date 2020-09-02
 */
public class CreditPayReq {

    String cardNo; //信用卡號
    String extendNo; //驗證碼
    String validMonth; //有效月份
    String validYear; //有效年份
    String installmentBank; //銀行
    Integer installmentPeriod; //分期付款期數

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getExtendNo() {
        return extendNo;
    }

    public void setExtendNo(String extendNo) {
        this.extendNo = extendNo;
    }

    public String getValidMonth() {
        return validMonth;
    }

    public void setValidMonth(String validMonth) {
        this.validMonth = validMonth;
    }

    public String getValidYear() {
        return validYear;
    }

    public void setValidYear(String validYear) {
        this.validYear = validYear;
    }

    public String getInstallmentBank() {
        return installmentBank;
    }

    public void setInstallmentBank(String installmentBank) {
        this.installmentBank = installmentBank;
    }

    public Integer getInstallmentPeriod() {
        return installmentPeriod;
    }

    public void setInstallmentPeriod(Integer installmentPeriod) {
        this.installmentPeriod = installmentPeriod;
    }
}
