package com.fet.estore.core.bean.bo;

import com.fet.estore.core.enums.OrderTypeEnum;

import java.util.Map;

/**
 * @description 呼叫PromotionServcieImpl.getProductPromo()的Input資料
 * @author Dennis.Chen
 * @Date 2020-10-07
 */
public class GetProdPromoBO {

    OrderTypeEnum orderType; //流程類別
    Long activityId; //活動賣場ID
    String fetNo; //商品料號
    Map<String, Boolean> deliverType; //該商品料號可地送貨物

    public GetProdPromoBO() {
    }

    public GetProdPromoBO(OrderTypeEnum orderType, Long activityId, String fetNo, Map<String, Boolean> deliverType) {
        this.orderType = orderType;
        this.activityId = activityId;
        this.fetNo = fetNo;
        this.deliverType = deliverType;
    }

    public OrderTypeEnum getOrderType() {
        return orderType;
    }

    public void setOrderType(OrderTypeEnum orderType) {
        this.orderType = orderType;
    }

    public Long getActivityId() {
        return activityId;
    }

    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }

    public String getFetNo() {
        return fetNo;
    }

    public void setFetNo(String fetNo) {
        this.fetNo = fetNo;
    }

    public Map<String, Boolean> getDeliverType() {
        return deliverType;
    }

    public void setDeliverType(Map<String, Boolean> deliverType) {
        this.deliverType = deliverType;
    }
}
