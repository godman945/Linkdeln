package com.fet.estore.core.bean.vo.frontend;

import java.io.Serializable;

public class HandsetFunCellVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1813475785492572551L;
	
	private HandsetFunctionVO vo;
	private String text;
	private int rowspan;
	private int colspan;
	private boolean display;
	private boolean isDescription;
	
	public HandsetFunctionVO getVo() {
		return vo;
	}
	public void setVo(HandsetFunctionVO vo) {
		this.vo = vo;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getRowspan() {
		return rowspan;
	}
	public void setRowspan(int rowspan) {
		this.rowspan = rowspan;
	}
	public int getColspan() {
		return colspan;
	}
	public void setColspan(int colspan) {
		this.colspan = colspan;
	}
	public boolean isDisplay() {
		return display;
	}
	public void setDisplay(boolean display) {
		this.display = display;
	}
	public boolean isDescription() {
		return isDescription;
	}
	public void setDescription(boolean isDescription) {
		this.isDescription = isDescription;
	}
	
}
