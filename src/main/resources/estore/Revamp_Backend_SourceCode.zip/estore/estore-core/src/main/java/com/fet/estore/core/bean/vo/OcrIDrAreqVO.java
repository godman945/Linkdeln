package com.fet.estore.core.bean.vo;

public class OcrIDrAreqVO implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 不指定
	 */
	public static final String idrType_0 = "0";
	/**
	 * 身分證正面 
	 */
	public static final String idrType_1 = "1"; 
	/**
	 * 身分證反面 
	 */
	public static final String idrType_2 = "2"; 
	/**
	 * 中華民國駕照 (新版) 
	 */
	public static final String idrType_31 = "31";
	/**
	 * 台灣健保卡 
	 */
	public static final String idrType_41 = "41";

	/*
	3 香港居民身份證 
	4 澳門居民身份證 第二代 
	5 澳門居民身份證 第一代 
	6 大陸身份證正面 
	7 大陸身份證背面 
	51 台灣護照 
	52 台胞証  
	53 國際機讀護照 
	71 中華民國汽車行車執照 
	81 中華民國機車行車執照
	92 中華民國居留證 正面 
	93 中華民國居留證 背面 
	101 Barcode_Set1 (support: QR code & Code 39) 
	111 CreditCard 信用卡 
	*/

	/**
	 * 必填，傳入的影像格式 類型 傳入的影像格式，請傳入 jpg、bmp、 tif、png
	 */
	String fileType;

	/**
	 * 必填，影像讀取 byte[] 傳入影像 binary Stream
	 */
	String uploadFile;

	/**
	 * 必填，例:身份證正面請 填 1 傳入證件種類代碼，代碼表如附件表格
	 */
	int idrType;

	/**
	 * 必填，預設 0，請傳入 0~20 浮水印的指定位置，代碼表如附件樣 式
	 */
	int waterMarkPosition;

	/**
	 * 必填，預設 0，請傳入 0~255 浮水印的指定顏色 R 值
	 */
	int waterMarkColorR;

	/**
	 * 必填，預設 0，請傳入 0~255 浮水印的指定顏色 G 值
	 */
	int waterMarkColorG;

	/**
	 * 必填，預設 0，請傳入 0~255 浮水印的指定顏色 B 值
	 */
	int waterMarkColorB;

	/**
	 * 選填,不填則為空值 浮水印的指定文字內容
	 */
	String waterMarkTextl;

	/**
	 * 選填，預設 0 快捷辨識模式定義，請見附件 4
	 */
	String expressMode;

	/**
	 * 必填，預設 1 1:CSV 檔案輸出 16:XML 檔案輸出 目前支援的輸出的檔案格式為 CSV及 XML，請傳入 1 或 16 注意：若 後續會使用
	 * IDR - E 取得 JSON 格式的辨識結果時，因為內部是解析 CSV 的 結 果，故 這 個 參 數 請 設 定 1 (CSV 檔案輸出 )
	 */
	int resultFileType;

	/**
	 * 必填，預設 7 0: 不取得影像 1: 是指辨識前，經過影 像處理後的影像 2 : 是指辨識後，找到 的證件位置，裁切出的 影像，(可打上浮水印，
	 * 也可不打) 3: 上述 1+2 的影像 4 : 是指辨識後，若有 找到的證件中的頭像位 置，裁切出的頭像影像 5: 上述 1+4 的影像 6: 上述
	 * 2+4 的影像 7: 上述 1+2+4 的影像 輸出的影像檔案格式，請傳入 0~4 （例：傳入 7 為影像處理過的結果+ 浮水印輸出+大頭照全部輸出)
	 * 注意： 影像處理及裁切功能分 2 階段 處理,設定值 1 表示只有經過第一階 段影像處理, 設定值2以上是經過第 一、二階段影像處理 細部說明如下:
	 * OutputImageType 帶 2，就會依辨識 核心找到的證件位置裁切，至於是否 要打上浮水印，請依據需求設定，浮 水印的位置欄位，若為 0，則不打
	 * 字，浮水印的位置欄位，若為 1 ~ 20， 則根據給的字串打上文字。
	 */
	int outputImageType;

	/**
	 * 來源系統代號 於網站組態檔設定值設定管控不同 的來源系統，則必需代入這個值以做 驗証，如同帳號
	 */
	String sysID;

	/**
	 * 來源系統識別值 於網站組態檔設定值設定管控不同 的來源系統，則必需代入這個值以做 驗証，如同密碼
	 */
	String mac;

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(String uploadFile) {
		this.uploadFile = uploadFile;
	}

	public int getIdrType() {
		return idrType;
	}

	public void setIdrType(int idrType) {
		this.idrType = idrType;
	}

	public int getWaterMarkPosition() {
		return waterMarkPosition;
	}

	public void setWaterMarkPosition(int waterMarkPosition) {
		this.waterMarkPosition = waterMarkPosition;
	}

	public int getWaterMarkColorR() {
		return waterMarkColorR;
	}

	public void setWaterMarkColorR(int waterMarkColorR) {
		this.waterMarkColorR = waterMarkColorR;
	}

	public int getWaterMarkColorG() {
		return waterMarkColorG;
	}

	public void setWaterMarkColorG(int waterMarkColorG) {
		this.waterMarkColorG = waterMarkColorG;
	}

	public int getWaterMarkColorB() {
		return waterMarkColorB;
	}

	public void setWaterMarkColorB(int waterMarkColorB) {
		this.waterMarkColorB = waterMarkColorB;
	}

	public String getWaterMarkTextl() {
		return waterMarkTextl;
	}

	public void setWaterMarkTextl(String waterMarkTextl) {
		this.waterMarkTextl = waterMarkTextl;
	}

	public String getExpressMode() {
		return expressMode;
	}

	public void setExpressMode(String expressMode) {
		this.expressMode = expressMode;
	}

	public int getResultFileType() {
		return resultFileType;
	}

	public void setResultFileType(int resultFileType) {
		this.resultFileType = resultFileType;
	}

	public int getOutputImageType() {
		return outputImageType;
	}

	public void setOutputImageType(int outputImageType) {
		this.outputImageType = outputImageType;
	}

	public String getSysID() {
		return sysID;
	}

	public void setSysID(String sysID) {
		this.sysID = sysID;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	
	
}
