package com.fet.estore.core.bean;

import java.io.Serializable;

public class OrderGift implements Serializable {

	private static final long serialVersionUID = -1985191077358274985L;
	private String type;
	private String image;
	private String value;
	private String meta;
	//商品名稱
	private String name;
	//購買數量
	private Integer number;
	//原價
	private Long originPrice;
	//商品價
	private Long productPrice;
	//顏色
	private String color;
	private OrderContent modal;
	private String productId;
	//活動優惠id
	private String apId;
	//商品類別 1:手機, 2:配件, 3:贈品, 4:預繳金, 6:門號, 10:加購服務, 12:競標門號
	private String prodTypeNo;
	//商品料號
	private String fetNo;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getMeta() {
		return meta;
	}
	public void setMeta(String meta) {
		this.meta = meta;
	}
	public Long getOriginPrice() {
		return originPrice;
	}
	public void setOriginPrice(Long originPrice) {
		this.originPrice = originPrice;
	}
	public Long getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Long productPrice) {
		this.productPrice = productPrice;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public OrderContent getModal() {
		return modal;
	}
	public void setModal(OrderContent modal) {
		this.modal = modal;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}
	public String getProdTypeNo() {
		return prodTypeNo;
	}
	public void setProdTypeNo(String prodTypeNo) {
		this.prodTypeNo = prodTypeNo;
	}
	public String getFetNo() {
		return fetNo;
	}
	public void setFetNo(String fetNo) {
		this.fetNo = fetNo;
	}

}
