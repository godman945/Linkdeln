package com.fet.estore.core.dao.impl;

import com.fet.estore.core.dao.ILogOtpDAO;
import com.fet.estore.core.dao.base.impl.AbstractBaseDAO;
import com.fet.estore.core.model.LogOtp;
import org.springframework.stereotype.Repository;

@Repository
public class LogOtpDAOImpl extends AbstractBaseDAO<LogOtp, String> implements ILogOtpDAO {
	
}
