package com.fet.estore.core.bean.bo;

/**
 * @description 紀錄3D驗證結果
 * @author Dennis.Chen
 * @Date 2020-09-18
 */
public class Valid3dSecureBO {

    boolean isPass;
    String errorMsg;

    public boolean isPass() {
        return isPass;
    }

    public void setIsPass(boolean isPass) {
        this.isPass = isPass;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
}
