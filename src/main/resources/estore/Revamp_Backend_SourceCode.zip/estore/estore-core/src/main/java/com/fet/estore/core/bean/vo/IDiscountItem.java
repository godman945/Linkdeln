package com.fet.estore.core.bean.vo;

public interface IDiscountItem {

    /** 原始贈品ID */
    Long getAaiId();
    /** 原始設定CODE */
    String getCode();
    /** 折扣料號 */
    String getFetNo();
    /** 折扣所屬活動 */
    Long getActivityId();
    /** 折扣名稱 */
    String getName();
    /** 折扣金額 */
    Long getAmount();
    /** COUPON ID */
    Long getCouponId();
    /** 帳單折抵ID */
    Long getOfferId();
    /** 成本中心ID */
    Long getCostCenterId();
    /** 顯示於前台折扣名稱 */
    String getDiscountName();

    Double getDiscountRatio();

    Long getActualDiscountAmt();

    String getDisplayGroup();

    default Long getAccActId() {
        return null;
    }

}
