package com.fet.estore.core.bean.vo.frontend;

public class CohResultVo {
	private String cohOrderId;
	private String cohTx;
	
	public String getCohOrderId() {
		return cohOrderId;
	}
	public String getCohTx() {
		return cohTx;
	}
	public void setCohOrderId(String cohOrderId) {
		this.cohOrderId = cohOrderId;
	}
	public void setCohTx(String cohTx) {
		this.cohTx = cohTx;
	}
}
